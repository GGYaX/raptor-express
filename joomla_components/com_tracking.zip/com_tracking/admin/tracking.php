<?php
  echo "Tracking back-end : nothing to do here for instance...";
?>