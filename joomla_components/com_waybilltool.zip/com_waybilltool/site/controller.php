<?php
/**
 * @package Joomla.Administrator
 * @subpackage com_waybilltool
 *
 * @copyright Copyright (C) 2014
 * @license GNU??? BSD???
 */
defined('_JEXEC') or die;
jimport('joomla.application.component.view');
/**
 * @since 1.0.0
 */
class WaybillToolController extends JControllerLegacy {

  // function choosesolution($cachable = false, $urlparams = false) {
  //   // set default view if not set
  //   $input = JFactory::getApplication()->input;
  //   $input->set('view', $input->getCmd('view', 'SolutionChooser'));
  //
  //   // call parent behavior
  //   parent::display($cachable);
  // }

}
