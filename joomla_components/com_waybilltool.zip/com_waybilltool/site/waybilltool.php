<?php

  defined('_JEXEC') or die;

  require_once JPATH_COMPONENT.DS.'helpers'.DS.'waybillparamscheckerhelper.php';
  require_once JPATH_COMPONENT.DS.'helpers'.DS.'solutionchooserhelper.php';

  $controller = JControllerLegacy::getInstance('WaybillTool');

  $input = JFactory::getApplication()->input;

  $controller->execute($input->getCmd('choosesolution'));
  $controller->redirect();
