<?php
/**
* @package Joomla.Administrator
* @subpackage com_waybilltool
*
* @copyright Copyright (C) 2014
* @license GNU??? BSD???
*/
defined('_JEXEC') or die;
?>

<?php

JHTML::_('behavior.formvalidation');
echo $this->form;

?>
