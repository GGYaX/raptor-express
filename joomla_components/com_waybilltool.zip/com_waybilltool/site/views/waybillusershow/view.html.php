<?php
/**
* @package Joomla.Administrator
* @subpackage com_waybilltool
*
* @copyright Copyright (C) 2014
* @license GNU??? BSD???
*/

defined('_JEXEC') or die;
jimport('joomla.application.component.view');

/**
* HTML View class for the Waybill Tool Component
*
* @since 0.0.1
*/
class WaybillToolViewWaybillUsershow extends JViewLegacy
{
	/**
         * @param   string  $tpl  The name of the template file to parse;
         * automatically searches through the template paths.
         * @return  void
         */
	public function display($tpl = null) {
		$user = JFactory::getUser();
		if (($user->guest)
		|| !($user->id > 0)){
			JFactory::getApplication()->redirect(JURI::base()
			.'index.php?option=com_users&view=login', $error, 'error' );
		}
		$solution = SolutionChooserHelper::chosenSolution();

		$waybillid = JFactory::getApplication()->input->get('waybillid', null);

		//1
		if($solution === null){
			$this->userlist = '<h1>选择快递公司</h1>';
			$this->userlist = $this->userlist . SolutionChooserHelper::getSolutionChooser();
		}
		//3
		else if($waybillid !== null) {
			$this->userlist = '<h1>订单：'.$waybillid.'</h1>';
			$this->userlist = $this->userlist . '（+ViewUserShowDetails+挂载PDF生成模块）<br><br>';
			$this->userlist = $this->userlist
			.'<div class="container">'
			.'<table style="width: 100%;" class="tg">'
			.'<tbody>'
			.'<tr>'
			.'<th class="tg-wvvv">寄件人姓名</th>'
			.'<td class="tg-huh2"></th>'
			.'</tr>'
			.'<tr>'
			.'<th class="tg-wvvv">寄件人地址</th>'
			.'<td class="tg-huh2"></th>'
			.'</tr>'
			.'<tr>'
			.'<th class="tg-wvvv">寄件人电话</th>'
			.'<td class="tg-huh2">00000000</th>'
			.'</tr>'
			.'<tr>'
			.'<th class="tg-wvvv">收件人姓名</th>'
			.'<td class="tg-huh2"></th>'
			.'</tr>'
			.'<tr>'
			.'<th class="tg-wvvv">收件人地址</th>'
			.'<td class="tg-huh2">RUE XXX</th>'
			.'</tr>'
			.'<tr>'
			.'<th class="tg-wvvv">收件人电话</th>'
			.'<td class="tg-huh2">00000000</th>'
			.'</tr>'
			.'<tr>'
			.'<th class="tg-wvvv">保价金额</th>'
			.'<td class="tg-huh2">200</th>'
			.'</tr>'
			.'<tr>'
			.'<th class="tg-wvvv">快递产品类别</th>'
			.'<td class="tg-huh2">普通包裹</th>'
			.'</tr>'
			.'<tr>'
			.'<th class="tg-wvvv">包裹内容</th>'
			.'<td class="tg-huh2">TESTORDERID</th>'
			.'</tr>'
			.'<tr>'
			.'<th class="tg-wvvv">长x宽x高</th>'
			.'<td class="tg-huh2">30*50*20</th>'
			.'</tr>'
			.'<tr>'
			.'<th class="tg-wvvv">重量</th>'
			.'<td class="tg-huh2">20</th>'
			.'</tr>'
			.'<tr>'
			.'<th class="tg-wvvv">备注</th>'
			.'<td class="tg-huh2">无</th>'
			.'</tr>'
			.'<tr>'
			.'<th class="tg-wvvv">价格</th>'
			.'<td class="tg-huh2">60</th>'
			.'</tr>'
			.'<tr>'
			.'<th class="tg-wvvv">身份证正面</th>'
			.'<td class="tg-huh2">USERNAME-2014123093048.jpg</th>'
			.'</tr>'
			.'<tr>'
			.'<th class="tg-wvvv">身份证正面</th>'
			.'<td class="tg-huh2">USERNAME-2014123093049.jpg</th>'
			.'</tr>'
			.'</tbody>'
			.'</table>'
			.'</div>';
		}
		//2
		else {
			$solutionName;
			switch ($solution) {
				case "LAP":
					$solutionName = "La Poste ";
					break;
				case "EMS":
					$solutionName = "EMS ";
					break;
				default:
					JError::raiseError(500, $solution."未知的快递公司", $solution);
					break;
			}
			$this->userlist = '<h1>'.$solutionName.'订单</h1>';
			$this->userlist = $this->userlist . $this->get('UserOrders');

			$this->userlist = $this->userlist
			.'<div class="container">'
			.'<table style="width: 100%;" class="tg">'
			.'<tbody>'
			.'<tr>'
			.'<th class="tg-wvvv">订单号</th>'
			.'<th class="tg-huh2">下单时间</th>'
			.'<th class="tg-huh2">发件人</th>'
			.'<th class="tg-huh2">收件人</th>'
			.'<th class="tg-huh2">付款状态</th>'
			.'<th class="tg-huh2">查看详细信息</th>'
			.'</tr>'
			.'<tr>'
			.'<td class="tg-xaq9">TESTORDER1</td>'
			.'<td class="tg-s6z2">2015-01-05-10:34:29</td>'
			.'<td class="tg-s6z2">Arthur</td>'
			.'<td class="tg-s6z2">王二狗</td>'
			.'<td class="tg-s6z2">已付款</td>'
			.'<td class="tg-s6z2"><a href="'.JRoute::_(JURI::current()).'?exp-solution='.$solution.'&waybillid=TESTORDER1">详细信息</a></td>'
			.'</tr>'
			.'<tr>'
			.'<td class="tg-xaq9">TESTORDER2</td>'
			.'<td class="tg-s6z2">2015-01-09-22:32:12</td>'
			.'<td class="tg-s6z2">张三</td>'
			.'<td class="tg-s6z2">ヒドゥン</td>'
			.'<td class="tg-s6z2">未付款</td>'
			.'<td class="tg-s6z2"><a href="'.JRoute::_(JURI::current()).'?exp-solution='.$solution.'&waybillid=TESTORDER2">详细信息</a></td>'
			.'</tr>'
			.'</tbody>'
			.'</table>'
			.'</div>';
		}

		if (count($errors = $this->get('Errors'))) {
			JLog::add(implode('<br />', $errors), JLog::WARNING, 'jerror');
			return false;
		}

		parent::display($tpl);
	}
}
