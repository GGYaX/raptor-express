<?php
defined('_JEXEC') or die('404');
jimport('joomla.application.component.modelitem');
class WaybillToolModelWaybill extends JModelItem {
    /**
     * @var string msg
     */
    protected $msg;
    /**
     长宽高重状态付款方式付款状态
     * Here we can load anything from DBO...
     * @return string The message to be displayed to the user
     */
    public function getInfo() {
        if (!isset($this->msg)) {
            $this->msg = 'Message from front admin model. Add access to DB here.';
        }
        $db = JFactory::getDBO();
        $query = $db->getQuery(true);
        $query->select('*');
        $query->from('t_packages p');
        $query->join('NATURAL', 't_orders o');
        $query->order('package_id ASC');
        $db->setQuery((string)$query);
        $messages = $db->loadObjectList();
        var_dump($messages);
        return $this->msg;
    }

    public function getUserOrders() {
      echo "读取用户订单";
    }

    public function insertNewOrder($data) {
      echo "写入数据库";
    }
}
