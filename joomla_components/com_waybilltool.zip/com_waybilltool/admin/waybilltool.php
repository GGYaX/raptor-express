<?php
  echo "Waybill Tool back-end : nothing to do here for instance...";
?>