<?php 
// No direct access
defined('_JEXEC') or die; 
require_once( dirname(__FILE__) . '/../jHelper.php' );

$waybill = JRequest::getVar('waybill', '0');

// Check variable exists
if(strlen($waybill)!==1){
  modPDFGenHelper::getPDF($waybill);
}
?>
<button name="Generate" class="btn btn-primary" onclick="window.location.href=window.location.href+'?waybill=RE12345678'">生成PDF</button>
<br>
