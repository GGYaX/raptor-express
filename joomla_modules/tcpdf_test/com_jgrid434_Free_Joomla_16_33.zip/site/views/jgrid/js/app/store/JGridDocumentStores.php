<?php
/*
 *  JGridDocumentStores.php in joomla/Components/com_jgrid/views/jgrid/js/app/store
 *
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */ 
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
for($i=0;$i<$gridCount;$i++) {    	 
	// Define Grid Store
	echo 'Ext.define("JGrid.store.JGridDocumentStore'.$i.'", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridDocumentModel'.$i.'",   
	model: "JGrid.model.JGridDocumentModel'.$i.'",
	alias : "widget.JGridDocumentStore'.$i.'",
	storeId:"JGridDocumentStore'.$i.'",
	id:"JGridDocumentStore'.$i.'",
	autoLoad: true,	
	proxy: {
   		type: "ajax",
   	 	url: "'.JURI::base().'index.php?option=com_jgrid&task=read_combo&controller=jgrid_documents&format=ajax&grid_id='.$griditems[$i]->id.'",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsDocumentModel['.$i.']),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});';
//JGrid.documentStore['.$i.'].load();
//';
	echo 'JGrid.documentStore['.$i.'] = Ext.create("JGrid.store.JGridDocumentStore'.$i.'"); ';
	//echo 'JGrid.documentStore['.$i.'] = Ext.getStore("JGridDocumentStore'.$i.'"); ';			
}

echo 'Ext.define("JGrid.store.JGridChartStore", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridDocumentModel0",   
	model: "JGrid.model.JGridDocumentModel0",
	alias : "widget.JGridChartStore",
	storeId:"JGridChartStore0",
	id:"JGridChartStore0",
	autoLoad: false,
	listeners: {
		load:function( storeObj, records, successful, eOpts){
				
				for(var i=0;i<records.length;i++){
					if(Ext.isEmpty(records[i].data.document_type)){
						storeObj.remove(records[i]);
					}
				}
		}
		

	},
	proxy: {
   		type: "ajax",
   	 	url: "'.JURI::base().'index.php?option=com_jgrid&task=read_combo&controller=jgrid_documents&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	}),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});';

echo 'JGrid.chartStore = Ext.create("JGrid.store.JGridChartStore"); ';

?>



