<?php
 /*
 *  JGridGrids.php  in joomla/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
require_once(JPATH_BASE . '/administrator/components/com_jgrid/os/jgrid/functions.php' );
if((JRequest::getVar('application_type','','','STRING')=='MODULE'))
{
	jimport( 'joomla.application.module.helper' );
	$app = JFactory::getApplication();
	$module = JModuleHelper::getModule(JRequest::getVar('jgrid_application_name'));
	$params = new JRegistry();
	if(class_exists('JParameter'))
	{
		$params = new JParameter( $module->params ); 
	}
	else 
	{
	   $params->loadString($module->params);
	}	
}
else 
{
	$params = JComponentHelper::getParams('com_jgrid');
}
//JError::raiseError(1005,$params->get ('jgrid_width'));
//return;

for($j=0;$j<$gridCount;$j++) {
	
			  if(($griditems[$j]->enableGroupBy == 1) || ($griditems[$j]->enableGroupBy == 2))
			  {
	              echo 'var groupingFeature'.$j.' = Ext.create("Ext.grid.feature.Grouping",{';
                  	//groupHeaderTpl: "Cuisine: {name} ({rows.length} Item{[values.rows.length > 1 ? "s" : ""]})",
        
		          if($griditems[$j]->showGroupName  == true)
		          {
			        echo 'hideGroupedHeader: false,';
		          }
		          else
		          {
			        echo 'hideGroupedHeader: true,';
		          }
		          if($griditems[$j]->hideGroupedColumn  == true)
		          {
			         echo 'hideGroupedColumn: true,';
		          }
		          else
		          {
			         echo 'hideGroupedColumn: false,';
		          }
			  	  if($griditems[$j]->startCollapsed  == true)
		          {
			         echo ' startCollapsed : true,';
		          }
		          else
		          {
			         echo ' startCollapsed : false,';
		          }                                 
                  echo'markDirty: false
                 });';
			  }   	
	
	
	

echo 'Ext.define("JGrid.view.JGridGrid'.$j.'", {
	
	extend : "Ext.grid.Panel",
	alias : "widget.JGridGrid'.$j.'",
	requires : [ "JGrid.view.JGridToolbar'.$j.'", "JGrid.store.JGridStore'.$j.'"  ],
    id: "' . $griditems[$j]->grid_reference_id  . '",';
	if($griditems[$j]->enableRowEditor  == true)
	{    
    	echo 'plugins: [
				JGrid.editor['.$j.']
		],';
	}
	else {
		echo 'selType: "cellmodel",
   	 	plugins: [
        	Ext.create("Ext.grid.plugin.CellEditing", {
            	clicksToEdit: 2
        	})
    	],';
	}
//    echo 'features: [{
// 		ftype: "filters"},
// 		{ftype: "grouping"
// 	}],';
  	echo 'features: [{
  		ftype: "filters"}';
    if($griditems[$j]->enableGroupBySummary==1){
      echo ',{ftype: "groupingsummary"}';
    }
    if($griditems[$j]->enableGroupBySummary==2){
     echo ',{ftype: "summary"}';
     }
     elseif($griditems[$j]->enableGroupBySummary==0 || $griditems[$j]->enableGroupBySummary==""){
     	if(($griditems[$j]->enableGroupBy == 1) || ($griditems[$j]->enableGroupBy == 2)) {
     		echo ',groupingFeature'.$j; 
     	}
     }
    echo '],';
    
    
    
	echo'enableDragDrop: true,';
	if($griditems[$j]->enableColumnMove == true) {
 		echo 'enableColumnMove: true,';
	} else {
		echo 'enableColumnMove: false,';
	}
	echo' store: JGrid.store['.$j.'],
 	columns: JGrid.columns['.$j.'],
 	';
 	//selModel: Ext.create("Ext.selection.RowModel", { singleSelect: true, selectFirstRow: true }),
 	echo 'selModel: Ext.create("Ext.selection.RowModel", { mode: "MULTI"}),    	
	tbar: {xtype: "JGridToolbar'.$j.'"},';
	if($griditems[$j]->cls)
	{
		echo 'cls: "'.$griditems[$j]->cls.'",';
	}
  	if($griditems[$j]->ctCls)
	{
		echo 'ctCls: "'.$griditems[$j]->ctCls.'",';
	}		    
	if($griditems[$j]->frame  == true)
 	{
    	echo 'frame: true,';
  	}
  	else 
   	{
    	echo 'frame: false,';
 	}
 	if($griditems[$j]->stripe_rows  == true)
 	{
    	echo 'stripeRows: true,';
   	}                                
   	else 
  	{
 		echo 'stripeRows: false,';
  	} 
 	if($griditems[$j]->enableColumnResize  == true)
   	{
    	echo 'enableColumnResize: true,';
  	}                               
   	else 
   	{
   		echo 'enableColumnResize: false,';
   	}
 	if($griditems[$j]->columnLines  == true)
  	{
   		echo 'columnLines: true,';
  	}                               
  	else 
 	{
   		echo 'columnLines: false,';
  	}
  	echo 'beforeRender: function() {
      	JGrid.grids[' . $j.'] = Ext.ComponentMgr.get("' . $griditems[$j]->grid_reference_id  . '");
    },';	
	echo 'onRender: function() {';
		// define common windows
        if($j==0)
        {       	
      		// assign application values
      		echo 'JGrid.application_name = "' .JRequest::getVar('jgrid_application_name'). '";';
   
      		// find application id
			$query = 'SELECT id
		               FROM #__jgrid_applications a
		               WHERE a.grid_application_name = "' . JRequest::getVar('jgrid_application_name').'"';
        	$db->setQuery($query);
			$jgrid_application_id = $db->loadResult();
			echo 'JGrid.application_id =  '.$jgrid_application_id.';';
      		 
      		
      		//create image view window
      		echo 'JGrid.image_win = Ext.create("JGrid.view.JGridImageWin");';
      		     		
      		// Set path to grid printer
      		echo 'if(!Ext.baseCSSPrefix) {
      			Ext.baseCSSPrefix = "x-";
      		}';
      		echo 'Ext.create("Ext.ux.grid.Printer");';            
     		echo 'Ext.ux.grid.Printer.stylesheetPath = "'. JURI::base() .  'components/com_jgrid/views/jgrid/js/app/ux/grid/gridPrinterCss/print.css";';

      		// Create Thumbnail window  
      		echo 'JGrid.thumbnail_win = Ext.create("JGrid.view.JGridThumbnailWin");
      		      JGrid.thumbnail_loader = Ext.getCmp("JGridThumbnailFm");';
      		
			// load initital store and grid
			echo 'JGrid.store[0].load(';
           if($griditems[$j]->enable_paging==true) { 	    			
				echo '{   params: {
					        // specify params for the first page load if using paging
					        start: 0,
					        limit: ' . $griditems[$j]->paging_records . '
    					}
        		}';
           }	
    		echo ');';
        }
        	    // set keys functions
//	    echo 'JGrid.grids[' . $j.'].getEl().addKeyMap({
//		    eventName: "keyup",
//		    binding: [{
//		        key: 46,
//		        fn: function () {
//	                if(access_level_array[0]>"3"&&edit_mode==false)
//	    			{
//	                	// jgrid_remove_row("'.$griditems[$j]->id.'", "'. $griditems[$j]->grid_reference_id  . '");
//	                }
//	            }
//		    },{
//		        key:   "cC",
//		        ctrl: true,
//		        fn: function () {
//                	JGrid.copy['.$j.'] = true;                    
//                }
//		    }]
//		});';
        
        
        echo ' JGrid.crossGridIdRef["'.$griditems[$j]->grid_reference_id.'"]= ' . $j.';
  		JGrid.crossReturnButtonIdRef[' . $j.']= "Grid_return'.$j.'";';		        
//  		Ext.ComponentMgr.get("' . $griditems[$j]->grid_reference_id  . '").on("columnresize", function(columnIndex,newSize){
//   				Ext.ComponentMgr.get("' . $griditems[$j]->grid_reference_id  . '").syncSize();
//  		});
		echo 'Ext.grid.GridPanel.prototype.onRender.apply(this, arguments);
        this.addEvents("beforetooltipshow");
        this.tooltip = new Ext.ToolTip({
	 		renderTo: Ext.getBody(),
		//	target: this.view.mainBody,
			listeners: {
	       		beforeshow: function(qt) {	        		   
	        		var v = this.getView();
			     	var rowIndex = v.findRowIndex(qt.baseTarget);
			       	var columnIndex = v.findCellIndex(qt.baseTarget);
			    	var record = this.getStore().getAt(rowIndex);  // Get the Record  
                  	if(columnIndex==null || columnIndex == 0 || record ==null)
                  	{
		     		   	return false;
			       	}
                  	var fieldName = this.panel.columns[columnIndex].dataIndex; // Get field name                       
                  	var data = record.get(fieldName);                        
                   	if(data=="" || fieldName.substr(0,1)!="P" || JGrid.editMode['.$j.']==true || data==null)
                  	{
                  		return false;
                  	}  
                  	var data_array=data.split("~");                
                  	var tooltip = data_array[1];                        
			       	this.fireEvent("beforetooltipshow", this, rowIndex, columnIndex, tooltip);
	        	},
	        	scope: this
	    	}
	   	});
  	},';
               echo' listeners: {
                  //RMS tooltip for images
			           render: function(g) {
				         g.on("beforetooltipshow", function(grid, rowIndex, columnIndex, data) {
					  //grid.tooltip.Ext.getBody().update("Tooltip for (" + row + ", " + col + ")");
				       grid.tooltip.Ext.getBody().update(data);
				    });
			      },
                  celldblclick: function(grid, td,  columnIndex, record, tr, rowIndex, e, eOpts) {
                  // var record = grid.getStore().getAt(rowIndex);  // Get the Record
                   var fieldName = grid.panel.columns[columnIndex].dataIndex; // Get field name
                   var data = String(record.get(fieldName));
                   JGrid.thumbnailImage["value"] = data;
                   JGrid.thumbnailImage["grid_id"]= "' . $griditems[$j]->grid_reference_id  . '".substr(5);
                   JGrid.thumbnailImage["column_id"] = fieldName.substr(1);
                   JGrid.thumbnailImage["row_id"] = record.get("id");
                   JGrid.thumbnailImage["document_id"] = JGrid.documentIdStack['.$j.'] [JGrid.documentIdStack['.$j.'].length - 1];
                   JGrid.thumbnailImage["grid_index"] = '.$j.';
                   JGrid.thumbnailImage["column_index"] = columnIndex;
                   JGrid.thumbnailImage["record"] = record;
                   JGrid.thumbnailImage["fieldName"] = fieldName;
                   JGrid.thumbnailImage["grid_reference_id"] = "' . $griditems[$j]->grid_reference_id  . '"; 
                   JGrid.thumbnailImage["grid_reference_id_document"] = "'. $griditems[$j]->grid_reference_id  .'_document";                
                   // decode filename  imagepath, tooltip, hyper_url, hyper_grid_sheet
				   if(fieldName.substr(0,1)=="E")
				   {
			   			var email_subject = grid.panel.columns[columnIndex].field.email_subject; // Get email_subject
					   
					   // replacing  "emailsubject @!ROWID @!T23 @!T345  with rowid and column data values
	                   JGrid.thumbnailImage["email_subject"] = insertColumnData(email_subject, record);
	               }
	               if(fieldName.substr(0,1)=="P")
	               {
	               	   var data_array=data.split("~");
	                   JGrid.thumbnailImage["image_path"] =  data_array[0];
	                   JGrid.thumbnailImage["tooltip"] =  data_array[1];

                  		//JGrid.thumbnailImage["hyper_url"] =  data_array[2];
                  	 	if(data_array[2]) {
	                  			JGrid.thumbnailImage["hyper_url"] = insertColumnData(data_array[2], record);
	                  	}
	                   JGrid.thumbnailImage["hyper_grid_sheet"] =  data_array[3];
	                   JGrid.thumbnailImage["extension"] =  data_array[4];
		               JGrid.thumbnailImage["email"] =  data_array[5];
					   if(JGrid.editMode['.$j.']==false) {
			                 if(!data_array[6]) { // if subject blank insert default subject
						       var defaultEmailSubject = grid.panel.columns[columnIndex].field.email_subject; // Get email_subject
						       if(defaultEmailSubject) {
						   	  	data_array[6] = defaultEmailSubject;
						   	  } 
						    }				   
						   	// replace wildcards with column data values  any grid column data   eg @T83  records all numbers after @T
		                  	// any grid column data @!ROWID  eg @!T83  records all numbers after @!T
	                  		if(data_array[6]) {
	                  			JGrid.thumbnailImage["email_subject"] = insertColumnData(data_array[6], record);
	                  		}
                  		}	  
					
					   JGrid.thumbnailImage["primary_key_value"] =  String(record.get("' . $griditems[$j]->primary_key_column . '"));
                    }
				   
                   if(JGrid.editMode['.$j.']==false)
                   {                                        
                      // Show Image
                      if(fieldName.substr(0,1)=="P" && (data.substr(0,5)=="/grid"||data.substr(0,5)=="/demo")||JGrid.thumbnailImage["extension"]=="swf")
                      { ';
                                                                                                
//                         if(JGrid.initialize==false)
//                         {
//                           	JGrid.initialize=true;
//                           	if(!JGrid.image_win)
//				    		{
//				    			JGrid.image_win = Ext.create("JGrid.view.JGridImageWin");
//				    		}                 
//                           JGrid.image_win.show();
//                         }                     
                         // set filename
                         echo 'if(data.substr(0,5)=="/demo") //path to demo data
                         {
                           var img_path = "'.JURI::base().'media/com_jgrid/image.php?demo=1&height="+JGrid.thumbnailImage["height"]+"&width="+JGrid.thumbnailImage["width"]+"&name="+JGrid.thumbnailImage["grid_id"]+"_"+JGrid.thumbnailImage["document_id"]+"_"+JGrid.thumbnailImage["grid_id"]+"_"+JGrid.thumbnailImage["document_id"]+"_"+JGrid.thumbnailImage["column_id"]+"_"+JGrid.thumbnailImage["row_id"]+"_"+JGrid.thumbnailImage["extension"];	                        
                           var swf_path = "'.JURI::base().'media/com_jgrid/demo_images/grid_"+JGrid.thumbnailImage["grid_id"]+"/document_"+JGrid.thumbnailImage["document_id"]+"/"+JGrid.thumbnailImage["grid_id"]+"_"+JGrid.thumbnailImage["document_id"]+"_"+JGrid.thumbnailImage["column_id"]+"_"+JGrid.thumbnailImage["row_id"]+"_orig."+JGrid.thumbnailImage["extension"];		
					     }
                         else // path to user images
                         {
                           var img_path = "'.JURI::base().'media/com_jgrid/image.php?demo=0&height="+JGrid.thumbnailImage["height"]+"&width="+JGrid.thumbnailImage["width"]+"&name="+JGrid.thumbnailImage["grid_id"]+"_"+JGrid.thumbnailImage["document_id"]+"_"+JGrid.thumbnailImage["grid_id"]+"_"+JGrid.thumbnailImage["document_id"]+"_"+JGrid.thumbnailImage["column_id"]+"_"+JGrid.thumbnailImage["row_id"]+"_"+JGrid.thumbnailImage["extension"];	                        
                           var swf_path = "'.JURI::base().'media/com_jgrid/grid_"+JGrid.thumbnailImage["grid_id"]+"/document_"+JGrid.thumbnailImage["document_id"]+"/"+JGrid.thumbnailImage["grid_id"]+"_"+JGrid.thumbnailImage["document_id"]+"_"+JGrid.thumbnailImage["column_id"]+"_"+JGrid.thumbnailImage["row_id"]+"_orig."+JGrid.thumbnailImage["extension"];	
	                         
						}
                     	
                     	 //Ext.getCmp("image_win_id").load("localhost/joomla256a");
                     	 //RMS <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
                    	if(JGrid.thumbnailImage["extension"]=="swf")
                       	{
                       		if(!Ext.isEmpty(JGrid.flash_win))
                       		{
   								Ext.destroy(JGrid.flash_win);
							}
							JGrid.flash_url = swf_path;
					    	JGrid.flash_win = create_flash_window();
                       		fwin = Ext.getCmp("flash_win_id");					    	                 
	                      	JGrid.flash_win.show();';
		                	 if(JRequest::getVar('allow_image_download')=="1")
	                         {
	                            echo 'if((access_level_array'.$j.'[0]>"2"||access_level_array'.$j.'[columnIndex].substr(0,1)=="C")) || access_level_array'.$j.'[0]==-1)
	                                  {          
	                                    Ext.ComponentMgr.get("download_button").show();
	                                  }                                               
	                                  else 
	                                  {
	                       	            Ext.ComponentMgr.get("download_button").hide();
	                                  }';
	                         }                                            
	                         echo 'if((!JGrid.thumbnailImage["hyper_url"])||JGrid.thumbnailImage["hyper_url"]=="Enter a URL...")
	                         {
	                           Ext.ComponentMgr.get("go_to_url2").hide();
	                         }
	                         else
	                         {
	                           Ext.ComponentMgr.get("go_to_url2").show();
	                         }';
	                         echo 'if((!JGrid.thumbnailImage["email"])||JGrid.thumbnailImage["email"]=="Enter an EMAIL...")
	                         {
	                           Ext.ComponentMgr.get("go_to_email2").hide();
	                         }
	                         else
	                         {
	                           Ext.ComponentMgr.get("go_to_email2").show();
	                         }';	                                                 	                                                
	                         echo 'if(!JGrid.thumbnailImage["hyper_grid_sheet"]||JGrid.thumbnailImage["hyper_grid_sheet"]=="null"||"Go to Sheet")
	                         {
	                           Ext.ComponentMgr.get("go_to_sheet2").hide();
	                         }
	                         else
	                         {
	                           Ext.ComponentMgr.get("go_to_sheet2").show();
	                         }'; 
                      	echo '}
                      	else
                      	{ 
	                       	if(!JGrid.image_win)
					    	{
					    			JGrid.image_win = Ext.create("JGrid.view.JGridImageWin");
					    	} 
                      		Ext.getCmp("image_win_id").load(img_path);';
		                    if(JRequest::getVar('allow_image_download')=="1")
	                         {
	                            echo 'if((access_level_array'.$j.'[0]>"2"||access_level_array'.$j.'[columnIndex].substr(0,1)=="C")) || access_level_array'.$j.'[0]==-1)
	                                  {          
	                                    Ext.ComponentMgr.get("download_button").show();
	                                  }                                               
	                                  else 
	                                  {
	                       	            Ext.ComponentMgr.get("download_button").hide();
	                                  }';
	                         }                                            
	                         echo 'if((!JGrid.thumbnailImage["hyper_url"])||JGrid.thumbnailImage["hyper_url"]=="Enter a URL...")
	                         {
	                           Ext.ComponentMgr.get("go_to_url").hide();
	                         }
	                         else
	                         {
	                           Ext.ComponentMgr.get("go_to_url").show();
	                         }';
	                         echo 'if((!JGrid.thumbnailImage["email"])||JGrid.thumbnailImage["email"]=="Enter an EMAIL...")
	                         {
	                           Ext.ComponentMgr.get("go_to_email").hide();
	                         }
	                         else
	                         {
	                           Ext.ComponentMgr.get("go_to_email").show();
	                         }';	                                                
	                         echo 'if(!JGrid.thumbnailImage["hyper_grid_sheet"]||JGrid.thumbnailImage["hyper_grid_sheet"]=="null")
	                         {
	                           Ext.ComponentMgr.get("go_to_sheet").hide();
	                         }
	                         else
	                         {
	                           Ext.ComponentMgr.get("go_to_sheet").show();
	                         }
			
		                 		JGrid.image_win.show();
		                    }';

	                    
                        	echo 'return(false);
                      } 
                      // check for url type window and open
                    // RMS check with url else if(data!="" && (fieldName.substr(0,1)=="U"||grid.panel.columns.config[columnIndex].editor.vtype=="url"))
	              	  else if(data!="" && (fieldName.substr(0,1)=="U"))
	                  {		
	                  // Do replacements of wildcards in URL string
	                  		// replace wildcards with column data values  any grid column data   eg @!T83  records all numbers after @!T
	                  		// any grid column data @!ROWID  eg @!T83  records all numbers after @!T
	                  		data = insertColumnData(data, record);	               			
							var index = data.indexOf("^");
							var title = "image_window'.$j.'";
	                  		if(index != -1) {
	                  			data = data.substr(index+1);
	                  			title = data.substr(0, index);
	                  		}
	                        window.open(data, title);
	                  }
	                  else if(data!="" && (fieldName.substr(0,1)=="E") && JGrid.public_user == false)
	                  {
	                  		JGrid.thumbnailImage["email"] = data;
	                  		show_email_window();
	                  }
	                  else if(data!="" && fieldName.substr(0,1)=="S")
                      {
                      } 
                   }else
                   {
                       // Store Image
                       if(fieldName.substr(0,1)=="P" && access_level_array'.$j.'[0]>"2")
                       {
                           JGrid.thumbnail_win.setPagePosition(e.getPageX()-50,e.getPageY()+15);
                           //JGrid.thumbnail_win.setPosition(e.xy[0],e.xy[1]);
                           
                           // set to current value
                      	  //JGrid.thumbnail_win.items.items[0].items.items[0].setValue(data);
                      	  
                           // set image to blank to encourage new upload
                           Ext.ComponentMgr.get("photo").setValue("");
                           Ext.ComponentMgr.get("thumbtabs").setActiveTab(0);
                           if(JGrid.thumbnailImage["image_path"]!=""&&JGrid.thumbnailImage["extension"]=="swf")
                           {
	                            // Ext.ComponentMgr.get("photo").setValue("");
	                            //if image already loaded then show upload for optional custom thumbnail
	                            Ext.ComponentMgr.get("thumbtabs").child("#JGridOptThumbFm").tab.show();
                                                
                           }
                           else
                           {
                           		Ext.ComponentMgr.get("thumbtabs").child("#JGridOptThumbFm").tab.hide();
                           }
                           if(JGrid.thumbnailImage["tooltip"]!="")
                           {
                             Ext.ComponentMgr.get("imagetooltip").setValue(JGrid.thumbnailImage["tooltip"]);
                           }
                           if(JGrid.thumbnailImage["hyper_url"]!="")
                           {
                             Ext.ComponentMgr.get("image_url").setValue(JGrid.thumbnailImage["hyper_url"]);
                           }
                           if(JGrid.thumbnailImage["hyper_grid_sheet"]!="")
                           {
                             Ext.ComponentMgr.get("grid_sheet_title").setValue(JGrid.thumbnailImage["hyper_grid_sheet"]);
                           }
                           if(!JGrid.thumbnail_win)
				    	   {
				    			JGrid.thumbnail_win = Ext.create("JGrid.view.JGridHelp");
				    	   }
                           JGrid.thumbnail_win.show();
                           return(false);
                       } 
                   }                           
		        },                
                beforeedit: function (thisEditor,e) {
                	if(JGrid.editMode['.$j.']==false) return false;
                    var grid_columns = e.grid.columns;
                    var editable_line = e.record.get("editable_line");
                    if(editable_line!=true)
                    {
                      thisEditor.cancelEdit();
                      return(false);
                    }                  
                    // If sheet access level is view only as default look for columns and rows that are editable to  user                                                                       
                    if(access_level_array'.$j.'[0]<"3") 
                    {
                       // look for columns that are "cell edit"
                       for(var i=1;i<access_level_array'.$j.'.length;i++)
                       {
                         if((access_level_array'.$j.'[i].substr(0,1)=="C")&&(editable_line==true)) {
							// find column index
	                		for(j=1;j<grid_columns.length;j++)
	                		{	                                
		                			if(e.field.substr(1) != access_level_array'.$j.'[i].substr(2))
		                			{
		                				thisEditor.cancelEdit();
                      					return(false);
		                			}		        
		               		}
	                 	}
	                 	// grid_columns.setEditable(grid_columns.getIndexById(access_level_array'.$j.'[i].substr(1)),true);
                       }                                                                    
                     }
                     else if(e.field.substr(0,1)=="P")// update picture record
                     { 
                      JGrid.thumbnailImage["value"] = data;		 
                     }
                },
                afteredit: function (thisEditor,e) {
                    var grid_columns = Ext.ComponentMgr.get("' . $griditems[$j]->grid_reference_id  . '").columns;
	//	            if(access_level_array'.$j.'[0]<"3") 
	//	            {
	//                   	// first reset all columns active
	//	              	for(j=1;j<grid_columns.length;j++)
	//	                {
	//	                	grid_columns[i].setDisabled(false);	
	//	                }                                               
	//	            }
                }
              },
              // RMS check this and see how to setup   
                sm: new Ext.selection.RowModel({
                    singleSelect: false
             }),'; 	         
                  if($griditems[$j]->enable_paging==true) {      
                      echo 'bbar: new Ext.PagingToolbar({
				         pageSize: ' . $griditems[$j]->paging_records . ',
				         store: JGrid.store['.$j.'],
				         displayInfo: true,  
                         displayMsg: "Displaying results {0} - {1} of {2}",  
                         emptyMsg: "'. JText::_("NO_RESULTS_TO_DISPLAY").'"			 
			          }),';
			      }
                  echo 'viewConfig: {
                  	getRowClass: set_row_color,
                  	allowCopy: true,
                  	copy: true,
                  	plugins: {
						ddGroup: "gridDD'.$j.'",
						ptype: "gridviewdragdrop",
                  		enableDrag: true,
                  		enableDrop: true                 		
                  	},
                  	listeners: {
                  		beforedrop: function(objThis, overModel, dropPosition, dropFunction) {
                  			if(JGrid.editMode['.$j.']==false)	return false;
                  			if(JGrid.copy['.$j.'] == true)
                  			{
                  				overModel.copy = true;              
                  			}
                  			else 
                  			{
                  				overModel.copy = false; 
                  			}
                  		},
                  		drop: function(objThis, dragData, dropData, position) {
                  			if(JGrid.copy['.$j.'] == true)
                  			{
                  				var msg_type = "'.JText::_("INSERTING_ROWS").'";
                  				var url_type = "'.JURI::base().'index.php?option=com_jgrid&task=copy&format=ajax";                 
                  			}
                  			else
                  			{
                  				var msg_type = "'.JText::_("MOVING_ROW").'";
                  				var url_type = "'.JURI::base().'index.php?option=com_jgrid&task=move&format=ajax";
                  			}                 		                      
            				if(dragData.records.length===0) return;
             				if (dropData.index==0)
              				{
               					// ordering at index 0 which is above index 1 shown on drop index
                   				var new_above_record_id=-1;
                   				var new_record_below_id = dropData.data.id;
            				}
               				else if(dropData.index==this.all.elements.endIndex)
               				{
               					// At last record of view
               					var new_above_record_id = dropData.data.id;
               					var new_record_below_id=-1;
               				}
               				else
               				{ 
               					// Has records above and below
               					if(position == "before")
            					{
            						var new_above_record_id = -1;
               						var new_record_below_id = dropData.data.id;
            					}
            					else
            					{
            						var new_above_record_id = dropData.data.id;
               						var new_record_below_id = -1;
            					}

             				}
             				   
               				Ext.Ajax.request({
               					waitMsg: msg_type,                                  
           						url: url_type,
             					params: {
				                	grid_id:' . $griditems[$j]->id .', 
				                  	first_record_id: dragData.records[0].data.id,
				                   	last_record_id: dragData.records[dragData.records.length-1].data.id,
				                   	new_above_record_id: new_above_record_id,
				                   	new_record_below_id: new_record_below_id,                                                       
				                   	number_of_records: dragData.records.length,
				                   	oldIndex: dragData.records[0].index,
				                   	newIndex: dropData.index                                                      
				              	},
				               	method: "POST",
				              	failure: function (response, options) {
				               		Ext.Msg.alert("'.JText::_("COLUMN_WAS_NOT_MOVED_IN_DATABASE").'");                                                                                                            
				            	},
				            	success: function (response, options) {
				               	},
				              	scope: this
			           		}); 
			           		JGrid.copy['.$j.'] = false;             
			           		//JGrid.proxy['.$i.'].resumeEvents();
			           		Ext.ComponentMgr.get("' . $griditems[$j]->grid_reference_id  . '").getView().refresh();
				       	}
				    }
                  }'; 
			        
     				
                 		
?>

});

<?php

}// end of define JGrid.view.panel for loop

?>
