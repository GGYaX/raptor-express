<?php
 /*
 *  JGridEmailWin.php  in joomla/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>

Ext.define("JGrid.view.JGridEmailWin", {
	extend : "Ext.window.Window",
	alias : "widget.JGridEmailWin",
	id: "JGridEmailWin",
    title: "",
    border: false,
    closeAction: "hide",
    layout: 'fit',
    autoHeight: true,
<?php    
	if($params->get ('jgrid_renderTo'))
	{
		echo 'renderTo: "'.$params->get ('jgrid_renderTo').'", ';
	} 
	else echo 'renderTo: "jgrid_component",';
    if($params->get ('jgrid_email_win_width') > 0)
    {
    	echo 'width: '.$params->get ('jgrid_email_win_width').',';
    } 
    else echo 'width: 600,';
    if($params->get ('jgrid_email_win_height') > 0)
    {
    	echo 'height: '.$params->get ('jgrid_email_win_height').',';
    } 
    else echo 'height: 650,';         
    if($params->get ('jgrid_email_win_x') > 0)
    {
    	echo 'x: '.$params->get ('jgrid_email_win_x').',';
    }
    if($params->get ('jgrid_email_win_y') > 0)
    {
    	echo 'y: '.$params->get ('jgrid_email_win_y').',';
    }
?>  
   	items:  
   	[{
		xtype: 'form',
		id: "JGridEmailFm",
		fileUpload: true,
	 	buttonAlign: "center",
	  	width: 590,
	  	//fit: true,
	 	frame: true,
	 	style: "margin: 0 auto;",
	<?php 	
	 	echo 'title: "'.JText::_("SEND_EMAIL_FORM").'",';
	?>
		autoHeight: true,
	 	bodyStyle: "padding: 10px 10px 0 10px;",
		labelWidth: 60,
	  	defaults: {
	    	anchor: "95%",
	      	allowBlank: true,
	      	msgTarget: "side"
		},
		items: 
		[
			{   xtype: "textfield",
<?php    
			    echo 'fieldLabel: "'.JText::_("EMAIL_TO").'",
			    plugins: [ new Ext.ux.FieldHelp("'. JText::_("EMAIL_TO_TOOLTIP").'") ],';
?>			                    
		        name: "email_to_address",
		        width: 100,
		       // disabled: true,
		        vtype : 'email'
	   		},
			{   xtype: "textfield",
<?php    
			    echo 'fieldLabel: "'.JText::_("EMAIL_FROM").'",
			    plugins: [ new Ext.ux.FieldHelp("'. JText::_("EMAIL_FROM_TOOLTIP").'") ],';
?>			                    
		        name: "email_from_address",
		        width: 100,
		        vtype : 'email'
	   		},
			{   xtype: "textfield",
<?php    
			    echo 'fieldLabel: "'.JText::_("NAME_FROM").'",
			    plugins: [ new Ext.ux.FieldHelp("'. JText::_("EMAIL_FROM_TOOLTIP").'") ],';
?>			                    
		        name: "email_from_name",
		        width: 100
	   		},	   		
			{
				xtype: "textfield",
<?php    
			    echo 'fieldLabel: "'.JText::_("EMAIL_SUBJECT").'",
			    plugins: [ new Ext.ux.FieldHelp("'. JText::_("EMAIL_SUBJECT_TOOLTIP").'") ],';
?>	
				name : 'email_subject_name',
				width: 150,
				anchor : '95%'
			}, 
			{
<?php    
			    echo 'fieldLabel: "'.JText::_("EMAIL_MESSAGE").'",
			    plugins: [ new Ext.ux.FieldHelp("'. JText::_("EMAIL_MESSAGE_TOOLTIP").'") ],';
?>	
				cls : 'x-plain',
				height : 300,
				name : 'email_message',
				layout : 'fit',
				xtype : 'htmleditor',
				anchor : '95%'
			},
			{ 
				xtype: "fileuploadfield",
				id: "attachment_up_load",
		<?php		                   
		     	echo 'emptyText: "'.JText::_("SELECT_A_FILE_TO_UPLOAD").'",
		   		fieldLabel: "'.JText::_("ATTACHMENT").'",
		      	plugins: [ new Ext.ux.FieldHelp("'. JText::_("SELECT_A_FILE_TO_UPLOAD").'") ],';
		?>                  
		   		name: "data"
			}
		], 
		buttons: [{
		<?php               
		      		echo 'text: "'. JText::_("SEND").'",';
		?>
		     		handler: function(){  
		            	if(JGrid.email_form.getForm().isValid()){
			            	JGrid.email_form.getForm().submit({
		<?php	            	
		                 		echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=send_email&format=ajax",	     
			                    waitMsg: "'.JText::_("SENDING_YOUR_EMAIL").'",
			                    timeout : 5,	                    
			                    failure: function (email_form, options) {  
		                        	Ext.MessageBox.alert("'. JText::_("SENDING_EMAIL_FAILED").'",Ext.decode(options.response.responseText).message);';                              
		?>
		                        },
			                    success: function(email_form, options){
			                    	if (!response.responseText.success) {                                                      
<?php 
                            			echo 'Ext.MessageBox.alert("'. JText::_("SENDING_EMAIL_FAILED").'",Ext.decode(options.response.responseText).message);'; 
?>                                       
                         			} 
                         			else 
                         			{			                    	
		                      			JGrid.email_win .hide(); 
		                      		}
			                    }
			                });
		                }
		            }                        
		 	},
		  	{
		<?php  	
		     	echo 'text: "'. JText::_("RESET").'",';
		?>
		      	handler: function(){
		        	JGrid.email_form.getForm().reset();
		    	}
			}]
	}]  
});
     
