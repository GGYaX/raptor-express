<?php
 /*
 *  JGridChartWin.php  in joomla/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */ 
// no direct access
defined('_JEXEC') or die('Restricted access');

echo 'Ext.define("JGrid.view.JGridChartToolbar", {
	extend : "Ext.toolbar.Toolbar",
	id : "JGridChartToolbar",
	alias : "widget.JGridChartToolbar",
	modal:true,
	requires : [ "Ext.data.Model"],
	items:[
		 {
               xtype: "tbtext",
               style: "font-weight:bold;",
               text:  "'. JText::_("SELECT_CHART_SHEET").'"
        },
		{
			  xtype: "combo",
			  id:"chart_sheetCb",
			  displayField: "document_title",
              valueField: "id",
			  emptyText: "'. JText::_("SELECT_A_SHEET_TO_LOAD").'",
              store:JGrid.chartStore,
              listeners: {
				select: {
                        fn: function (combo, records, eOpts) {
							var gridIdVal=JGrid.view.Viewport.static_grid_id;
							var itemIndex = JGrid.view.Viewport.static_itemIndex;
							Ext.getCmp("chartBody").removeAll();
							JGrid.store[itemIndex].load({
                                    params: {
                                        new_document_id: combo.getValue(),
                                        last_document_id: combo.getValue()
                                    }
                                });
							
							JGrid.view.Viewport.static_new_document_id=combo.getValue();
							JGrid.view.Viewport.static_last_document_id=combo.getValue();
							createDataChart(gridIdVal,combo.getValue(),combo.getValue(),Ext.getCmp("chartBody"),itemIndex);
						}
				}

			  }
			  
		},
		"-",
		{
			xtype:"button",
			text:"Switch to Data Grid",
			id:"backBtn",
			handler:function(){
						Ext.getCmp("chartBody").removeAll();
						var previousTabId="dataTab"+(JGrid.view.Viewport.static_itemIndex);
						Ext.getCmp("jgrid_tabpanel").setActiveTab(previousTabId);
						Ext.getCmp("jgrid_tabpanel").child("#chartTab").tab.hide();												
			}
		}]});';
?>

Ext.define("JGrid.view.JGridChartWin", {
	alias : "widget.JGridChartWin",
	floating: true,	
<?php    
//	if($params->get ('jgrid_renderTo'))
//	{
//		echo 'renderTo: "'.$params->get ('jgrid_renderTo').'", ';
//	} 
//	else echo 'renderTo: "jgrid_component",';
    if($params->get ('jgrid_chart_win_width') > 0)
    {
    	echo 'width: '.$params->get ('jgrid_chart_win_width').',';
    }
    if($params->get ('jgrid_chart_win_height') > 0)
    {
    	echo 'height: '.$params->get ('jgrid_chart_win_height').',';
    } 
    else echo 'height: 600,';         
    if($params->get ('jgrid_chart_win_x') > 0)
    {
    	echo 'x: '.$params->get ('jgrid_chart_win_x').',';
    }
    if($params->get ('jgrid_chart_win_y') > 0)
    {
    	echo 'y: '.$params->get ('jgrid_chart_win_y').',';
    }
    else echo 'y: 10,'; 
?>  	
	draggable:true, 
	extend : "Ext.panel.Panel",
	tbar: {xtype: "JGridChartToolbar"},
	layout: "fit",	
	id:"chartBody"
});


     
