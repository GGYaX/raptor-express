<?php
 /*
 *  JGridToolbarSecurity.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');




echo 'Ext.define("JGrid.view.JGridToolbarSecurity", {
	extend : "Ext.toolbar.Toolbar",
	//requires : [ "JGrid.view.JGridHelpAccess"],	
	alias : "widget.JGridToolbarSecurity",
	id : "JGridToolbarSecurity",
	items : [{
                text: "'. JText::_("ADD_ACCESS_RULE").'",
                icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_add.png",
                cls: "x-btn-text-icon",
                tooltip: "'. JText::_("ADD_ACCESS_RULE_TOOLTIP").'",
               	handler: add_access_menu
            },
            {
                text: "'. JText::_("EDIT_ACCESS_RULE").'",
                icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_add.png",
                cls: "x-btn-text-icon",
                tooltip: "'. JText::_("EDIT_ACCESS_RULE_TOOLTIP").'",
               	handler: edit_access_menu
            },
            {
                text: "'. JText::_("DELETE_ACCESS_RULE").'",
                icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_delete.png",
                cls: "x-btn-text-icon",
                tooltip: "'. JText::_("DELETE_ACCESS_RULE_TOOLTIP").'",
                handler: function () {
                    JGrid.currenteditgrid = JGrid.JGridSecurity;
                    var sm = JGrid.currenteditgrid.getSelectionModel();
                    var sel = sm.getSelection();
                    if (sm.hasSelection()) {
                        Ext.Msg.show({
                            title: "'. JText::_("REMOVE_ACCESS_RULE").'",
                            buttons: Ext.MessageBox.YESNOCANCEL,
                            msg: "'. JText::_("REMOVE_RULE").'",
                            fn: function (btn) {
                                if (btn == "yes") {
                                    JGrid.store_access.remove(sel[0]);
                                }
                            }
                        })
                    }
                }
            },
             {    
                        id: "user_help_access",                   
                        text: "<b>'. JText::_("HELP").'</b>",
                        icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/help.png",
                        tooltip: "'. JText::_("INSTRUCTIONS_DESCRIBING_GRID_OPERATION_TOOLTIP").'",
                        handler: function () {                              
                        	if(!JGrid.HelpAccess)
    						{
    							JGrid.HelpAccess = Ext.create("JGrid.view.JGridHelpAccess");
    						}
    						JGrid.HelpAccess.show();  
                        }                            	
        }]
});';
?>

