<?php
/*
 *  JGridComboModels.php in joomla/Components/com_jgrid/views/jgrid/js/app/model
 *
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

// combo for selecting grid sheets
Ext.define("JGrid.model.JGridComboModel1", {
    extend: "Ext.data.Model",
    fields: [	{name: 'grid_sheet_id', type: 'string'}, 
             	{name: 'grid_sheet_title', type: 'string'},
             	{name: 'document_type', type: 'int'}
            ],
    alias : "widget.JGridComboModel1",
    id:"JGridComboModel1"
});
JGrid.dsComboModel[1] = Ext.create("JGrid.model.JGridComboModel1");

// combo for upload or download deliminator selection
Ext.define("JGrid.model.JGridCModel2", {
    extend: "Ext.data.Model",
    fields: [	{name: 'delimiter', type: 'string'}, 
             	{name: 'delimiter_description', type: 'string'}
            ],
    alias : "widget.JGridCModel2",
    id:"JGridCModel2"
});
JGrid.dsComboModel[2] = Ext.create("JGrid.model.JGridCModel2");

// combo boxs for popup image jump to sheet sheets
Ext.define("JGrid.model.JGridCModel3", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel3",
    id: "JGridCModel3",
    fields: [	{name: 'grid_sheet_id', type: 'string'}, 
             	{name: 'grid_sheet_title', type: 'string'}
            ]
});
JGrid.dsCModel[3] = Ext.create("JGrid.model.JGridCModel3");


// combo boxs for security access for type role or user	
Ext.define("JGrid.model.JGridCModel40", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel40",
    id: "JGridCModel40",
    fields: [{name: 'access_for', type: 'string'}, 
             {name: 'Type', type: 'string'}
           ]
});
JGrid.dsCModel[40] = Ext.create("JGrid.model.JGridCModel40");

// combo boxs for security role or user model
Ext.define("JGrid.model.JGridCModel41", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel41",
    id: "JGridCModel41",
    fields: [	{name: 'rslvl_id', type: 'string'}, 
             	{name: 'role_or_user', type: 'string'}
            ]
});
JGrid.dsCModel[41] = Ext.create("JGrid.model.JGridCModel41");

// combo boxs for user access type grid, sheet, or column type
Ext.define("JGrid.model.JGridCModel42", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel42",
    id: "JGridCModel42",
    fields: [{name: 'access_type', type: 'string'}, 
             {name: 'Type', type: 'string'}
           ]
});
JGrid.dsCModel[42] = Ext.create("JGrid.model.JGridCModel42");

// combo boxs for user access grid, sheet, or column
Ext.define("JGrid.model.JGridCModel43", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel43",
    id: "JGridCModel43",
    fields: [	{name: 'access_type_id', type: 'string'}, 
             	{name: 'access_type_name', type: 'string'}
            ]
});
JGrid.dsCModel[43] = Ext.create("JGrid.model.JGridCModel43");

// combo boxs for acess level
Ext.define("JGrid.model.JGridCModel44", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel44",
    id: "JGridCModel44",
    fields: [{name: 'access_level', type: 'string'}, 
             {name: 'Type', type: 'string'}
           ]
});
JGrid.dsCModel[44] = Ext.create("JGrid.model.JGridCModel44");

// combo boxs for security role or user
Ext.define("JGrid.model.JGridCModel50", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel50",
    id: "JGridCModel50",
    fields:	[	{name: 'rslvl_id', type: 'string'}, 
                {name: 'role_or_user', type: 'string'}
          	]
});
JGrid.dsCModel[50] = Ext.create("JGrid.model.JGridCModel50");

// combo boxs userdefined column listbox
Ext.define("JGrid.model.JGridCModel60", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel60",
    id: "JGridCModel60",
    fields:	[	{name: "id", type: 'string'}, 
          		{name: "listboxvalues", type: 'string'},
              	{name: "listboxvaluerowcolor", type: 'string'}
     		]
});
JGrid.dsCModel[50] = Ext.create("JGrid.model.JGridCModel50");

// combo boxs for security role or user model
Ext.define("JGrid.model.JGridCModel411", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel411",
    id: "JGridCModel411",
    fields: [	{name: 'access_for_id', type: 'string'}, 
             	{name: 'access_for_name', type: 'string'}
            ]
});

JGrid.dsCModel[411] = Ext.create("JGrid.model.JGridCModel411");

// combo boxs for user access grid, sheet, or column
Ext.define("JGrid.model.JGridCModel431", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel431",
    id: "JGridCModel431",
    fields: [	{name: 'access_type_id', type: 'string'}, 
             	{name: 'access_type_name', type: 'string'}
           	]
});
JGrid.dsCModel[431] = Ext.create("JGrid.model.JGridCModel431");

