<?php
 /*
 *  JGridDownloadWin.php  in joomla/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>

Ext.define("JGrid.view.JGridDownloadWin", {
	extend : "Ext.window.Window",
	alias : "widget.JGridDownloadWin",
	id: "JGridDownloadWin",
    title: "",
    border: false,
    closeAction: "hide",
    layout: 'fit',
    autoHeight: true,
<?php    
    if($params->get ('jgrid_renderTo'))
	{
		echo 'renderTo: "'.$params->get ('jgrid_renderTo').'", ';
	} 
	else echo 'renderTo: "jgrid_component",';
   	if($params->get ('jgrid_data_loader_win_width') > 0)
    {
    	echo 'width: '.$params->get ('jgrid_data_loader_win_width').',';
    } 
    else echo 'width: 500,';
    if($params->get ('jgrid_data_loader_win_height') > 0)
    {
    	echo 'height: '.$params->get ('jgrid_data_loader_win_height').',';
    } 
    else echo 'height: 250,';         
    if($params->get ('jgrid_data_loader_win_x') > 0)
    {
   	 	echo 'x: '.$params->get ('jgrid_data_loader_win_x').',';
    }
    if($params->get ('jgrid_data_loader_win_y') > 0)
    {
    	echo 'y: '.$params->get ('jgrid_data_loader_win_y').',';
    }
?>    
    items: [{
    	xtype: 'form',
    	id: "JGridDownloadFm",
	    buttonAlign: "center",
	    width: 450,
	    frame: true,
	    style: "margin: 0 auto;",
	<?php    
	    echo ' title: "'.JText::_("CSV_FILE_DOWNLOAD_FORM").'",';
	?>    
	    autoHeight: true,
	    bodyStyle: "padding: 10px 10px 0 10px;",
	    labelWidth: 60,
		    defaults: {
		    	autoEl: {},
		        anchor: '100%',
		        allowBlank: true,
		        msgTarget: "side",
		        layout: 'form'
		    },
          	items: [{
          		xtype: 'fieldset',
              	autoHeight: true,
              	labelAlign: 'right',
               	waitMsgTarget: true,
              	defaultType: "container",
	    items: 
	    [
	    	{   xtype: "textfield",
<?php    
			    echo 'fieldLabel: "'.JText::_("FILE_NAME").'",
			    plugins: [ new Ext.ux.FieldHelp("'. JText::_("DOWNLOAD_FILE_NAME_TOOLTIP").'") ],';
?>			                    
		        name: "download_file_name",
		        width: 100
	   		},
			combo2
	    ]
	    }],    
		buttons: [{
		<?php        		 	       
			echo 'text: "'. JText::_("SAVE").'",
			handler: function(){
				testValues =  JGrid.data_downloader.getValues();
				var download_file_name = JGrid.data_downloader.getForm().findField("download_file_name").getValue();;
				var delimiter_combo = JGrid.data_downloader.getForm().findField("delimiter_combo").getValue();
				var grid_id = JGrid.csvDownload["grid_id"];
				var document_id = JGrid.csvDownload["document_id"];
				urlValue = "'.JURI::base().'index.php?option=com_jgrid&task=read&format=ajax&download_csv_document=1&filename="+download_file_name+"&delimiter="+delimiter_combo+"&grid_id="+grid_id+"&document_id="+document_id+"";
		      	window.open(urlValue);';                        
		?>               			
		      	JGrid.download_win.hide();
			}                                    
		},
		{
	<?php        		
	            		echo 'text: "'. JText::_("RESET").'",';
	?>
	            		handler: function(){
	                		JGrid.data_downloader.getForm().reset();
	            		}
	        		}]
    }]
});        

     
