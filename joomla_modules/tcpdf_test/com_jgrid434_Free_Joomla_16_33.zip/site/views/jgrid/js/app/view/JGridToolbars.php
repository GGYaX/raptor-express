<?php
 /*
 *  JGridToolbars.php  in joomla/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
$params = JComponentHelper::getParams('com_jgrid');
$fversion = $params->get ('fversion');
for($j=0;$j<$gridCount;$j++) {


echo 'Ext.define("JGrid.view.JGridToolbar'.$j.'.php", {
	extend : "Ext.toolbar.Toolbar",
	id : "JGridToolbar'.$j.'",
	alias : "widget.JGridToolbar'.$j.'",
	requires: [ "JGrid.view.JGridSheetSettingWin","Ext.data.Model"],';
	echo 'items : [{
					  id: "Grid_return'.$j.'",
                      xtype: "button",
                  //  text: "'. JText::_("MANAGE_SHEETS").'",
                      icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/arrow_left.png",
                      hidden: true,
                      tooltip: "'. JText::_("RETURN_TO_PREVIOUS_GRID").'",
                      handler: function () {
                         last_grid_id = JGrid.lastGridIdStack[JGrid.lastGridIdStack.length - 1];
                         JGrid.lastGridIdStack.pop();
                         Ext.ComponentMgr.get("Grid_return'.$j.'").hide();
                         grid_tabpanel.setActiveTab(last_grid_id);
                      }
                    },
                    {
                        xtype: "tbtext",
                        style: "font-weight:bold;",
                        text:  "'. JText::_("SELECT_SHEET").'"
                    },                    
                    {
						xtype: "combo",
						id: "'. $griditems[$j]->grid_reference_id  .'_document",
						emptyText: "'. JText::_("SELECT_A_SHEET_TO_LOAD").'",
						store: JGrid.documentStore['.$j.'],
						displayField: "document_title",
						valueField: "id",
						width: 200,
						growToLongestValue: false,
						hideTrigger: false,
						lastquery:"",
						mode: "remote",
						value: "'.$griditems[$j]->document_title.'",
						typeAhead: true,
						editable: true,
						triggerAction: "all",
						listeners: {
							select:{
								fn: function (combo, records, eOpts) {
									new_document_id = parseInt(records[0].data.id);
									last_document_id = 0;
									if (new_document_id === 0) {
										last_document_id = JGrid.documentIdStack['.$j.'].pop();
										new_document_id = JGrid.documentIdStack['.$j.'] [JGrid.documentIdStack['.$j.'].length - 1];
										var new_document_title = JGrid.documentStore['.$j.'].findRecord("id", new_document_id).data.document_title;
										Ext.ComponentMgr.get("'. $griditems[$j]->grid_reference_id  .'_document").setValue(new_document_title);
										if (new_document_id==0||new_document_id==null) {
											JGrid.documentIdStack['.$j.'].push(last_document_id);
											Ext.Msg.alert("'. JText::_("END_OF_PREVIOUS_SHEETS").'", "'. JText::_("PLEASE_SELECT_A_SHEET_FROM_THE_LIST").'");
											return;
										}
									}
									else {
										last_document_id = JGrid.documentIdStack['.$j.'] [JGrid.documentIdStack['.$j.'].length - 1];
										JGrid.documentIdStack['.$j.'].push(new_document_id);
									}
									var gridIdVal=parseInt('.$griditems[$j]->id.');
									JGrid.view.Viewport.static_grid_id=gridIdVal;
									JGrid.view.Viewport.static_new_document_id=new_document_id;
									JGrid.view.Viewport.static_last_document_id=last_document_id;
									JGrid.view.Viewport.static_itemIndex =parseInt('.$j.');                                                                
									JGrid.store['.$j.'].load({
										params: {
											new_document_id: new_document_id,
											last_document_id: last_document_id
										}
									});';
									if($fversion == 0)
									{                                  
										echo 'if(records[0].get("document_type")){
											Ext.getCmp("Chart_Mode'.$j.'").setVisible(true);
										}else{
											Ext.getCmp("Chart_Mode'.$j.'").setVisible(false);
										}
										if(records[0].get("document_type")){
											createDataChart(gridIdVal,new_document_id,last_document_id,Ext.getCmp("chartBody"),'.$j.');
										}';
									}                       
								echo '}
							},
							afterrender:function(cobObj,opt){
								last_document_id = JGrid.documentIdStack['.$j.'] [JGrid.documentIdStack['.$j.'].length - 1];
								var gridIdVal=parseInt('.$griditems[$j]->id.');
								JGrid.documentStore['.$j.'].each(function(item, index, count) {
									if(last_document_id==item.get("id")){
										if(item.get("document_type")){
											Ext.getCmp("Chart_Mode'.$j.'").setVisible(true);
										}else{
											Ext.getCmp("Chart_Mode'.$j.'").setVisible(false);
										}
										if(item.get("document_type")){
											createDataChart(gridIdVal,last_document_id,last_document_id,Ext.getCmp("chartBody"),'.$j.');
										}									
									}									
									
								});
								
							} 
						},						
						scope: this
                },
                {
					id:"Chart_Mode'.$j.'",	
					text:"Chart View",
					hidden:true,
					handler:function(){
							
						var gridIdVal=parseInt('.$griditems[$j]->id.');
						current_document_id = JGrid.documentIdStack['.$j.'] [JGrid.documentIdStack['.$j.'].length - 1];
						var currentIndex='.$j.';
						if(!JGrid.chartObj)
				    	{
				    			JGrid.chartObj = Ext.create("JGrid.view.JGridChartWindow",{
									gridIdVal:gridIdVal,
									currentIndex:currentIndex,
									current_document_id:current_document_id																	
								});
								chartObj=JGrid.chartObj;
				    	}					
						JGrid.chartObj.show();
					}
				},
                {
                        xtype: "tbtext",
                        style: "font-weight:bold;",
                        id: "spacer'.$j.'",
                        text:  "  "
                },
                {
                        xtype: "tbtext",
                        style: "font-weight:bold;",
                        id: "searchname'.$j.'",
                        text:  "'. JText::_("SEARCH").'"
                    },
                    {
	                 xtype: "textfield",
	                 id: "searchField'.$j.'",
	                 hideLabel: true,
	                 width: 200,
	                 listeners: {
	                     specialkey: {
	                         fn: function ( field, e, opt ) {
	                         	if(e.button == 12 || e.button == 9 || e.button  == 13)
	                         	{
	                         		JGrid.searchstring['.$j.'] = field.value;
	                         		JGrid.store['.$j.'].load({params: {searchString: JGrid.searchstring['.$j.']}});
	                         	}	                        	 
	                         }
	                     }
	                 }
            		},
            		{
                    id: "Edit_Mode'.$j.'",
                    text: "Edit",
                    icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/application_edit.png",
                    cls: "x-btn-text-icon",
                    hidden: true,
                    tooltip: "'. JText::_("ADD_GRID_ROW_TOOLTIP").'",
                    handler: function () {
//                       if('.$griditems[$j]->id.'<9&&demodata'.$j.'==false)
//                       {
//                         Ext.Msg.alert("'. JText::_("WARNING_CREATE_YOUR_OWN_GRIDS").'", "'. JText::_("CHANGES_MADE_TO_DEMO_GRIDS_WILL_BE_LOST_WHEN_UPGRADEING").'");
//                         demodata'.$j.'=true;
//                       }
                       Ext.ComponentMgr.get("Edit_Mode'.$j.'").hide();
                       Ext.ComponentMgr.get("View_Mode'.$j.'").show();
                       Ext.ComponentMgr.get("spacer'.$j.'").hide();
                       Ext.ComponentMgr.get("searchname'.$j.'").hide();
                       Ext.ComponentMgr.get("searchField'.$j.'").hide();
                       JGrid.combo_store[1].load(); 
                       JGrid.editMode['.$j.']=true;';
//                if($griditems[$j]->enableRowEditor  == true)
//                {
//                    echo 'editor'.$j.'.changeMode(true);';
//                }
                   
                  echo '     set_access_levels('.$j.',
                                         "' . $griditems[$j]->grid_reference_id  . '",
                                         "Manage_Sheet_Access'.$j.'",
                                         "Manage_Sheets'.$j.'",
                                         "Add_Row_Above'.$j.'",
                                         "Edit_Row'.$j.'",
                                         JGrid.editMode['.$j.'] );
                    }
                },
                {
                    id: "View_Mode'.$j.'",
                    text: "View",
                    icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/application_view_columns.png",
                    cls: "x-btn-text-icon",
                    hidden: true,
                    tooltip: "'. JText::_("ADD_GRID_ROW_TOOLTIP").'",
                    handler: function () {
                       Ext.ComponentMgr.get("View_Mode'.$j.'").hide();
                       Ext.ComponentMgr.get("Edit_Mode'.$j.'").show();
                       Ext.ComponentMgr.get("spacer'.$j.'").show();
                       Ext.ComponentMgr.get("searchname'.$j.'").show();
                       Ext.ComponentMgr.get("searchField'.$j.'").show(); 
                       // re-show any hidden images as backup to normal behavied of editor
                       var grid_columns = Ext.ComponentMgr.get("' . $griditems[$j]->grid_reference_id  . '").columns;
                       for(var i=1;i<=JGrid.columnCount['.$j.'];i++)
                       {
                         if(grid_columns[i].id.substr(0,1)=="P")
                         {
                           grid_columns[i].show(); 
                         } 
                       } 
                       
                       JGrid.editMode['.$j.']=false;';
//              if($griditems[$j]->enableRowEditor  == true)
//                {
//                    echo 'JGrid.editor['.$j.'].changeMode(false);';
//                }
                       
                      echo' set_access_levels('.$j.',
                                         "' . $griditems[$j]->grid_reference_id  . '",
                                         "Manage_Sheet_Access'.$j.'",
                                         "Manage_Sheets'.$j.'",
                                         "Add_Row_Above'.$j.'",
                                         "Edit_Row'.$j.'" ,
                                         JGrid.editMode['.$j.']);
                    }
                },
                {
                    id: "Add_Row_Above'.$j.'",
                    text: "'. JText::_("ADD_GRID_ROW").'",
                    icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_row_insert.png",
                    cls: "x-btn-text-icon",
                    hidden: true,
                    tooltip: "'. JText::_("ADD_GRID_ROW_TOOLTIP").'",
                    handler: function () {
                        JGrid.add_row(ADD_ROW_BELOWW, "'.$griditems[$j]->id.'", "'. $griditems[$j]->grid_reference_id  .'", '.$j.');
                    }
                },
                {
                    id: "Edit_Row'.$j.'",
                    xtype: "button",
                    text: "'. JText::_("EDIT_DELETE").'",
                    hidden: true,
                    icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_edit.png",
                    tooltip: "'. JText::_("EDIT_DELETE_TOOLTIP").'",
                    menu: [';
                    if($griditems[$j]->select_type<2)
                    {              
	                    echo '{
	                        id: "Delete_Row'.$j.'",
	                        ref: "./deleteBtn",
	                        text: "<b>'. JText::_("DELETE_ROW").'</b>",
	                        icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_row_delete.png",
	                        tooltip: "'. JText::_("DELETE_ROW_TOOLTIP").'",
	                        handler: function () {
	                            jgrid_remove_row("'.$griditems[$j]->id.'", "'. $griditems[$j]->grid_reference_id  .'");
	                        }
	                    },
	                    {
	                        id: "Insert_Row_Above'.$j.'",
	                        text: "<b>'. JText::_("INSERT_ROW_ABOVE").'</b>",
	                        icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_row_insert.png",
	                        tooltip: "'. JText::_("INSERT_ROW_ABOVE_TOOLTIP").'",
	                        handler: function () {                  
	                            JGrid.add_row(ADD_ROW_ABOVEE, "'.$griditems[$j]->id.'", "'. $griditems[$j]->grid_reference_id  .'", '.$j.');
	                        }
	                    },
	                    {
	                        id: "Insert_Row_Below'.$j.'",
	                        text: "<b>'. JText::_("INSERT_ROW_BELOW").'</b>",
	                        icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_row_insert.png",
	                        tooltip: "'. JText::_("INSERT_ROW_BELOW_TOOLTIP").'",
	                        handler: function () {                       
	                           JGrid.add_row(ADD_ROW_BELOWW, "'.$griditems[$j]->id.'", "'. $griditems[$j]->grid_reference_id  .'", '.$j.');
	                        }
	                    },';
                    }
                    echo '{
                        id: "Copy_Rows'.$j.'",
                        text: "<b>'. JText::_("COPY_ROWS").'</b>",
                        icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_refresh.png",
                        tooltip: "'. JText::_("COPY_ROWS_TOOLTIP").'",
                        handler: function () {                                 
                           if (!Ext.ComponentMgr.get("'. $griditems[$j]->grid_reference_id  .'").getSelectionModel().hasSelection()) {
                                Ext.Msg.alert("'. JText::_("PLEASE").'", "'. JText::_("SELECT_ROW_BEFORE_COPY").'");
                                return;
                           }                   
                           JGrid.copy['.$j.'] = true;
                        }
                    }';
                    if($griditems[$j]->select_type<2)
                    {  
	                    echo ',{
	                        id: "Upload_Data'.$j.'",
	                        text: "<b>'. JText::_("UPLOAD_DATA").'</b>",
	                        icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/database_go.png",
	                        tooltip: "'. JText::_("UPLOAD_DATA_TOOLTIP").'",
	                        handler: function () { 
	                            var pgrid = Ext.ComponentMgr.get("'. $griditems[$j]->grid_reference_id  .'");
	                            var sm = pgrid.getSelectionModel();
	                            if (!sm.hasSelection()) {
	                                Ext.Msg.alert("'. JText::_("PLEASE").'", "'. JText::_("SELECT_ROW_BEFORE_UPLOAD").'");
	                                return;
	                           }
	                           else
	                           {
	                             JGrid.csvUpload["index"] = '.$j.';
	                             JGrid.csvUpload["grid_id"] = '.$griditems[$j]->id.';
	                             var sel = sm.getSelection();
	                             JGrid.csvUpload["sel_row_id"]=1;
	                             JGrid.csvUpload["sel_row_id"] =  sel[0].get("id");
	                             var current_row_count = pgrid.store.getCount();
	                             if (current_row_count === 0||JGrid.csvUpload["sel_row_id"]===""||JGrid.csvUpload["sel_row_id"]===0) 
	                             {
	                               JGrid.csvUpload["row_insert_position"] = FIRSTROWW;
	                             }
	                             else
	                             {
	                               JGrid.csvUpload["row_insert_position"] = ADD_ROW_BELOWW;
	                             }                              
	                           }
	                           if(!JGrid.upload_win)
				    		   {
				    				JGrid.upload_win = Ext.create("JGrid.view.JGridUploadWin");
				    				JGrid.data_loader = Ext.getCmp("JGridUploadFm");
				    		   }
				    		   JGrid.upload_win.show();
	                        }
	                    }';
                    }
                    if($params->get('allow_image_download',1)==1)
                    {         	
                     echo ',{
                      id: "Download_data'.$j.'",
                      text: "<b>'. JText::_("DOWNLOAD_DATA").'</b>",
                      icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/database_go.png",
                      tooltip: "'. JText::_("DOWNLOAD_DATA_TOOLTIP").'",	
                      handler: function()
                      {
	                	JGrid.csvDownload["grid_id"] = '.$griditems[$j]->id.';
	                	JGrid.csvDownload["document_id"] = JGrid.documentIdStack['.$j.'] [JGrid.documentIdStack['.$j.'].length - 1];
	                 	if(!JGrid.download_win)
				    	{
				    		JGrid.download_win = Ext.create("JGrid.view.JGridDownloadWin");
				    		JGrid.data_downloader = Ext.getCmp("JGridDownloadFm");
				    	}
				    	JGrid.download_win.show();            
                      }                                           
                    }';
                    }                                                           
                 echo'],
                    scope: this 
                },
                {
                    id: "Manage_Sheets'.$j.'",
                    xtype: "button",
                    text: "'. JText::_("MANAGE_SHEETS").'",
                    icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/folder_user.png",
                    hidden: true,
                    tooltip: "'. JText::_("MANAGE_SHEETS_TOOLTIP").'",
                    menu: [{
                        id: "Create_Sheets'.$j.'",
                        text: "<b>'. JText::_("CREATE_NEW_SHEET").'</b>",
                        icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_add.png",
                        tooltip: "'. JText::_("CREATE_NEW_SHEET_TOOLTIP").'",
                        handler: function () {                        
                              // CHART Changes                        	 
                        	  // globalSelectedGrid='.$griditems[$j]->id.'
                        	  //var array_index = JGrid.documentIdStack['.$j.'],'.$j.';
							if(!jgridSheetObj){
								//Chart Config
                        		 var jgridSheetObj= Ext.create("JGrid.view.JGridSheetSettingWin",{selectedId:"'.$griditems[$j]->id.'",grid_reference_id:"'.$griditems[$j]->grid_reference_id.'",documentIdStack:JGrid.documentIdStack['.$j.'],array_index:"'.$j.'",task:"New",selectedSheetId:null});
								}
                        	  	jgridSheetObj.show(); 
                        	  	   //alert(jgridSheetObj+"'.$griditems[$j]->id.'"+"'. $griditems[$j]->grid_reference_id  . '"+ JGrid.documentIdStack['.$j.'],'.$j.');
                        	   //alert(Ext.getCmp("'.$griditems[$j]->grid_reference_id.'").getStore().getProxy().getModel().modelName.)
                        	    //alert(Ext.getCmp("'.$griditems[$j]->grid_reference_id.'").columns[2].text)
                        	  //  var grid_columns = Ext.ComponentMgr.get(grid_reference_id).columns;                        	   
                        	  // alert("'.$griditems[$j]->grid_reference_id.'")
                             //jgrid_create_document("'.$griditems[$j]->id.'", "'. $griditems[$j]->grid_reference_id  . '", JGrid.documentIdStack['.$j.'],'.$j.');
                            // End 
                        }
                    },
                    {
                        id: "Delete_Sheets'.$j.'",
                        text: "<b>'. JText::_("DELETE_CURRENT_SHEET").'</b>",
                        icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_delete.png",
                        tooltip: "'. JText::_("DELETE_CURRENT_SHEET_TOOLTIP").'",
                        handler: function () {
                            jgrid_remove_document("'.$griditems[$j]->id.'", "'. $griditems[$j]->grid_reference_id  . '", JGrid.documentIdStack['.$j.'],'.$j.');
                        }
                    },
                    {
                        id: "Copy_Sheets'.$j.'",
                        text: "<b>'. JText::_("COPY_CURRENT_SHEET").'</b>",
                        icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_multiple.png",
                        tooltip: "'. JText::_("COPY_CURRENT_SHEET_TOOLTIP").'",
                        handler: function () {
                            jgrid_copy_document("'.$griditems[$j]->id.'", "'. $griditems[$j]->grid_reference_id  . '", JGrid.documentIdStack['.$j.'],'.$j.');
                        }
                    },{
                        id: "Rename_Sheets'.$j.'",
                        text: "<b>'. JText::_("RENAME_CURRENT_SHEET").'</b>",
                        icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_link.png",
                        tooltip: "'. JText::_("RENAME_CURRENT_SHEET_TOOLTIP").'",
                        handler: function () {
                            jgrid_rename_document("'.$griditems[$j]->id.'", "'. $griditems[$j]->grid_reference_id  . '", JGrid.documentIdStack['.$j.'],'.$j.');
                        }
                    },{
						id:"edit_chart_setting'.$j.'",
						text:"<b>'. JText::_("EDIT_CURRENT_SHEET").'</b>",
						icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_multiple.png",
                        tooltip: "'. JText::_("EDIT_CURRENT_SHEET_TOOLTIP").'",
                        handler: function () {
							last_document_id = JGrid.documentIdStack['.$j.'] [JGrid.documentIdStack['.$j.'].length - 1];
							var gridIdVal=parseInt('.$griditems[$j]->id.');
							JGrid.documentStore['.$j.'].each(function(item, index, count) {
									if(last_document_id==item.get("id")){
										if(item.get("document_type")){
											
											//IF chart then open edit chart setting window	
											if(!jgridSheetObj){
												var selectedSheetId=item.get("id");
												var jgridSheetObj= Ext.create("JGrid.view.JGridSheetSettingWin",{selectedId:"'.$griditems[$j]->id.'",grid_reference_id:"'.$griditems[$j]->grid_reference_id.'",documentIdStack:JGrid.documentIdStack['.$j.'],array_index:"'.$j.'",task:"Edit",selectedSheetId:selectedSheetId});
											}
											jgridSheetObj.show();										
										}
										else{
											Ext.MessageBox.confirm("Confirm", "Are you sure you want to edit this as chart sheet?", 
												function(btn){
													if(btn=="yes"){
														//IF chart then open edit chart setting window	
														if(!jgridSheetObj){
															var selectedSheetId=item.get("id");
															var jgridSheetObj= Ext.create("JGrid.view.JGridSheetSettingWin",{selectedId:"'.$griditems[$j]->id.'",grid_reference_id:"'.$griditems[$j]->grid_reference_id.'",documentIdStack:JGrid.documentIdStack['.$j.'],array_index:"'.$j.'",task:"Edit",selectedSheetId:selectedSheetId});
														}
														jgridSheetObj.show();
													
													}
												
											});
										}								
									}		
									
							});							
                           // jgrid_copy_document("'.$griditems[$j]->id.'", "'. $griditems[$j]->grid_reference_id  . '", JGrid.documentIdStack['.$j.'],'.$j.');
                        }
							
					}';
				if($fversion == 0)
				{                   
                    echo ',{
                        id: "Manage_Sheet_Access'.$j.'",
                        text: "<b>'. JText::_("MANAGE_SHEET_ACCESS").'</b>",
                        icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/key.png", 
                        tooltip: "'. JText::_("ADD_GRID_COLUMNS_TOOLTIP").'",
                        handler: function () {
                     		JGrid.combo_store[43].load({
                        		params: {
                               		grid_id: JGrid.gCurrentGridId,
                                  	grid_application_name: "'.$griditems[0]->grid_application_name.'"
                             	}
                          	});
                          	JGrid.store_access.load({
                                    params: {
                                        gird_id: JGrid.gCurrentGridId,
                                        grid_application_name: "'.$griditems[0]->grid_application_name.'"
                                    }
                          	});
                            JGrid.gCurrentGridId = "'. $griditems[$j]->id  . '";
                            if(!JGrid.JGridSecurityWin)
  						    {
 							  JGrid.JGridSecurityWin = Ext.create("JGrid.view.Security");
   						    }
  						    JGrid.JGridSecurityWin.show();
						}
                     }';
				} 
				echo ']}';
				/* RMS put back once filters added
                if($has_filters[$j]==true)
                {
                    echo',{
                        id: "clear_filters'.$j.'",
                        text: "'. JText::_("CLEAR_ALL_FILTERS").'",
                        icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table.png",
                        cls: "x-btn-text-icon",
                        tooltip: "'. JText::_("CLEAR_ALL_FILTERS_TOOLTIP").'",
                        handler: function () {
                               Ext.ComponentMgr.get("'. $griditems[$j]->grid_reference_id  .'").filters.clearFilters();                              
                        }
                    }';
                }
                */
                if($griditems[$j]->print  == true)
                {
                     echo ',{    
                        id: "Print_Grid'.$j.'",                   
                        text: "<b>'. JText::_("PRINT_GRID").'</b>",
                        icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/printer.png",
                        tooltip: "'. JText::_("PRINT_GRID_TOOLTIP").'",
                        handler: function () {
                            Ext.ux.grid.Printer.print(Ext.ComponentMgr.get("'. $griditems[$j]->grid_reference_id  .'")); 
                        }          
                     }';
                }
                	echo ',{    
                        id: "user_help'.$j.'",                   
                        text: "<b>'. JText::_("HELP").'</b>",
                        icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/help.png",
                        tooltip: "'. JText::_("INSTRUCTIONS_DESCRIBING_GRID_OPERATION").'",
                        handler: function () {                              
                  			if(!JGrid.help[0])
				    		{
				    			JGrid.help[0] = Ext.create("JGrid.view.JGridHelp");
				    		}
							JGrid.help[0].show();
                        }          
                     }';                
  ?>             
			]
});

<?php
}
?>
