<?php
/**
 * Jgrid_documents Controller in Joomla/Components/controllers
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_documents controller
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid  "Sheets" screens
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class JgridControllerJgrid_documents extends JgridController
{
	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The pointer to the joomla model to be accesses
	 * @var array
	 */
	var $_model=null;

	// demo version demo = 1
	var $demo = 1;

	/**
	 * Retrieves the "sheets " data
	 * @return string json string containing the "Column Settings" grid rows or false if no row returned
	 */
	function read()
	{
		$this->_model = $this->getModel('jgrid_documents');
		list($this->_result_count,$this->_result) = $this->_model->getSheets();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Retrieves the access_for_name and ID  to add in combo box
	 * @var array last_document_call adds "Reload Previous Document" as first element in document dropdown list
	 * @return array Array of objects containing the data from the database integer of results returned
	 */
	function read_combo()
	{
		$this->_model = $this->getModel('jgrid_documents');
		list($this->_result_count,$this->_result) = $this->_model->get_read_combo();
		// add selection to recall last selection
		$last_document_call = array ("id"=>"0","document_title"=>"Reload Previous Document");
		array_unshift($this->_result, $last_document_call);
		$this->_result_count++;
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Retrieves the access_type_name and ID  to add in combo box
	 * @return array Array of objects containing the data from the database integer results returned
	 */
	function access_type_name_id()
	{
		$this->_model = $this->getModel('jgrid_documents');
		list($this->_result_count,$this->_result) = $this->_model->get_access_type_name_id();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Updates the   "sheets" data being edited
	 * @return integer return true if row updated or false if update failed.
	 */
	function update()
	{
		// check for demo version return
		$session =& JFactory::getSession();
		if($session->get('demo_mode')){
			Echo '{success:true}';
			return;
		}
		$this->model = $this->getModel('jgrid_documents');
		if($this->model->updateSheet()) Echo '{success:true}';
		else Echo '{success:false}';
	}

	/**
	 * Creates new sheet for the grid
	 * @return string json encoded string containing new sheet id to the grid  or false if column not created.
	 */
	function create_document()
	{
		// check for demo version return
		$session =& JFactory::getSession();
		if($session->get('demo_mode')){
			$row_data["new_document_id"]=50;
			Echo '{success:true,results:"1",rows:'. json_encode($row_data) .'}';
			return;
		}
		$this->model = $this->getModel('jgrid_documents');
		$this->_result = $this->model->createSheet();
		if($this->_result) Echo '{success:true,results:"1",rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}
	
/**
	 *
	 * Creates new Chart sheet for the grid
	 * @return string json encoded string containing new sheet id to the chart grid  or false if column not created.
	 */
	function create_chart_document()
	{
		
		// check for demo version return
		$session =& JFactory::getSession();
		if($session->get('demo_mode')){
			$row_data["new_document_id"]=50;
			Echo '{success:true,results:"1",rows:'. json_encode($row_data) .'}';
			return;
		}
		$this->model = $this->getModel('jgrid_documents');
		$this->_result = $this->model->create_chart_document();
		
		if($this->_result) Echo '{success:true,results:"1",rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
		
	}
	
	/**
	*
	* read chart sheet setting data 
	* @return string json encoded string containing new sheet id to the chart grid  or false if column not created.
	*/
	function read_chart_setting()
	{
	
		// check for demo version return
		$session =JFactory::getSession();
		if($session->get('demo_mode')){
			$row_data["new_document_id"]=50;
			Echo '{success:true,results:"1",rows:'. json_encode($row_data) .'}';
			return;
		}
		$this->model = $this->getModel('jgrid_documents');
		//$this->_result = $this->model->read_chart_setting();
		$resultArr = $this->model->read_chart_setting();
		
		//RMS return no data found
		if($resultArr===false) Echo '{success:false}';
	
		//Example of bar chart & column chart configuration
		/*if($this->_result) Echo '{success:true,results:"1",rows:'. json_encode($this->_result) .',legend:[{position:"left",x:230,y:300,padding:20,itemSpacing:10,boxFill:"#A35FCC",labelFont:""}],
		category_axes:[{position:"bottom",title:"Team",cfields:"T24",minorTickSteps:0,majorTickSteps:10,label_dgree_rotate:90}],
		numeric_axes:[{position:"left",title:"Lost",fields:[{field_value:"I27"},{field_value:"I26"}],minorTickSteps:5,majorTickSteps:5,minimum:0}],
		chart_series:[{type:"area",axis:"bottom",highlight:true,xField:"T24",yField:[{field_value:"I26"},{field_value:"I27"}],stacked:true}]
		}';*/
		
		//line chart example
    if($resultArr[0][0])
    {
  		$objectvar=$resultArr[0][0];
  		$objectvar->chart_category;
  		
  		if($objectvar->chart_category=="cartesian"){		
  			
  			if(count($resultArr)>0) Echo '{success:true,results:"1",rows:'. json_encode($resultArr[0]) .',legend:'. json_encode($resultArr[4]) .',
  					category_axes:'.json_encode($resultArr[2]).',
  					numeric_axes:'.json_encode($resultArr[1]).',
  					chart_series:'.json_encode($resultArr[3]).'
  					//chart_series:[{type:"scatter",axis:"left",highlight:true,xField:"L59",yField:[{field_value:"I60"}],stacked:true},{type:"scatter",axis:"left",highlight:true,xField:"T25",yField:[{field_value:"I61"}],stacked:true}]
  					}';
  		
  		}else if($objectvar->chart_category=="pie"){
  			if(count($resultArr)>0) Echo '{success:true,results:"1",rows:'. json_encode($resultArr[0]) .',legend:'. json_encode($resultArr[4]) .',
  					chart_series:'.json_encode($resultArr[1]).'					
  					}';
  		}
  		else if($objectvar->chart_category=="radar"){
  			
  			if(count($resultArr)>0) Echo '{success:true,results:"1",rows:'. json_encode($resultArr[0]) .',legend:'. json_encode($resultArr[4]) .',
  							chart_series:'.json_encode($resultArr[1]).'					
  							}';
  		}else{
  			
  			if(count($resultArr)>0) Echo '{success:false,results:"1",rows:'. json_encode($resultArr[0]) .'}';
  		}
    }
	}	
	

	/**
	 * Creates new sheet and copies data from old sheet for the grid
	 * @return string json encoded string containing new sheet id to the grid  or false if copy of sheet not made.
	 */
	function copy_document()
	{
		// check for demo version return
		$session =& JFactory::getSession();
		if($session->get('demo_mode')){
			$row_data["new_document_id"]=50;
			Echo '{success:true,results:"1",rows:'. json_encode($row_data) .'}';
			return;
		}
		$this->model = $this->getModel('jgrid_documents');
		$this->_result = $this->model->copySheet();
		if($this->_result) Echo '{success:true,results:"1",rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Renames current sheet of data in current grid
	 * @return string json encoded string containing new sheet id to the grid  or false if sheet not renamed.
	 */
	function rename_document()
	{
		// check for demo version return
		$session =& JFactory::getSession();
		if($session->get('demo_mode')){
			Echo '{success:true,results:"1",rows:'. json_encode($row_data) .'}';
			return;
		}
		$this->model = $this->getModel('jgrid_documents');
		$this->_result = $this->model->renameSheet();
		if($this->_result) Echo '{success:true,results:"1",rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Removes sheet and all associated data from grid
	 * @return integer result true if sheet removed or false if remove failed
	 */
	function remove_document()
	{
		// check for demo version return
		$session =& JFactory::getSession();
		if($session->get('demo_mode')){
			$row_data["new_document_id"]=JRequest::getVar('new_document_id','','','INTEGER');
			Echo '{success:true,results:"1",rows:'. json_encode($row_data["new_document_id"]) .'}';
			return;
		}
		$this->model = $this->getModel('jgrid_documents');
		$this->_result = $this->model->remove_document();
		if($this->_result) Echo '{success:true,results:"1",rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Get the grid-sheet combo list
	 * @return string json encoded string containing grid-sheet combo values  or false if none available.
	 */
	function get_combo_Grid_Sheet()
	{

		$this->model = $this->getModel('jgrid_documents');
		list($this->_result_count,$this->_result) = $this->model->get_combo_Grid_Sheet();
		if($this->_result==true)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Get the application-grid-sheet combo list
	 * @return string json encoded string containing grid-sheet combo values  or false if none available.
	 */
	function get_combo_Application_Grid_Sheet()
	{

		$this->model = $this->getModel('jgrid_documents');
		list($this->_result_count,$this->_result) = $this->model->get_combo_Application_Grid_Sheet();
		if($this->_result==true)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

}
