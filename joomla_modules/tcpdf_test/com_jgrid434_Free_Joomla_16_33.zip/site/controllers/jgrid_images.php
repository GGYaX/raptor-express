<?php
/**
 * Jgrid_images Controller in Joomla/Components/controllers
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_images controller
 *
 * upload and read images
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class JgridControllerJgrid_images extends JgridController
{
	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The pointer to the joomla model to be accesses
	 * @var array
	 */
	var $_model=null;
	

	/**
	 * Retrieves the "sheets " data
	 * @return string json string containing the "Column Settings" grid rows or false if no row returned
	 */
	function save_images()
	{
		// check for demo version return
		$session =& JFactory::getSession();
		if($session->get('demo_mode')){
			Echo '{success:true}';
			return;
		}
		$this->_model = $this->getModel('jgrid_images');
		list($this->success,$this->_result) = $this->_model->save_images();
		if($this->success)Echo '{success:true,data:'. json_encode($this->_result) .'}';
		else Echo '{success:false,data:'. json_encode($this->_result) .'}';		
	}
	
	/**
	 * Downloads Images to computer the 
	 * @return string json string containing the "Column Settings" grid rows or false if no row returned
	 */
	function download_images()
	{
		// check for demo version return
		$session =& JFactory::getSession();
		if($session->get('demo_mode')){
			Echo '{success:true}';
			return;
		}
		$this->_model = $this->getModel('jgrid_images');
		list($this->success,$this->_result) = $this->_model->download_images();
		if($this->success)Echo '{success:true,data:'. json_encode($this->_result) .'}';
		else Echo '{success:false,data:'. json_encode($this->_result) .'}';			
	}
	
	/**
	 * deletes grid Images to computer the 
	 * @return true of deleted or false if failed
	 */
	function delete_images()
	{
		// check for demo version return
		$session =& JFactory::getSession();
		if($session->get('demo_mode')){
			Echo '{success:true}';
			return;
		}
		$this->_model = $this->getModel('jgrid_images');
		list($this->success,$this->_result) = $this->_model->delete_images();
		if($this->success)Echo '{success:true,data:'. json_encode($this->_result) .'}';
		else Echo '{success:false,data:'. json_encode($this->_result) .'}';			
	}

}