<?php
/**
 * Jgrid_security Controller in Joomla/Components/controllers
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_security controller
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid administrator "Manager User Access" screens
 * to "Manage User Access" rights
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class JgridControllerJgrid_security extends JgridController
{

	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The pointer to the joomla model to be accesses
	 * @var array
	 */
	var $_model=null;

	// set to 1 for demo version
	var $demo = 1;

	/**
	 * Retrieves the "User Access Rules" data
	 * @return string json string containing the "User Access Rules" grid rows of false if no date read
	 */
	function read()
	{
		// delay to allow the list boxes to populate first
		sleep(1);
		$this->_model = $this->getModel('jgrid_security');
		list($this->_result_count,$this->_result) = $this->_model->getUserAccessRules();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Retrieves the users ID and Name that access rules can be applied and adds in combo box drop down selector box
	 * @return string json string containing the user id's and names or false if no user records found
	 */
	function access_for_name_id()
	{
		$this->_model = $this->getModel('jgrid_security');
		list($this->_result_count,$this->_result) = $this->_model->get_combo_User_Id_List(JRequest::getVar( 'access_for' ));
		if($this->_result==true)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Retrieves the "object type" id and name to add in combo box selector drop down
	 * @param string $access_type type of "User Access Rule" (All=0,Grid=1,Sheet=2,Column=3)
	 * @return string json encoded string containing the object id and name depending on the access type selection or false if no objects found
	 */
	function access_type_name_id()
	{
		$this->_model = $this->getModel('jgrid_security');
		list($this->_result_count,$this->_result) = $this->_model->get_combo_User_Access_Rule_Id_List(JRequest::getVar( 'access_type' ));
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Updates the   "Manager User Access" rule being edited in the  "Manager User Access" grid
	 * @return integer true if update successful or false if update failed.
	 */
	function update()
	{
		// check for demo version return
		$session =& JFactory::getSession();
		if($session->get('demo_mode')){
			Echo '{success:true}';
			return;
		}
		$this->_model = $this->getModel('jgrid_security');
		if($this->_model->updateUserAccessRule())Echo '{success:true}';
		else Echo '{success:false}';
	}

	/**
	 * Creates new rule in the "Manager User Access" grid
	 * @var array $row_data array of objects sent from the "Manager User Access" grid containing the values to be updated in the database
	 * @return string json encoded string containing the new rule default data ($last_id, and $user->id) to the "Manage User Access" grid row or false if rule not created.
	 */
	function create()
	{
		// check for demo version return
		$session =& JFactory::getSession();
		if($session->get('demo_mode')){
			Echo '{success:true}';
			return;
		}
		$this->_model = $this->getModel('jgrid_security');
		$this->_result = $this->_model->createUserAccessRule();
		if($this->_result==true)Echo '{success:true,results:"1",rows: '. json_encode($this->_result) .'}';
		else Echo '{success:false}';

	}

	/**
	 * Deletes rule in the "Manager User Access" grid
	 * @return integer result true if rule deleted or false delete failed
	 */
	function destroy()
	{
		// check for demo version return
		$session =& JFactory::getSession();
		if($session->get('demo_mode')){
			Echo '{success:true}';
			return;
		}
		$this->_model = $this->getModel('jgrid_security');
		if($this->_model->deleteUserAccessRule()) Echo '{success:true}';
		else Echo '{success:false}';
	}
}