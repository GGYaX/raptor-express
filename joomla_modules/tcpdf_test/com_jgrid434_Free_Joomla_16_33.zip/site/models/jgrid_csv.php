<?php
/**
 * Jgrid_csv Model in Joomla/Components/models
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once(JPATH_BASE . '/administrator/components/com_jgrid/os/jgrid/functions.php' );
jimport( 'joomla.application.component.model' );



//define a maxim size for the uploaded csv
define ("MAX_CSV_UPLOAD_SIZE",1500000);

/**
 * Jgrid_csv model
 *
 * upload and delete csv data to grid
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */

if(!class_exists('RMWorksAroundJoomlaToGetAModel')) {
	if(interface_exists('JModel')) {
		abstract class RMWorksAroundJoomlaToGetAModel extends JModelLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAModel extends JModel {}
	}
}

class JgridModelJgrid_csv extends RMWorksAroundJoomlaToGetAModel
{
	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The string containing the SQL call (query) that will retrieve the desired results
	 * @var string
	 */
	var $_query=null;

	// this is the function that will create the thumbnail image from the uploaded image
	// the resize will be done considering the width and height defined, but without deforming the image
	static function make_directory($dir)
	{

		// check on grid directory
		if(!(file_exists($dir) && is_dir($dir)))
		{
			if(!mkdir ($dir))
			{
				return array(false,JText::_("UNABLE_TO_MAKE_DIRECTORY").'" "'. $dir);
			}
			else // write index.html
			{
				$fptr= fopen($dir.'/index.html','x');
				if($fptr)
				{
					fwrite($fptr,'<html><body bgcolor="#FFFFFF"></body></html>');
					fclose($fptr);
				}
			}
		}
	}

	// this is the function will remove rows in undo and clear undo
	//
	function undo($grid_id,$current_document_id,$userid,$redo_days)
	{
		$db =JFactory::getDBO();
		$user =JFactory::getUser();

		// delete rows from the grid.
		$query =   'SELECT row_id AS id
                           FROM  #__jgrid_upload_undo 
                           WHERE grid_id = '.$grid_id.'
			                     AND document_id = '.$current_document_id.'
			                     AND userid = '.$userid; 

		$result_count = $this->_getListCount( $query );
		if($result_count==0)
		{
			return array(false,JText::_("NO_UNDO_DATA_IS_AVAILABLE_FOR_THIS_SHEET"));
		}
		$result = $this->_getList( $query );
		
		// convert to array of rows to delete
		for($i=0; $i < count($result); $i++)
		{
			$row_id[$i]['id'] = $result[$i]->id;
		}

	    $deleted_row_ids = deleteRow($grid_id,
			$current_document_id,
			$row_id);
		if(!$deleted_row_id)  return array(false,JText::_("UNDO_NOT_SUCCESSFUL"));


		// delete undo rows
		$db->setQuery('DELETE
		                      FROM  #__jgrid_upload_undo
			                  WHERE (grid_id = '.$grid_id.'
			                           AND document_id = '.$current_document_id.'
			                           AND userid = '.$userid.' )
			                         OR TIMESTAMPDIFF(DAY, last_updated, NOW()) > '.$redo_days) ; 
		$db->query();
	}


	// saves a csv file
	// 
	function save_csv()
	{
		$db =JFactory::getDBO();
		$user =JFactory::getUser();
		$session = JFactory::getSession();
		$session_id = $session->getId();
	if((JRequest::getVar('application_type','','','STRING')=='MODULE'))
{
	jimport( 'joomla.application.module.helper' );
	$app = JFactory::getApplication();
	$module = JModuleHelper::getModule(JRequest::getVar('jgrid_application_name'));
	$params = new JRegistry();
	if(class_exists('JParameter'))
	{
		$params = new JParameter( $module->params ); 
	}
	else 
	{
	   $params->loadString($module->params);
	}	
}
else 
{
	$params = JComponentHelper::getParams('com_jgrid');
}

		if($params->get ('jgrid_data_loader_redo_days'))
		{
			$redo_days = $params->get ('jgrid_data_loader_redo_days');
		}
		else $redo_days =  15;

//echo 'ss'.JgridModelJgrid_csv::getExtension($_FILES['data']['name']).'ss';
//return;
		if (isset($_FILES)&&(getExtension($_FILES['data']['name']) == 'csv'))
		{


			$current_document_id=0;
			$grid_id=JRequest::getVar('grid_id','','','INTEGER');

			// get current document ID
			$this->_query = 'SELECT g.current_document_id
	   		                 FROM #__jgrid_current_user_grid_document g
	   		                 WHERE g.userid = ' . $user->id .'
	                           AND g.grid_id = '.$grid_id.'
	                           AND g.session_id = "'.$session_id.'"';				
			$db->setQuery($this->_query);
			$current_document_id=$db->loadResult();

			// Check user security
			// check user access rights to be edit
			list($admin_user,$access_control,$remove_access_control,$document_security_level) = check_access_control($grid_id,$current_document_id,3);
			if($access_control==0 || $remove_access_control > 0)
			{
				return array(false,JText::_("USER_DOES_NOT_HAVE_ACCESS_RIGHTS_TO_UPLOAD_DATA_TO_GRID"));
			}

			// if data size is too big then return
			if($params->get ('MAX_CSV_UPLOAD_SIZE'))
			{
				$max_csv_upload_size = $params->get ('MAX_CSV_UPLOAD_SIZE');
			}
			else $max_csv_upload_size =  MAX_CSV_UPLOAD_SIZE;
			if($_FILES['data']['size']>$max_csv_upload_size)
			{
				return array(false,JText::_("MAX_UPLOAD_SIZE_OF").'" "'.$max_csv_upload_size.'" "'.JText::_("EXCEEDED_YOUR_FILE_SIZE_IS").'" "'.$_FILES['data']['size']);
			}

			// check to see if user directory exists for this user, if not create one.
			JgridModelJgrid_csv::make_directory(JPATH_BASE.'/media/com_jgrid');
			JgridModelJgrid_csv::make_directory(JPATH_BASE.'/media/com_jgrid/csv_uploads');
			$dir = JPATH_BASE.'/media/com_jgrid/csv_uploads';
			JgridModelJgrid_csv::make_directory($dir);

			$imgpath =  $grid_id. '_'.$user->id.'_'. $session_id;
			$imgname = $dir    . '/'. $imgpath. '.'.getExtension($_FILES['data']['name']);
			// save csv file
			move_uploaded_file ($_FILES['data']['tmp_name'],$imgname);
			$row = 1;
			if($params->get ('LOCAL_LANGUAGE_CSV'))
			{
				$local_language_csv = $params->get ('LOCAL_LANGUAGE_CSV');
			}
			else $local_language_csv =  ''; // defaults to your system language setting '' or 'ja_JP.UTF8' or multiple 'de_DE@euro', 'de_DE', 'de', 'ge', 'croatian'
			setlocale(LC_ALL, $local_language_csv);
			//setlocale(LC_ALL, 'croatian');
			if($params->get ('CORE_LC')!='')
			{
				$local_language_core_lc = $params->get ('CORE_LC');
				//define("CORE_LC", 'croatian');
				define("CORE_LC", $local_language_core_lc);
			}
			if($params->get ('CORE_LC2')!='')
			{
				$local_language_core_lc2 = $params->get ('CORE_LC2');
				//define("CORE_LC2", 'croatian');
				define("CORE_LC2", $local_language_core_lc2);
			}
			if($params->get ('CHARSET')!='')
			{
				$local_language_charset = $params->get ('CHARSET');
				//define("CHARSET", "Windows-1250");
				define("CHARSET", $local_language_charset);
			}


			if($params->get ('DATE_FORMAT_OF_CSV'))
			{
				$date_format_of_csv = $params->get ('DATE_FORMAT_OF_CSV');
			}
			else $date_format_of_csv = 'Y-m-d'; // defaults to date format for converting csv string

			if (($handle = fopen($imgname, "r")) !== FALSE) {
				$this->_query =   'SELECT DISTINCT
	                           CONCAT(c.data_type,
	                                  b.column_id) AS "dataindex" 	                              
                         FROM  #__jgrid_columngrid b,
                               #__jgrid_columns c 
                         WHERE c.id = b.column_id
                         AND   b.grid_id = '.$grid_id.'                         
                         ORDER BY b.ordering'; 						
				$column_index_array = $this->_getList($this->_query);
				// delete previous undo rows
				$this->_db->setQuery('DELETE
		                      FROM  #__jgrid_upload_undo
			                  WHERE (grid_id = '.$grid_id.'
			                           AND document_id = '.$current_document_id.'
			                           AND userid = '.$user->id.' )
			                         OR TIMESTAMPDIFF(DAY, last_updated, NOW()) > '.$redo_days); 		          
				$this->_db->query();
				$selected_row_number = JRequest::getVar('sel_row_id','','','INTEGER');
				$error=false;
				$row_insert_position = JRequest::getVar('row_insert_position','','','INTEGER');
				$column_count = count($column_index_array);
				$column_count_wo_picture = $column_count;
				// strip out picture columns
				for($i=0;$i < $column_count; $i++)
				{
						if($column_index_array[$i]->dataindex[0]=='P') $column_count_wo_picture--;
				}				
				while (($line_array = fgetcsv($handle, 5000, JRequest::getVar('delimiter',',','','STRING'))) !== FALSE)
				{				
					if(!$line_array) break;										
					// check that proper number of columns are in line
					$number_of_fields = count($line_array);
					if($column_count_wo_picture != $number_of_fields)
					{
						fclose($handle);
						unlink($imgname);
						for($i=0;$i <$number_of_fields; $i++)
						{
							if($i!=0) $text_row .= JRequest::getVar('delimiter',',','','STRING');
							$text_row .= $line_array[$i];
						}
						return array(false,JText::_("CSV_FIELD_COUNT_DOES_NOT_MATCH_REQUIRED_GRID_FIELD_COUNT_OF".$column_count_wo_picture." != ".$number_of_fields.": ".$text_row));
					}
					// handle the 0 row condition
					if($selected_row_number == 0)
					{
						$row_insert_position = FIRSTROW;
					}
					else $row_insert_position = ADD_ROW_BELOW;
					$_result = createGridRow('#__jgrid_rows',
					$grid_id,
					$row_insert_position,
					$selected_row_number);
					// just allow first row insert once, then row below for rest.
					if($row_insert_position == FIRSTROW) $row_insert_position = ADD_ROW_BELOW;
					if($_result["id"]>0)
					{
						$new_row_number = $_result['id'];
						$selected_row_number = $_result['id'];

						// update undo row list
						$this->_query = 'INSERT INTO #__jgrid_upload_undo (grid_id,
		                                                                   document_id,
		                                                                   row_id,
		                                                                   userid,
		                                                                   session_id)
                          VALUES ('.$grid_id.',
                                  '.$current_document_id.',
                                  '.$new_row_number.',
                                  '.$user->id.',
                                  "'.$session_id.'")'; 
							
						$this->_db->setQuery( $this->_query);
						$this->_db->query();
					}
					else
					{
						return array(false,JText::_("NEW_ROW_COULD_NOT_BE_CREATED"));
					}
//echo 'sql'.print_r($line_array);
		//JError::raiseError(1001, JText::_('sql'.print_r($line_array)));
			//return;						
					for($i=0,$j=0;$i<count($column_index_array)&&$j<count($line_array);$i++)
					{
						$key=$column_index_array[$i]->dataindex;
						switch (substr($key,0,1))
						{
							//text
							case 'T':
								if(!is_string($line_array[$j]))
								{
									$error = true;
									$error_msg = "Data Value ' . $line_array[$j] .' is not String Data and Does not match Grid Column Data Type";
									break;
								}
								$this->_query = 'UPDATE  #__jgrid_columndata  SET string_data = "' . $line_array[$j] .'"
                                  WHERE column_id = "' . substr($key,1) .'"
	                                 AND row_number = ' . $new_row_number .' 
	                                 AND document_id = '.$current_document_id.'
	                                 AND '.$remove_access_control.' = 0
		                             AND '.$access_control.'>0'; 																								
								break;


								// Integer
							case 'I':
//echo 'sqla '.$line_array[$j];
								if(!(preg_match('@^[-]?[0-9]+$@',$line_array[$j]) === 1))
								{
									$error = true;
									$error_msg = 'Data Value ' . $line_array[$j] . JText::_('IS_NOT_INTEGER_DATA');
									break;
								}
								$this->_query = 'UPDATE  #__jgrid_columndata
	   		                      SET int_data = "' . $line_array[$j] .'" 
	                              WHERE column_id = "' . substr($key,1) .'" 
	                                  AND row_number = ' . $new_row_number .'
	                                 AND document_id = '.$current_document_id.'
	                                 AND '.$remove_access_control.' = 0
		                             AND '.$access_control.'>0';   
								break;
								// Date
							case 'D':
								// clean up date data
								$stamp = strtotime( $line_array[$j] );
								if (!$stamp)
								{
									$stamp = "00000000";
								}
								if (!is_numeric($stamp))
								{
									$error = true;
									$error_msg = 'Data Value ' . $line_array[$j] . JText::_('IS_NOT_DATE_DATA');
									break;
								}
								$month = date( 'm', $stamp );
								$day   = date( 'd', $stamp );
								$year  = date( 'Y', $stamp );

								if (!checkdate($month, $day, $year))
								{
									$error = true;
									$error_msg = 'Data Value ' . $line_array[$j] . JText::_('IS_NOT_DATE_DATA');
									break;
								}
								if(!is_string($line_array[$j]))
								{
									$error = true;
									$error_msg = 'Data Value ' . $line_array[$j] . $line_array[$j] . JText::_('IS_NOT_STRING_DATA');
									break;
								}
								$phpdate = substr($line_array[$j],0,15);
								$dateinteger = strtotime($phpdate);
								$value = (!$dateinteger) ? '00000000' : date('Y-m-d', $dateinteger);

								$this->_query = 'UPDATE  #__jgrid_columndata SET date_data = "'.$value.'"
	   		                      WHERE column_id = "' . substr($key,1) .'" 
	   		                          AND row_number = ' . $new_row_number .' 
	                                 AND document_id = '.$current_document_id.'
	                                 AND '.$remove_access_control.' = 0
		                             AND '.$access_control.'>0';					  
								break;
								// Boolean
							case 'B':
								if(!is_bool(filter_var($line_array[$j], FILTER_VALIDATE_BOOLEAN)))
								{
									$error = true;
									$error_msg = 'Data Value ' . $line_array[$j] . JText::_('IS_NOT_BOOLEAN_DATA');
									break;
								}
								$this->_query = 'UPDATE  #__jgrid_columndata SET boolean_data = "' . $line_array[$j] .'"
	   		                      WHERE column_id = "' . substr($key,1) .	'" 
	                                  AND row_number = ' . $new_row_number .' 
	                                 AND document_id = '.$current_document_id.'
	                                 AND '.$remove_access_control.'=0
		                             AND '.$access_control.'>0';  
								break;
								// Float
							case 'F':
								
								if(!is_numeric($line_array[$j]) && $line_array[$j] != "" )
								{
									$error = true;
									$error_msg = 'Data Value ' . $line_array[$j] . JText::_('IS_NOT_FLOAT_DATA');
									break;
								}
								$this->_query = 'UPDATE  #__jgrid_columndata SET float_data = "' . $line_array[$j] .'"
	   		                      WHERE column_id = "' . substr($key,1) .'" 
	   		                          AND row_number = ' . $new_row_number .' 
	                                 AND document_id = '.$current_document_id.'
	                                 AND '.$remove_access_control.'=0
		                             AND '.$access_control.'>0';
								break;
								//list
							case 'L':
								// validate value is on list and add or skip
								if(!is_string($line_array[$j]))
								{
									$error = true;
									$error_msg = 'Data Value ' . $line_array[$j] . $line_array[$j] . JText::_('IS_NOT_STRING_DATA');
									break;
								}
								$this->_query = 'SELECT  id
								                 FROM #__jgrid_column_list_field_values 
								                 WHERE listboxvalues = "' . $line_array[$i] .'"
								                  AND  column_id = "' . substr($key,1) .'"';
								$this->_db->setQuery($this->_query);
								if($this->_db->query())
								{
									$this->_query = 'UPDATE  #__jgrid_columndata SET string_data = "' . $line_array[$j] .'"
                                    WHERE column_id = "' . substr($key,1) .'"
	                                  AND row_number = ' . $new_row_number .' 
	                                  AND document_id = '.$current_document_id.'
	                                  AND '.$remove_access_control.'=0
		                              AND '.$access_control.'>0';
								}
								else
								{
									break;
								}
								break;
								//Picture
							case 'P':
								//skip column
								continue 2;
								//								$this->_query = 'UPDATE  #__jgrid_columndata SET string_data = "' . $line_array[$i] .'"
								//                                  WHERE column_id = "' . substr($key,1) .'"
								//	                                 AND row_number = ' . $new_row_number .'
								//	                                 AND document_id = '.$current_document_id.'
								//	                                 AND '.$remove_access_control.'=0
								//		                             AND '.$access_control.'>0';
								break;
								//URL
							case 'U':
								if(!is_string($line_array[$j]))
								{
									$error = true;
									$error_msg = 'Data Value ' . $line_array[$j] . $line_array[$j] . JText::_('IS_NOT_STRING_DATA');
									break;
								}
								$this->_query = 'UPDATE  #__jgrid_columndata SET string_data = "' . $line_array[$j] .'"
                                  WHERE column_id = "' . substr($key,1) .'"
	                                 AND row_number = ' . $new_row_number .' 
	                                 AND document_id = '.$current_document_id.'
	                                 AND '.$remove_access_control.'=0
		                             AND '.$access_control.'>0';
								break;
								//Grid Sheet
							case 'S':
								if(!is_string($line_array[$j]))
								{
									$error = true;
									$error_msg = 'Data Value ' . $line_array[$j] . $line_array[$j] . JText::_('IS_NOT_STRING_DATA');
									break;
								}
								$this->_query = 'UPDATE  #__jgrid_columndata SET string_data = "' . $line_array[$j] .'"
                                  WHERE column_id = "' . substr($key,1) .'"
	                                 AND row_number = ' . $new_row_number .' 
	                                 AND document_id = '.$current_document_id.'
	                                 AND '.$remove_access_control.'=0
		                             AND '.$access_control.'>0';
								break;
						}
						if($error==true)
						{
							// delete rows from the grid.
							$this->undo($grid_id,$current_document_id,$user->id,$redo_days);
							return array(false,$error_msg);
						}
						$this->_db->setQuery($this->_query);
						$this->_result = $this->_db->query();
						$j++;
					}
				}
				fclose($handle);
				unlink($imgname);
			}
			else
			{
				return array(false,JText::_("DATABASE_ERROR1_FILE_NOT_SAVED"));
			}
			return array(true,'');
		}
		else
		{
			return array(false,JText::_("FILE_MUST_BE_CSV_COMMA_SEPARATED_VALUES_WITH_A_CSV_EXTENSION"));
		}

	}

	//  undo last csv upload
	function undo_last_csv_upload()
	{
		$db =JFactory::getDBO();
		$user =JFactory::getUser();
		$session = JFactory::getSession();
		$session_id = $session->getId();
		$grid_id=JRequest::getVar('grid_id','','','INTEGER');
	if((JRequest::getVar('application_type','','','STRING')=='MODULE'))
{
	jimport( 'joomla.application.module.helper' );
	$app = JFactory::getApplication();
	$module = JModuleHelper::getModule(JRequest::getVar('jgrid_application_name'));
	$params = new JRegistry();
	if(class_exists('JParameter'))
	{
		$params = new JParameter( $module->params ); 
	}
	else 
	{
	   $params->loadString($module->params);
	}	
}
else 
{
	$params = JComponentHelper::getParams('com_jgrid');
}

		if($params->get ('jgrid_data_loader_redo_days'))
		{
			$redo_days = $params->get ('jgrid_data_loader_redo_days');
		}
		else $redo_days =  15;

		// get current document ID
		$this->_query = 'SELECT g.current_document_id
	   		             FROM #__jgrid_current_user_grid_document g
	   		             WHERE g.userid = ' . $user->id .'
	                       AND g.grid_id = '.$grid_id.'
	                       AND g.session_id = "'.$session_id.'"';
		$db->setQuery($this->_query);
		$current_document_id=$db->loadResult();
		// check user access rights to be edit
		list($admin_user,$access_control,$remove_access_control,$document_security_level) = check_access_control($grid_id,$current_document_id,3);
		if($access_control==0 || $remove_access_control > 0)
		{
			return array(false,JText::_("USER_DOES_NOT_HAVE_ACCESS_RIGHTS_TO_DELETE_UPLOAD_DATA_FROM_GRID"));
		}

		// delete rows from the grid.
		$this->undo($grid_id,$current_document_id,$user->id,$redo_days);

		return array(true,'');
	}


}