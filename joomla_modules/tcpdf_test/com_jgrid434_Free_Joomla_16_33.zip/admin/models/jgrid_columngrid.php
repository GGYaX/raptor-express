
<?php
/**
 * Jgrid_columngrid Model in Joomla/Administrator/Components/models
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.model' );
require_once(JPATH_BASE . '/components/com_jgrid/os/jgrid/functions.php' );

/**
 * Jgrid_columngrid model
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid administrator "Column Settings" screen
 * to "Grid Column Settings"
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */

if(!class_exists('RMWorksAroundJoomlaToGetAModel')) {
	if(interface_exists('JModel')) {
		abstract class RMWorksAroundJoomlaToGetAModel extends JModelLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAModel extends JModel {}
	}
}

class JgridsModelJgrid_columngrid extends RMWorksAroundJoomlaToGetAModel
{
	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The string containing the SQL call (query) that will retrieve the desired results
	 * @var string
	 */
	var $_query=null;

	/**
	 * Retrieves the "Columns assigned to grid" data
	 * @return array containing the "Columns assigned to grid" rows or false if no rows returned
	 *
	 */
	function getColumnGridRows()
	{
		$this->_query = 'SELECT b.id,
		                        b.grid_id, 
		                        b.column_id, 
		                        b.ordering,
		                        b.row_color_pressidence,
		                    	b.column_type,
  								b.database_sql_name_id,
  								b.table_sql_name_id,
  								b.column_sql_name_id,
  								b.primary_key_column,
  								b.formula, 
		                        c.header,
	                            CONCAT(c.data_type,b.id) AS "dataindex", 
	                            a.title 
	                      FROM  #__jgrid_grids a,  
	                            #__jgrid_columngrid b,
	                            #__jgrid_columns c 	                           	                            
	                      WHERE a.id = b.grid_id
	                      AND c.id = b.column_id
	                      AND b.grid_id = '. JRequest::getVar('grid_id','','','INTEGER') .'
	                      ORDER BY b.ordering';			
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;
	}

	/**
	 * Retrieves the jgrid columns that have not been added yet to grid and are available to add in combo box
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function getColumnList()
	{
		$this->_query = 'SELECT  a.id,
		                         a.header
	                      FROM  #__jgrid_columns a
	                      WHERE a.id NOT IN (	SELECT c.column_id
	                                       		FROM	#__jgrid_columns b, 
	                                             		#__jgrid_columngrid c, 
	                                                  	#__jgrid_grids d
	                                      		WHERE d.id = c.grid_id
	                                         		AND b.id = c.column_id
	                                               	AND c.grid_id = '. JRequest::getVar('selected_grid_id','','','INTEGER') .')
	                     ORDER BY a.header';			
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;

	}


	/**
	 * Updates the   "Columns assigned to Grid" data being edited in the  "Add Columns to selected grid" grid
	 * @var array $row_data array of objects sent from the "Add Columns to selected grid" grid containing the values to be updated in the database
	 * @return integer return true if row updated or false if update failed.
	 */
	function updateColumnGridRows()
	{
		$db =JFactory::getDBO();
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		// update if primary key to query  database.table.column
//echo 'sql '.print_r($row_data);	
//return;	
		if($row_data[0]['primary_key_column']==true)
		{	

			// find primary key column of this database.table
			$this->_query = '	SELECT COLUMN_NAME
	                       		FROM information_schema.KEY_COLUMN_USAGE 
		                       	WHERE TABLE_SCHEMA = "'.$row_data[0]['database_sql_name_id'].'"
									AND TABLE_NAME = "'.$row_data[0]['table_sql_name_id'].'"
									AND CONSTRAINT_NAME = "PRIMARY"';					
			$db->setQuery($this->_query);
			$primary_key_column = $db->loadResult();
			$primary_key = $row_data[0]['database_sql_name_id'].'.'.$row_data[0]['table_sql_name_id'].'.'.$primary_key_column;
			
			
			// check to see if primary column has changed and if it has delete all data related to old key
			$this->_query = '	SELECT primary_key_column
	                       		FROM #__jgrid_grids 
		                       	WHERE id = '.$row_data[0]['grid_id'];
			$db->setQuery($this->_query);
			$current_primary_key_column = $db->loadResult();
			if(strcmp($primary_key, $current_primary_key_column))
			{							
				$this->_query = 'UPDATE #__jgrid_grids 	
								SET primary_key_column = "'.$primary_key.'"
								WHERE id = '.$row_data[0]['grid_id'];			
				$this->_db->setQuery($this->_query );
				$this->_result = $this->_db->query($this->_query);
				
				if($this->_result)
				{
					// remove any JGrid data tied to this key
					$db->setQuery('DELETE FROM #__jgrid_data 
	                               WHERE primary_key_value = "'.$current_primary_key_column.'"');
					$db->query();				
				}
			}
		}
		else $row_data[0]['primary_key_column'] = 0; // set to zero if null or false	
		// check to see if data_column assigned and if not assign one.
	  	// find jgrid_data columns in use
		$this->_query = 'SELECT jgrid_data_column
	                       FROM #__jgrid_columngrid 
	                       WHERE id = '.$row_data[0]['id'];
		$db->setQuery($this->_query);
		$jgrid_data_column = $db->loadResult();
		if(!$jgrid_data_column)
		{
			// find the next data column available
			$next_data_column = getNextDataColumn($row_data[0]['grid_id'],$row_data[0]['dataindex'][0]);
		}
	
		$query = 'UPDATE  #__jgrid_columngrid
			                  SET ';  
		if(array_key_exists('row_color_pressidence',$row_data[0])) 	$query .= ' row_color_pressidence ="'.$row_data[0]['row_color_pressidence'].'",';
		if(array_key_exists('formula',$row_data[0])) 				$query .= ' formula ="'.$row_data[0]['formula'].'",';
		if(array_key_exists('column_type',$row_data[0]))  			$query .=    ' column_type="'.$row_data[0]['column_type'].'",'; 
		if(array_key_exists('database_sql_name_id',$row_data[0]))  	$query .=    ' database_sql_name_id="'.$row_data[0]['database_sql_name_id'].'",';
		if(array_key_exists('table_sql_name_id',$row_data[0]))  	$query .=    ' table_sql_name_id="'.$row_data[0]['table_sql_name_id'].'",';
		if(array_key_exists('column_sql_name_id',$row_data[0]))  	$query .=    ' column_sql_name_id="'.$row_data[0]['column_sql_name_id'].'",';
		if(array_key_exists('primary_key_column',$row_data[0])) 	$query .=    ' primary_key_column='.$row_data[0]['primary_key_column'].',';
		if($next_data_column) 	$query .=    ' jgrid_data_column = "'.$next_data_column.'",';
		
		$query[strlen($query)-1] = ' '; 
	    $query .=              ' WHERE id = '.$row_data[0]['id'];
	    
		$this->_db->setQuery($query);	
		if($this->_db->query()) return true;
		else return false;
	}

	/**
	 * Creates new column assigned to grid  in the "Add Columns to selected grid" grid
	 * @var array $row_data array of objects sent from the "Add Columns to selected grid" grid containing the values to be updated in the database
	 * @var integer $last_id the database row id of the new column grid assignment to be returned to the grid
	 * @return array return the new column assigned to grid data that was updated ($last_id) to the grid row or false if row not created.
	 */
	function createColumnGridRow()
	{
		$user=JFactory::getUser();
		$db =JFactory::getDBO();
		$app = JFactory::getApplication();
    	$database_schema= $app->getCfg('db');
		//insert row
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		// add default database name
		if(!$row_data[0]['database_sql_name_id']) $row_data[0]['database_sql_name_id'] = $database_schema;
		// Find last record row_id ID
		if(JRequest::getVar('last_record_id','','','INTEGER')==0)
		{
			$last_record_ordering = 0;
		}
		else {
			$db->setQuery('SELECT ordering
	                          FROM #__jgrid_columngrid
	                          WHERE id = ' . JRequest::getVar('last_record_id','','','INTEGER'));
			$last_record_ordering = $db->loadResult();
		}
	  	// find column data type
		$this->_query = 'SELECT a.data_type, 
								a.ddefault
	                       FROM #__jgrid_columns a
	                       WHERE a.id = '.$row_data[0]['column_id'];
		$db->setQuery($this->_query);
		$column_data_array = $db->loadObjectList();
		
		// find the next data column available
		$next_data_column = getNextDataColumn($row_data[0]['grid_id'],$column_data_array[0]->data_type);
		
		$this->_db->setQuery( 'INSERT  INTO #__jgrid_columngrid (column_id,
		                                                         grid_id,  
		                                                         ordering,
		                                                         formula,
		                                                         jgrid_data_column,
		                                                         database_sql_name_id)
			                   VALUES ('.$row_data[0]['column_id'].',
			                           '.$row_data[0]['grid_id'].',
			                           '.$last_record_ordering.'+1,
			                           "",
			                           "'.$next_data_column.'",
		                               "'.$row_data[0]['database_sql_name_id'].'")');		              
		$this->_result = $this->_db->query();

		//find new row id and return
		$this->_db->setQuery('SELECT last_insert_id() FROM #__jgrid_columngrid');
		$last_id = $this->_db->loadResult();
		$row_data[0]["id"] = $last_id;
		$row_data[0]["row_color_pressidence"] = 9;
		$row_data[0]["column_type"] = 1;
		$row_data[0]["formula"] = '';
		$row_data[0]["dataindex"] = $column_data_array[0]->data_type.$last_id;

		// Put in liked list and ordering
		$this->_db->setQuery('UPDATE #__jgrid_columngrid
                              SET parent_id = '.JRequest::getVar('last_record_id','','','INTEGER').'
                              WHERE id = '.$last_id);
		$this->_db->query();
		//If first column added default the group by and sort by columns
		if(JRequest::getVar('last_record_id','','','INTEGER')==0)
		{
			$this->_db->setQuery('UPDATE  #__jgrid_grids
			                        SET  groupByField= (SELECT header
			                                            FROM #__jgrid_columns
			                                            WHERE id = '.$row_data[0]['column_id'].'), 
			                             sortByField = (SELECT header
			                                            FROM #__jgrid_columns
			                                            WHERE id = '.$row_data[0]['column_id'].')
	                                WHERE id = '.$row_data[0]['grid_id']);
			$this->_db->query();
		}

		
		
		//Update columndata to store column data
		$this->_query = 'INSERT INTO #__jgrid_columndata  (
	          column_id,
	          columngrid_id,	                          
	          column_header,
	          row_number,
	          userid,';
		switch ($column_data_array[0]->data_type)
		{
			// text
			case 'T':
			 // List Box
			case 'L':
				// Picture Image
			case 'P':
				// URL
			case 'U':
				// Grid Sheet
			case 'S':
				// EMail
			case 'E':								
				$this->_query .= 'string_data,';				
				break;
				// Integer
			case 'I':
				$this->_query .= 'int_data,';
				break;
			 // Date
			case 'D':
				$this->_query .= 'date_data,';
				break;
				// Boolean
			case 'B':
				$this->_query .= 'boolean_data,';
				break;
				// Float
			case 'F':
				$this->_query .= 'float_data,';
				break;

		}
		$this->_query .= 'document_id)
                             SELECT DISTINCT '.$row_data[0]['column_id'].',
                             		'.$row_data[0]["id"].', 
	                                "'.$row_data[0]['header'].'",
	                                b.id,
	                                '. $user->id .',
	                                "'.$column_data_array[0]->ddefault.'",
	                                b.document_id
	                         FROM #__jgrid_rows b
	                         where b.grid_id = '.$row_data[0]['grid_id']; 
//echo 'sql '.$this->_query;        
		$this->_db->setQuery($this->_query);
		$this->_db->query();
		
		// delete old grid view
		dropGridJView($row_data[0]['grid_id']);
		
		//create view
		addGridJView($row_data[0]['grid_id']);
		
		if($last_id) return $row_data[0];
		else return false;
	}

	/**
	 * Moves grid order in  "Data Grid Settings" grid
	 * @return integer result true if grid moved or false if move failed
	 */
	function moveColumn()
	{
		return moveGridColumn('#__jgrid_columngrid',
		JRequest::getVar('grid_id','','','INTEGER'),
		JRequest::getVar("number_of_records","","","INTEGER"),
		JRequest::getVar('new_above_record_id','','','INTEGER'),
		JRequest::getVar('new_record_below_id','','','INTEGER'),
		JRequest::getVar('first_record_id','','','INTEGER'),
		JRequest::getVar('last_record_id','','','INTEGER'));
	}

	//	/**
	//	 * Moves grid order in  "Data Grid Settings" grid
	//	 * @return integer result true if grid moved or false if move failed
	//	 */
	//	function moveGridRowh($table)
	//	{
	//		$now_row_below=false;
	//	    if(JRequest::getVar('new_above_record_id','','','INTEGER')==-1)
	//		{
	//			$new_record_below_id=JRequest::getVar('new_record_below_id','','','INTEGER');
	//			//Get record id above new insert record location
	//		  	$this->_db->setQuery('SELECT parent_id FROM '.$table.'
	//                                  WHERE id ='.$new_record_below_id);
	//		    $new_above_record_id = $this->_db->loadResult();
	//		    $new_above_record_ordering =0;
	//		}
	//		else
	//		{
	//			$new_above_record_id=JRequest::getVar('new_above_record_id','','','INTEGER');
	//			//Get new_above_record_ordering
	//			$this->_db->setQuery('SELECT ordering FROM '.$table.'
	//                                  WHERE id ='.$new_above_record_id);
	//			$new_above_record_ordering=$this->_db->loadResult();
	//			//Get record id below new insert record location
	//		    $this->_db->setQuery('SELECT id FROM '.$table.'
	//                                  WHERE parent_id ='.$new_above_record_id);
	//		    $new_record_below_id = $this->_db->loadResult();
	//		    if(!$new_record_below_id) $no_row_below=true;
	//		}
	//		//Get record id above first record_id to be moved and first record ordering
	//		$this->_query = 'SELECT parent_id, ordering
	//		                      FROM '.$table.'
	//                              WHERE id ='.JRequest::getVar('first_record_id','','','INTEGER');
	//		$this->_result = $this->_getList( $this->_query );
	//		$first_record_ordering=$this->_result[0]->ordering;
	//		$old_record_above_id=$this->_result[0]->parent_id;
	////		//Get record id below last record to be moved
	////		$this->_db->setQuery('SELECT id
	////                              FROM '.$table.'
	////                              WHERE parent_id ='.JRequest::getVar('last_record_id','','','INTEGER'));
	////		$old_record_below_id=$this->_db->loadResult();
	//		// Get last record ordering
	//		$this->_db->setQuery('SELECT ordering
	//                              FROM '.$table.'
	//                              WHERE id ='.JRequest::getVar('last_record_id','','','INTEGER'));
	//		$last_record_ordering=$this->_db->loadResult();
	//		//remove rows from list
	//		$this->_db->setQuery('UPDATE '.$table.'
	//                             SET parent_id = '.$old_record_above_id.'
	//                             WHERE id = (SELECT id FROM
	//                                                  (SELECT id
	//                                                   FROM '.$table.'
	//                                                   WHERE parent_id ='.JRequest::getVar('last_record_id','','','INTEGER').') AS temp_table1
	//                                         )');
	//		$this->_db->query();
	//		// insert rows back into linked list
	//		// insert bottom row
	//		if($no_row_below==false)
	//		{
	//	    	$this->_db->setQuery('UPDATE '.$table.'
	//                                  SET parent_id = '.JRequest::getVar('last_record_id','','','INTEGER').'
	//                                  WHERE id ='. $new_record_below_id);
	//	    	$this->_db->query();
	//		}
	//
	//		// Insert top row
	//		$this->_db->setQuery('UPDATE '.$table.'
	//                             SET parent_id = '.$new_above_record_id.'
	//                             WHERE id = '.JRequest::getVar('first_record_id','','','INTEGER'));
	//		$this->_db->query();
	//
	//		// now move the ordering to match
	//		if(JRequest::getVar('newIndex','','','INTEGER') < JRequest::getVar('oldIndex','','','INTEGER'))
	//		{
	//		// Select column rows to be moved out of ordering by adding 999999999 to order
	//		$this->_db->setQuery('UPDATE '.$table.'
	//                            SET ordering = ordering
	//                                           + 999999999
	//                                           - '.$first_record_ordering.'
	//                                           + '.$new_above_record_ordering.'
	//                                           +1
	//                            WHERE ordering >=  '.$first_record_ordering.'
	//                            AND   ordering <= '.$last_record_ordering.'
	//                            ORDER BY ordering');
	//		$this->_db->query();
	//			// Make roow for moved columns
	//			$this->_db->setQuery('UPDATE '.$table.'
	//                                  SET ordering = ordering
	//                                                 + '.JRequest::getVar("number_of_records","","","INTEGER").'
	//                                  WHERE ordering > '.$new_above_record_ordering.'
	//                                  AND   ordering <= '.$last_record_ordering.'
	//                                  ORDER BY ordering');
	//			$this->_db->query();
	//		}
	//		else if (JRequest::getVar('newIndex','','','INTEGER') > JRequest::getVar('oldIndex','','','INTEGER'))
	//		{
	//		// Select column rows to be moved out of ordering by adding 999999999 to order
	//		$this->_db->setQuery('UPDATE '.$table.'
	//                            SET ordering = ordering
	//                                           + 999999999
	//                                           - '.$first_record_ordering.'
	//                                           + '.$new_above_record_ordering.'
	//                                           - '.JRequest::getVar("number_of_records","","","INTEGER").'
	//                                           +1
	//                            WHERE ordering >=  '.$first_record_ordering.'
	//                            AND   ordering <= '.$last_record_ordering.'
	//                            ORDER BY ordering');
	//		$this->_db->query();
	//			// Make roow for moved columns
	//			$this->_db->setQuery('UPDATE '.$table.'
	//                                  SET ordering = ordering
	//                                                 - '.JRequest::getVar("number_of_records","","","INTEGER").'
	//                                  WHERE ordering <= '.$new_above_record_ordering.'
	//                                  AND   ordering > '.$first_record_ordering.'
	//                                  ORDER BY ordering');
	//			$this->_db->query();
	//		}
	//		else return true;
	//
	//		// Insert new columns into order
	//		$this->_db->setQuery('UPDATE '.$table.'
	//                            SET ordering = ordering - 999999999
	//                            WHERE ordering >= 999999999
	//                            ORDER BY ordering');
	//		if($this->_db->query())return true;
	//		else return false;
	//	}




	//	/**
	//	 * Moves Column order in  "Add Columns to selected grid" grid
	//	 * @return integer result true if grid moved or false if move failed
	//	 */
	//	function moveColumn()
	//	{
	//		// RMS if new above_record_id == 0 check to make sure it is 0 by looking at either old grid location 0 record parent_id
	//		if(JRequest::getVar('new_above_record_id','','','INTEGER')==-1){
	//			$new_record_below_id=JRequest::getVar('new_record_below_id','','','INTEGER');
	//			//Get record id above new insert record location
	//			$this->_db->setQuery('SELECT parent_id FROM #__jgrid_columngrid
	//                                  WHERE id ='.$new_record_below_id);
	//			$new_above_record_id = $this->_db->loadResult();
	//			$new_above_record_ordering =0;
	//		}
	//		else {
	//			$new_above_record_id = JRequest::getVar('new_above_record_id','','','INTEGER');
	//			//Get new_above_record_ordering
	//			$this->_db->setQuery('SELECT ordering FROM #__jgrid_columngrid
	//                                  WHERE id ='.$new_above_record_id);
	//			$new_above_record_ordering=$this->_db->loadResult();
	//			//Get record id below new insert record location
	//			$this->_db->setQuery('SELECT id FROM #__jgrid_columngrid
	//                                  WHERE parent_id ='.$new_above_record_id);
	//			$new_record_below_id = $this->_db->loadResult();
	//		}
	//		//Get record id above first record_id to be moved and first record ordering
	//
	//		//echo 'new_above_record_id = '.$new_above_record_id. 'new_record_below_id ='.$new_record_below_id. 'new_above_record_id2 ='.$new_above_record_id2;
	//		$this->_query = 'SELECT parent_id, ordering
	//		                      FROM #__jgrid_columngrid
	//                              WHERE id ='.JRequest::getVar('first_record_id','','','INTEGER');
	//		$this->_result = $this->_getList( $this->_query );
	//		$first_record_ordering=$this->_result[0]->ordering;
	//		$old_record_above_id=$this->_result[0]->parent_id;
	//		//Get record id below last record to be moved
	//		$this->_db->setQuery('SELECT id
	//                              FROM #__jgrid_columngrid
	//                              WHERE parent_id ='.JRequest::getVar('last_record_id','','','INTEGER'));
	//		$old_record_below_id=$this->_db->loadResult();
	//		// Get last record ordering
	//		$this->_db->setQuery('SELECT ordering
	//                              FROM #__jgrid_columngrid
	//                              WHERE id ='.JRequest::getVar('last_record_id','','','INTEGER'));
	//		$last_record_ordering=$this->_db->loadResult();
	//		// Find top and bottom of range based on the selection index location
	//		//		if(JRequest::getVar('newIndex','','','INTEGER') < JRequest::getVar('oldIndex','','','INTEGER')){
	//		//			$id_above_top_of_move_range=$old_record_above_id;
	//		//			$id_below__bottom_of_move_range=$new_record_below_id;
	//		//		}
	//		//		else if (JRequest::getVar('newIndex','','','INTEGER') > JRequest::getVar('oldIndex','','','INTEGER')){
	//		//			$id_above_top_of_move_range=$new_above_record_id;
	//		//			$id_below_bottom_of_move_range=$old_record_below_id;
	//		//		}
	//		//		else return true;
	//		//remove rows from list
	//		$this->_db->setQuery('UPDATE #__jgrid_columngrid
	//                             SET parent_id = (SELECT parent_id FROM
	//                                                (SELECT parent_id
	//                                                     FROM #__jgrid_columngrid
	//                                                     WHERE id ='.JRequest::getVar('first_record_id','','','INTEGER').') AS temp_table1
	//                                             )
	//                             WHERE id = (SELECT id FROM
	//                                                  (SELECT id
	//                                                   FROM #__jgrid_columngrid
	//                                                   WHERE parent_id ='.JRequest::getVar('last_record_id','','','INTEGER').') AS temp_table2)');
	//		$this->_db->query();
	//		// insert rows back into linked list
	//		// insert bottom row
	//		$this->_db->setQuery('UPDATE #__jgrid_columngrid
	//                             SET parent_id = '.JRequest::getVar('last_record_id','','','INTEGER').'
	//                             WHERE id ='. $new_record_below_id);
	//		$this->_db->query();
	//		// Insert top row
	//
	//		$this->_db->setQuery('UPDATE #__jgrid_columngrid
	//                              SET parent_id = '.$new_above_record_id.'
	//                              WHERE id = '.JRequest::getVar('first_record_id','','','INTEGER').'');
	//		$this->_db->query();
	//		// now move the ordering to match
	//		// Select column rows to be moved out of ordering by adding 999999999 to order
	//		$this->_db->setQuery('UPDATE #__jgrid_columngrid
	//                            SET ordering = ordering + 999999999 - '.$first_record_ordering.' + '.$new_above_record_ordering.' +1
	//                            WHERE ordering >=  '.$first_record_ordering.'
	//                            AND   ordering <= '.$last_record_ordering.'
	//                            AND grid_id = '.JRequest::getVar('grid_id','','','INTEGER').'
	//                            ORDER BY ordering');
	//		$this->_db->query();
	//
	//		// Make room for moved columns
	//		if(JRequest::getVar('newIndex','','','INTEGER') < JRequest::getVar('oldIndex','','','INTEGER'))
	//		{
	//			$this->_db->setQuery('UPDATE #__jgrid_columngrid
	//                                  SET ordering = ordering + '.JRequest::getVar("number_of_records","","","INTEGER").'
	//                                  WHERE ordering > '.$new_above_record_ordering.'
	//                                  AND   ordering <= '.$last_record_ordering.'
	//                                  AND grid_id = '.JRequest::getVar('grid_id','','','INTEGER').'
	//                                  ORDER BY ordering');
	//			$this->_db->query();
	//		}
	//		else if (JRequest::getVar('newIndex','','','INTEGER') > JRequest::getVar('oldIndex','','','INTEGER'))
	//		{
	//			$this->_db->setQuery('UPDATE #__jgrid_columngrid
	//                                  SET ordering = ordering - '.JRequest::getVar("number_of_records","","","INTEGER").'
	//                                  WHERE ordering <= '.$new_above_record_ordering.'
	//                                  AND   ordering > '.$first_record_ordering.'
	//                                  AND grid_id = '.JRequest::getVar('grid_id','','','INTEGER').'
	//                                  ORDER BY ordering');
	//			$this->_db->query();
	//		}
	//		else return true;
	//
	//		// Insert new columns into order
	//		$this->_db->setQuery('UPDATE #__jgrid_columngrid
	//                            SET ordering = ordering - 999999999
	//                            WHERE ordering > 999999999
	//                            AND grid_id = '.JRequest::getVar('grid_id','','','INTEGER').'
	//                            ORDER BY ordering');
	//		if($this->_db->query())return true;
	//		else return false;
	//
	//
	//
	//
	//
	//		// RMS reset ordering with linked list traverse  (under development)
	//		//       $this->_db->setQuery('SET @pos=(SELECT ordering
	//		//                                       FROM #__jgrid_columngrid
	//		//                                       WHERE id = '.$id_above_top_of_move_range.')');
	//		//       $this->_db->query();
	//		//
	//		//        $this->_db->setQuery('INSERT INTO b.ordering
	//		//                              SELECT @pos:=@pos+1
	//		//                              FROM    (
	//		//                                      SELECT @r AS _parent,
	//		//                                            @r :=
	//		//                                            (
	//		//                                             SELECT  id
	//		//                                             FROM    #__jgrid_columngrid
	//		//                                             WHERE   parent_id = _parent
	//		//                                            ) AS id
	//		//	                              FROM  (
	//		//                                     SELECT  @r := $id_above_top_of_move_range
	//		//                                     ) vars,
	//		//                                     #__jgrid_columngrid
	//		//                                     WHERE @r IS NOT NULL
	//		//                                     AND ??? to stop $id_below_bottom_of_move_range
	//		//                                     )q
	//		//		                         JOIN #__jgrid_columngrid a
	//		//                                 ON a.id = q.id
	//		//
	//	}

	/**
	 * Deletes column assigned to grid record (row) in the "Add Columns to selected grid" grid
	 * @var integer $row_id the database row id of the row to be deleted.
	 * @return integer result true if row deleted or false if delete failed
	 */

	function deleteColumnGridRow()
	{
		$db =JFactory::getDBO();
		
		// RMS first get the ordering then delete

		//delete data rows stored in column to be removed from all sheets used in where the column is used on this grid
		$rows = json_decode(JRequest::getVar('rows','','','STRING'),TRUE);

		for($n=0; $n<count($rows);$n++)
		{
    	
			$query = 'SELECT a.id
	                  FROM 	#__jgrid_columndata a,
	                  	 	#__jgrid_columngrid b,
	                  	 	#__jgrid_document c
	                  WHERE  b.id = '.$rows[$n]["id"].'
			        	AND b.column_id = a.column_id
			         	AND c.id = a.document_id';
		
			$this->_count = $this->_getListCount( $query );
			if($this->_count!=0)
			{
				// delete 
				$this->_data = $this->_getList( $query );
				for ($i=0;$i<$this->_count;$i++)
				{
					
					$query = 'DELETE FROM  #__jgrid_columndata 
			                      WHERE id = '.$this->_data[$i]->id;
					$db->setQuery($query);
					$result=$db->query();			
				}
			}

			// removedata from jgrid_data
			$this->_db->setQuery('SELECT jgrid_data_column
	                              FROM #__jgrid_columngrid 
	                              WHERE id ='.$rows[$n]["id"]);
			$jgrid_data_column = $this->_db->loadResult();

			if($jgrid_data_column)
			{
				$query = 'UPDATE #__jgrid_data
						  SET '. $jgrid_data_column .' = ""
				                      WHERE grid_id = '.$rows[$n]["grid_id"];
				$db->setQuery($query);
				$result=$db->query();
			}
	
			// remove gridcolumn from linked list row order
			// Get id of row below deleted row
			$this->_db->setQuery('SELECT id
	                              FROM #__jgrid_columngrid 
	                              WHERE parent_id ='.$rows[$n]["id"]);
			$below_deleted_row_id = $this->_db->loadResult();
			if($below_deleted_row_id)
			{
				$this->_db->setQuery('UPDATE #__jgrid_columngrid
		                              SET parent_id = (SELECT parent_id FROM 
		                                                (SELECT parent_id 
		                                                 FROM #__jgrid_columngrid 
		                                                 WHERE id ='.$rows[$n]["id"].') AS temp_table1
		                                             )
		                              WHERE id = '.$below_deleted_row_id);
				$this->_db->query();
				
				// Reorder column ordering below removed ID
				$this->_db->setQuery('UPDATE #__jgrid_columngrid
		                              SET ordering = ordering - 1
		                              WHERE ordering >= (SELECT ordering FROM
		                              						(SELECT ordering 
		                                                	 FROM #__jgrid_columngrid
		                                                	 WHERE id = '.$below_deleted_row_id.') AS temp_table1
		                                              ) 
		                              AND grid_id = '.$rows[$n]["grid_id"]);
				$this->_db->query();
			}	
	
			//delete column from  grid it is used in
			$this->_db->setQuery('DELETE FROM  #__jgrid_columngrid
				                  WHERE id = '.$rows[$n]["id"]);
			$this->result = $this->_db->query();
		}
		
		// delete old grid view
		dropGridJView($rows[0]["grid_id"]);
		
		//create view
		addGridJView($rows[0]["grid_id"]);
		
		if($this->result)return true;
		else return false;
	}
	
	/**
	 * selects jgrid_columngrid_column_type combo list valid entries
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function jgrid_columngrid_column_type()
	{
		$this->_query = 'SELECT  a.id,
		                         a.column_type_name
	                      FROM  #__jgrid_columngrid_column_type a
	                     ORDER BY a.column_type_name';			
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;

	}

	
	/**
	 * selects database_sql_name combo list valid entries
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function database_sql_name()
	{
		$grid_id = JRequest::getVar('grid_id','','','INTEGER');
		$this->_query = 'SELECT  a.SCHEMA_NAME as database_sql_name,
								 a.SCHEMA_NAME as database_sql_name_id,
								 a.SCHEMA_NAME as jdatabase_sql_name_id  
	                      FROM  information_schema.SCHEMATA a
	                     ORDER BY a.SCHEMA_NAME';			
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
	//echo print_r($this->_result);
	//return;	
		// Add databases already in use at the top
		$this->_query = 'SELECT * FROM (SELECT DISTINCT a.database_sql_name_id as database_sql_name,
								 			a.database_sql_name_id as database_sql_name_id,
								 			a.database_sql_name_id as jdatabase_sql_name_id 
	                      FROM  #__jgrid_columngrid a
	                       WHERE a.grid_id = '. $grid_id .'
	                       	AND column_type > 1
	                     UNION
	                     SELECT DISTINCT 	b.database_sql_name_id as database_sql_name,
								 			b.database_sql_name_id as database_sql_name_id,
								 			b.database_sql_name_id as jdatabase_sql_name_id 
	                      FROM  #__jgrid_select_join_criteria b
	                       WHERE b.grid_id = '. $grid_id .'
	                     UNION
	                     SELECT DISTINCT 	c.jdatabase_sql_name_id as database_sql_name,
								 			c.jdatabase_sql_name_id as database_sql_name_id,
								 			c.jdatabase_sql_name_id as jdatabase_sql_name_id 
	                      FROM  #__jgrid_select_join_criteria c
	                       WHERE c.grid_id = '. $grid_id .') AS temptable1
	                     ORDER BY database_sql_name';
				
		$inUseTablesCount = $this->_getListCount( $this->_query );
		
		
		if($inUseTablesCount)
		{
			$inUseTables = $this->_getList( $this->_query );					
			$this->_result = array_merge($inUseTables,$this->_result);			
		}
		
		if($this->_result) return array(count($this->_result),$this->_result);
		else return false;

	}
	
	/**
	 * selects table_sql_name combo list valid entries
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function table_sql_name()
	{
		$grid_id = JRequest::getVar('grid_id','','','INTEGER');
		$database_sql_name = JRequest::getVar('database_sql_name','','','STRING');
		$this->_query = 'SELECT  a.TABLE_NAME as table_sql_name,
								 a.TABLE_NAME as table_sql_name_id,
								 a.TABLE_NAME as jtable_sql_name_id
	                      FROM  information_schema.tables a
	                      WHERE TABLE_SCHEMA = "'.$database_sql_name.'"
	                     ORDER BY a.TABLE_NAME';			
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );

		// add tables already in call to top of result
		$this->_query = 'SELECT * FROM (SELECT DISTINCT a.table_sql_name_id as table_sql_name,
								 			a.table_sql_name_id as table_sql_name_id,
								 			a.table_sql_name_id as jtable_sql_name_id 
	                      FROM  #__jgrid_columngrid a
	                       WHERE a.grid_id = '. $grid_id .'
	                       	AND column_type > 1
	                     UNION
	                     SELECT DISTINCT 	b.table_sql_name_id as table_sql_name,
								 			b.table_sql_name_id as table_sql_name_id,
								 			b.table_sql_name_id as jtable_sql_name_id 
	                      FROM  #__jgrid_select_join_criteria b
	                       WHERE b.grid_id = '. $grid_id .'
	                     UNION
	                     SELECT DISTINCT 	c.jtable_sql_name_id as table_sql_name,
								 			c.jtable_sql_name_id as table_sql_name_id,
								 			c.jtable_sql_name_id as jtable_sql_name_id 
	                      FROM  #__jgrid_select_join_criteria c
	                       WHERE c.grid_id = '. $grid_id .') AS temptable1
	                     ORDER BY table_sql_name';			
		$inUseTablesCount = $this->_getListCount( $this->_query );
		if($inUseTablesCount)
		{
			$inUseTables = $this->_getList( $this->_query );
			$this->_result = array_merge($inUseTables,$this->_result);
		}		
		
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;

	}
	
	/**
	 * selects column_sql_name combo list valid entries
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function column_sql_name()
	{
		$database_sql_name = JRequest::getVar('database_sql_name','','','STRING');
		$table_sql_name = JRequest::getVar('table_sql_name','','','STRING');
		$this->_query = 'SELECT  a.COLUMN_NAME as column_sql_name,
								 a.COLUMN_NAME as column_sql_name_id,
								 a.COLUMN_NAME as jcolumn_sql_name_id
	                      FROM  information_schema.columns a
	                      WHERE TABLE_SCHEMA = "'.$database_sql_name.'"
	                      	AND TABLE_NAME = "'.$table_sql_name.'" 
	                     ORDER BY a.COLUMN_NAME';		
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;

	}
	
	/**
	 * Retrieves the select criteria 
	 * @return array containing the "Columns assigned to grid" rows or false if no rows returned
	 *
	 */
	function readJoinCriteria()
	{
		$this->_query = 'SELECT a.id,
		                        a.grid_id, 
		                        a.criteria_type_id,
								a.database_sql_name_id,
								a.table_sql_name_id,
								a.column_sql_name_id,
								a.criteria_operator_id,
								a.jdatabase_sql_name_id,
								a.jtable_sql_name_id,
								a.jcolumn_sql_name_id,
								a.select_wildcard_id,
								a.criteria_value
	                      FROM  #__jgrid_select_join_criteria a 	                           	                            
	                      WHERE a.grid_id = '. JRequest::getVar('selected_grid_id','','','STRING');			
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;
	}


	/**
	 * Updates the select criteria
	 * @return integer return true if row updated or false if update failed.
	 */
	function updateJoinCriteria()
	{
		$db =JFactory::getDBO();
		
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		
		$query = 'UPDATE  #__jgrid_select_join_criteria
			                  SET ';  
		if(array_key_exists('criteria_type_id',$row_data[0])) 		$query .= ' criteria_type_id ="'.$row_data[0]['criteria_type_id'].'",';
		if(array_key_exists('database_sql_name_id',$row_data[0]))  	$query .=    ' database_sql_name_id="'.$row_data[0]['database_sql_name_id'].'",';
		if(array_key_exists('table_sql_name_id',$row_data[0]))  	$query .=    ' table_sql_name_id="'.$row_data[0]['table_sql_name_id'].'",';
		if(array_key_exists('column_sql_name_id',$row_data[0]))  	$query .=    ' column_sql_name_id="'.$row_data[0]['column_sql_name_id'].'",';
		if(array_key_exists('criteria_operator_id',$row_data[0])) 	$query .= 	 ' criteria_operator_id ="'.$row_data[0]['criteria_operator_id'].'",';
		if(array_key_exists('jdatabase_sql_name_id',$row_data[0])) 	$query .=    ' jdatabase_sql_name_id="'.$row_data[0]['jdatabase_sql_name_id'].'",';
		if(array_key_exists('jtable_sql_name_id',$row_data[0]))  	$query .=    ' jtable_sql_name_id="'.$row_data[0]['jtable_sql_name_id'].'",';
		if(array_key_exists('jcolumn_sql_name_id',$row_data[0]))  	$query .=    ' jcolumn_sql_name_id="'.$row_data[0]['jcolumn_sql_name_id'].'",';
		if(array_key_exists('select_wildcard_id',$row_data[0]))  	$query .=    ' select_wildcard_id="'.$row_data[0]['select_wildcard_id'].'",';
		if(array_key_exists('criteria_value',$row_data[0])) 		$query .=    ' criteria_value="'.$row_data[0]['criteria_value'].'",';
		$query[strlen($query)-1] = ' '; 
	    $query .=              ' WHERE id = '.$row_data[0]['id'];   
		$this->_db->setQuery($query);		
		if($this->_db->query()) return true;
		else return false;
	}

	/**
	 * Creates a new select criterial where clause rule
	 * @return array return the new column assigned to grid data that was updated ($last_id) to the grid row or false if row not created.
	 */
	function createJoinCriteria()
	{
		$user=JFactory::getUser();
		$db =JFactory::getDBO();
		$app = JFactory::getApplication();
    	$database_schema= $app->getCfg('db');
		//insert row
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		// add default database name
		if(!$row_data[0]['database_sql_name_id']) $row_data[0]['database_sql_name_id'] = $database_schema;
		if(!$row_data[0]['jdatabase_sql_name_id']) $row_data[0]['jdatabase_sql_name_id'] = $database_schema;
			  
		$this->_db->setQuery( 'INSERT  INTO #__jgrid_select_join_criteria (	grid_id,  
		                                                         			database_sql_name_id,
		                                                         			Jdatabase_sql_name_id)
			                   VALUES ('.$row_data[0]['grid_id'].',
			                   			"'.$row_data[0]['database_sql_name_id'].'",
		                               	"'.$row_data[0]['jdatabase_sql_name_id'].'")');		              
		$this->_result = $this->_db->query();

		//find new row id and return
		$this->_db->setQuery('SELECT last_insert_id() FROM #__jgrid_select_join_criteria');
		$last_id = $this->_db->loadResult();
		$row_data[0]["id"] = $last_id;

		if($last_id) return $row_data[0];
		else return false;
	}


	/**
	 * Deletes SELECT CRITERIA VALUE
	 * @return integer result true if row deleted or false if delete failed
	 */

	function destroyJoinCriteria()
	{
		$db =JFactory::getDBO();


		//delete data rows stored in column to be removed from all sheets used in where the column is used on this grid
		$rows = json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		for ($i=0;$i<count($rows);$i++)
		{
			$query = '	DELETE FROM  #__jgrid_select_join_criteria
			 			WHERE id = '.$rows[$i]['id'];
			$db->setQuery($query);
			$this->result = $db->query();			
		}

		if($this->result)return true;
		else return false;
	}
	
		
	/**
	 * selects jgrid_select_wildcards combo list valid entries
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function jgrid_select_wildcards()
	{
		$this->_query = 'SELECT	a.id,
								a.select_wildcard as select_wildcard_id,	
		                     	a.select_wildcard
	                      FROM  #__jgrid_select_wildcards a
	                     ORDER BY a.select_wildcard';			
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;

	}
	
	/**
	 * selects jgrid_select_criteria_type combo list valid entries
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function jgrid_select_criteria_type()
	{
		$this->_query = 'SELECT  a.id AS criteria_type_id,
		                         a.criteria_type
	                      FROM  #__jgrid_select_criteria_type a
	                     ORDER BY a.criteria_type';			
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;

	}
	
	/**
	 * selects  Database Select Query
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function read_jgrid_select_query()
	{
		$this->_query =	'SELECT	a.id,
    							a.grid_id, 
              					a.sql_query,
              					a.validated,
                           		a.database_sql_name_id,
	                          	a.table_sql_name_id,
	                          	a.p_column_sql_name_id
	                	FROM  #__jgrid_select_query a
	                  	WHERE a.grid_id = '. JRequest::getVar('selected_grid_id','','','STRING');				
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;

	}

	/**
	 * selects Custom SQL QUERY Saved in DATABASE
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function read_jgrid_custom_sql_query()
	{
		$this->_query = 'SELECT	a.id,
    							a.grid_id, 
              					a.sql_query,
              					a.validated
	                 	FROM  #__jgrid_custom_select_query a
	                	WHERE a.grid_id = '. JRequest::getVar('selected_grid_id','','','STRING');			
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;

	}

	/**
	 * selects Custom Where Clause Depedencies 
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function read_jgrid_select_custom_criteria()
	{
		$this->_query = 'SELECT	a.id,
    							a.grid_id, 
		                      	a.custom_where_query
	                   	FROM  #__jgrid_select_custom_criteria a
	                   	WHERE a.grid_id = '. JRequest::getVar('selected_grid_id','','','STRING');	
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;

	}	
	
	
	/**
	 * test and update select query 
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function update_jgrid_select_query()
	{
		$db =JFactory::getDBO();
		$rows = json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		
		// Check to see if string has changed
		$this->_query =	'SELECT	a.id,
    							a.grid_id, 
              					a.sql_query,
              					a.validated
	                	FROM  #__jgrid_select_query a
	                  	WHERE a.grid_id = '.$rows[0]['grid_id'];				
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result[0]->validated == true)
		{
			if(!strcmp ( $this->_result[0]->sql_query , $rows[0]['sql_query'])||$rows[0]['sql_query']=='')
			{
				return true; // no change to string so still validated
			}
		}
		
		// string has changed so update string and mark unvalidated
		$this->_db->setQuery('REPLACE INTO #__jgrid_select_query 	
						SET grid_id = '.$rows[0]['grid_id'].',
		            		sql_query = "'.$rows[0]['sql_query'].'",
		                   	validated = false');
		$this->_result = $this->_db->query();
		
		if($this->_result) return true;
		else return false;

	}
	
	/**
	 * update Custom sql select query  
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function update_jgrid_custom_sql_query()
	{
		$db =JFactory::getDBO();
		$rows = json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		$this->_db->setQuery(	'REPLACE INTO #__jgrid_custom_select_query 	
								SET grid_id = '.$rows[0]['grid_id'].', 
		                      	sql_query = "'.$rows[0]['sql_query'].'",
		                      	validated = false');	
		$this->_result = $this->_db->query();
		
		if($this->_result) return true;
		else return false;

	}
	
	/**
	 * update Custom Where Clause Depedencies 
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function update_jgrid_select_custom_criteria()
	{
		$db =JFactory::getDBO();
		$rows = json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		$this->_db->setQuery('	REPLACE INTO #__jgrid_select_custom_criteria	
							SET grid_id = '.$rows[0]['grid_id'].', 
		                      	custom_where_query = "'.$rows[0]['custom_where_query'].'"');	
		$this->_result = $this->_db->query();
		
		if($this->_result) return true;
		else return false;

	}

	/**
	 * test grid sql query 
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function jgrid_test_grid_select()
	{
		$db =JFactory::getDBO();
		$user=JFactory::getUser();
		$grid_id = JRequest::getVar('grid_id','','','INTEGER');
		
		// pre process sql query adding jgrid dataindes's etc.
		//create select for JGRID_data tied to sql select
		// find jgrid_data columns in use
		$this->_query = 'SELECT a.jgrid_data_column, 
								CONCAT(b.data_type,a.id) AS "dataindex",
								a.column_type,
								a.database_sql_name_id, 
								a.table_sql_name_id, 
								a.column_sql_name_id, 
								a.primary_key_column  
	                       FROM #__jgrid_columngrid a, 
	                       		#__jgrid_columns b
	                       WHERE a.grid_id = '.$grid_id.'
	                         AND a.column_id = b.id
	                         ORDER BY a.ordering';
//echo 'sql'.$this->_query;
//return;		
		$db->setQuery($this->_query);
		$jgrid_data_column_array = $db->loadObjectList();
		
		// find join column
		$this->_query = '	SELECT primary_key_column
	                       	FROM #__jgrid_grids 
		                    WHERE id = '.$grid_id;
			$db->setQuery($this->_query);
			$jgrid_join_column = $db->loadResult();
			// just take column name
			$jgrid_join_key = substr($jgrid_join_column, strrpos($jgrid_join_column, '.') + 1);
					
//echo 'sql '.print_r(jgrid_data_column_array );
//return;		
		if($jgrid_data_column_array && JRequest::getVar('select_type','','','INTEGER') != 4 )
		{	
			// find join column and if non exists return error
			$key_exists = false;
			for($i=0;$i<count($jgrid_data_column_array);$i++)
			{
					if($jgrid_data_column_array[$i]->primary_key_column == true)
					{
						$key_exists = true;
						// save database and table of key
						$key_database = $jgrid_data_column_array[$i]->database_sql_name_id;
						$key_table = $jgrid_data_column_array[$i]->table_sql_name_id;
					}
			}
			if($i==1) $onlyOneColumn = true;
			else $onlyOneColumn = false;
			if($key_exists == false && !$onlyOneColumn)
			{
				return array(false,"Join Column has not been defined");
			}
			
			
			for($i=0;$i<count($jgrid_data_column_array);$i++)
			{
//echo 'sql '.print_r($jgrid_data_column_array);
//return;					
				if($jgrid_data_column_array[$i]->column_type==1||$jgrid_data_column_array[$i]->column_type==4)// add jgrid_data column index to jgrid data and formulas
				{
					$jgrid_select_data_columns .= ' JGD.' .$jgrid_data_column_array[$i]->dataindex . ', ';
					// add jgrid_data as data index for left join to match above
					$jgrid_data_columns .= 'ROW.'.$jgrid_data_column_array[$i]->jgrid_data_column . 
					  ' AS ' . $jgrid_data_column_array[$i]->dataindex .', ';
				}	
				// add SQL data column index select_type 1,2,or 3
				else  
				{
					if($jgrid_data_column_array[$i]->primary_key_column == true)
					{
						
						//$jgrid_join_column = $jgrid_data_column_array[$i]->dataindex;
						//$jgrid_select_data_columns .= ' convert(value SQLD.' .$jgrid_data_column_array[$i]->dataindex . ',unsigned) AS id, ';									
					}
					$jgrid_select_data_columns .= ' SQLD.' .$jgrid_data_column_array[$i]->dataindex . ', ';
				}
			}
			$jgrid_data_select = $jgrid_data_columns .' primary_key_value, row_access_id AS rslvl_id, row_color FROM #__jgrid_data ROW  WHERE grid_id = '.$grid_id.' AND document_id = @document_id';		
			
			
			// remove trailing comma
			$jgrid_select_data_columns = substr($jgrid_select_data_columns,0,count($jgrid_select_data_columns)-3);
			$jgrid_data_columns = substr($jgrid_data_columns,0,count($jgrid_data_columns)-3);
			//RMS put on end of left join
			$sql_query = JRequest::getVar('sql_query','','','STRING');
//echo 'sql '.$sql_query;
//return;			
			// first search for for primary_key_table with database
			$key_n = strpos($sql_query, $key_database.'.'.$key_table);
			// then search without database
			if($key_n===false)
			{
				$key_n = strpos($sql_query, $key_table);
				$key_n += strlen($key_table);
			}
			else 
			{
				$key_n += strlen($key_database.'.'.$key_table);
			}

			// add call to primary key as id as join field		
			if(!$onlyOneColumn) $key_table_letter = substr ( $sql_query , $key_n+1 , 1 );
			else $key_table_letter = 'a';
					
			$sql_query_w_id = substr_replace ( $sql_query  , 'SELECT ' .$key_table_letter . '.' .$jgrid_join_key. ' AS JOIN_KEY_ID, ' , 0, 6 );
			$jgrid_select = 'SELECT DISTINCT SQLD.JOIN_KEY_ID AS id, '.$jgrid_select_data_columns . ', @document_security_level AS slvl, @editable_line AS editable_line, JGD.rslvl_id, JGD.row_color
				                 FROM ( '.$sql_query_w_id.') SQLD
				                 LEFT JOIN (SELECT '.$jgrid_data_select.' ) JGD ON SQLD.JOIN_KEY_ID = JGD.primary_key_value
				                 GROUP BY id';			
		}
		
	
    	
    // find select
//select
//    B.Name as `Budget Item`,
//    B.Amount as `Budget amount`,
//    COALESCE(E.Amount, 0) as `Expenses`,
//    COALESCE(C.RemainingCommitmentAmount, 0) as `Remaining commitment`
//from
//    (
//        select
//            Name, Amount
//        from
//            Budget B
//    ) B
//left join
//    (
//        select
//            Budget, sum(Amount) As Amount
//        from
//            Expense E
//        group by
//            Budget
//    ) E on B.Name = E.Budget
//left join
//    (
//        select
//            C.Budget, T.Amount - SUM(E.Amount) as RemainingCommitmentAmount
//        from
//            Commitment C
//        inner join
//            Expense E on C.RefNumber = E.RefNumber
//        inner join
//            (select Budget, SUM(Amount) as Amount from Commitment C group by Budget) T
//                on T.Budget = C.Budget
//        group by
//            C.Budget, T.Amount
//    ) C on C.Budget = B.Name
    	
		//update wildcards
		
		else 
		{                    				
			$jgrid_select = JRequest::getVar('sql_query','','','STRING');
		}
		
		$jgrid_sql_query = $jgrid_select;
		
		// create query replacing wild cards and document_id
        $jgrid_select = str_replace("@document_security_level",1,$jgrid_select); // add current document number
		$jgrid_select = str_replace("@rslvl_id",1,$jgrid_select); // add current document number
		$jgrid_select = str_replace("@UserName",$user->name,$jgrid_select); // The name of the user. (e.g. Vint Cerf)
		$jgrid_select = str_replace("@UserID",$user->id,$jgrid_select); //  The unique, numerical user id. Use this when referencing the user record in other database tables.
		$jgrid_select = str_replace("@UserGroupID",$user->gid,$jgrid_select); //  Set to the user's group id, which corresponds to the usertype.		
		$jgrid_select = str_replace("@UserUsername",$user->username,$jgrid_select); // The login/screen name of the user. (e.g. shmuffin1979)
		$jgrid_select = str_replace("@UserEmail",$user->email,$jgrid_select); // The email address of the user. (e.g. crashoverride@hackers.com)
		$jgrid_select = str_replace("@UserType",$user->usertype,$jgrid_select); // The role of the user within Joomla!. (Super Administrator, Editor, etc...)
		$jgrid_select = str_replace("@UserRegisterDate",$user->registerDate,$jgrid_select); // Set to the date when the user was first registered.
		$jgrid_select = str_replace("@UserlastvisitDate",$user->lastvisitDate,$jgrid_select); //  Set to the date the user last visited the site.		
		$jgrid_select = str_replace("@CurrentDateTimeStamp",JFactory::getDate(),$jgrid_select); // add current document number
		
		
//echo 'sql '.$jgrid_select;
//return;		
		$this->_result = $this->_getList($jgrid_select);
		// replace wildcards and test document

		if($this->_result) 
		{
			$this->_db->setQuery('	INSERT INTO #__jgrid_select_query (	grid_id,
																		validated,
			                                           					jgrid_sql_query) 
			                        VALUES ('.$grid_id.',
			                        		true,
			                                "'.$jgrid_sql_query.'")
  									ON DUPLICATE KEY UPDATE 
										validated = true,
                              			jgrid_sql_query = "'.$jgrid_sql_query.'"');
			$this->_db->query();
			
			$this->_db->setQuery('	UPDATE #__jgrid_grids
                              		SET primary_key_column = "'.$jgrid_join_column.'"
                              		WHERE id = '.$grid_id);
			$this->_db->query();
			
			
			if(JRequest::getVar('select_type','','','INTEGER')==4) 
			{
				$this->_db->setQuery('	UPDATE #__jgrid_custom_select_query
                              		SET validated = true
                              		WHERE grid_id = '.$grid_id);
				$this->_db->query();
			}
			return array(true,$this->_result);
		}
		else 
		{
				// does not get to here on bad sql statement
               	return array(false,"RMS error");
		}

	}
	
	/**
	 * error message from last sql select test RMS does not work for descriptive error messages
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function jgrid_test_error_message()
	{
		$db =JFactory::getDBO();
		$this->_errorNum = 0;
        $this->_errorMsg = '';
		                      				
		$this->_errorNum .= mysqli_errno($db) . ' ';
        $this->_errorMsg .= mysqli_error($db)."<br />";
        return array(true,$this->_errorMsg);

	}

}