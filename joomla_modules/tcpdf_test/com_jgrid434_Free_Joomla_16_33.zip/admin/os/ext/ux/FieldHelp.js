Ext.ux.FieldHelp = Ext.extend(Object, (function(){
    function syncInputSize(w, h) {
        this.el.setSize(w, h);
    }

    function afterFieldRender() {
        if (!this.wrap) {
        	//RMS updated for 4.1
        //    this.wrap = this.el.wrap({cls: 'x-form-field-wrap'}); // extjs 3.x for from fields that are not tables
        // find next to last element and then wrap in text under field
        //for example this.wrap = this.el.last().last().last();
        var temp_el = new Array();
        temp_el[0] = this.el;
        i=0;
        while(temp_el[i]) //change for extjs 4.1 to append at end or form/table field on next to last element for field type
        {
          temp_el[i+1] = temp_el[i].last();
          i++;
        }
        var fullXt = this.getXType();
        var xt      = this.getXType().substr(4);
        if (xt == 'obox') // combobox
        {
           this.wrap = temp_el[i-4];  // insert before 3 elements from last for combo type
        }
        else if(fullXt == 'filefield' || fullXt == 'filefield')
        {
        	 this.wrap = temp_el[i-5];  // insert before 2 elements from last for combo type
        }	
        else // textfield, checkbox, etc
        {
          this.wrap = temp_el[i-2];  // insert before next to last table element for all other types
        }  
            this.positionEl = this.resizeEl = this.wrap;
            this.actionMode = 'wrap';
            this.onResize = Ext.Function.createSequence(this.onResize,syncInputSize);
        }
       this.wrap[this.helpAlign == 'top' ? 'insertFirst' : 'createChild']({
            cls: 'x-form-helptext',
            html: this.helpText
       });
    }

    return {
        constructor: function(t, align) {
            this.helpText = t;
            this.align = align;
        },
    
        init: function(f) {
            f.helpAlign = this.align;
            f.helpText = this.helpText;
            test = f.afterRender;
            f.afterRender = Ext.Function.createSequence(f.afterRender,afterFieldRender);
        }
    };
})());


