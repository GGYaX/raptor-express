// save mootools document_id that gets overridden by extjs library to reload for page load then overright later
MOOTOOLS_DOCUMENT_ID_VALUE = document.id;