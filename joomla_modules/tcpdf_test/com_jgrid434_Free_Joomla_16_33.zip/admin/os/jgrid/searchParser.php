<?php

/**
 * searchParser in Joomla/Administrator/Components/os/jgrid
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */


	function search_escape_rlike($string){
		return preg_replace("/([.\[\]*^\$])/", '\\\$1', $string);
	}

	function search_db_escape_terms($terms){
		$out = array();
		foreach($terms as $term){
			$out[] = '[[:<:]]'.AddSlashes(search_escape_rlike($term)).'[[:>:]]';
		}
		return $out;
	}

/**
* Internal function, used to keep quoted text together when building
*  the query.  i.e.... [fish and chips and "chipped ham"] syntax
*
* It essentially replaces " " with "~~~~" as long as we aren't within
* a set of quotes, in which case " " is retained.  The string is then
* explode on "~~~~~" with the surviving spaces intact.
* @return sql where string or false
*/
	
function bq_explode_respect_quotes($line)
{
	//keep track if we are in or out of quote-space
    $quote_level = 0;	
    $buffer = '';
                
    for($i = 0; $i < strlen($line); $i++)
    {
        if($line[$i] == '"' || $line[$i] == '\'')
        {
            $quote_level = $quote_level + 1;

            if ($quote_level == 2)
            {
                $quote_level = 0;
            }
        }    
        else
        { 
            if($line[$i] == ' ' && $quote_level == 0)
            {
                    $buffer = $buffer . '~~~~';   //---Hackish magic key
            }
            else
            { 
                    $buffer = $buffer . $line[$i];
            }
        }
	}
	//$buffer = str_replace('\\', '', $buffer);
	//$buffer = preg_replace("/\"(.*?)\"/e", "search_transform_term('\$1')", $buffer);
	$output_array = (array) explode('~~~~',$buffer);
    return($output_array);
}	
	
/**
*  Internal function, used to apply a single keyword against an
*  arbitrary number of fields in the database in the same fashion.
* 
*  Works via replacing whitespace rather than interation
*/

function bq_make_subquery($fields, $word, $mode)
{	
	
	if($mode == 'not')
	{
        $back = ' LIKE "%' . $word . '%"))';
	}
	else
	{
        $back = ' LIKE "%' . $word . '%")';
	}

	if($mode == 'not')
	{
        $front = '(NOT (';
        $glue = ' LIKE "%' . $word . '%" OR ';
	}
	else 
	{
        $front = '(';
        $glue = ' LIKE "%' . $word . '%" OR ';
	}
	
	
	// find the last value of i that is a valid field to search
	for($i=0, $j=0 ;$i<count($fields);$i++)
	{
			if(!is_numeric($word)&&$fields[$i]->type=='number') continue;
			$valid_fields[$j] = $fields[$i]->name;
			$j++;
	}
	// skip number fields if not numberic search string
	for($i=0;$i<count($valid_fields)-1;$i++)
	{
		$text = $valid_fields[$i] . $glue;	
	}
	//$text = str_replace( ' ', $glue, $fields);
	$text = $front . $valid_fields[$i] . $back;
    return($text);
}




	
/**
 * create sql where clause for convertint from users advanced search string
 * @return sql where string or false 
 *
 */
function searchParser($fields, $text, $select_type)
{

	$text = strtolower($text);
	// combine repeating spaces
	$text = preg_replace('!\s+!', ' ', $text);
		   
	// Support +keyword -keyword
	$text = str_replace(" +", " and ",$text);
    $text = str_replace(" -", " not ",$text);

	// Split, but respect quotation
	$wordarray = bq_explode_respect_quotes($text);
	$buffer = "";
	$output = "";		
    
	if($select_type < 2) // jgrid type
	{
		
//JError::raiseError(1002,print_r($wordarray));
//echo 'sql'.print_r($wordarray);
//return;			
//		$searchStringArray = explode(' ',$searchString1);
		$output = ' ( ';			
		for($i=0;$i<count($wordarray);$i++)
		{
			$word = $wordarray[$i];
			if($word == "and" || $word == "or" || $word == "not") continue;	
				if($buffer) $buffer .= ' OR ';			
				$buffer .= ' (h.string_data LIKE "%'.$word.'%"';
//echo 'sql'.print_r($buffer);				
				if(is_numeric($word)) 
				{
					$buffer .= ' OR h.int_data LIKE "%'.$word.'%"';
					$buffer .= ' OR h.float_data LIKE "%'.$word.'%"';		
			}
			$buffer .= ' ) ';
		}
		$buffer .= ' ) ';
	}
	else // mysql type
	{
			/**
		*  work through each word (or "quoted phrase") in the text and build the
		*   outer shell of the query, filling the insides via bq_make_subquery
		*
		*  "or" is assumed if neither "and" nor "not" is specified
		*/
		
		$first_word = false;
	    for($i = 0;$i<count($wordarray);$i++)
	    {
	        $word = $wordarray[$i];
	     
	       // loop until a non keyword if found to start
	       if($first_word==false)
	       {
	       		if($word == "and" || $word == "or" || $word == "not") continue;
	       		else $first_word = true;
	       }
	
	        // joomla should take care of sql injection
	       // $word = search_db_escape_terms($word);
	        
	     
	        if($word == "and" || $word == "or" || $word == "not")
	        {
	        	 // $i++ kicks us to the actual keyword that the 'not' is working against, etc
	        	$i = $i + 1;
	        	
	        	// skip couble key words or key word at end of string
	        	if($wordarray[$i+1] == "and" || $wordarray[$i+1] == "or" || $wordarray[$i+1] == "not" || $i+1==count($wordarray)) continue;
	        	
	        	$i = $i + 1;
	            if($word == "not")
	            {
	            	if( $i == 1)
	                {   //invalid sql syntax to prefix the first check with and/or/not
		                $buffer = bq_make_subquery($fields, $wordarray[$i], "not");
	                }
	                else
	                {
		                $buffer = " AND " . bq_make_subquery($fields, $wordarray[$i], "not");
	                }
	            }    
	            else if($word == "or")
	            {
	                if( $i == 1)
	                {
		                $buffer = bq_make_subquery($fields, $wordarray[$i], "");
	                }
	                else
	                {
		                $buffer = " OR " & bq_make_subquery($fields, $wordarray[$i], "");
	                }
	                
	            } 
	            else if($word = "and")
	            {
	                              
	                if( $i == 1)
	                {
		                $buffer = bq_make_subquery($fields, $wordarray[$i], "");
	                }
	                else 
	                {
		                $buffer = " AND " . bq_make_subquery($fields, $wordarray[$i], "");
	                }
	                
	        	}
	        }
	        else
	        {    
		        if($i == 0)
		        {  // 0 instead of 1 here because there was no conditional word to skip and no $i++;
	                $buffer = bq_make_subquery($fields, $word, "");
		        }else
		        {
	                $buffer = " OR " . bq_make_subquery($fields, $word, "");
		        }	            
		    }
    	}  	
    }
//echo "sql3".$buffer;    
    $output .= $buffer;
    return array($output,$wordarray);
    return($output);
}
