/*
 * @author Nam Hoang
 */


Ext.require([
   'Ext.grid.*',
    'Ext.data.*',
    'Ext.util.*',
    'Ext.grid.PagingScroller'    
]);

Ext.Loader.setConfig({enabled: true});


Ext.application({
    name: 'Flower',	//name of the application    
    appFolder:'../../../../../javascript/js/app',	//define app folder
    requires:['Flower.view.Viewport'],
    
	controllers: ['SelectorController',"ArrangerController","FilePanelController"],

    launch: function() {
    	Ext.create('Flower.view.Viewport').show();
    	
    }
});
  







