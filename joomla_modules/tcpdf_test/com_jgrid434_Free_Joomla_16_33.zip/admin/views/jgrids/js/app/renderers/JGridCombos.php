<?php
/*
 *  JGridColumns.php in joomla/Components/com_jgrid/r/jgrid/js/app/renderers
 *
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>



var combo1 = Ext.create('Ext.form.ComboBox', {
    typeAhead: true,
    height: "32px",
    hiddenName: 'sortByField',
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_FIELD").'",';
?>  
    lazyRender: true,
	forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("SELECT_A_FIELD").'",
    fieldLabel: "'.JText::_("GROUP_BY_FIELD").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("GROUP_BY_FIELD_TOOLTIP").'") ],';
?>    
    mode: 'local',
    store: JGrid.combo_store[1],
    valueField: 'groupByField',
    displayField: 'groupByFieldDisplay',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all'
});

var combo2 = Ext.create('Ext.form.ComboBox', {
    typeAhead: true,
    height: "32px",
    hiddenName: 'sortByField',
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_FIELD").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("SELECT_A_FIELD").'",
    fieldLabel: "'.JText::_("SORT_BY_FIELD").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("SORT_BY_FIELD_TOOLTIP").'") ],';
?>    
    mode: 'local',
    store: JGrid.combo_store[2],
    valueField: 'sortByField',
    displayField: 'sortByFieldDisplay',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all'
});






var combo101 = {
	xtype: "combobox",
	id: "combo101",
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    triggerAction: 'all',
    lazyRender: true,
    xtype: "combobox",
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",';
?>    
    mode: 'local',
    store: JGrid.combo_store[101],
    valueField: 'grid_application_name',
    displayField: 'grid_application_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true
};
	      
// create new columns JGrid.columns	data_type	   
var combo11 = {
	xtype: "combobox",
	id: "combo11",
    typeAhead: true,
          
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                          
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[11],
    valueField: 'data_type',
    displayField: 'Type',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all',
        listeners: {
        select: {
            fn: function (combo, value) {
                if(value[0].data_type=='L')
                {
                 // window.alert("got here");
                 // editor1.stopEditing();
                  var selectedColumn=Ext.ComponentMgr.get("columns_data").getSelectionModel().getSelection();
                  JGrid.store[12].load({
                     params: {
                       column_id: selectedColumn[0].get('id')
                     }
                  });
                  //win12.alignTo(Ext.get(combo11),[2,2]);
                  win12.show();
                }
            }
        }
    }
};

var combo102 = new Ext.form.ComboBox({
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    queryMode: 'local',
    lazyRender: true,
    forceSelection: true,
    value: '1',
    width: 125,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",';
?>    
    mode: 'local',
    store: JGrid.combo_store[102],
    valueField: 'id',
    displayField: 'grid_theme_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
	listeners: {
        select: {
            fn: function (combo, value)
            {
                jgrid_change_theme("com_jgrid", value[0].data.id);
<?php  
				echo 'switch(value[0].data.id)
					{
						case "1":
							new_theme = "'.JURI::base().'components/com_jgrid/os/ext/resources/css/ext-all.css";	
							break;
						case "2":
							new_theme = "'.JURI::base().'components/com_jgrid/os/ext/resources/css/ext-all-gray.css";	
							break;
						case "3":
							new_theme = "'.JURI::base().'components/com_jgrid/os/ext/resources/css/ext-all-access.css";	
							break;
						case "4":
							new_theme = "'.JURI::base().'components/com_jgrid/os/ext/resources/css/ext-all-neptune.css";	
							break;
						case "5":
							new_theme = "'.JURI::base().'components/com_jgrid/os/ext/resources/css/ext-theme-classic-sandbox.css";	
							break;								
						default:
							new_theme = "'.JURI::base().'components/com_jgrid/os/ext/resources/css/ext-all.css"; 
						 break;	
				}';
?> 					
				Ext.util.CSS.swapStyleSheet("theme",new_theme);
			}
		}						
    }
});

var combo13 = {
	xtype: "combobox",
	id: "combo13",
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    triggerAction: 'query',
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",';
?>         
    mode: 'remote',
    store: JGrid.combo_store[13],
    valueField: 'valid_format',
    displayField: 'valid_format_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all',
    listeners: {
        expand: {
            fn: function (combo, value) {
                  //editor1.stopEditing();
                 var selectedColumn=Ext.ComponentMgr.get("columns_data").getSelectionModel().getSelection();
                  JGrid.combo_store[13].load({
                     params: {
                       data_type: selectedColumn[0].get('data_type')
                     }
                  });
            }
        }        
    }
};

// Select column alignment		   
var combo14 = {
	xtype: "combobox",
	id: "combo14",
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    triggerAction: 'all',
    lazyRender: true,
    forceSelection: true,
    lastQuery: "",
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",';
?>
    mode: 'local',
    store: new Ext.data.SimpleStore({
        id: 14,
      	fields: [	{name: 'align', type: 'string'}, 
             		{name: 'display_alignment', type: 'string'}
        ],
<?php       
     echo 'data: [
            ["", "'. JText::_("JNONE").'"],     
            ["right", "'. JText::_("RIGHT").'"],
            ["left", "'. JText::_("LEFT").'"],
            ["center", "'. JText::_("CENTER").'"]]';//alignment types
?>           
    }),
    valueField: 'align',
    displayField: 'display_alignment'
};

// combo boxs criteria operator
var combo15 = {
	xtype: "combobox",
	id: "combo15",
    typeAhead: true,
          
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_CRITERIA_OPERATOR").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[15],
    valueField: 'criteria_operator_id',
    displayField: 'criteria_operator',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all',
    listeners: {
        select: {
            fn: function (combo, value) {
                build_sql();
            }
        }
    }
};

// combo boxs for jgrid_select_wildcards
var combo16 = {
	xtype: "combobox",
	id: "combo16",
    typeAhead: true,
          
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_WILDCARD_TYPE").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[16],
    valueField: 'select_wildcard_id',
    displayField: 'select_wildcard',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all',
    listeners: {
        select: {
            fn: function (combo, value) {
                build_sql();
            }
        }
    }
};


// combo boxs for jgrid_select_criteria_type
var combo17 = {
	xtype: "combobox",
	id: "combo17",
    typeAhead: true,
          
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_CRITERIA_TYPE").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[17],
    valueField: 'criteria_type_id',
    displayField: 'criteria_type',
    selectOnFocus: true,
    value: 1,
    typeAhead: true,
    editable: true,
    triggerAction: 'all',
    listeners: {
        select: {
            fn: function (combo, value) {
            	var where_clause_dependencies = Ext.ComponentMgr.get("where_clause_dependencies");
	            switch(value[0].data.criteria_type_id) {
	            	case 1:
	            		if(JGrid.multiple_databases==true) where_clause_dependencies.columns[3].hide();
	            		else where_clause_dependencies.columns[3].show();	            	
	            		if(JGrid.multiple_databases==true) where_clause_dependencies.columns[6].hide();
	            		else where_clause_dependencies.columns[6].show();
	            		where_clause_dependencies.columns[7].show();
	            		where_clause_dependencies.columns[8].show();
	            		where_clause_dependencies.columns[9].hide();
	            		where_clause_dependencies.columns[10].hide();
	            		break;
	            	case 2:	            	
	            		if(JGrid.multiple_databases==true) where_clause_dependencies.columns[3].hide();
	            		else where_clause_dependencies.columns[3].show();	            	
	            		if(JGrid.multiple_databases==true) where_clause_dependencies.columns[6].hide();
	            		else where_clause_dependencies.columns[6].show();
	            		where_clause_dependencies.columns[7].hide();
	            		where_clause_dependencies.columns[8].hide();
	            		where_clause_dependencies.columns[9].hide();
	            		where_clause_dependencies.columns[10].show();            	
	            		break;
	            	case 3:            	
	            		if(JGrid.multiple_databases==true) where_clause_dependencies.columns[3].hide();
	            		else where_clause_dependencies.columns[3].show();	            	
	            		if(JGrid.multiple_databases==true) where_clause_dependencies.columns[6].hide();
	            		else where_clause_dependencies.columns[6].show();
	            		where_clause_dependencies.columns[7].hide();
	            		where_clause_dependencies.columns[8].hide();
	            		where_clause_dependencies.columns[9].show();
	            		where_clause_dependencies.columns[10].hide();
	            		break;

            	}            
                build_sql();
            }
        }
    }
};

// combo box for color priority setting
var combo22 = {
	xtype: "combobox",
	id: "combo22",
    typeAhead: true,
          
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_COLOR_PRIORITY").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[22],
    valueField: 'row_color_pressidence',
    displayField: 'Color_Priority',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all'
};

var combo23 =  {
	xtype: "combobox",
    typeAhead: true,
          
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_DATABASE_NAME").'",';
?>  
    lazyRender: true,
    forceSelection: true,
    id: "combo23",
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                           
   ';
?>    
    queryMode: 'remote',
    store: JGrid.combo_store[23],
    valueField: 'database_sql_name_id',
    displayField: 'database_sql_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all',
    listeners: {
        select: {
            fn: function (combo, value) {
            	combo24.clearValue( );
            	combo25.clearValue( );
            }
        }
    }        
};

var combo24 = {
	xtype: "combobox",
	id: "combo24",
    typeAhead: true,
          
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TABLE_NAME").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[24],
    valueField: 'table_sql_name_id',
    displayField: 'table_sql_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all',
    listeners: {
        select: {
            fn: function (combo, value) {
            	combo25.clearValue( );
            }
        }
    } 
};




var combo25 = {
	xtype: "combobox",
	id: "combo25",
    typeAhead: true,
          
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_COLUMN_NAME").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[25],
    valueField: 'column_sql_name_id',
    displayField: 'column_sql_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all',
    listeners: {
        select: {
            fn: function (combo, value) {
                build_sql();
            }
        }
    }
};



// database select type
var combo26 = Ext.create('Ext.form.ComboBox', {
	id: 'database_select_type',
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",
    fieldLabel: "'.JText::_("DATABASE_SELECT_TYPE").'",                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[26],
    valueField: 'query_type',
    displayField: 'Type',
    selectOnFocus: true,
    value: "1",
    typeAhead: true,
    editable: true,
    listeners: {
        select: {
            fn: function (combo, value) {
	            JGrid.select_type = combo.getValue();
	            var crecord = JGrid.store[0].findRecord('id', JGrid.selectedgridid )
	            if(crecord) 
	            {
	            	crecord.set("select_type",JGrid.select_type);
	            }
	            set_gridcolumn_view();
           }
        }
    }
});

// column Select type combobox
var combo27 = {
	xtype: "combobox",
	id: 'column_select_type',
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[27],
    valueField: 'column_type',
    displayField: 'column_type_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    listeners: {
        select: {
            fn: function (combo, value) {
	            var gridcolumns_data = Ext.ComponentMgr.get("gridcolumns_data");
	            var column_type = combo.getValue();
	            switch(column_type) {
	            	case 1:	            	
	            		gridcolumns_data.columns[3].hide();
	            		gridcolumns_data.columns[4].show();
	            		gridcolumns_data.columns[5].hide();
	            		gridcolumns_data.columns[6].hide();
	            		gridcolumns_data.columns[7].hide();
	            		gridcolumns_data.columns[8].hide();
	            		gridcolumns_data.columns[9].hide();
	            		JGrid.cselection[0].set({	database_sql_name_id: '',
	            								table_sql_name_id: '',
	            								column_sql_name_id: '',
	            								formula: '',
	            								primary_key_column: false
	            		});
	            		break;
	            	case 2:
						gridcolumns_data.columns[3].hide();
						gridcolumns_data.columns[4].show();
	            		gridcolumns_data.columns[5].hide();
	            		gridcolumns_data.columns[6].show();
	            		gridcolumns_data.columns[7].show();
	            		gridcolumns_data.columns[8].show();
	            		gridcolumns_data.columns[9].hide();
	            		JGrid.cselection[0].set({	formula: ''});	            		
	            		combo23.store.add({database_sql_name_id: JGrid.joomla_database , database_sql_name: JGrid.joomla_database});
	            		combo23.setValue(JGrid.joomla_database);
	            		JGrid.cselection[0].set({	database_sql_name_id: JGrid.joomla_database});	            			            			 	            		            	
	            		break;
	            	case 3:
	            		gridcolumns_data.columns[3].show();
	            		gridcolumns_data.columns[4].show();
	            		gridcolumns_data.columns[5].show();
	            		gridcolumns_data.columns[6].show();
	            		gridcolumns_data.columns[7].show();
	            		gridcolumns_data.columns[8].show();
	            		gridcolumns_data.columns[9].hide();
	            		JGrid.cselection[0].set({	formula: ''});
	            		break;
	            	case 4:
	            		if(!(JGrid.cselection[0].data.dataindex[0] == 'I' ||  JGrid.cselection[0].data.dataindex[0] == 'F'))
	            		{	            			 
             				<?php echo 'window.alert("'. JText::_("FORMULAS_ONLY_VALID_FOR_NUMBER_COLUMNS").'", "'. JText::_("CHANGE_COLUMN_TYPE_TO_INTEGER_OR_FLOAT_IN_COLUMN_TAB").'");';?> 
      						combo27.clearValue( )
      						return false;
	            		}	            	
	            		gridcolumns_data.columns[3].hide();
	            		gridcolumns_data.columns[4].show();
	            		gridcolumns_data.columns[5].hide();
	            		gridcolumns_data.columns[6].hide();
	            		gridcolumns_data.columns[7].hide();
	            		gridcolumns_data.columns[8].hide();
	            		gridcolumns_data.columns[9].show();
	            		JGrid.cselection[0].set({	database_sql_name_id: '',
	            								table_sql_name_id: '',
	            								column_sql_name_id: '',
	            								primary_key_column: false
	            		});  
	            		break;	            		
            	}

           }
        }
    }
};

// criteria select database
var combo28 = {
	xtype: "combobox",
	id: "combo28",
    typeAhead: true,
          
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_DATABASE_NAME").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                           
   ';
?>    
    queryMode: 'remote',
    store: JGrid.combo_store[28],
    valueField: 'database_sql_name_id',
    displayField: 'database_sql_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all',
    listeners: {
        select: {
            fn: function (combo, value) {
            	Ext.getCmp("combo29").clearValue( );
            	Ext.getCmp("combo30").clearValue( );
            }
        }
    }
};

// criteria select table
var combo29 = {	
	xtype: "combobox",
	id: "combo29",
    typeAhead: true,
          
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TABLE_NAME").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[29],
    valueField: 'table_sql_name_id',
    displayField: 'table_sql_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all',
    listeners: {
        select: {
            fn: function (combo, value) {
            	Ext.getCmp("combo30").clearValue( );
            }
        },
        expand: {
        	fn: function(field, eOpts) {
			    var database_sql_name = Ext.getCmp("combo28").getValue();
			    if (database_sql_name=="") 
			    {
			      Ext.getCmp("combo29").collapse();
			<?php 
			             echo 'window.alert("'. JText::_("DATABASE_NAME_NOT_SELECTED").'", "'. JText::_("PLEASE_SELECT_A_DATABASE").'");';
			?> 
			      return false;
			    } 
			    JGrid.combo_store[29].load({
			    })
			}
        }
    }
};


// criteria select column
var combo30 = {
	xtype: "combobox",
	id: "combo30",
    typeAhead: true,
          
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_COLUMN_NAME").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[30],
    valueField: 'column_sql_name_id',
    displayField: 'column_sql_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all',
    listeners: {
        select: {
            fn: function (combo, value) {
                build_sql();
            }
        },
        expand: {
        	fn: function(field, eOpts) {
			    var table_sql_name = Ext.getCmp("combo29").getValue();
			    if (table_sql_name=="") 
			    {
			      Ext.getCmp("combo30").collapse();
			<?php 
			             echo 'window.alert("'. JText::_("TABLE_NAME_NOT_SELECTED").'", "'. JText::_("PLEASE_SELECT_A_TABLE").'");';
			?> 
			      return false;
			    } 
			    JGrid.combo_store[30].load({
			    })
			}
        }
    }
};

// combo box for criteria join database
var combo31 = {
	xtype: "combobox",
	id: "combo31",
    typeAhead: true,
          
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_DATABASE_NAME").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                           
   ';
?>    
    queryMode: 'remote',
    store: JGrid.combo_store[31],
    valueField: 'jdatabase_sql_name_id',
    displayField: 'database_sql_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all',
    listeners: {
        select: {
            fn: function (combo, value) {
            	Ext.getCmp("combo32").clearValue( );
            	Ext.getCmp("combo33").clearValue( );
            }
        }
    }
};

// combo box for criteria join table
var combo32 = {
	xtype: "combobox",
	id: "combo32",
    typeAhead: true,
          
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TABLE_NAME").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[32],
    valueField: 'jtable_sql_name_id',
    displayField: 'table_sql_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all',
    listeners: {
        select: {
            fn: function (combo, value) {
            	Ext.getCmp("combo33").clearValue( );
            }
        },
        expand: {
        	fn: function(field, eOpts) {
			    var database_sql_name = Ext.getCmp("combo31").getValue();
			    if (database_sql_name=="") 
			    {
			      Ext.getCmp("combo32").collapse();
			<?php 
			             echo 'window.alert("'. JText::_("DATABASE_NAME_NOT_SELECTED").'", "'. JText::_("PLEASE_SELECT_A_DATABASE").'");';
			?> 
			      return false;
			    } 
			    JGrid.combo_store[32].load({
			    })
			}
        }
    }
};

// combobox for join criteria column

var combo33 = {
	xtype: "combobox",
	id: "combo33",
    typeAhead: true,
          
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_COLUMN_NAME").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[33],
    valueField: 'jcolumn_sql_name_id',
    displayField: 'column_sql_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all',
    listeners: {
        select: {
            fn: function (combo, value) {
                build_sql();
            }
        },
        expand: {
        	fn: function(field, eOpts) {
			    var table_sql_name = Ext.getCmp("combo31").getValue();
			    if (table_sql_name=="") 
			    {
			      Ext.getCmp("combo33").collapse();
			<?php 
			             echo 'window.alert("'. JText::_("TABLE_NAME_NOT_SELECTED").'", "'. JText::_("PLEASE_SELECT_A_TABLE").'");';
			?> 
			      return false;
			    } 
			    JGrid.combo_store[33].load({
			    })
			}
        }
    }
};

// combo boxs for security access for type role or user	
var combo40 = Ext.create('Ext.form.ComboBox', {
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",
    fieldLabel: "'.JText::_("ACCESS_FOR").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("ACCESS_FOR_TOOLTIP").'") ],                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[40],
    valueField: 'access_for',
    displayField: 'Type',
    selectOnFocus: true,
    typeAhead: true,
    editable: true
});

// hide selections when creator type
combo40.on('select', function () {
  if(combo40.getValue() == "4")
  {
    combo44.setValue("4");
    combo44.hide();
  }
  else
  {
    combo44.show();
  }
  combo411.clearValue();
});

var combo41 = Ext.create('Ext.form.ComboBox', {
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",
    fieldLabel: "'.JText::_("USER_ROLE_NAME").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("USER_NAME_TOOLTIP").'") ],                           
   ';
?>    
    mode: 'local',
    store: JGrid.combo_store[41],
    valueField: 'access_for_id',
    displayField: 'access_for_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all'
});

combo41.on('expand', function () {
    var access_for = combo40.getValue();
    if (access_for=="") 
    {
      combo41.collapse();
<?php 
             echo 'window.alert("'. JText::_("ACCESS_FOR_NOT_SELECTED").'", "'. JText::_("PLEASE_SELECT_ACCESS_FOR").'");';
?> 
      return false;
    } 
    JGrid.combo_store[41].load({
        params: {
            access_for: access_for
        }
    })
});

// combo boxs for user access type grid, sheet, or column type
var combo42 = Ext.create('Ext.form.ComboBox', {
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",
    fieldLabel: "'.JText::_("ACCESS_TYPE").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("ACCESS_TYPE_TOOLTIPP").'") ],                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[42],
    valueField: 'access_type',
    displayField: 'Type',
    selectOnFocus: true,
    typeAhead: true,
    editable: true
});

// hide selections when creator type
combo42.on('select', function () {
  combo431.clearValue();
});

var combo43 = new Ext.form.ComboBox({
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",
    fieldLabel: "'.JText::_("OBJECT_NAME").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("OBJECT_NAME_TOOLTIPP").'") ],';
?>  
    triggerAction: 'query',
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",';
?>         
    mode: 'local',
    store: JGrid.combo_store[43],
    valueField: 'access_type_id',
    displayField: 'access_type_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all'
});

combo43.on('focus', function () {
    var access_type = combo42.getValue();
    var application_id = combo45.getValue();
    if (access_type=="") 
    {
       combo43.collapse();
<?php 
             echo 'window.alert("'. JText::_("ACCESS_TYPE_NOT_SELECTED").'", "'. JText::_("PLEASE_SELECT_ACCESS_TYPE").'");';
?> 
      return false;
    }    
    JGrid.combo_store[43].load({
          params: {
             access_type: access_type,
             application_id: application_id 
          }
    });
});



     
 
 
var combo44 = Ext.create('Ext.form.ComboBox', {
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",
    fieldLabel: "'.JText::_("ACCESS_LEVEL").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("ACCESS_LEVEL_TOOLTIPP").'") ],';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",';
?>         
    queryMode: 'local',
    store: JGrid.combo_store[44],
    valueField: 'access_level',
    displayField: 'Type',
    selectOnFocus: true,
    typeAhead: true,
    editable: true
}); 
 
var combo45 = new Ext.form.ComboBox({
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",
    fieldLabel: "'.JText::_("APPLICATION").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("APPLICATION_RULE_TOOLTIP").'") ],                           
   ';
?>    
    mode: 'local',
    store: JGrid.combo_store[45],
    valueField: 'access_rule_application_id',
    displayField: 'access_rule_application',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all'
});   
   
 
var combo71 = {
	xtype: "combobox",
    id: 'combo71',
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    triggerAction: 'all',
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",';
?>    
    mode: 'remote',
    store: JGrid.combo_store[71],
    valueField: 'role_id',
    displayField: 'role_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true
};

var combo73 = {
	xtype: "combobox",
	id: "combo73",
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    triggerAction: 'all',
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",';
?>         
    mode: 'remote',
    store: JGrid.combo_store[73],
    valueField: 'userid',
    displayField: 'username',
    selectOnFocus: true,
    typeAhead: true,
    editable: true
};  

var combo99 = {
	xtype: "combobox",
	id: "combo99",
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",';
?>         
    queryMode: 'local',
    store: JGrid.combo_store[44],
    valueField: 'access_level',
    displayField: 'Type',
    selectOnFocus: true,
    typeAhead: true,
    editable: true
};

// Select column alignment		   
var comboSummarytype = {
	xtype: "combobox",
	id: "comboSummarytype",
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_SUMMARY_TYPE").'",';
?>  
    triggerAction: 'all',
    lazyRender: true,
    forceSelection: true,
    lastQuery: "",
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",';
?>
    mode: 'local',
    store: new Ext.data.SimpleStore({
        id: 'comboSummarytypeStrId',
      	fields: [	{name: 'summarytype', type: 'summarytype'}, 
             		{name: 'display_summarytype', type: 'string'}
        ],
<?php       
     echo 'data: [
            ["count", "'. JText::_("COUNT").'"],     
            ["sum", "'. JText::_("SUM").'"],
            ["min", "'. JText::_("MIN").'"],
            ["max", "'. JText::_("MAX").'"],
            ["average", "'. JText::_("AVERAGE").'"]]';//alignment types
?>           
    }),
    valueField: 'summarytype',
    displayField: 'display_summarytype'
};

var combo411 = Ext.create('Ext.form.ComboBox', {
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",
    fieldLabel: "'.JText::_("USER_ROLE_NAME").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("USER_NAME_TOOLTIP").'") ],                           
   ';
?>    
    mode: 'local',
    store: JGrid.combo_store[411],
    valueField: 'access_for_id',
    displayField: 'access_for_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all'
});

combo411.on('expand', function () {
    var access_for = combo40.getValue();
    if (access_for=="") 
    {   
      combo411.collapse();
<?php 
             echo 'window.alert("'. JText::_("ACCESS_FOR_NOT_SELECTED").'", "'. JText::_("PLEASE_SELECT_ACCESS_FOR").'");';
?> 
      return false;
    }
    JGrid.combo_store[411].proxy.url =  "index.php?option=com_jgrid&task=access_for_name_id&controller=jgrid_security&format=ajax&access_for="+access_for;  	 
    JGrid.combo_store[411].load({
        params: {
            access_for: access_for
        }
    })
});


var combo431 = new Ext.form.ComboBox({
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",
    fieldLabel: "'.JText::_("OBJECT_NAME").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("OBJECT_NAME_TOOLTIPP").'") ],';
?>  
    triggerAction: 'query',
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",';
?>         
    mode: 'local',
    store: JGrid.combo_store[431],
    valueField: 'access_type_id',
    displayField: 'access_type_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all'
});

combo431.on('focus', function () {
    var access_type = combo42.getValue();
    var application_id = combo45.getValue();
    if (access_type=="") 
    {
       combo431.collapse();
<?php 
             echo 'window.alert("'. JText::_("ACCESS_TYPE_NOT_SELECTED").'", "'. JText::_("PLEASE_SELECT_ACCESS_TYPE").'");';
?> 
      return false;
    }
    JGrid.combo_store[431].proxy.url =  "index.php?option=com_jgrid&task=access_type_name_id&controller=jgrid_security&format=ajax&access_type="+access_type+"&application_id="+application_id;  	 	   
    JGrid.combo_store[431].load({
          params: {
             access_type: access_type,
             application_id: application_id 
          }
    });
});
