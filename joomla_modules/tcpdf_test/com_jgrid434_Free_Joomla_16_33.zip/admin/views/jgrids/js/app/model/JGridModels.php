<?php
 /*
 *  JGridModels.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/model
 *
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
Ext.define("JGrid.model.JGridModel0", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridModel0",
    id: "JGridModel0",
    fields: [{name: 'id', type: 'int'},
    		 {name: 'select_type', type: 'string'},
             {name: 'grid_application_name', type: 'string'}, 
             {name: 'renderto', type: 'string'}, 
             {name: 'grid_reference_id', type: 'string'},
             {name: 'title', type: 'string'}, 
             {name: 'frame', type: 'bool'},
             {name: 'height', type: 'string'},
             {name: 'width', type: 'string'},
             {name: 'ordering', type: 'int'},
             {name: 'stripe_rows', type: 'bool'},
             {name: 'enableColumnMove', type: 'bool'}
           ]
});
JGrid.dsModel[0] = Ext.create("JGrid.model.JGridModel0");

Ext.define("JGrid.model.JGridModel1", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridModel1",
    id: "JGridModel1",
    fields: [	{name: 'id', type: 'int'},
         		{name: 'header', type: 'string'},
           		{name: 'column_type', type: 'int'},             	 
           		{name: 'editable', type: 'bool'}, 
             	{name: 'width', type: 'string'},
              	{name: 'data_type', type: 'string'},
               	{name: 'validation_type', type: 'string'},
              	{name: 'dfilter', type: 'bool'},
               	{name: 'sortable', type: 'bool'},
               	{name: 'ddefault', type: 'string'},
             	{name: 'align', type: 'string'},
               	{name: 'css', type: 'string'},                                       
             	{name: 'tooltip', type: 'string'},            	
             	{name: 'email_subject', type: 'string'},
               	{name: 'freeze_column', type: 'bool'},             	                	             	
             	{name: 'summarycolumn', type: 'bool'},
             	{name: 'summarytype', type: 'string'},
             	{name: 'summaryprefix', type: 'string'},
             	{name: 'summarypostfix', type: 'string'}
 	]
});
JGrid.dsModel[1] = Ext.create("JGrid.model.JGridModel1");

// adding a column to a grid jgrid_columngrid. Pop up grid called from "Data Grid Settings" screen xtype: "editorgrid" 
Ext.define("JGrid.model.JGridModel2", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridModel2",
    id: "JGridModel2",
    fields: [	{name: 'id', type: 'int'},
    			{name: 'dataindex', type: 'string'},
               	{name: 'title', type: 'string'}, 
               	{name: 'header', type: 'string'},
            	{name: 'row_color_pressidence', type: 'int'}, 
          		{name: 'ordering', type: 'int'}, 
               	{name: 'grid_id', type: 'int'},
               	{name: 'column_id', type: 'int'},
              	{name: 'column_type', type: 'int'},
               	{name: 'database_sql_name_id', type: 'string', defaultValue: JGrid.joomla_database},
               	{name: 'table_sql_name_id', type: 'string'},
               	{name: 'column_sql_name_id', type: 'string'},
               	{name: 'sql_table_letter', type: 'string'},
               	{name: 'primary_key_column', type: 'bool'},
               	{name: 'formula', type: 'string'}
 	]
});
JGrid.dsModel[2] = Ext.create("JGrid.model.JGridModel2");


// manage grid user access jgrid_security administrator screen xtype: "editorgrid"
Ext.define("JGrid.model.JGridModel4", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridModel4",
    id: "JGridModel4",
    fields: [	{name: 'id', type: 'int'},
              	{name: 'access_rule_application_id', type: 'int'},
             	{name: 'userid_assigning_access', type: 'int'}, 
              	{name: 'access_for', type: 'int'}, 
               	{name: 'access_for_id', type: 'string'}, 
            	{name: 'access_for_name', type: 'string'}, 
             	{name: 'access_type', type: 'int'},
          		{name: 'access_type_id', type: 'string'},
               	{name: 'access_type_name', type: 'string'},
               	{name: 'access_level', type: 'int'},
             	{name: 'last_updated', type: 'date'}
 	]
});
JGrid.dsModel[4] = Ext.create("JGrid.model.JGridModel4");

// manage grid roles administrator screen xtype: "editorgrid"
Ext.define("JGrid.model.JGridModel7", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridModel7",
    id: "JGridModel7",
    fields: [	{name: 'id', type: 'int'},
               	{name: 'role_name', type: 'string'}, 
            	{name: 'role_id', type: 'string'}, 
              	{name: 'username', type: 'string'},
               	{name: 'userid', type: 'int'}	
 	]
});
JGrid.dsModel[7] = Ext.create("JGrid.model.JGridModel7");

// add roles button on administrator screen xtype: "editorgrid" roles screen
Ext.define("JGrid.model.JGridModel8", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridModel8",
    id: "JGridModel8",
    fields: [	{name: 'id', type: 'int'},
               	{name: 'role_name', type: 'string'}, 
              	{name: 'description', type: 'string'}
 	]
});
JGrid.dsModel[8] = Ext.create("JGrid.model.JGridModel8");




// default group access rights
Ext.define("JGrid.model.JGridModel9", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridModel9",
    id: "JGridModel9",
    fields: [	{name: 'id', type: 'int'},
                {name: 'usertype_name', type: 'string'}, 
                {name: 'access_level', type: 'string'}
 	]
});
JGrid.dsModel[9] = Ext.create("JGrid.model.JGridModel9");

// Add Values for list box valid types (user defined)  screenxtype "editorgrid" 
Ext.define("JGrid.model.JGridModel12", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridModel12",
    id: "JGridModel12",
    fields: [	{name: 'id', type: 'int'}, 
              	{name: 'listboxvalues', type: 'string'},
               	{name: 'listboxvaluerowcolor', type: 'string'}
 	]
});
JGrid.dsModel[12] = Ext.create("JGrid.model.JGridModel12");

// Database Select Query
Ext.define("JGrid.model.JGridModel13", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridModel13",
    id: "JGridModel13",
    fields: [	{name: 'id', type: 'int'},
    			{name: 'grid_id', type: 'int'}, 
              	{name: 'sql_query', type: 'string'},
              	{name: 'validated', type: 'bool'}
 	]
});
JGrid.dsModel[13] = Ext.create("JGrid.model.JGridModel13");

//Custom SQL Select Query Saved in Database
Ext.define("JGrid.model.JGridModel14", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridModel14",
    id: "JGridModel14",
    fields: [	{name: 'id', type: 'int'},
    			{name: 'grid_id', type: 'int'}, 
              	{name: 'sql_query', type: 'string'},
              	{name: 'validated', type: 'bool'}
 	]
});
JGrid.dsModel[14] = Ext.create("JGrid.model.JGridModel14");


// Where Clause Dependencies 
Ext.define("JGrid.model.JGridModel15", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridModel15",
    id: "JGridModel15",
    fields: [	{name: 'id', type: 'int'},
                {name: 'grid_id', type: 'int'}, 
              	{name: 'criteria_type_id', type: 'int'},
               	{name: 'database_sql_name_id', type: 'string', defaultValue: JGrid.joomla_database},
               	{name: 'table_sql_name_id', type: 'string'},
               	{name: 'column_sql_name_id', type: 'string'},
               	{name: 'criteria_operator_id', type: 'string'},
               	{name: 'jdatabase_sql_name_id', type: 'string', defaultValue: JGrid.joomla_database},
               	{name: 'jtable_sql_name_id', type: 'string'},
               	{name: 'jcolumn_sql_name_id', type: 'string'},
                {name: 'select_wildcard_id', type: 'string'},
               	{name: 'criteria_value', type: 'string'}      	
               	
 	]
});
JGrid.dsModel[15] = Ext.create("JGrid.model.JGridModel15");

// Custom Where Clause Depedencies 
Ext.define("JGrid.model.JGridModel16", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridModel16",
    id: "JGridModel16",
    fields: [	{name: 'id', type: 'int'},
                {name: 'grid_id', type: 'int'},  
              	{name: 'custom_where_query', type: 'string'}
 	]
});
JGrid.dsModel[16] = Ext.create("JGrid.model.JGridModel16");


// combo box for groupbyfield in Grid Settings Form
Ext.define("JGrid.model.JGridCModel1", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel1",
    id: "JGridCModel1",
    fields: [	{name: 'id', type: 'string'},
        		{name: 'header', type: 'string'},
        		{name: 'groupByField', type: 'string'},
        		{name: 'groupByFieldDisplay', type: 'string'}
           	]
});
JGrid.dsCModel[1] = Ext.create("JGrid.model.JGridCModel1");

// combo box for sortbybyfield in Grid Settings Form
Ext.define("JGrid.model.JGridCModel2", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel2",
    id: "JGridCModel2",
    fields:	[	{name: 'id', type: 'string'},
        		{name: 'header', type: 'string'},
        		{name: 'sortByField', type: 'string'},
        		{name: 'sortByFieldDisplay', type: 'string'}
          	]
});
JGrid.dsCModel[2] = Ext.create("JGrid.model.JGridCModel2");

// create new columns JGrid.columns	data_type
Ext.define("JGrid.model.JGridCModel11", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel11",
    id: "JGridCModel11",
    fields: [{name: "data_type", type: "string"}, 
     		 {name: "Type", type: "string"}
           ]
});
JGrid.dsCModel[11] = Ext.create("JGrid.model.JGridCModel11");


// combo boxs for data format validation
Ext.define("JGrid.model.JGridCModel13", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel13",
    id: "JGridCModel13",
    fields:	[	{name: 'valid_format', type: 'string'}, 
                {name: 'valid_format_name', type: 'string'}
          	]
});
JGrid.dsCModel[13] = Ext.create("JGrid.model.JGridCModel13");


// combo boxs for criteria operator
Ext.define("JGrid.model.JGridCModel15", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel15",
    id: "JGridCModel15",
    fields:	[	{name: 'criteria_operator_id', type: 'string'}, 
                {name: 'criteria_operator', type: 'string'}
          	]
});
JGrid.dsCModel[15] = Ext.create("JGrid.model.JGridCModel15");


// combo boxs for jgrid_select_wildcards
Ext.define("JGrid.model.JGridCModel16", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel16",
    id: "JGridCModel16",
    fields:	[	{name: 'select_wildcard_id', type: 'string'}, 
                {name: 'select_wildcard', type: 'string'}
          	]
});
JGrid.dsCModel[16] = Ext.create("JGrid.model.JGridCModel16");

// combo boxs for jgrid_select_criteria_type
Ext.define("JGrid.model.JGridCModel17", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel17",
    id: "JGridCModel17",
    fields:	[	{name: 'criteria_type_id', type: 'int'}, 
                {name: 'criteria_type', type: 'string'}
          	]
});
JGrid.dsCModel[17] = Ext.create("JGrid.model.JGridCModel17");




// combo boxs for newcolumnlist
Ext.define("JGrid.model.JGridCModel21", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel21",
    id: "JGridCModel21",
    fields: [{name: "id", type: "string"}, 
     		 {name: "header", type: "string"},
          	 {name: "dataindex", type: "string"}
           ]
});
JGrid.dsCModel[21] = Ext.create("JGrid.model.JGridCModel21");

// combo boxs for SELECT_A_COLOR_PRIORITY
Ext.define("JGrid.model.JGridCModel22", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel22",
    id: "JGridCModel22",
    fields: [{name: "row_color_pressidence", type: "int"}, 
     		 {name: "Color_Priority", type: "string"}
           ]
});
JGrid.dsCModel[22] = Ext.create("JGrid.model.JGridCModel22");

// combo boxs for database_sql_name
Ext.define("JGrid.model.JGridCModel23", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel23",
    id: "JGridCModel23",
    fields: [{name: "database_sql_name_id", type: "string"},
    		{name: "jdatabase_sql_name_id", type: "string"}, 
     		{name: "database_sql_name", type: "string"}
           ]
});
JGrid.dsCModel[23] = Ext.create("JGrid.model.JGridCModel23");

// combo boxs for table_sql_name
Ext.define("JGrid.model.JGridCModel24", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel24",
    id: "JGridCModel24",
    fields: [{name: "table_sql_name_id", type: "string"},
    		{name: "jtable_sql_name_id", type: "string"},  
     		{name: "table_sql_name", type: "string"}
           ]
});
JGrid.dsCModel[24] = Ext.create("JGrid.model.JGridCModel24");

// combo boxs for column_sql_name
Ext.define("JGrid.model.JGridCModel25", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel25",
    id: "JGridCModel25",
    fields: [{name: "column_sql_name_id", type: "string"},
    		{name: "jcolumn_sql_name_id", type: "string"},  
     		{name: "column_sql_name", type: "string"}
           ]
});
JGrid.dsCModel[25] = Ext.create("JGrid.model.JGridCModel25");

// combo boxs for table sql query type
Ext.define("JGrid.model.JGridCModel26", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel26",
    id: "JGridCModel26",
    fields: [{name: "query_type", type: "string"}, 
     		 {name: "Type", type: "string"}
           ]
});
JGrid.dsCModel[26] = Ext.create("JGrid.model.JGridCModel26");

// combo boxs for column type eg: jgrid or sql or remote
Ext.define("JGrid.model.JGridCModel27", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel27",
    id: "JGridCModel27",
    fields: [{name: "column_type", type: "int"}, 
     		 {name: "column_type_name", type: "string"}
           ]
});
JGrid.dsCModel[27] = Ext.create("JGrid.model.JGridCModel27");


// combo boxs for security access for type role or user	
Ext.define("JGrid.model.JGridCModel40", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel40",
    id: "JGridCModel40",
    fields: [{name: 'access_for', type: 'string'}, 
             {name: 'Type', type: 'string'}
           ]
});
JGrid.dsCModel[40] = Ext.create("JGrid.model.JGridCModel40");

// combo boxs for security role or user model
Ext.define("JGrid.model.JGridCModel41", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel41",
    id: "JGridCModel41",
    fields: [{name: 'access_for_id', type: 'string'}, 
             {name: 'access_for_name', type: 'string'}
           ]
});
JGrid.dsCModel[41] = Ext.create("JGrid.model.JGridCModel41");

// combo boxs for user access type grid, sheet, or column type
Ext.define("JGrid.model.JGridCModel42", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel42",
    id: "JGridCModel42",
    fields: [{name: 'access_type', type: 'string'}, 
             {name: 'Type', type: 'string'}
           ]
});
JGrid.dsCModel[42] = Ext.create("JGrid.model.JGridCModel42");

// combo boxs for user access grid, sheet, or column ids
Ext.define("JGrid.model.JGridCModel43", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel43",
    id: "JGridCModel43",
    fields: [{name: 'access_type_id', type: 'string'}, 
             {name: 'access_type_name', type: 'string'}
           ]
});
JGrid.dsCModel[43] = Ext.create("JGrid.model.JGridCModel43");

// combo boxs for acess level
Ext.define("JGrid.model.JGridCModel44", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel44",
    id: "JGridCModel42",
    fields: [{name: 'access_level', type: 'string'}, 
             {name: 'Type', type: 'string'}
           ]
});
JGrid.dsCModel[44] = Ext.create("JGrid.model.JGridCModel44");


// combo boxs for security role or user
Ext.define("JGrid.model.JGridCModel45", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel45",
    id: "JGridCModel45",
    fields:	[	{name: 'access_rule_application_id', type: 'string'}, 
                {name: 'access_rule_application', type: 'string'}
          	]
});
JGrid.dsCModel[45] = Ext.create("JGrid.model.JGridCModel45");

// combo boxs for security role or user
Ext.define("JGrid.model.JGridCModel71", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel71",
    id: "JGridCModel71",
    fields: [	{name: 'role_id', type: 'string'}, 
                 {name: 'role_name', type: 'string'}
           	]
});
JGrid.dsCModel[71] = Ext.create("JGrid.model.JGridCModel71");

// combo boxs for users assigned to role
Ext.define("JGrid.model.JGridCModel73", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel73",
    id: "JGridCModel73",
    fields:	[	{name: 'userid', type: 'int'}, 
                {name: 'username', type: 'string'}
          	]
});
JGrid.dsCModel[73] = Ext.create("JGrid.model.JGridCModel73");

// list box for jgrid_application_name values
Ext.define("JGrid.model.JGridCModel101", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel101",
    id: "JGridCModel101",
    fields:	[	{name: 'id', type: 'string'}, 
                {name: 'grid_application_name', type: 'string'}
          	]
});
JGrid.dsCModel[101] = Ext.create("JGrid.model.JGridCModel101");

// list box for theme values
Ext.define("JGrid.model.JGridCModel102", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridCModel102",
    id: "JGridCModel102",
    fields:	[	{name: 'id', type: 'string'}, 
                {name: 'grid_theme_name', type: 'string'}
          	]
});
JGrid.dsCModel[102] = Ext.create("JGrid.model.JGridCModel102");








