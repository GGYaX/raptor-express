<?php
/**
 * viewport.php in joomla/administrator/components/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

//require_once(JPATH_BASE . '/administrator/components/com_jgrid/os/jgrid/functions.php' );
$params = JComponentHelper::getParams('com_jgrid');
$fversion = $params->get ('fversion');
?>	
Ext.define("JGrid.view.Viewport", {
	// As full page view port
	//extend : "Ext.container.Viewport",
	
	// as panel in joomla structure
	extend : "Ext.panel.Panel",
	layout: "border",
	requires : [ "JGrid.view.JGridGrid0", "JGrid.view.JGridGrid1"
<?php  	 
if($fversion==0)
{
	echo ', "JGrid.view.JGridGrid4" 
	, "JGrid.view.JGridGrid7"
	';
}
?>	
	],
	layout : "fit",
	renderTo: "editcell",
    height: 750,
<?php    
    echo 'title: "'. JText::_("GRID_COLUMNS_AND_USER_ACCESS_MANAGEMENT").'",';
?>	    	
	items : [ {
	    id: "mypanel",
		region: "center",
		xtype : "tabpanel",
		enableTabScroll:true,
		margins: "5 5 0 0",
        activeTab: 0,
        listeners: {
            tabchange: function (tabpanel, tab) {
                if(tab.id=="jgrid_security")
                {
                  JGrid.combo_store[41].load({
                    params: {
                      access_type: "0"
                    }
                  });
                  JGrid.combo_store[43].load({
                    params: {
                      access_type: "0"
                    }
                  });
                }
                tab.store.load(); 
           }
		},
		items : [ 
				{xtype : "JGridGrid0"}
				, {xtype : "JGridGrid1"}
<?php  	 
if($fversion==0)
{				
	echo ', {xtype : "JGridGrid4"}
	, {xtype : "JGridGrid7"}
	';
}
?>			
			
		] // items of tab panel
	}] // items of Viewport
});

