<?php
 /*
 *  JGridToolbar0.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');




echo 'Ext.define("JGrid.view.JGridToolbar8.php", {
	extend : "Ext.toolbar.Toolbar",
	requires : [ "JGrid.view.JGridHelp5"],	
	alias : "widget.JGridToolbar8",
	id : "JGridToolbar8",
	items : [{
				text: "'. JText::_("ADD_NEW_ROLE").'",
                tooltip: "'. JText::_("ADD_NEW_ROLE_TOOLTIP").'",            
                icon: "components/com_jgrid/os/jgrid/icons/table_add.png",
                cls: "x-btn-text-icon",
                handler: function () {
                     //   editor8.stopEditing();
                        var newrowlocation = JGrid.store[8].getCount();
                        var jgrid_newrow = {
                        	id: "",
                        	role_name: "",
                        	description: ""
                        };
                        if(newrowlocation==0) var last_record_id=0;
                        else var last_record_id=JGrid.store[8].data.items[newrowlocation-1].data.id;
                        JGrid.proxy[8].api.create = "index.php?option=com_jgrid&task=create&controller=jgrid_roles&format=ajax&last_record_id="+last_record_id;   
                        JGrid.store[8].insert(newrowlocation, jgrid_newrow);
                        JGrid.currenteditgrid = Ext.ComponentMgr.get("role_names");
                        JGrid.currenteditgrid.getView().refresh();
                   }    
                
            },
            {
				text: "'. JText::_("REMOVE_ROLE").'",
                tooltip: "'. JText::_("REMOVE_ROLE_TOOLTIP").'",
                icon: "components/com_jgrid/os/jgrid/icons/table_delete.png",
                cls: "x-btn-text-icon",
                handler: function () {
               //     editor8.stopEditing();
                    JGrid.currenteditgrid = Ext.ComponentMgr.get("role_names");
                    var sm = JGrid.currenteditgrid.getSelectionModel();
                    if (sm.hasSelection()) {
                        Ext.Msg.show({
                            title: "Remove Row",
                            buttons: Ext.MessageBox.YESNOCANCEL,
							msg: "'. JText::_("REMOVE_SELECTED_ROLES").'",                      
                            fn: function (btn) {
                                if (btn == "yes") {
                                  //JGrid.currenteditgrid.stopEditing();
                                  var sels = sm.getSelection();
                                  // Multiple row delete
                                  for(var i = 0, r; r = sels[i]; i++){             
                                    JGrid.currenteditgrid.getStore().remove(r);
                                  }
                                }
                            }
                        })
                    }
                }
            },
            {  
						id: "user_help_newrole",               
                        text: "<b>'. JText::_("HELP").'</b>",                       
                        icon: "components/com_jgrid/os/jgrid/icons/help.png",
                        tooltip: "'. JText::_("INSTRUCTIONS_DESCRIBING_ADDING_NEW_ROLES_TOOLTIP").'",                       
                        handler: function () {                              
                      		if(!JGrid.help[5])
    						{
    							JGrid.help[5] = Ext.create("JGrid.view.JGridHelp5");
    						}
    						JGrid.help[5].show();  
                        }          
                     }]
});';
?>

