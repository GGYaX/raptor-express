<?php
/*
 * view.html.pha in Joomla/administrator/Components/views/jgrid
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );
JLoader::register('JToolbarHelper', JPATH_ADMINISTRATOR.'/includes/toolbar.php');

/**
 * Jgrids View
 *
 * HTML View Class to display javascript view
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */

if(!class_exists('RMWorksAroundJoomlaToGetAView')) {
	if(interface_exists('JView')) {
		abstract class RMWorksAroundJoomlaToGetAView extends JViewLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAView extends JView {}
	}
}

class JgridsViewJgrids extends RMWorksAroundJoomlaToGetAView
{


	/**
	 * Jgrids view display method
	 * @return void
	 **/
	function display($tpl = null)
	{

		JToolBarHelper::title(   JText::_('JGRID_MANAGER'), 'generic.png' );
	     JToolBarHelper::preferences( 'com_jgrid',$height='400', $width='1000'  );
 //  JToolBarHelper::custom('jgrid_database_upgrade','save-new.png','save-new.png','Upgrade_JGrid_Database',false);

		// Get data from the model
		//	$items		= & $this->get( 'Data');

		//	$this->assignRef('items',		$items);




		parent::display($tpl);
	}
	
}