<?php
/**
 * Jgrids Controller in Joomla/Administrator/Components
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

/**
 * Jgrids controller
 *
 * read,update,create,delete,combo box drop downs data and popups in com_jgrid administrator "Manager User Access" screens
 * to "Manage "Data Grid Settings" rights
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */

if(!class_exists('RMWorksAroundJoomlaToGetAController')) {
	if(interface_exists('JController')) {
		abstract class RMWorksAroundJoomlaToGetAController extends JControllerLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAController extends JController {}
	}
}

class JgridsController extends RMWorksAroundJoomlaToGetAController
{
	/**
	 * Method to display the view
	 *
	 * @access	public
	 */
	function display($cachable = false, $urlparams = false)
	{
		parent::display();
	}

	/**
	 * Retrieves the "Data Grid Settings" data
	 * @return string json string containing the "Data Grid Settings" grid rows or false if no grids found
	 */
	function read()
	{
		$this->_model = $this->getModel('jgrids');
		list($this->_result_count,$this->_result) = $this->_model->getgrids();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Updates the   "Data Grid Settings" grid row being edited in the  "Data Grid Settings" grid
	 * @return string return true if row updated or false if grid row not updated.
	 */
	function update()
	{
		$this->_model = $this->getModel('jgrids');
		if($this->_model->updateGrid())Echo '{success:true}';
		else Echo '{success:false}';
	}

	/**
	 * Creates new data grid in the Data Grid Settings" grid
	 * @var array $row_data array of objects sent from the "Data Grid Settings" grid containing the values to be updated in the database
	 * @return string json encoded string containing the new grid default data or false if grid not created.
	 */
	function create()
	{

		$this->_model = $this->getModel('jgrids');
		$this->_result = $this->_model->createGrid();
		if($this->_result==true)Echo '{success:true,results:"1",rows: '. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Deletes grid in the "Data Grids" grid
	 * @return integer result true if grid deleted or false if delete failed
	 */
	function destroy()
	{
		$this->_model = $this->getModel('jgrids');
		if($this->_model->deleteGrid()) Echo '{success:true}';
		else Echo '{success:false}';
	}

	/**
	 * Moves selected data grid order "Data Grids" grid
	 * @return integer result true if grid moved or false if move failed
	 */
	function moveColumn()
	{
		$this->_model = $this->getModel('jgrid_columngrid');
		if($this->_model->moveColumn()) Echo '{success:true}';
		else Echo '{success:false}';
	}


	/**
	 * Moves selected data grid order "Data Grids" grid
	 * @return integer result true if grid deleted or false if delete failed
	 */
	function moveGrid()
	{
		$this->_model = $this->getModel('jgrids');
		if($this->_model->moveGrid()) Echo '{success:true}';
		else Echo '{success:false}';
	}

	/**
	 * Move Stub to return success on destroy's generated when rows moved. Move function does actual move
	 * proxy suspendevents() not working
	 * @return integer result true
	 */
	function movestub()
	{
		Echo '{success:true}';
	}

	/**
	 * Retrieves the grid application  combo boxs selections
	 * @access public
	 * @return string json string containing the "application values"  or false if no grids found
	 */
	function jgrid_application_name()
	{
		$this->_model = $this->getModel('jgrids');
		list($this->_result_count,$this->_result) = $this->_model->jgrid_application_name_combo();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Retrieves the "Data Grid Detailed Settings" data popup window
	 * @return string json string containing the "Data Grid Settings" grid rows or false if no grids found
	 */
	function loadgridsettings()
	{
		//delay to load list boxes
		sleep(1);
		$this->_model = $this->getModel('jgrids');
		$this->_result = $this->_model->loadGridSettings();
		if($this->_result)Echo '{success:true,data:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Updates the detailed popup form  "Data Grid Settings" grid row being edited in the  "Data Grid Settings" grid
	 * @var array $row_data array of objects sent from the "Data Grid Settings" grid popup form containing the values to be updated in the database
	 * @return integer true to the form if update successfull or false if grid row settings not updated.
	 */
	function submitgridsettings()
	{
		$this->_model = $this->getModel('jgrids');
		$this->_result = $this->_model->submitGridSettings();
		if($this->_result)Echo '{success:true,data:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Retrieves the grid columns assisgned to the grid data to the combo boxs groupByCombo
	 * @access public
	 * @return string json string containing the "Data Grid Settings" grid rows or false if no grids found
	 */
	function gridColumnsGroupByComboList()
	{
		$this->_model = $this->getModel('jgrids');
		list($this->_result_count,$this->_result) = $this->_model->gridColumnsGroupByComboList();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}
	/**
	 * Retrieves the grid columns assisgned to the grid data to the combo boxs sortByCombo
	 * @access public
	 * @return string json string containing the "Data Grid Settings" grid rows or false if no grids found
	 */
	function gridColumnsSortByComboList()
	{
		$this->_model = $this->getModel('jgrids');
		list($this->_result_count,$this->_result) = $this->_model->gridColumnsSortByComboList();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Retrieves the list box data to popluate the user grids list box callup.
	 * @return string json string containing the "user list box"  or false if no values returned
	 */
	function read_role_or_user()
	{
		$this->_model = $this->getModel('jgrids');
		list($this->_result_count,$this->_result) = $this->_model->read_role_or_user();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}
	
	/**
	 * Change JGRID THEME
	 * @return true if success false if fail
	 */
	function change_theme()
	{
		$this->_model = $this->getModel('jgrids');
		$this->_result = $this->_model->change_theme();
		if($this->_result)Echo '{success:true}';
		else Echo '{success:false}';
	}
	
}