<?php
/**
 * Jgrid_grids Table  in Joomla/Components/Tables
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_grids Table Class
 *
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class TableJgrid_grids extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id = null;

	/**
	 * @var int
	 */
	var $select_type = null;

	/**
	 * @var string
	 */
	var $primary_key_column = null;

	/**
	 * @var int
	 */
	var $parent_id = null;

	/**
	 * @var string
	 */
	var $grid_reference_id = null;

	/**
	 * @var string
	 */
	var $grid_application_name = null;

	/**
	 * @var string
	 */
	var $renderTo = null;

	/**
	 * @var string
	 */
	var $title = null;

	/**
	 * @var int
	 */
	var $ordering = null;

	/**
	 * @var int
	 */
	var $access_level_default = null;

	/**
	 * @var boolean
	 */
	var $frame = null;

	/**
	 * @var string
	 */
	var $height = null;

	/**
	 * @var string
	 */
	var $width = null;

	/**
	 * @var boolean
	 */
	var $stripe_rows = null;

	/**
	 * @var boolean
	 */
	var $enable_row_numbers = null;

	/**
	 * @var boolean
	 */
	var $enableRowEditor = null;

	/**
	 * @var boolean
	 */
	var $columnlines = null;

	/**
	 * @var boolean
	 */
	var $enableColumnMove = null;

	/**
	 * @var boolean
	 */
	var $enableColumnResize = null;
		
	/**
	 * @var int
	 */
	var $enableGroupBy = null;

	/**
	 * @var string
	 */
	var $groupByField = null;

  /**
  * @var int
  */
  var $enableGroupBySummary = null;	
	
	/**
	 * @var string
	 */
	var $groupDir = null;	
	
	/**
	 * @var boolean
	 */
	var $showGroupName = null;
	
	/**
	 * @var boolean
	 */
	var $hideGroupedColumn = null;
	
		/**
	 * @var boolean
	 */
	var $startCollapsed = null;
  
  /**
  * @var int
  */
  var $enableSortBy = null;	

	/**
	 * @var string
	 */
	var $sortByField = null;

	/**
	 * @var string
	 */
	var $sortByDirection = null;

	/**
	 * @var boolean
	 */
	var $enable_paging = null;

	/**
	 * @var string
	 */
	var $paging_records = null;

	/**
	 * @var string
	 */
	var $tabtip = null;
	
	/**
	 * @var string
	 */
	var $cls = null;
  
	/**
	 * @var string
	 */
	var $ctCls = null;  	
	
	/**
	 * @var boolean
	 */
	var $print = null;
	
  /**
  * @var int
  */
  var $number_width = null;	

	/**
	 * @var string
	 */
	var $number_header = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableJgrid_grids(& $db) {
		parent::__construct('#__jgrid_grids
		', 'id', $db);
	}
}