<?php
/**
 * Jgrid_data Table  in Joomla/Components/Tables
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_data Table Class
 *
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class TableJgrid_data extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id = null;


	/**
	 * @var int
	 */
	var $parent_id = null;
	
	/**
	 * @var int
	 */
	var $ordering = null;	

	/**
	 * @var string
	 */
	var $database_sql_name_id = null;

	/**
	 * @var string
	 */
	var $table_sql_name_id = null;

	/**
	 * @var string
	 */
	var $p_column_sql_name_id = null;

	/**
	 * @var int
	 */
	var $document_id = null;

	/**
	 * @var int
	 */
	var $creator_userid = null;

	/**
	 * @var string
	 */
	var $row_access_id = null;

	/**
	 * @var string
	 */
	var $row_color = null;
		
	/**
	 * @var int
	 */
	var $primary_key_value = null;
	
 /**
  * @var int
  */
  var $grid_id = null;	

	/**
	 * @var mediumtext 
	 * 
	 * 	 sample row T1 to T50
	 */
	var $T1 = null;
	
	/**
	 * @var mediumtext 
	 * 
	 * 	 sample row L1 to L30
	 */
	var $L1 = null;	
	
	/**
	 * @var int
	 * 
	 * sample row I1 to I50   	 
	 */
	var $I1 = null;
  
	/**
	 * @var mediumtext 
	 * 
	 * 	 sample row P1 to P30
	 */
	var $P1 = null;  	

	/**
	 * @var float 
	 * 
	 * 	 sample row F1 to F50
	 */
	var $F1 = null;
	
	/**
	 * @var date 
	 * 
	 * 	 sample row D1 to D50
	 */
	var $D1 = null;

	/**
	 * @var boolean 
	 * 
	 * 	 sample row B1 to B30
	 */
	var $B1 = null;

	/**
	 * @var timestamp
	 */
	var $last_updated = null;

	/**
	 * @var string
	 */
	var $sortByDirection = null;

	/**
	 * @var boolean
	 */
	var $enable_paging = null;

	/**
	 * @var string
	 */
	var $paging_records = null;

	/**
	 * @var string
	 */
	var $tabtip = null;
	
	/**
	 * @var string
	 */
	var $cls = null;
  
	/**
	 * @var string
	 */
	var $ctCls = null;  	
	


	/**
	 * @var string
	 */
	var $number_header = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableJgrid_data(& $db) {
		parent::__construct('#__jgrid_data
		', 'id', $db);
	}
}