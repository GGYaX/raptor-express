<?php
/**
 * Jgrid_images Table  in Joomla/Components/Tables
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_documents Table Class
 *
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class TableJgrid_images extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id = null;
	
	/**
	 * 
	 * @var string
	 */
	var $filename = null;
	
	/**
	 * 
	 * @var string
	 */
	var $download_filename = null;	
	
	/**
	 * 
	 * @var string
	 */
	var $file_type = null;
	
	/**
	 * 
	 * @var int
	 */
	
	var $file_size = null;
	
	/**
	 * 
	 * @var string
	 */
	var $image_thumb_path = null;
	
	/**
	 * 
	 * @var string
	 */
	var $tooltip = null;
	
	/**
	 * 
	 * @var string
	 */
	var $hyper_url = null;
	
	/**
	 * 
	 * @var string
	 */
	var $image_email = null;


	/**
	 * 
	 * @var string
	 */
	var $image_email_subject = null;
  
	/**
	 * 
	 * @var string
	 */
	var $hyper_grid_sheet = null;
    	
	/**
	 * 
	 * @var string
	 */
	var $extension = null;
	
	
	/**
	 * 
	 * @var int
	 */
	var $grid_id = null;
	
	
	/**
	 *
	 * @var int
	 */	
	var $document_id = null;
			
	/**
	 *
	 * @var int
	 */	
	var $column_id= null;
	
	/**
	 *
	 * @var int
	 */	
	var $row_id= null;
	
	/**
	 *
	 * @var int
	 */	
	var $userid= null;

	
	/** 
	 *
	 * @var timestamp
	 */
	var $last_updated = null;
	
	
	

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableJgrid_images(& $db) {
		parent::__construct('#__jgrid_images', 'id', $db);
	}
}