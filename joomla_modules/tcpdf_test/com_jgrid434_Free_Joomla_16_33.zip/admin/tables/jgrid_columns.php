<?php
/**
 * Jgrid_columns Table  in Joomla/Components/Tables
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_columns Table Class
 *
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class TableJgrid_columns extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id = null;

	/**
	 * @var string
	 */
	var $header = null;

	/**
	 * @var boolean
	 */
	var $editable = null;

	/**
	 * @var string
	 */
	var $width = null;
	
	/**
	 * @var int  legacy for pre-jgrid4.0 versions
	 */
	var $dataindex = null;
	
	/**
	 * @var int
	 */
	var $data_size = null;	

	/**
	 * @var string
	 */
	var $data_type = null;

	/**
	 * @var string
	 */
	var $ddefault = null;
	
		/**
	 * @var string
	 */
	var $align = null;
	
		/**
	 * @var string
	 */
	var $css = null;
	
	/**
	 * @var string
	 */
	var $validation_type = null;

	/**
	 * @var string
	 */
	var $tooltip = null;
	
	/**
	 * @var boolean
	 */
	var $freeze_column = null;	

	/**
	 * @var string
	 */
	var $email_subject = null;
	
	/**
	 * @var boolean
	 */
	var $dfilter = null;

	/**
	 * @var boolean
	 */
	var $sortable = null;
	
	/**
	 * @var boolean
	 */
	var $summarycolumn = null;
	
		/**
	 * @var enum
	 */
	var $summarytype = null;
  
	/**
	 * @var string
	 */
	var $summaryprefix = null;

	/**
	 * @var string
	 */
	var $summarypostfix = null;  	

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableJgrid_columns(& $db) {
		parent::__construct('#__jgrid_columns', 'id', $db);
	}
}