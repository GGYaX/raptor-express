<?php
/**
 * Jgrid_chart_series Table  in Joomla/Components/Tables
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_chart_series Table Class
 *
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class TableJgrid_chart_series extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $series_id = null;
	
	/**
	 * @var int
	 */
	var $chart_id = null;
	
	/**
	 * @var string
	 */
	var $stacked = null;	
	
	/**
	 * @var string
	 */
	var $series_type = null;	
		
	/**
	 * @var string
	 */
	var $highlight = null;
	
		/**
	 * @var boolean
	 */
	var $showInLegend = null;
	
	/**
	 * @var string
	 */
	var $xField = null;
	
	/**
	 * @var string
	 */
	var $yField = null;

	/**
	 * @var string
	 */
	var $axis = null;

	/**
	 * @var int
	 */
	var $chart_id = null;
	
	/**
	 * @var int
	 */
	var $serise_label_id = null;	
		
	/**
	 * @var string
	 */
	var $field = null;
	
		/**
	 * @var int
	 */
	var $donut= null;
	
	/**
	 * @var boolean
	 */
	var $showMarkers = null;
	
	/**
	 * @var int
	 */
	var $markerConfig_id = null;

	/**
	 * @var int
	 */
	var $series_style = null;
	
	/**
	 * @var boolean
	 */
	var $needle = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableJgrid_chart_series(& $db) {
		parent::__construct('#__jgrid_chart_series
		', 'id', $db);
	}
}