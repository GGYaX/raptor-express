DROP TABLE IF EXISTS `#__jgrid_current_user_grid_document`;
DROP TABLE IF EXISTS `#__jgrid_code_vcontrol`;
DROP TABLE IF EXISTS `#__jgrid_user_type_defaults`;
DROP TABLE IF EXISTS `#__jgrid_temp_table`;
DROP TABLE IF EXISTS `#__jgrid_temp_table2`;



CREATE TABLE IF NOT EXISTS `#__jgrid_applications` (
  `id` int(11) NOT NULL auto_increment,
  `grid_application_name` varchar(25) NOT NULL,
  `theme` int(11) default 1,
  PRIMARY KEY  (`id`), UNIQUE KEY (`grid_application_name`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table is stores JGrid Component and Module Application Names and Themes' DEFAULT CHARSET=utf8;

INSERT IGNORE INTO `#__jgrid_applications` (`id`,`grid_application_name`)
 VALUES (1,'com_jgrid'),
        (2,'mod_jgrid'),
        (3,'mod_jgrid2'),
        (4,'mod_jgrid3'),
        (5,'mod_jgrid4'),
        (6,'mod_jgrid5'),
        (7,'mod_jgrid6'),
        (8,'mod_jgrid7'),
        (9,'mod_jgrid8'),
        (10,'mod_jgrid9'),
        (11,'mod_jgrid10'),
        (12,'mod_jgrid11'),
        (13,'mod_jgrid12');
        
CREATE TABLE IF NOT EXISTS `#__jgrid_grids` (
  `id` int(11) NOT NULL auto_increment,
  `select_type` int(11) NOT NULL default 1,
  `primary_key_column` varchar(50) default 0, 
  `parent_id` int(11),
  `grid_reference_id` varchar(25) NOT NULL default 'panel-grid',
  `grid_application_name` varchar(25) NOT NULL default 'jgrid_component',
  `renderTo` varchar(25) NOT NULL default 'edit-grid',
  `title` varchar(120) NOT NULL default 'firstgrid',
  `ordering` int(11) NOT NULL,
  `access_level_default` int(4) default 1,
  `frame` boolean NOT NULL default true,
  `height` varchar (4) NOT NULL default '250',
  `width` varchar(4) NOT NULL default '520',
  `stripe_rows` boolean NOT NULL default true,
  `enable_row_numbers` boolean NOT NULL default true,
  `enableRowEditor` boolean NOT NULL default true,
  `columnlines` boolean NOT NULL default false,
  `enableColumnMove` boolean NOT NULL default false,
  `enableColumnResize` boolean NOT NULL default true,
  `enableGroupBy` int(11) NOT NULL default 0,
  `groupByField` varchar(25),
  `enableGroupBySummary` INT(11) NOT NULL,
  `groupDir` varchar(4) NOT NULL default 'ASC',
  `showGroupName` boolean NOT NULL default false,
  `hideGroupedColumn` boolean NOT NULL default false,
  `startCollapsed` boolean NOT NULL default false,
  `enableSortBy` int(11) NOT NULL default 0,
  `sortByField` varchar(25),
  `sortByDirection` varchar(4) NOT NULL default 'ASC',
  `enable_paging` boolean NOT NULL default false,  
  `paging_records` varchar (6) NOT NULL default '30',
  `tabtip` varchar (240),
  `cls` varchar (240),
  `ctCls` varchar (240),    
  `print` boolean NOT NULL default true,
  `number_width` int(11) NOT NULL default 35,
  `number_header` varchar(120),
  PRIMARY KEY  (`id`),
  INDEX (`parent_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Grid Configuration Settings Data' DEFAULT CHARSET=utf8;
    
CREATE TABLE IF NOT EXISTS `#__jgrid_select_join_criteria` (
  `id` int(11) NOT NULL auto_increment,
  `grid_id` int(11)  NOT NULL,
  `criteria_type_id` int(11)  NOT NULL default 1,
  `database_sql_name_id` varchar(50),
  `table_sql_name_id` varchar(50),
  `column_sql_name_id` varchar (50),
  `criteria_operator_id` varchar (30),
  `jdatabase_sql_name_id` varchar(50),
  `jtable_sql_name_id` varchar(50),
  `jcolumn_sql_name_id` varchar (50),
  `select_wildcard_id` varchar (50),
  `criteria_value` varchar (240),
  PRIMARY KEY  (`id`),
  INDEX (`grid_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Grid SQL Query Join Criteria' DEFAULT CHARSET=utf8;

 
  CREATE TABLE IF NOT EXISTS `#__jgrid_select_custom_criteria` (
  `id` int(11) NOT NULL auto_increment,
  `grid_id` int(11)  NOT NULL,
  `custom_where_query` varchar(5000) NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY (`grid_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Custom Join Criteria' DEFAULT CHARSET=utf8;

 CREATE TABLE IF NOT EXISTS `#__jgrid_custom_select_query` (
  `id` int(11) NOT NULL auto_increment,
  `grid_id` int(11)  NOT NULL,
  `sql_query` varchar(5000) NOT NULL,
  `validated` boolean NOT NULL default false,
  PRIMARY KEY  (`id`),
  UNIQUE KEY (`grid_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Complete Custom SQL Select Queries' DEFAULT CHARSET=utf8; 
 
 
 CREATE TABLE IF NOT EXISTS `#__jgrid_select_query` (
  `id` int(11) NOT NULL auto_increment,
  `grid_id` int(11)  NOT NULL,
  `sql_query` varchar(5000) NOT NULL,
  `jgrid_sql_query` varchar(5000) NOT NULL,
  `validated` boolean NOT NULL default false,
  `database_sql_name_id` varchar(50),
  `table_sql_name_id` varchar(50),
  `p_column_sql_name_id` varchar (50),
  PRIMARY KEY  (`id`),
  UNIQUE KEY(`grid_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Grid SQL Select Query' DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `#__jgrid_select_criteria_type` (
  `id` int(11) NOT NULL auto_increment,
  `criteria_type` varchar(25) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Grid SQL Select Criteria Type Lookup Data' DEFAULT CHARSET=utf8;

INSERT IGNORE INTO `#__jgrid_select_criteria_type` (`id`, `criteria_type`)
 VALUES (1,'Database Join'),(2,'Column Value'),(3,'Wildcard Value');

CREATE TABLE IF NOT EXISTS `#__jgrid_select_sheet_values` (
  `id` int(11) NOT NULL auto_increment,
  `grid_id` int(11)  NOT NULL, 
  `document_id` int (11) NOT NULL,
  `select_join_criteria_id` int (11) NOT NULL,
  `join_criteria_sheet_value` varchar(25) NOT NULL,
  PRIMARY KEY  (`id`),
  INDEX (`grid_id`, `document_id`, `select_join_criteria_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Sheet SQL Join Criteria and Value For Each Sheet View' DEFAULT CHARSET=utf8;

 CREATE TABLE IF NOT EXISTS `#__jgrid_select_wildcards` (
  `id` int(11) NOT NULL auto_increment,
  `select_wildcard` varchar(25) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid SQL Join Criteria Wildcard Lookup Data' DEFAULT CHARSET=utf8;

INSERT IGNORE INTO `#__jgrid_select_wildcards` (`id`, `select_wildcard`)
 VALUES (1,'UserName'),(2,'UserID'),(3,'UserGroupID'),(4,'UserUsername'),(5,'UserEmail'),(6,'UserType'),(7,'UserRegisterDate'),(8,'UserlastvisitDate'),(9,'CurrentDateTimeStamp');  

CREATE TABLE IF NOT EXISTS `#__jgrid_columns` ( 
  `id` int(11) NOT NULL auto_increment,
  `header` varchar(25) NOT NULL,
  `editable` boolean NOT NULL default true,
  `width` varchar(25) NOT NULL default '50',
  `data_size` int(11) NOT NULL default '25',
  `data_type` varchar (25) NOT NULL default 'T',
  `ddefault` varchar (240) default'',
  `align` varchar (25),
  `css` varchar (240), 
  `validation_type` varchar (25) NOT NULL default 'none',
  `tooltip` varchar (240),
  `freeze_column` boolean NOT NULL default false,
  `email_subject` varchar (240) default '',
  `dfilter` boolean NOT NULL default true,
  `sortable` boolean NOT NULL default true,
  `summarycolumn` boolean NOT NULL DEFAULT '0',
  `summarytype` ENUM('count','sum','min','max','average') NOT NULL DEFAULT 'count',
  `summaryprefix` VARCHAR( 24 ) NOT NULL,
  `summarypostfix` VARCHAR( 24 ) NOT NULL,  		                                                 
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Grid Column Configuration Settings Data' DEFAULT CHARSET=utf8;
 
CREATE TABLE IF NOT EXISTS `#__jgrid_column_list_field_values` (
  `id` int(11) NOT NULL auto_increment,
  `column_id` int(11)  NOT NULL,
  `listboxvalues` varchar(240) NOT NULL,
  `listboxvaluerowcolor` varchar(64),
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Grid Column List Field Lookup Values' DEFAULT CHARSET=utf8;
        
CREATE TABLE IF NOT EXISTS `#__jgrid_columngrid` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11),
  `column_id` int(11)  NOT NULL,
  `column_type` int(11)  NOT NULL default 1,
  `grid_id` int(11) NOT NULL,
  `ordering` int(11) NOT NULL,
  `row_color_pressidence` int(11) NOT NULL DEFAULT 9,
  `database_sql_name_id` varchar(50),
  `table_sql_name_id` varchar(50),
  `column_sql_name_id` varchar (50),
  `jgrid_data_column` varchar (50),
  `primary_key_column` boolean NOT NULL default false,
  `formula` varchar(1000) DEFAULT '',
  PRIMARY KEY  (`id`),
  INDEX (`parent_id`),
  INDEX (`grid_id`,`column_id`,`ordering`),
  INDEX (`grid_id`,`database_sql_name_id`,`table_sql_name_id`,`column_sql_name_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Grid-Column Configuration Settings Data' DEFAULT CHARSET=utf8;
              
CREATE TABLE IF NOT EXISTS `#__jgrid_columngrid_column_type` (
  `id` int(11) NOT NULL auto_increment,
  `column_type_name` varchar(25) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Dolumn Type Lookup Data' DEFAULT CHARSET=utf8;
       
INSERT IGNORE INTO `#__jgrid_columngrid_column_type` (`id`, `column_type_name`)
 VALUES (1,'Joomla Table Column'),(2,'MYSQL Table Column'),(3,'JGrid Editable Data Column');
 
 CREATE TABLE IF NOT EXISTS `#__jgrid_rows` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11),
  `ordering` int(11) NOT NULL,
  `document_id` int (11) NOT NULL,
  `creator_userid` int(11) NOT NULL DEFAULT 62,
  `grid_id` int(11) NOT NULL,
  `row_access_id` VARCHAR(11) NOT NULL DEFAULT 'D',
  PRIMARY KEY  (`id`),
  INDEX (`parent_id`),
  INDEX (`document_id`,`id`,`ordering`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Grid Rows Configuration Settings' DEFAULT CHARSET=utf8;
         
CREATE TABLE IF NOT EXISTS `#__jgrid_document` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11),
  `document_type` int(11),
  `ordering` int(11),
  `document_title` varchar (25) NOT NULL,
  `parent_document` int (11) DEFAULT -1,
  `creator_userid` int(11) NOT NULL,
  `grid_id` int (11) NOT NULL,
  `grid_default_document_flag` boolean NOT NULL default false,
  `summary_document_flag` boolean NOT NULL default false,
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
    INDEX (`grid_id`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Document Configuration Settings' DEFAULT CHARSET=utf8;
        
CREATE TABLE IF NOT EXISTS `#__jgrid_document_summary_detail` (
  `id` int(11) NOT NULL auto_increment,
  `grid_id` int (11) NOT NULL,
  `summary_document_id` int (11),
  `summarized_document_id` int (11),  
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
    INDEX (`grid_id`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Document Summary Pointer' DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__jgrid_document_column_filters` (
  `id` int(11) NOT NULL auto_increment,
  `grid_id` int (11) NOT NULL,
  `document_id` int (11), 
  `column_id` int (11),
  `filter_type` varchar(25),
  `filter_comparison` varchar(25),
  `filter_value` varchar(240),
  `summary_document_flag` boolean NOT NULL default false,
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
    INDEX (`grid_id`,`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Document Column Filter Setup Settings' DEFAULT CHARSET=utf8;          
         
CREATE TABLE IF NOT EXISTS `#__jgrid_current_user_grid_document` (
  `id` int(11) NOT NULL auto_increment,
  `userid` int(11) NOT NULL,
  `grid_id` int(11) NOT NULL,
  `session_id` varchar(200) NOT NULL,
  `current_document_id` int (11),
  `previous_document_id1` int (11),   
  `last_accessed` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  INDEX(`grid_id`,`userid`,`current_document_id`,`session_id`),
  CONSTRAINT MyUniqueKey UNIQUE (userid,grid_id,current_document_id,session_id)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores Current Users Last Document Viewed' DEFAULT CHARSET=utf8;
      
UPDATE IGNORE `#__jgrid_current_user_grid_document` 
SET session_id = 'NA'
WHERE userid != '0';

CREATE TABLE IF NOT EXISTS `#__jgrid_data` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11),
  `ordering` int(11) NOT NULL,
  `database_sql_name_id` varchar(50),
  `table_sql_name_id` varchar(50),
  `p_column_sql_name_id` varchar (50),
  `document_id` int (11) NOT NULL,
  `creator_userid` int(11) NOT NULL DEFAULT 62,  
  `row_access_id` VARCHAR(11) NOT NULL DEFAULT 'D',
  `row_color` varchar (64), 
  `primary_key_value` int(11) NOT NULL,
  `grid_id` int(11) NOT NULL,
  `T1`    MEDIUMTEXT,
  `T2`    MEDIUMTEXT,
  `T3`    MEDIUMTEXT,
  `T4`    MEDIUMTEXT,
  `T5`    MEDIUMTEXT,
  `T6`    MEDIUMTEXT,
  `T7`    MEDIUMTEXT,
  `T8`    MEDIUMTEXT,
  `T9`    MEDIUMTEXT,
  `T10`   MEDIUMTEXT,
  `T11`   MEDIUMTEXT,
  `T12`   MEDIUMTEXT,
  `T13`   MEDIUMTEXT,
  `T14`   MEDIUMTEXT,
  `T15`   MEDIUMTEXT,
  `T16`   MEDIUMTEXT,
  `T17`   MEDIUMTEXT,
  `T18`   MEDIUMTEXT,
  `T19`   MEDIUMTEXT,
  `T20`   MEDIUMTEXT,
  `T21`   MEDIUMTEXT,
  `T22`   MEDIUMTEXT,
  `T23`   MEDIUMTEXT,
  `T24`   MEDIUMTEXT,
  `T25`   MEDIUMTEXT,
  `T26`   MEDIUMTEXT,
  `T27`   MEDIUMTEXT,
  `T28`   MEDIUMTEXT,
  `T29`   MEDIUMTEXT,
  `T30`   MEDIUMTEXT,
  `T31`   MEDIUMTEXT,
  `T32`   MEDIUMTEXT,
  `T33`   MEDIUMTEXT,
  `T34`   MEDIUMTEXT,
  `T35`   MEDIUMTEXT,
  `T36`   MEDIUMTEXT,
  `T37`   MEDIUMTEXT,
  `T38`   MEDIUMTEXT,
  `T39`   MEDIUMTEXT,
  `T40`   MEDIUMTEXT,
  `T41`   MEDIUMTEXT,
  `T42`   MEDIUMTEXT,
  `T43`   MEDIUMTEXT,
  `T44`   MEDIUMTEXT,
  `T45`   MEDIUMTEXT,
  `T46`   MEDIUMTEXT,
  `T47`   MEDIUMTEXT,
  `T48`   MEDIUMTEXT,
  `T49`   MEDIUMTEXT,
  `T50`   MEDIUMTEXT,  
  `L1`    MEDIUMTEXT,
  `L2`    MEDIUMTEXT,
  `L3`    MEDIUMTEXT,
  `L4`    MEDIUMTEXT,
  `L5`    MEDIUMTEXT,
  `L6`    MEDIUMTEXT,
  `L7`    MEDIUMTEXT,
  `L8`    MEDIUMTEXT,
  `L9`    MEDIUMTEXT,
  `L10`   MEDIUMTEXT,
  `L11`   MEDIUMTEXT,
  `L12`   MEDIUMTEXT,
  `L13`   MEDIUMTEXT,
  `L14`   MEDIUMTEXT,
  `L15`   MEDIUMTEXT,
  `L16`   MEDIUMTEXT,
  `L17`   MEDIUMTEXT,
  `L18`   MEDIUMTEXT,
  `L19`   MEDIUMTEXT,
  `L20`   MEDIUMTEXT,
  `L21`   MEDIUMTEXT,
  `L22`   MEDIUMTEXT,
  `L23`   MEDIUMTEXT,
  `L24`   MEDIUMTEXT,
  `L25`   MEDIUMTEXT,
  `L26`   MEDIUMTEXT,
  `L27`   MEDIUMTEXT,
  `L28`   MEDIUMTEXT,
  `L29`   MEDIUMTEXT,
  `L30`   MEDIUMTEXT,    
  `I1`    int(11),
  `I2`    int(11),
  `I3`    int(11),
  `I4`    int(11),
  `I5`    int(11),
  `I6`    int(11),
  `I7`    int(11),
  `I8`    int(11),
  `I9`    int(11),
  `I10`   int(11),
  `I11`   int(11),
  `I12`   int(11),
  `I13`   int(11),
  `I14`   int(11),
  `I15`   int(11),
  `I16`   int(11),
  `I17`   int(11),
  `I18`   int(11),
  `I19`   int(11),
  `I20`   int(11),
  `I21`   int(11),
  `I22`   int(11),
  `I23`   int(11),
  `I24`   int(11),
  `I25`   int(11),
  `I26`   int(11),
  `I27`   int(11),
  `I28`   int(11),
  `I29`   int(11),
  `I30`   int(11),
  `I31`   int(11),
  `I32`   int(11),
  `I33`   int(11),
  `I34`   int(11),
  `I35`   int(11),
  `I36`   int(11),
  `I37`   int(11),
  `I38`   int(11),
  `I39`   int(11),
  `I40`   int(11),
  `I41`   int(11),
  `I42`   int(11),
  `I43`   int(11),
  `I44`   int(11),
  `I45`   int(11),
  `I46`   int(11),
  `I47`   int(11),
  `I48`   int(11),
  `I49`   int(11),
  `I50`   int(11),  
  `P1`    MEDIUMTEXT,
  `P2`    MEDIUMTEXT,
  `P3`    MEDIUMTEXT,
  `P4`    MEDIUMTEXT,
  `P5`    MEDIUMTEXT,
  `P6`    MEDIUMTEXT,
  `P7`    MEDIUMTEXT,
  `P8`    MEDIUMTEXT,
  `P9`    MEDIUMTEXT,
  `P10`   MEDIUMTEXT,
  `P11`   MEDIUMTEXT,
  `P12`   MEDIUMTEXT,
  `P13`   MEDIUMTEXT,
  `P14`   MEDIUMTEXT,
  `P15`   MEDIUMTEXT,
  `P16`   MEDIUMTEXT,
  `P17`   MEDIUMTEXT,
  `P18`   MEDIUMTEXT,
  `P19`   MEDIUMTEXT,
  `P20`   MEDIUMTEXT,
  `P21`   MEDIUMTEXT,
  `P22`   MEDIUMTEXT,
  `P23`   MEDIUMTEXT,
  `P24`   MEDIUMTEXT,
  `P25`   MEDIUMTEXT,
  `P26`   MEDIUMTEXT,
  `P27`   MEDIUMTEXT,
  `P28`   MEDIUMTEXT,
  `P29`   MEDIUMTEXT,
  `P30`   MEDIUMTEXT,    
  `F1`    float,
  `F2`    float,
  `F3`    float,
  `F4`    float,
  `F5`    float,
  `F6`    float,
  `F7`    float,
  `F8`    float,
  `F9`    float,
  `F10`   float,
  `F11`   float,
  `F12`   float,
  `F13`   float,
  `F14`   float,
  `F15`   float,
  `F16`   float,
  `F17`   float,
  `F18`   float,
  `F19`   float,
  `F20`   float,
  `F21`   float,
  `F22`   float,
  `F23`   float,
  `F24`   float,
  `F25`   float,
  `F26`   float,
  `F27`   float,
  `F28`   float,
  `F29`   float,
  `F30`   float,
  `F31`   float,
  `F32`   float,
  `F33`   float,
  `F34`   float,
  `F35`   float,
  `F36`   float,
  `F37`   float,
  `F38`   float,
  `F39`   float,
  `F40`   float,
  `F41`   float,
  `F42`   float,
  `F43`   float,
  `F44`   float,
  `F45`   float,
  `F46`   float,
  `F47`   float,
  `F48`   float,
  `F49`   float,
  `F50`   float,     
  `D1`    date,
  `D2`    date,
  `D3`    date,
  `D4`    date,
  `D5`    date,
  `D6`    date,
  `D7`    date,
  `D8`    date,
  `D9`    date,
  `D10`   date,
  `D11`   date,
  `D12`   date,
  `D13`   date,
  `D14`   date,
  `D15`   date,
  `D16`   date,
  `D17`   date,
  `D18`   date,
  `D19`   date,
  `D20`   date,
  `D21`   date,
  `D22`   date,
  `D23`   date,
  `D24`   date,
  `D25`   date,
  `D26`   date,
  `D27`   date,
  `D28`   date,
  `D29`   date,
  `D30`   date,
  `D31`   date,
  `D32`   date,
  `D33`   date,
  `D34`   date,
  `D35`   date,
  `D36`   date,
  `D37`   date,
  `D38`   date,
  `D39`   date,
  `D40`   date,
  `D41`   date,
  `D42`   date,
  `D43`   date,
  `D44`   date,
  `D45`   date,
  `D46`   date,
  `D47`   date,
  `D48`   date,
  `D49`   date,
  `D50`   date,        
  `B1`    int(4),
  `B2`    int(4),
  `B3`    int(4),
  `B4`    int(4),
  `B5`    int(4),
  `B6`    int(4),
  `B7`    int(4),
  `B8`    int(4),
  `B9`    int(4),
  `B10`   int(4),
  `B11`   int(4),
  `B12`   int(4),
  `B13`   int(4),
  `B14`   int(4),
  `B15`   int(4),
  `B16`   int(4),
  `B17`   int(4),
  `B18`   int(4),
  `B19`   int(4),
  `B20`   int(4),
  `B21`   int(4),
  `B22`   int(4),
  `B23`   int(4),
  `B24`   int(4),
  `B25`   int(4),
  `B26`   int(4),
  `B27`   int(4),
  `B28`   int(4),
  `B29`   int(4),
  `B30`   int(4),       
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  INDEX (`grid_id`, `document_id`, `primary_key_value`),
  INDEX  (`database_sql_name_id`, `table_sql_name_id`, `p_column_sql_name_id`, `primary_key_value`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores Rows of Cell Data for SQL Query Type Additional Column Data' DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `#__jgrid_columndata` (
  `id` int(11) NOT NULL auto_increment,
  `document_id` int (11) NOT NULL,
  `column_id` int(11) NOT NULL,
  `columngrid_id` int(11),
  `column_header` varchar(100) NOT NULL,
  `userid` int(11) NOT NULL,
  `row_number` int(11) NOT NULL,
  `string_data` varchar (5000),
  `int_data` int,
  `float_data` float,
  `boolean_data` boolean NOT NULL default false,
  `date_data` date,
  `listboxvaluerowcolor` varchar(64),
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  INDEX(`column_id`,`row_number`,`document_id`),
  INDEX(`columngrid_id`,`row_number`,`document_id`),
  INDEX(`row_number`),
  INDEX(`document_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Cell Data' DEFAULT CHARSET=utf8;

 CREATE TABLE IF NOT EXISTS `#__jgrid_roles` (
  `id` int(11) NOT NULL auto_increment,
  `role_name` varchar (25) NOT NULL,
  `description` varchar (50) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Role Names and Descriptions' DEFAULT CHARSET=utf8;

INSERT IGNORE INTO `#__jgrid_roles` (`id`,`role_name`)
 VALUES (1,'NoAccess'),(2,'Viewer'),(3,'RowEditor'),(4,'AddDeleteRows'),(5,'DocumentManager'),(6,'AccessManager');


CREATE TABLE IF NOT EXISTS `#__jgrid_role_userlist` (
  `id` int(11) NOT NULL auto_increment,
  `userid` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `userid_assigning_role` int(11) NOT NULL,
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  INDEX (`role_id`),
  INDEX (`userid`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores List of Users Assigned to JGrid Roles' DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__jgrid_security` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11),
  `access_rule_application_id` int(11) NOT NULL default 1,
  `userid_assigning_access` int(11) NOT NULL,
  `access_for` int(11) NOT NULL,
  `access_for_name` varchar(150) NOT NULL,
  `access_for_id` int(11) NOT NULL,
  `access_type` int(11) NOT NULL,
  `access_type_name` varchar(25) NOT NULL,
  `access_type_id` varchar(11) NOT NULL,
  `access_subtype_grid_id` int(11) NULL,
  `access_subtype_column_id` int(11) NULL,
  `access_subtype_document_id` int(11) NULL,
  `access_level` int(4) default 0,
   `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  INDEX `ind1` (`access_for`,`access_for_id`),
  INDEX `ind2` (`access_type`,`access_type_id`),
  INDEX `ind3` (`access_type`,`access_subtype_grid_id`,`access_subtype_column_id`),
  INDEX `ind4` (`access_type`,`access_subtype_document_id`,`access_subtype_column_id`),
  INDEX `ind5` (`access_for_name`,`access_type_name`)
  
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGRID Access Control Rules' DEFAULT CHARSET=utf8;
 
CREATE TABLE IF NOT EXISTS `#__jgrid_tables_vcontrol` (
  `id` int(11) NOT NULL auto_increment,
  `grid_version` varchar(25) NOT NULL,
  `jgrid_installed` int(11),
  `grid_comments` varchar(25) NOT NULL,
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores Version and Current JGrid Code' DEFAULT CHARSET=utf8;

INSERT IGNORE INTO `#__jgrid_tables_vcontrol` (`id`,`grid_version`,`jgrid_installed`)
 VALUES (1,'4.2', 0);
 
 
 CREATE TABLE IF NOT EXISTS `#__jgrid_code_vcontrol` (
  `id` int(11) NOT NULL auto_increment,
  `grid_version` varchar(25) NOT NULL,
  `jgrid_installed` int(11),
  `grid_comments` varchar(25) NOT NULL,
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores Version and Current JGrid Tables and Table Data' DEFAULT CHARSET=utf8;

INSERT IGNORE INTO `#__jgrid_code_vcontrol` (`id`,
                                             `grid_version`,
                                             `jgrid_installed`)
 VALUES (1,'4.2', 0);
 
UPDATE IGNORE `#__jgrid_code_vcontrol` 
SET `grid_version` = '4.2',
     `jgrid_installed` = 0
WHERE `id` = 1; 

 CREATE TABLE IF NOT EXISTS `#__jgrid_user_type_defaults` (
  `id` int(11) NOT NULL auto_increment,
  `parent_id` int(11),
  `ordering` int(11),
  `usertype_name` varchar(25) NOT NULL,
  `access_level` int(11),
  `version15` int(11),
  `version16` int(11),
  `version_future` int(11),
  `settings` varchar(25),  
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  INDEX `ind1` (`usertype_name`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Default Types for Registered Joomla User' DEFAULT CHARSET=utf8;

INSERT IGNORE INTO `#__jgrid_user_type_defaults` (`id`,
                                                  `parent_id`,
                                                  `ordering`,
                                                  `usertype_name`,
                                                  `access_level`,
                                                  `version15`,
                                                  `version16`)
 VALUES (1,0,1,'Guest',1,1,0),
        (2,1,2,'Registered',1,1,1),
        (3,2,3,'Author',3,1,1),
        (4,3,4,'Editor',4,1,1),
        (5,4,5,'Publisher',5,1,1),
        (6,5,6,'Manager',6,1,1),
        (7,6,7,'Administrator',6,1,1), 
        (8,7,8,'Super Administrator',6,1,0),
        (9,8,9,'Public',1,0,1), 
        (10,9,10,'Super Users',6,0,1);
        
 CREATE TABLE IF NOT EXISTS `#__jgrid_images` (
  `id` int(11) NOT NULL auto_increment,
  `filename` varchar(120),
  `download_filename` varchar(120),
  `file_type` varchar(25),
  `file_size` int(11),
  `image_thumb_path` varchar(240),
  `tooltip` varchar(240),
  `hyper_url` varchar(240),
  `image_email` varchar(240),
  `image_email_subject` varchar(240),
  `hyper_grid_sheet` varchar(240),
  `extension` varchar(11),
  `grid_id` int(11) NOT NULL,
  `document_id` int(11) NOT NULL,
  `column_id` int(11) NOT NULL,
  `columngrid_id` int(11) NOT NULL,
  `row_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  UNIQUE imageidx (`grid_id`,`document_id`,`column_id`,`row_id`)
  
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores Meta Data of JGrid Stored User Images' DEFAULT CHARSET=utf8;
    
 CREATE TABLE IF NOT EXISTS `#__jgrid_upload_undo` (
  `id` int(11) NOT NULL auto_increment,
  `grid_id` int(11) NOT NULL,
  `document_id` int(11) NOT NULL,
  `row_id` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `session_id` varchar(64) NOT NULL,
  `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                  ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`),
  UNIQUE uploadidx (`grid_id`,`document_id`,`row_id`,`userid`,`session_id`)
  
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores UNDO Data for Last JGrid Upload' DEFAULT CHARSET=utf8;

 CREATE TABLE IF NOT EXISTS `#__jgrid_valid_format` (
  `id` int(11) NOT NULL auto_increment,
  `valid_format` varchar(64) NOT NULL,
  `valid_format_name` varchar(64) NOT NULL,
  `data_type` varchar(11) NOT NULL,
  PRIMARY KEY  (`id`)
  
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores List of Valid Column Format Types' DEFAULT CHARSET=utf8;

INSERT IGNORE INTO `#__jgrid_valid_format` (`id`,
                                            `valid_format`,
                                            `valid_format_name`,
                                            `data_type`)
 VALUES (1,'none','none','T'),
        (2,'alpha','alpha','T'),
        (3,'alphanum','alphanum','T'),
        (4,'url','url','U'),
        (5,'email','email','E'),
        (6,'numeric','numeric','T'),
        (7,'decimal','decimal','T'),
        (8,'phone','phone','T'), 
        (9,'dollar','dollar','T'),
        (10,'time','time','T'), 
        (11,'none','none','T'),
        (12,'m/d/Y','4/1/2010','D'),
        (13,'n/j/Y','04/01/2010','D'),
        (14,'n/j/y','4/1/10','D'),
        (15,'m/j/y','04/1/10','D'),
        (16,'n/d/y','4/01/10','D'),
        (17,'m/j/Y','04/1/2010','D'),
        (18,'n/d/Y','4/01/2010','D'), 
        (19,'m-d-y','04-01-10','D'),
        (20,'m-d-Y','04-01-2010','D'),
        (21,'m/d/Y','04/01/2010','D'),
        (22,'m/d','04/01','D'),
        (23,'m-d','04-01','D'),
        (24,'md','0401','D'),
        (25,'mdy','040110','D'),
        (26,'mdY','04012010','D'),
        (27,'d','01','D'), 
        (28,'Y-m-d','2010-04-01','D'),
        (29,'n-j','4-1','D'),
        (30,'n/j','4/1','D'),
        (31,'D M j Y','Thu Apr 1 2010','D'),
        (32,'d/m/Y','01/04/2010','D'),
        (33,'d.m.Y','01.04.2010','D'),
        (34,'j/n/y','1/4/10','D'),        
        (35,'j.n.Y','1.4.2010','D'),
        (36,'1000','1000','F'),
        (37,'1000.0','1000.0','F'),
        (38,'1000.00','1000.00','F'),
        (39,'1000.000','1000.000','F'),
        (40,'1000.0000','1000.0000','F'),
        (41,'1,000','1,000','F'),
        (42,'1,000.0','1,000','F'),
        (43,'1,000.00','1,000.00','F'),
        (44,'1,000.000','1,000.000','F'),
        (45,'1,000.0000','1,000.0000','F'),
        (46,'$1,000','$1,000','F'),
        (47,'$1,000.0','$1,000.0','F'),
        (48,'$1,000.00','$1,000.00','F'),
        (49,'$1,000.000','$1,000.000','F'),
        (50,'$1,000.0000','$1,000.0000','F');

 CREATE TABLE IF NOT EXISTS `#__jgrid_temp_table` (
  `ordering` int(11) NOT NULL auto_increment,
  `column_id` int(11),
  `group_name` varchar(120),
  `row_id` int(11),
  `grid_application_name` varchar(25) NOT NULL,
  `userid` int(11) NOT NULL,
  `session_id` varchar(64) NOT NULL,
  `temp_type` int(11) NOT NULL,
  PRIMARY KEY  (`ordering`),
  INDEX(`userid`,`session_id`,`row_id`),
  INDEX(`row_id`,`ordering`)  
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid temporary Table for Row Grouping and Sorting Pass 1' DEFAULT CHARSET=utf8;

 CREATE TABLE IF NOT EXISTS `#__jgrid_temp_table2` (
  `ordering` int(11) NOT NULL auto_increment,
  `column_id` int(11),
  `group_name` varchar(120),
  `row_id` int(11),
  `grid_application_name` varchar(25) NOT NULL,
  `userid` int(11) NOT NULL,
  `session_id` varchar(64) NOT NULL,
  `temp_type` int(11) NOT NULL,
  PRIMARY KEY  (`ordering`),
  INDEX(`userid`,`session_id`,`row_id`),
  INDEX(`row_id`,`ordering`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid temporary Table for Row Grouping and Sorting Pass 2' DEFAULT CHARSET=utf8;    
        
CREATE TABLE IF NOT EXISTS `#__jgrid_chart_category_axes` (
  `caxes_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `chart_id` int(11) NOT NULL,
  `position` varchar(50) NOT NULL,
  `title` varchar(255) NOT NULL,
  `cfields` varchar(500) NOT NULL,
  `cat_names` varchar(500) NOT NULL,
  `minorTickSteps` int(11) NOT NULL,
  `majorTickSteps` int(11) NOT NULL,
  `length` int(11) NOT NULL,
  `label_dgree_rotate` int(11) NOT NULL DEFAULT '90',
  PRIMARY KEY (`caxes_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Chart Category Axis Configuration Settings' DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `#__jgrid_chart_common_label` (
  `chart_label` int(11) NOT NULL AUTO_INCREMENT,
  `chart_id` int(11) NOT NULL,
  PRIMARY KEY (`chart_label`)
) ENGINE=MyISAM AUTO_INCREMENT=1 COMMENT='This table stores JGrid Chart Common Label Configuration Settings' DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__jgrid_chart_gauge_axes` (
  `gaxes_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `chart_id` int(11) NOT NULL,
  `position` varchar(50) NOT NULL,
  `minimum` int(11) NOT NULL,
  `maximum` int(11) NOT NULL,
  `steps` int(11) NOT NULL,
  `margin` int(11) NOT NULL,
  PRIMARY KEY (`gaxes_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Chart Gauge Axis Settings' DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__jgrid_chart_legend` (
  `legend_id` int(11) NOT NULL AUTO_INCREMENT,
  `chart_id` int(11) NOT NULL,
  `position` varchar(50) NOT NULL,
  `x` int(11) NOT NULL,
  `y` int(11) NOT NULL,
  `padding` int(11) NOT NULL,
  `itemSpacing` int(11) NOT NULL,
  `boxFill` varchar(50) NOT NULL,
  `labelFont` varchar(255) NOT NULL,
  PRIMARY KEY (`legend_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Chart Legend Configuration Settings' DEFAULT CHARSET=utf8;


CREATE TABLE IF NOT EXISTS `#__jgrid_chart_numeric_axes` (
  `naxes_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `chart_id` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `grid` varchar(10) NOT NULL,
  `position` varchar(100) NOT NULL,
  `fields` varchar(300) NOT NULL,
  `minimum` int(11) NOT NULL,
  `minorTickSteps` int(11) NOT NULL,
  `majorTickSteps` int(11) NOT NULL,
  `width` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`naxes_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Chart Numeric Axes Configuration Settings' DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__jgrid_chart_numeric_axes_fields` (
  `num_axes_field_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `numeric_axes_id` int(11) NOT NULL,
  `field_value` varchar(255) NOT NULL,
  `chart_id` int(11) NOT NULL,
  PRIMARY KEY (`num_axes_field_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Chart Numeric Axis Fields Configuration Settings' DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__jgrid_chart_radial_axes` (
  `raxes_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `chart_id` int(11) NOT NULL,
  `fields` varchar(255) NOT NULL,
  `position` varchar(50) NOT NULL,
  `label` varchar(250) NOT NULL,
  `steps` varchar(250) NOT NULL,
  `maximum` int(11) NOT NULL,
  `minimum` int(11) NOT NULL,
  PRIMARY KEY (`raxes_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Chart Radial Axis Configuration Settings' DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__jgrid_chart_series` (
  `series_id` int(11) NOT NULL AUTO_INCREMENT,
  `chart_id` int(11) NOT NULL,
  `stacked` varchar(6) DEFAULT 'false',
  `series_type` varchar(50) NOT NULL,
  `highlight` varchar(500) NOT NULL,
  `showInLegend` tinyint(1) NOT NULL DEFAULT '1',
  `xField` varchar(255) NOT NULL,
  `yField` varchar(255) NOT NULL,
  `axis` varchar(100) NOT NULL,
  `serise_label_id` int(11) NOT NULL,
  `field` varchar(255) NOT NULL,
  `donut` int(11) NOT NULL,
  `showMarkers` tinyint(1) NOT NULL DEFAULT '0',
  `markerConfig_id` int(11) NOT NULL,
  `series_style` int(11) NOT NULL,
  `needle` tinyint(1) NOT NULL,
  PRIMARY KEY (`series_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Chart Series Configuration Settings' DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__jgrid_chart_series_markerConfig` (
  `marker_config_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `series_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `radius` int(11) NOT NULL,
  `fill` varchar(100) NOT NULL,
  `size` int(11) NOT NULL,
  PRIMARY KEY (`marker_config_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__jgrid_chart_series_label` (
  `serise_label_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `serise_id` int(11) NOT NULL,
  `display` varchar(50) NOT NULL,
  `color` varchar(30) NOT NULL,
  `contrast` tinyint(1) NOT NULL,
  `field` varchar(255) NOT NULL,
  `orientation` varchar(20) NOT NULL,
  `font` varchar(255) NOT NULL,
  PRIMARY KEY (`serise_label_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Chart Series Label Configuration Settings' DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__jgrid_chart_time_axes` (
  `taxes` int(11) NOT NULL AUTO_INCREMENT,
  `chart_id` int(11) NOT NULL,
  `title` varchar(300) NOT NULL,
  `position` varchar(50) NOT NULL,
  `fields` varchar(300) NOT NULL,
  `dateFormat` varchar(20) NOT NULL,
  `fromDate` varchar(50) NOT NULL,
  `toDate` varchar(50) NOT NULL,
  PRIMARY KEY (`taxes`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Chart Time Axis Configuration Settings' DEFAULT CHARSET=utf8;

CREATE TABLE IF NOT EXISTS `#__jgrid_document_graph` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `document_id` int(11) DEFAULT 0,
  `parent_id` int(11) DEFAULT 0,
  `ordering` int(11) DEFAULT 0,
  `column_id` int(11) DEFAULT 0,
  `column_graph_title` varchar(25) NOT NULL,
  `grid_id` int(11) NOT NULL,
  `num_axis_title` varchar(255) NOT NULL,
  `num_axes_position` varchar(100) NOT NULL,
  `num_field_val` varchar(555) NOT NULL,
  `chart_grid_option` varchar(15) NOT NULL,
  `cat_axes_position` varchar(50) NOT NULL,
  `cat_title` varchar(255) NOT NULL,
  `cat_field_val` varchar(500) NOT NULL,
  `chat_type` varchar(255) NOT NULL,
  `serise_axis_id` varchar(50) NOT NULL,
  `stacked_chart_opt` varchar(10) NOT NULL,
  `chart_highlight_opt` varchar(10) NOT NULL,
  `chart_category` varchar(20) NOT NULL,
  `last_updated` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,  
  PRIMARY KEY (`id`),
  KEY `document_id` (`document_id`)
) ENGINE=MyISAM AUTO_INCREMENT=0 COMMENT='This table stores JGrid Document Graph Configuration Settings' DEFAULT CHARSET=utf8;

        