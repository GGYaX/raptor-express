<?php
/**
 * jSecure Lite components for Joomla!
 * Originally written for Joomla as jSecure Lite by Ajay Lulia.
 *
 * @author      $Author: Ajay Lulia $
 * @copyright   Joomla Service Provider - 2012
 * @package     jSecure Lite 1.0
 * @license     http://www.gnu.org/copyleft/gpl.html GNU/GPL
 * @version     $Id: jsecurelite.php  $
 */
defined( 'JPATH_BASE' ) or die( 'Direct Access to this location is not allowed.' );
echo JText::_("There is no frontend component built in to jSecure Lite.");
