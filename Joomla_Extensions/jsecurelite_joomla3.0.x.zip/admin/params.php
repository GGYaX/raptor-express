<?php
defined( '_JEXEC' ) or die( 'Restricted access' );
class JSecureliteConfig {
	public $publish = '1';
	public $key = '00be0f3bc3c448a2f4fcbc7b6e6b6746';
	public $passkeytype = 'url';
	public $options = '0';
	public $custom_path = 'plugins/system/jsecurelite/404.html';
}