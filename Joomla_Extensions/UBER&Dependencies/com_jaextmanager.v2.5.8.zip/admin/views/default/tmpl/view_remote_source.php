<?php defined ( '_JEXEC' ) or die ( 'Restricted access' ); ?>
<div align="diff-source">
<div id="diff-view-mode">
<pre><code><?php echo $this->source; ?></code></pre>
</div>
</div>