 
<?php 
/**
 * Jgrids default.php in Joomla/Modules/mod_jgrid/tmpl
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Module
 * @subpackage	mod_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
// no direct access
defined('_JEXEC') or die('Restricted access');
require_once(JPATH_BASE . '/administrator/components/com_jgrid/os/jgrid/functions.php' );
$document = JFactory::getDocument();
$db =JFactory::getDBO();
$jinput=JFactory::getApplication()->input;

JLoader::import( 'joomla.version' );
$jversion = new JVersion();
if (version_compare( $jversion->RELEASE, '2.5', '<=')) {
    if(JFactory::getApplication()->get('jquery') !== true) {
        // load jQuery here
        JFactory::getApplication()->set('jquery', true);
    }
} else {
    JHtml::_('jquery.framework');
}

//Make extjs 3.1.0 compatable with ie 8
header('X-UA-Compatible: IE=EmulateIE7');

// check and see if database needs upgraded from new install
jgrid_database_upgrade_check("Site");

$jgrid_theme=1;

	$query = 'SELECT theme
              FROM #__jgrid_applications
              WHERE grid_application_name = "com_jgrid"'; 					
	$db->setQuery($query);
	$jgrid_theme=$db->loadResult();



if($jgrid_theme)
{
	switch($jgrid_theme)
	{
		case 1:
			$document->addCustomTag('<link rel="stylesheet" type="text/css" href="administrator/components/com_jgrid/os/ext/resources/css/ext-all.css" />' );	
			Break;
		case 2:
			$document->addCustomTag('<link rel="stylesheet" type="text/css" href="administrator/components/com_jgrid/os/ext/resources/css/ext-all-gray.css" />' );	
			Break;
		case 3:
			$document->addCustomTag('<link rel="stylesheet" type="text/css" href="administrator/components/com_jgrid/os/ext/resources/css/ext-all-access.css" />' );	
			Break;
		case 4:
			$document->addCustomTag('<link rel="stylesheet" type="text/css" href="administrator/components/com_jgrid/os/ext/resources/css/ext-all-neptune.css" />' );	
			Break;
		case 5:
			$document->addCustomTag('<link rel="stylesheet" type="text/css" href="administrator/components/com_jgrid/os/ext/resources/css/ext-sandbox.css" />' );	
			Break;       	
	}
}
else 
{
	$document->addCustomTag('<link rel="stylesheet" type="text/css" href="administrator/components/com_jgrid/os/ext/resources/css/ext-all.css" />' );
}



$document->addCustomTag('<link rel="stylesheet" type="text/css" href="administrator/components/com_jgrid/os/ext/ux/css/FieldHelp.css" />
		               	 <link rel="stylesheet" type="text/css" href="administrator/components/com_jgrid/os/ext/ux/gridfilters/css/GridFilters.css" />
		           	     <link rel="stylesheet" type="text/css" href="administrator/components/com_jgrid/os/ext/ux/gridfilters/css/RangeMenu.css" />
		           	     <link rel="stylesheet" type="text/css" href="administrator/components/com_jgrid/os/ext/ux/css/jgrid_custom.css" />
                         
                         '); 
// keeps the Joomla page from timing out when the extjs grid is displayed		
echo JHTML::_('behavior.keepalive');

// script change to keep mootools working with extjs 4.0
echo JHTML::script('administrator/components/com_jgrid/os/jgrid/mooltools_document_id_save.js',false);

//echo JHTML::script('administrator/components/com_jgrid/os/ext/adapter/ext/ext-base.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ext-all.js',false);
//echo JHTML::script('administrator/components/com_jgrid/os/ext/ext-all-debug.js',false);
//echo JHTML::script('administrator/components/com_jgrid/os/ext/ext-all-debug-w-comments.js',false);

if($jgrid_theme)
{
	switch($jgrid_theme)
	{
		case 2:
			//echo JHTML::script('administrator/components/com_jgrid/os/ext/ext-theme-gray.js',false);	
			Break;
		case 3:
			//echo JHTML::script('administrator/components/com_jgrid/os/ext/ext-theme-access.js',false);	
			Break;
		case 4:
			echo JHTML::script('administrator/components/com_jgrid/os/ext/ext-theme-neptune.js',false);
			Break;	
	}
}

// script change to keep mootools working with extjs 4.0
echo JHTML::script('administrator/components/com_jgrid/os/jgrid/extjs4_document_id_save.js',false);

//echo JHTML::script('administrator/components/com_jgrid/os/ext/plugin/TreeViewDragDrop.js',false);

echo JHTML::script('components/com_jgrid/views/jgrid/js/MessageBus.js',false);

echo JHTML::script('administrator/components/com_jgrid/os/jgrid/Extjs_Loader_getPath_php.js',false);

//echo JHTML::script('Ext.Loader.setConfig({enabled: true});
                  //  Ext.onReady(function(){ mo
                   //  });',false);

//echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/RowEditor.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/TransformGrid.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/menu/ListMenu.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/menu/RangeMenu.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/filter/Filter.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/filter/StringFilter.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/filter/DateFilter.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/filter/ListFilter.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/filter/NumericFilter.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/filter/BooleanFilter.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/FiltersFeature.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/IFrame.js',false);
//echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/Override.js',false);
//echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/HelpQtip.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/FieldHelp.js',false);
//echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/fileuploadfield/FileUploadField.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/jgrid/Custom_JSON.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/jgrid/formula/FormulaDate.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/jgrid/formula/FormulaStack.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/jgrid/formula/FormulaTokanizer.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/jgrid/formula/FormulaEvaluator.js',false);

ob_start();


// load extjs 4 mvc application

require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/Config.php' );
require(JPATH_BASE . '/administrator/components/com_jgrid/os/jgrid/CustomVtypes.php' );
require(JPATH_BASE . '/administrator/components/com_jgrid/os/ext/ux/Printer.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/view/JGridHelp.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/model/JGridDocumentModels.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/model/JGridModels.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/model/JGridComboModels.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/store/JGridComboStores.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/store/JGridDocumentStores.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/store/JGridStores.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/renderers/JGridCombos.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/view/JGridImageWin.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/view/JGridEmailWin.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/view/JGridThumbnailWin.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/view/JGridDownloadWin.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/view/JGridUploadWin.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/renderers/JGridColRenderers.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/renderers/JGridGridRenderers.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/renderers/JGridColumns.php' );
	require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/view/JGridToolbarSecurity.php' );
	require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/view/JGridAccessRules.php' );
	require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/view/JGridSecurity.php' );	
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/view/JGridSheetSettingWin.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/view/JGridToolbars.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/renderers/JGridChart.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/view/JGridGrids.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/controller/JGridControllers.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/view/Viewport.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/view/JGridChartWindow.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app/view/JGridChartWin.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/Initalize.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrid/js/app.php' );
//load the jgrid component to the users screen
$script = ob_get_clean();
$document->addScriptDeclaration($script);
//JError::raiseError(1005,$params->get ('jgrid_width'));
//return;
?>	
<style>
.grid-row-insert-below {
	border-bottom: 1px solid #3366cc;
}

.grid-row-insert-above {
	border-top: 1px solid #3366cc;
}
</style>
<div id="<?php  if($params->get ('jgrid_renderTo'))
                {
                 echo $params->get ('jgrid_renderTo');
                } 
                else echo 'jgrid_module1';               
?>"></div>
