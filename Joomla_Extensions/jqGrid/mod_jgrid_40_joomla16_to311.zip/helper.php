<?php
/**
 * helper.php model in Joomla/Modules/mod_jgrid
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Module
 * @subpackage	mod_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

require_once(JPATH_BASE . '/administrator/components/com_jgrid/os/jgrid/functions.php' );
// no direct access
defined('_JEXEC') or die('Restricted access');

class modJgridHelper
{
	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The string containing the SQL call (query) that will retrieve the desired results
	 * @var string
	 */
	var $_query=null;

	/**
	 * Retrieves the "Columns assigned to grid" data
	 * @return array containing the "Columns assigned to grid" rows or false if no rows returned
	 *
	 */
	var $_data =NULL;


	function initializeModule($params)
	{

		$user=JFactory::getUser();
		//get database
		$db =JFactory::getDBO();
	 // load initial data so grid visible
		 
		// check to see if application already registered
		$query = 'SELECT count(1)
                       FROM #__jgrid_applications
                       WHERE grid_application_name="'.JRequest::getVar('jgrid_application_name').'"';  

		$db->setQuery($query);


		if(!$db->loadResult())
		{
			// register application
			$query = 'INSERT INTO #__jgrid_applications (grid_application_name)
      VALUES ("'.JRequest::getVar('jgrid_application_name').'")';                    
			$db->setQuery($query);

			if($db->query())
			{
				$db->setQuery('SELECT max(ordering)
		                      FROM #__jgrid_grids');
				$max_ordering = $db->loadResult();
				if(!$max_ordering)
				{
					$max_ordering = 0;
					$new_parent_id = 0;
				}
				else
				{
					$db->setQuery('SELECT id
		                      FROM #__jgrid_grids
                          WHERE ordering = '.$max_ordering);
					$new_parent_id = $db->loadResult();
				}

				$max_ordering = $max_ordering + 1;

				// create one grid
				$query = 'INSERT INTO #__jgrid_grids (parent_id,
                                             grid_reference_id, 
                                             grid_application_name, 
                                             renderTo, 
                                             title, 
                                             ordering,
                                             frame, 
                                             height,
                                             width, 
                                             stripe_rows, 
                                             enableColumnMove,
                                             enableGroupBy,
                                             groupByField,
                                             sortByField,
                                             sortByDirection,
                                             enable_paging,
                                             paging_records,
                                             tabtip)
              VALUES ('.$new_parent_id.',
                      "'.JRequest::getVar('jgrid_application_name').'-1",
                      "'.JRequest::getVar('jgrid_application_name').'",
                      "'.$params->get ('jgrid_renderTo').'", 
                      "Sample Grid",
                      '.$max_ordering.',
                      true,
                      "'.$params->get ('jgrid_height').'",
                      "'.$params->get ('jgrid_width').'",
                      true,
                      true,
                      false,
                      "name",
                      "name",
                      "ASC",
                      false,
                      "30",
                      "Sample Module Grid")';                      
				$db->setQuery($query);
				if($db->query())
				{
					// get new grid id
					$db->setQuery('SELECT last_insert_id() FROM #__jgrid_grids');
					$grid_id = $db->loadResult();
					//create one column into table
					$query = 'INSERT INTO #__jgrid_columngrid (parent_id,
                                                      column_id, 
                                                      grid_id,
                                                      ordering)
                     VALUES (0,
                            (SELECT id
                              FROM #__jgrid_columns
                              LIMIT 1),
                              '.$grid_id.',
                             1)';
					$db->setQuery($query);
					if($db->query())
					{
						// Insert one document
						$query = 'INSERT INTO #__jgrid_document (document_title,
                                                        creator_userid, 
                                                        grid_id, 
                                                        grid_default_document_flag)
          VALUES ("Public Sheet '.JRequest::getVar('jgrid_application_name').'-1",
                  ' . $user->id .',
                  '.$grid_id.',
                  1)';
						$db->setQuery($query);
						$db->query();
						 
						// get new grid id
						$db->setQuery('SELECT last_insert_id() FROM #__jgrid_document');
						$document_id = $db->loadResult();
						 
						// give access to creating user
						$query = 'INSERT INTO #__jgrid_security (userid_assigning_access,
                                                           access_for, 
                                                           access_for_id, 
                                                           access_type,
                                                           access_type_id,
                                                           access_subtype_grid_id,
                                                           access_subtype_column_id,
                                                           access_subtype_document_id,
                                                           access_level)
                          VALUES (' . $user->id .',
                                  1,
                                  ' . $user->id .',
                                  1,
                                '.$grid_id.',
                                '.$grid_id.',
                                  0,
                                  0,
                                  6)';                   
						$db->setQuery($query);
						$db->query();

						//assign user to document for this new grid
						$query = ' INSERT IGNORE INTO #__jgrid_current_user_grid_document (userid,
                                                                             grid_id, 
                                                                             current_document_id,
                                                                             previous_document_id1)
                            VALUES ('.$user->id.',
                                    '.$grid_id.',
                                    '.$document_id.',
                                    0)'; 
						$db->setQuery($query);
						$db->query();
					}
				}
			}
		}
	}

	/*
	 If (!$params->get ('tablecreated'))
		{
		$query = 'CREATE TABLE IF NOT EXISTS '.$db->nameQuote(`#__jgrid_data`).'('
		.$db->nameQuote('id').' int (11) NOT NULL auto_increment, '
		.$db->nameQuote('greeting').' varchar (25) NOT NULL , '
		.$db->nameQuote('coverthumb').' varchar (25) NOT NULL , '
		.$db->nameQuote('title').' varchar (25)  NOT NULL , '
		.$db->nameQuote('director').' varchar (25)  NOT NULL, '
		.$db->nameQuote('released').' date NOT NULL, '
		.$db->nameQuote('genre').' varchar (25) NOT NULL , '
		.$db->nameQuote('tagline').' varchar (25) NOT NULL , '
		.$db->nameQuote('type').' varchar (25) NOT NULL , '
		.'Primary Key ('.$db->nameQuote('id'). ' )'
		.') CHARACTER SET `utf8 COLLATE `utf8_general_ci`';
		$db->setQuery($query);
		$db->query();
			
			
			
		// set the 'tabledreated' flag to true
		$params->set('tablecreated', 1);
		}

		$type = $params->get('type', 0);
		$query = modJgridHelper::_buildQuery($type);
		$db->setQuery($query);
		$rows = $db->loadObjectList();
		return (json_encode($rows)	);
		}
		*/
	/**
	 * Retrieves the jgrid data
	 * @return array Array of objects containing the data from the database
	 */
	function getGriddata($params)
	{
		$user=JFactory::getUser();
		$db =JFactory::getDBO();
		// check for joomla version
		$version = new JVersion;
		$joomla = $version->getShortVersion();
		$no_access_override_list='0';
		$global_grid_rule_override = '0';


		//check to see if current document exists, if not update to the default document, always reset guest to default
		$session =JFactory::getSession();
		$temp_session_id = '"'.$session->getId().'"';

		// Remove old sessions for guest users
		$query= 'DELETE FROM #__jgrid_current_user_grid_document
                       WHERE NOT EXISTS (SELECT *
                                         FROM #__session
                                         WHERE #__jgrid_current_user_grid_document.session_id = #__session.session_id)';                 
		$db->setQuery($query);
		$db->query();

		$query='UPDATE #__jgrid_current_user_grid_document a,
		                      #__jgrid_document b		                      
		               SET a.current_document_id = b.id
		               WHERE b.grid_default_document_flag=1
		                 AND a.userid = ' . $user->id .'
		                 AND a.grid_id = b.grid_id
		                 AND a.session_id = '.$temp_session_id.'
		                 AND (0 =  (SELECT count(1) 		                                                    
		                            FROM #__jgrid_document c 		                                   
		                            WHERE a.current_document_id = c.id))';						               	
		$db->setQuery($query);
		$db->query();
		
		//check to see if user has current document access if not assign user to default document
		// find document to display
		$query='INSERT IGNORE INTO #__jgrid_current_user_grid_document (current_document_id,
		                                                                  userid,
		                                                                  grid_id,
		                                                                  session_id)                                                
		               SELECT a.id as current_document_id,
		                      ' . $user->id.' as userid,
		                       a.grid_id,
		                       '.$temp_session_id.' as session_id
	                   FROM  #__jgrid_document a
	                   WHERE a.grid_default_document_flag=1
		               AND   a.grid_id NOT IN (SELECT grid_id 
		                                FROM #__jgrid_current_user_grid_document b, 
		                                     #__jgrid_grids c
		                                WHERE b.userid = ' . $user->id .'
		                                AND b.grid_id = c.id
		                                AND b.session_id = '.$temp_session_id.'
		                                AND c.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'")'; 	
		//JError::raiseError(1001, JText::_('sql'.$query));
		//  	return;
		$db->setQuery($query);
		$db->query();
		
		$admin_user = check_for_backend_admin_access_rights();
		
		if(!$admin_user)
		{
		  $admin_user = 0;
		  // check for all grid override for global grid rules applying to this user
      $global_grid_rule_override = 0; 
			$query='SELECT count(1)
		                                FROM #__jgrid_grids a,
		                                     #__jgrid_security e, 
		                                     #__jgrid_role_userlist f
		                                WHERE ((e.access_for = 1 
		                                         AND e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2 
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.')
		                                        OR (e.access_for=4))
		                                 AND e.access_type_id = -1   
		                                 AND e.access_level > 0
		                                 AND a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"';
		    $db->setQuery($query);
			$global_grid_rule_override = $db->loadResult();
		  
		   	$no_access_override_list = '0';
		    if(!$global_grid_rule_override)
		    {
		    	$global_grid_rule_override = 0;
		  
		  
		  // check for overrides for no access commands for specific roles or users
				$query='SELECT DISTINCT a.id
			                                FROM #__jgrid_grids a,
			                                     #__jgrid_security e, 
			                                     #__jgrid_role_userlist f,
			                                     #__jgrid_document g
			                                WHERE ((e.access_for = 1 
			                                         AND e.access_for_id = '.$user->id.')
			                                       OR
			                                       (e.access_for=2 
			                                          AND e.access_for_id = f.role_id
			                                          AND f.userid ='.$user->id.')
			                                        OR (e.access_for=4))
			                                 AND ((a.id = e.access_type_id
			                                        OR e.access_type_id = -1) 
			                                       OR (a.id = g.grid_id)
			                                             AND g.grid_id = e.access_type_id)  
			                                AND ((e.access_level > 0
			                                       OR e.access_for=4)
			                                     OR  
			                                      (a.id = e.access_type_id
			                                         AND e.access_type = 1))
			                                 AND a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"';	
		                                 		                                 
		  $db->setQuery($query);
		  $result = $db->loadObjectList();
		  $no_access_override_list = '0';
	  	for($i=0;$i<count($result);$i++)
	  	{
		  	$no_access_override_list.=',';
		  	$no_access_override_list.=$result[$i]->id;

	  	}
	  	}
		}
		

		if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
		{
			$query =  'SELECT   DISTINCT
		                          a.id,
		                          a.select_type,
		                          a.primary_key_column,
		                          a.grid_reference_id,
		                          a.ordering, 
		                          a.grid_application_name, 
		                          a.renderTo,
		                          a.title, 
		                          a.frame,
		                          a.print,
		                          a.number_width,
		                          a.number_header, 
		                          a.height, 
		                          a.width, 
		                          a.stripe_rows,
		                          a.enable_row_numbers,
		                          a.enableColumnMove,
		                          a.enableColumnResize,
		                          a.columnLines,
		                          a.enableRowEditor,
		                          a.enableGroupBy,
		                          a.enableGroupBySummary,
		                          a.groupByField,
		                          a.hideGroupedColumn,
		                          a.showGroupName,
		                          a.startCollapsed,
		                          a.enableSortBy, 
		                          a.sortByField,
		                          a.sortByDirection,
		                          a.enable_paging,
		                          a.paging_records,
		                          a.tabtip,
		                          a.cls,
		                          a.ctCls,
		                          b.current_document_id,
		                          b.previous_document_id1, 
		                          c.document_title
		                   FROM #__jgrid_grids a, 
		                        #__jgrid_current_user_grid_document b,
		                        #__jgrid_document c,
		                        #__jgrid_columngrid d
		                   WHERE a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"
		                   AND   a.id = b.grid_id
		                   AND   a.id = d.grid_id
		                   AND   c.id = b.current_document_id
		                   AND   b.userid = ' . $user->id .'
		                   AND   b.session_id = '.$temp_session_id.'		                       
                           AND   (a.id IN ('.$no_access_override_list.')
                           		   OR '.$admin_user.' > 0 		                       
                                   OR     0 = (SELECT count(1) 
		                                FROM #__jgrid_security e, 
		                                     #__jgrid_role_userlist f,
		                                     #__jgrid_user_type_defaults g,
		                                     #__usergroups h,
		                                     #__user_usergroup_map i
		                                WHERE ((e.access_for = 1 
		                                         AND 
		                                         e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.')
		                                       OR
		                                       (e.access_for=3
		                                          AND e.access_for_id = g.id
		                                          AND ((g.usertype_name = h.title
		                                                 AND i.user_id = '.$user->id.'
		                                                 AND h.id=i.group_id)
		                                               OR (e.access_for_id = 9 AND '.$user->id.' = 0))
		                                              )
		                                       )
		                                 AND e.access_level = 0
		                                 AND 0 = ' .$global_grid_rule_override . '
		                                 AND '.$admin_user.' = 0
		                                 AND ((a.id = e.access_type_id
		                                 		OR e.access_type_id = -1)
		                                      AND e.access_type = 1))
		                        )                  
                           ORDER BY a.ordering';
                                                                                
		//	echo print_r($user);
//echo 'sql'.$this->_query;
			//SELECT DISTINCT a.id, a.grid_reference_id, a.ordering, a.grid_application_name, a.renderTo, a.title, a.frame, a.print, a.height, a.width, a.stripe_rows, a.enable_row_numbers, a.enableColumnMove, a.enableColumnResize, a.columnLines, a.enableRowEditor, a.enableGroupBy, a.groupByField, a.sortByField, a.sortByDirection, a.enable_paging, a.paging_records, a.tabtip, b.current_document_id, b.previous_document_id1, c.document_title FROM `jos_jgrid_grids` a, `jos_jgrid_current_user_grid_document` b, `jos_jgrid_document` c, `jos_jgrid_columngrid` d WHERE a.grid_application_name = "com_jgrid" AND a.id = b.grid_id AND a.id = d.grid_id AND c.id = b.current_document_id AND b.userid = 42 AND b.session_id = "9e6d9012665a2565bc5233344a721968" AND 0 = (SELECT count(1) FROM `jos_jgrid_security` e, `jos_jgrid_role_userlist` f, `jos_jgrid_user_type_defaults` g, `jos_usergroups` h, `jos_user_usergroup_map` i WHERE ((e.access_for = 1 AND e.access_for_id = 42) OR (e.access_for=2 AND e.access_for_id = f.role_id AND f.userid =42) OR (e.access_for=3 AND e.access_type_id NOT IN (0) AND e.access_for_id = g.id AND g.usertype_name = h.title AND i.user_id = 42 AND h.id=i.group_id)) AND e.access_level = 0 AND (a.id = e.access_type_id AND e.access_type = 1)) ORDER BY a.ordering

			//JError::raiseError(1002,$query);
			//return;
		}
		else
		{
			$query = 'SELECT   DISTINCT
		                          a.id,
		                          a.select_type,	                          
		                          a.primary_key_column,
		                          a.grid_reference_id,
		                          a.ordering, 
		                          a.grid_application_name, 
		                          a.renderTo,
		                          a.title, 
		                          a.frame,
		                          a.print,
		                          a.number_width,
		                          a.number_header, 
		                          a.height, 
		                          a.width, 
		                          a.stripe_rows,
		                          a.enable_row_numbers,
		                          a.enableColumnMove,
		                          a.enableColumnResize,
		                          a.columnLines,
		                          a.enableRowEditor,
		                          a.enableGroupBy,	                          
		                          a.enableGroupBySummary,
		                          a.groupByField,
		                          a.hideGroupedColumn,
		                          a.showGroupName,
		                          a.enableSortBy, 
		                          a.sortByField,
		                          a.sortByDirection,
		                          a.enable_paging,
		                          a.paging_records,
		                          a.tabtip,
		                          a.cls,
		                          a.ctCls,
		                          b.current_document_id,
		                          b.previous_document_id1, 
		                          c.document_title
		                   FROM #__jgrid_grids a, 
		                        #__jgrid_current_user_grid_document b,
		                        #__jgrid_document c,
		                        #__jgrid_columngrid d
		                   WHERE a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"
		                   AND   a.id = b.grid_id
		                   AND   a.id = d.grid_id
		                   AND   c.id = b.current_document_id
		                   AND   b.userid = ' . $user->id .'
		                   AND   b.session_id = '.$temp_session_id.'		                       
		                   AND   (a.id IN ('.$no_access_override_list.')
		                   		    OR '.$admin_user.' > 0 		                       
                                   OR     0 = (SELECT count(1) 
		                                FROM #__jgrid_security e, 
		                                     #__jgrid_role_userlist f,
		                                     #__jgrid_user_type_defaults g
		                                WHERE ((e.access_for = 1 
		                                         AND 
		                                         e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.')
		                                       OR
                                       (e.access_for=3
		                                          AND (e.access_for_id = g.id
		                                                OR 
		                                               (e.access_for_id = 1
		                                                  AND '.$user->id.' = 0))
		                                        )
		                                      )
		                                 AND e.access_level = 0
		                                 AND 0 = ' .$global_grid_rule_override . '
		                                 AND '.$admin_user.' = 0
		                                 AND ((a.id = e.access_type_id
		                                 		OR e.access_type_id = -1)
		                                      AND e.access_type = 1))
		                        )                   
                           ORDER BY a.ordering';                         
		}
		//JError::raiseError(1001, JText::_('sql'.$query));
		//return;

		$db->setQuery($query);
		$data = $db->loadObjectList();

		if($data) return $data;
		else return false;
	}
	/**
	 * Retrieves the jgrid data
	 * @return array Array of objects containing the data from the database
	 */
	function getColumndata($params)
	{
		$data=$columnitems;
		$user=JFactory::getUser();
		$db =JFactory::getDBO();
		$global_grid_rule_override = '0';

		// check for joomla version
		$version = new JVersion;
		$joomla = $version->getShortVersion();
		$no_access_override_list='0';
		
		$admin_user = check_for_backend_admin_access_rights();
		
		if(!$admin_user)
		{
		  $admin_user = 0;
		  	// check for all grid override for global grid rules applying to this user
      $global_grid_rule_override = 0;  
			$query='SELECT count(1)
		                                FROM #__jgrid_grids a,
		                                     #__jgrid_security e, 
		                                     #__jgrid_role_userlist f
		                                WHERE ((e.access_for = 1 
		                                         AND e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2 
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.')
		                                        OR (e.access_for=4))
		                                 AND e.access_type_id = -1   
		                                 AND e.access_level > 0
		                                 AND a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"';
			$db->setQuery($query);
			$global_grid_rule_override = $db->loadResult();
			$no_access_override_list = '0';
			if(!$global_grid_rule_override)
		    {
		    	$global_grid_rule_override = 0;      	
		  // check for overrides for no access commands for specific roles or users
				$query='SELECT DISTINCT a.id
			                                FROM #__jgrid_grids a,
			                                     #__jgrid_security e, 
			                                     #__jgrid_role_userlist f,
			                                     #__jgrid_document g
			                                WHERE ((e.access_for = 1 
			                                         AND e.access_for_id = '.$user->id.')
			                                       OR
			                                       (e.access_for=2 
			                                          AND e.access_for_id = f.role_id
			                                          AND f.userid ='.$user->id.')
			                                        OR (e.access_for=4))
			                                 AND ((a.id = e.access_type_id
			                                        OR e.access_type_id = -1)
			                                       OR (a.id = g.grid_id)
			                                             AND g.grid_id = e.access_type_id)  
			                                AND ((e.access_level > 0
			                                       OR e.access_for=4)
			                                     OR  
			                                      (a.id = e.access_type_id
			                                         AND e.access_type = 1))
			                                 AND a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"';
		  $db->setQuery($query);
	  	$result = $db->loadObjectList();
	  	$no_access_override_list = '0';
	  	for($i=0;$i<count($result);$i++)
	  	{
	  		$no_access_override_list.=',';
	  		$no_access_override_list.=$result[$i]->id;
	  	}
	  	}
	}	

		//	JError::raiseError(1001, JText::_('sql'.$user->id));
		//	return;


		if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
		{
			$query =   'SELECT DISTINCT
		                          b.id,
		                          b.parent_id,
		                          a.id AS aid,
		                          b.grid_id,
		                          a.parent_id as aparent_id,
	                              b.column_id,
                                b.column_type, 
	                              b.ordering,
	                              c.header,
	                        CONCAT(c.data_type, b.id) AS "dataindex", 
	                               c.editable, 
	                               c.width, 
	                               c.data_type,  
	                               c.ddefault,
	                               c.align,
	                               c.css,
	                               c.tooltip,
	                               c.email_subject,
	                               c.freeze_column, 
	                               c.dfilter,
	                               c.validation_type,
	                               c.sortable,
	                               c.summarycolumn,
                                   c.summarytype,
                                   c.summaryprefix,
                                   c.summarypostfix,
                                   b.formula                                 	                              
                         FROM  #__jgrid_grids a, 
                               #__jgrid_columngrid b,
                               #__jgrid_columns c 
                         WHERE a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"
                         AND   a.id = b.grid_id 
                         AND   c.id = b.column_id
                         AND (a.id IN ('.$no_access_override_list.')
                         	   OR '.$admin_user.' > 0 
                               OR 0 = (SELECT count(1) AS w
		                           FROM #__jgrid_security g, 
		                                #__jgrid_role_userlist h,
		                                #__jgrid_user_type_defaults i,
		                                #__usergroups j,
		                                #__user_usergroup_map k
		                           WHERE ((g.access_for = 1 
		                                     AND 
		                                     g.access_for_id = '.$user->id.')
		                                  OR
		                                   (g.access_for=2
		                                      AND g.access_for_id = h.role_id
		                                      AND h.userid ='.$user->id.')
		                                   OR
		                                       (g.access_for=3
		                                          AND g.access_for_id = i.id
		                                          AND ((i.usertype_name = j.title
		                                                 AND k.user_id = '.$user->id.'
		                                                 AND j.id=k.group_id)
		                                                 OR ('.$user->id.' = 0))))
		                           AND g.access_level = 0
		                           AND 0 = ' .$global_grid_rule_override . ' 
		                           AND '.$admin_user.' = 0 
				                   AND ((g.access_type=1 
				                          AND (g.access_type_id=b.grid_id
				                                OR g.access_type_id = -1))				        
		                                 OR  (g.access_type=2
		                                       AND g.access_subtype_grid_id=b.grid_id
                                               AND g.access_subtype_column_id=b.column_id)))
                              )                          
                         ORDER BY a.ordering, 
                                  b.grid_id, 
                                  b.ordering';
                                                                
		}
		else
		{
			$query =   'SELECT DISTINCT
		                          b.id,
		                          b.parent_id,
		                          a.id AS aid,
		                          b.grid_id,
		                          a.parent_id as aparent_id,
	                              b.column_id,
                                b.column_type, 
	                              b.ordering,
	                              c.header,
	                        CONCAT(c.data_type, b.id) AS "dataindex", 
	                               c.editable, 
	                               c.width, 
	                               c.data_type,  
	                               c.ddefault,
	                               c.align,
	                               c.css,
	                               c.tooltip,
	                               c.email_subject,
	                               c.freeze_column, 
	                               c.dfilter,
	                               c.validation_type,
	                               c.sortable,
	                               c.summarycolumn,
                                   c.summarytype,
                                   c.summaryprefix,
                                   c.summarypostfix,
                                   b.formula   	                              
                         FROM  #__jgrid_grids a, 
                               #__jgrid_columngrid b,
                               #__jgrid_columns c 
                         WHERE a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"
                         AND   a.id = b.grid_id 
                         AND   c.id = b.column_id
                         AND (a.id IN ('.$no_access_override_list.')
                         	    OR '.$admin_user.' > 0 
                         		OR 0 = (SELECT count(1) AS w
		                           FROM #__jgrid_security g, 
		                                #__jgrid_role_userlist h,
		                                #__jgrid_user_type_defaults i
		                           WHERE ((g.access_for = 1 
		                                     AND 
		                                     g.access_for_id = '.$user->id.')
		                                  OR
		                                   (g.access_for=2
		                                      AND g.access_for_id = h.role_id
		                                      AND h.userid ='.$user->id.')
		                                   OR
		                                       (g.access_for=3
		                                          AND g.access_for_id = i.id
		                                          AND ('.$user->id.' = 0)))
		                           AND g.access_level = 0
		                           AND 0 = ' .$global_grid_rule_override . '
		                           AND '.$admin_user.' = 0  
				                   AND ((g.access_type=1 
				                          AND (g.access_type_id=b.grid_id
				                            OR g.access_type_id = -1))				        
		                                 OR  (g.access_type=2
		                                       AND g.access_subtype_grid_id=b.grid_id
                                               AND g.access_subtype_column_id=b.column_id))))                          
                         ORDER BY a.ordering, 
                                  b.grid_id, 
                                  b.ordering';
		}

//JError::raiseError(1003,$query);
	//return;
		$db->setQuery($query);
		$data = $db->loadObjectList();
//JError::raiseError(1003,$data[0]->header);
	//return;

		$current_grid = $data[0]->grid_id;
		$number_of_grid_columns[$current_grid] = 0;
		for ($i=0, $j=0 , $n=count( $data ); $i < $n; $i++)	{
			if($data[$i]->grid_id == $current_grid) $number_of_grid_columns[$current_grid]++ ;
			else
			{
				$current_grid = $data[$i]->grid_id;
				$j++;
				$number_of_grid_columns[$current_grid]=1;
			}
		}
		// save number of grid columns in session variable
		$session = JFactory::getSession();
        $session->set('number_of_grid_columns', $number_of_grid_columns);
        $number = $session->get('number_of_grid_columns');
        
 	//JError::raiseError(10039,$number[5]);
	//return;       



		if($data) return $data;
		else return false;
	}

}
