<?php
/**
 * mod_jgrid.php module in Joomla/Modules/mod_jgrid
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Module
 * @subpackage	mod_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */


// no direct access
defined('_JEXEC') or die('Restricted access');
require_once (dirname(__FILE__).'/helper.php');
//check to make sure component is installed
if (!JComponentHelper::isEnabled('com_jgrid',true))
{
   JError::raiseError(JText::_("com_jgrid component not installed"), JText::_("Install Joomla Component com_jgrid before jgrid modules"));
   return;
}

$module = JModuleHelper::getModule('mod_jgrid');
$params = new JRegistry();
if(class_exists('JParameter'))
{
	$params = new JParameter( $module->params ); 
}
else 
{
   $params->loadString($module->params);
}	
$params->set ('jgrid_application_name', 'mod_jgrid');
// set application type jgrid variable as module
if(class_exists('Jinput')) {	
	$input = new Jinput;
	$input->set('application_type','MODULE');
	$input->set('jgrid_application_name', 'mod_jgrid');
	modJgridHelper::initializeModule($params);
	$input->set($params->get ('mod_jgridcreated'), 1);	
}
else
{
	JRequest::setVar('application_type', 'MODULE');
	JRequest::setVar('jgrid_application_name', 'mod_jgrid');
	modJgridHelper::initializeModule($params);
	JRequest::setVar('mod_jgridcreated', 1);
}    	

if(!$params->get ('jgrid_renderTo')) $params->set ('jgrid_renderTo','jgrid_module1');

//JError::raiseError(1003,$params->get('jgrid_renderTo'));
	//return;



   



$griditems = modJgridHelper::getGriddata($params);
if($griditems==false)
{
	  JError::raiseError(1001, JText::_("No Data Grids Available to User. Please Contact Administrator to Assign Data Grid Access"));
	  return;
}
	//	$this->assignRef('griditems', $griditems);
$columnitems= modJgridHelper::getColumndata($params);
		if($columnitems==false)
	    {
	    	JError::raiseError(1001, JText::_("No Data Grids Columns Available to User. Please Contact Administrator to Assign Data Grid Access"));
	    	return;
	    }
	//	$this->assignRef('columnitems', $columnitems);
		// RMS REmove debug before production
require(JModuleHelper::getLayoutPath('mod_jgrid'));

