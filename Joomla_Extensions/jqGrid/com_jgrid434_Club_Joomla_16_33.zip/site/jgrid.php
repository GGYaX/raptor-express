<?php
/**
 * Jgrid in Joomla/Components
 *
 * @version	    $id$ V2.4
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2011 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

// Require the base controller
require_once (JPATH_COMPONENT.'/controller.php');


$controller = JRequest::getWord('controller');

if($controller == 'controller'  ||
$controller == 'jgrid_documents' ||
$controller == 'jgrid_images' ||
$controller == 'jgrid_csv' ||
$controller == 'jgrid_security' )
{
	$path = JPATH_COMPONENT.'/controllers/'.$controller.'.php';
	if (file_exists($path)) {
		require_once ($path);
	} else {
		$controller = '';
	}
}


// Create the controller
$classname	= 'JgridController'.$controller;
$controller = new $classname();

// Perform the Request task
// reads url and looks for task
$controller->execute( JRequest::getVar('task'));


// Redirect if set by the controller
$controller->redirect();

?>
