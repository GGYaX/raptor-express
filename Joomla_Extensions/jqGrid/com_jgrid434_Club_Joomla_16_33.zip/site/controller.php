<?php
/**
 * Jgrid Controller in Joomla/Components
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport('joomla.application.component.controller');

/**
 * Jgrid controller
 *
 * Calls view to display jgrid data grid
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */

if(!class_exists('RMWorksAroundJoomlaToGetAController')) {
	if(interface_exists('JController')) {
		abstract class RMWorksAroundJoomlaToGetAController extends JControllerLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAController extends JController {}
	}
}

class JgridController extends RMWorksAroundJoomlaToGetAController
{

	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The pointer to the joomla model to be accesses or a general return value
	 * @var array
	 */
	var $_model=null;

	/**
	 * The pointer to the joomla view to be displayed
	 * @var array
	 */
	var $_view=null;


	/**
	 * Displays the default View View.html.php to load the grids and grid columns
	 *
	 * @access	public
	 */

	function display($cachable = false, $urlparams = false)
	{
		$session =JFactory::getSession();
		$session->set('demo_mode', 0);
		$params = JComponentHelper::getParams('com_jgrid');
		$db =JFactory::getDBO();
		
		// set default application name if not set in config file
		if(!$params->get ('jgrid_application_name'))
		{
			$params->set('jgrid_application_name', 'com_jgrid' );
		}
		// set application type jgrid variable as module
		if(class_exists('Jinput')) {	
			$input = new Jinput;
			$input->set('application_type','COMPONENT');
			$input->set('jgrid_application_name',$params->get ('jgrid_application_name'));
		}
		else
		{
			JRequest::setVar('application_type', 'COMPONENT');
			JRequest::setVar('jgrid_application_name', $params->get ('jgrid_application_name'));
		}

		//display jgrid component
		// delay to allow the list boxes to populate first
		sleep(1);
		parent::display();
	}

	/**
	 * Retrieves the user data to popluate the user grids already loaded above. Calls the view view.ajax.php to parse and display the grid data
	 * @return string json string containing the "Grid Data" grid rows or false if no row returned
	 */
	function read()
	{
		$this->_model = $this->getModel('jgrid');
		list($document_security_level,$this->_result,$select_type,$hide_column_ids,$wordarray) = $this->_model->getGridRowData();
		$this->_view = $this->getview('jgrid','ajax');
		$this->_view->assignRef('columndata_values', $this->_result);
		$this->_view->assignRef('document_security_level', $document_security_level);
		$this->_view->assignRef('select_type', $select_type);
		$this->_view->assignRef('hide_column_ids', $hide_column_ids);
		$this->_view->assignRef('wordarray', $wordarray);
		$this->_result =  $this->_view->display();
	}

	/**
	 * Updates the   "user grids" data being edited
	 * @return integer return true if row updated or false if update failed.
	 */
	function update()
	{
		// check for demo version return
		$session =JFactory::getSession();
		if($session->get('demo_mode')){
			Echo '{success:true}';
			return;
		}
		$this->model = $this->getModel('jgrid');
		list($this->_result_count,$this->_result) = $this->model->updateGridRow();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * insert a row into the user grid at selected location
	 * @var number row_number of new row
	 * @return if new row inserted return number new_row_number and integer true, false if row not inserted
	 */
	function insert()
	{
		// check for demo version return
		$session =JFactory::getSession();
		if($session->get('demo_mode')){
			Echo '{success:true}';
			return;
		}
		$this->model = $this->getModel('jgrid');
		$row_number = $this->model->insertGridRow();
		if(!$row_number) echo '{success:false}';
		else echo '{success:true,"new_row_number":' . $row_number . '}';
	}

	/**
	 * RMS create (stub to handle the json store auto create. Send update data for first update since create proxy fires
	 * @return place holder rownumber to get a no exception result
	 * This needs to be removed once the store proxy is fixed by extjs to properly handle success listner on proxy
	 */
	function create()
	{
		// check for demo version return
		$session =JFactory::getSession();
		if($session->get('demo_mode')){
			Echo '{success:true}';
			return;
		}
		$this->model = $this->getModel('jgrid');
		$this->_result = $this->model->createRow();
		if($this->_result) Echo '{success:true,results:"1",rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Copy selected row order "jgrid" grid
	 * @return integer result true if row moved or false if row not moved failed
	 */
	function copy()
	{
		// check for demo version return
		$session =JFactory::getSession();
		if($session->get('demo_mode')){
			Echo '{success:true}';
			return;
		}
		$this->_model = $this->getModel('jgrid');
		list($this->_result_count,$this->_result) = $this->_model->copyRow();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Moves selected row order "jgrid" grid
	 * @return integer result true if row moved or false if row not moved failed
	 */
	function move()
	{
		// check for demo version return
		$session =JFactory::getSession();
		if($session->get('demo_mode')){
			Echo '{success:true}';
			return;
		}
		$this->_model = $this->getModel('jgrid');
		if($this->_model->moveRow()) Echo '{success:true}';
		else Echo '{success:false}';
	}

	/**
	 * Move Stub to return success on destroy's generated when rows moved. Move function does actual move
	 * proxy suspendevents() not working
	 * @return integer result true
	 */
	function movestub()
	{
		Echo '{success:true}';
	}

	/**
	 * Removes row from the data grid row and all associated data from grid
	 * @return integer result true if sheet removed or false if remove failed
	 */
	function destroy()
	{
		// check for demo version return
		$session =JFactory::getSession();
		if($session->get('demo_mode')){
			Echo '{success:true,"removed_row_number":'.JRequest::getVar('last_document_id','','','INTEGER').'}';
			return;
		}
		$model = $this->getModel('jgrid');
		$row_number = $model->deleteGridRow();
		if($row_number) echo '{success:true,"removed_row_numbers":' . $row_number . '}';
		else echo '{success:false}';
	}

	/**
	 * Retrieves the list box data to popluate the user grids list box callup.
	 * @return string json string containing the "user list box"  or false if no values returned
	 */
	function read_listboxvalues()
	{
		$this->_model = $this->getModel('jgrid');
		list($this->_result_count,$this->_result) = $this->_model->read_listBoxValues();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Retrieves the list box data to popluate the user grids list box callup.
	 * @return string json string containing the "user list box"  or false if no values returned
	 */
	function read_role_or_user()
	{
		$this->_model = $this->getModel('jgrid');
		list($this->_result_count,$this->_result) = $this->_model->read_role_or_user();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}
	
	/**
	 * send_email send email to to address
	 * @return integer return true if email send or false if send failed.
	 */
	function send_email()
	{
		// check for demo version return
		$session =JFactory::getSession();
		if($session->get('demo_mode')){
			Echo '{success:true}';
			return;
		}
		$this->_model = $this->getModel('jgrid');
		list($_result,$_message) = $this->_model->send_email_msg();
		if($_result)Echo '{success:true,message:'.json_encode($_message) .'}';
		else Echo '{success:false, message: '.json_encode($_message) .'}';
	}

}
?>
