<?php
/**
 * Jgrid_security Model in Joomla/Administrator/Components/models
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2011 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once(JPATH_BASE . '/administrator/components/com_jgrid/os/jgrid/functions.php' );
jimport( 'joomla.application.component.model' );

/**
 * Jgrid_security model
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid administrator "Manager User Access" screens
 * to "Manage User Access" rights
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */

if(!class_exists('RMWorksAroundJoomlaToGetAModel')) {
	if(interface_exists('JModel')) {
		abstract class RMWorksAroundJoomlaToGetAModel extends JModelLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAModel extends JModel {}
	}
}

class JgridModelJgrid_security extends RMWorksAroundJoomlaToGetAModel
{
	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * Retrieves the "User Access Rules" data
	 * @return array Array of objects containing the "User Access Rules" grid rows
	 */
	var $_query=null;


	/**
	 * Retrieves the "User Access Rules" data
	 * @return string json string containing the "User Access Rules" grid rows
	 */
	function getUserAccessRules()
	{
		$this->_result_count=0;
		$this->_result=0;

		$this->_query = 'SELECT DISTINCT a.id,
		                                 a.userid_assigning_access, 
		                                 a.access_for,
                                         a.access_for_id,					    
					                     a.access_type,
                                         a.access_type_id,					    
				                         a.access_level, 
				                         a.last_updated
			        FROM #__jgrid_security a,
			        	 #__jgrid_applications b
			        WHERE a.access_rule_application_id = b.id
			        	AND	b.grid_application_name = "'.JRequest::getVar("grid_application_name").'"
			        	AND	a.access_type="3"
			          		OR  a.access_type = "4"       	                      
			        ORDER BY a.access_for_name, 
			                 a.access_type_name';
//echo 'sql '.$this->_query;					          
		$this->_result_count = $this->_getListCount($this->_query );
		if($this->_result_count==0)
		{
			return false;
		}
		$this->_result = $this->_getList( $this->_query );

		for($i=0;$i<$this->_result_count;$i++)
		{

			switch ($this->_result[$i]->access_for)
			{
		 	// USER
		 	case '1':
		 		$this->_result[$i]->access_for_id="U".$this->_result[$i]->access_for_id;
		 		break;
		 		// ROLE
		 	case '2':
		 		$this->_result[$i]->access_for_id="R".$this->_result[$i]->access_for_id;
		 		break;
		 		// DEFAULT
		 	case '3':
		 		$this->_result[$i]->access_for_id="D".$this->_result[$i]->access_for_id;
		 		break;
		 		// CREATOR
		 	case '4':
		 		$this->_result[$i]->access_for_id="C".$this->_result[$i]->access_for_id;
		 		break;		 		
		 		
			}

			switch ($this->_result[$i]->access_type)
			{
		 	// Sheet
				case '3':
					$this->_result[$i]->access_type_id="D".$this->_result[$i]->access_type_id;
		 		break;
		 		// Sheet-Column
				case '4':					
					$this->_result[$i]->access_type_id="E".$this->_result[$i]->access_type_id;
		 		break;
			}
		}
		if($this->_result)return array($this->_result_count,$this->_result);
		else return false;
	}

	/**
	 * Retrieves the users ID and Name that access rules can be applied and adds in combo box drop down selector box
	 * @return array Array of objects containing the user id's and names or false if no users were found
	 */
	function get_combo_User_Id_List($access_for)
	{
		$session =JFactory::getSession();
		// check for joomla version
		$version = new JVersion;
		$joomla = $version->getShortVersion();
		$creator_rule[0]->access_for_name = JText::_("CREATOR_EDIT_PRIVATE");
		$creator_rule[0]->access_for_id = "C1";
		$creator_rule[1]->access_for_name = JText::_("CROLE_EDIT_PRIVATE");
		$creator_rule[1]->access_for_id = "C2";
		$creator_rule[2]->access_for_name = JText::_("CREATOR_EDIT_CROLE_VIEW");
		$creator_rule[2]->access_for_id = "C3";
		$creator_rule[3]->access_for_name = JText::_("CREATOR_EDIT_REG_VIEW");
		$creator_rule[3]->access_for_id = "C4";
		$creator_rule[4]->access_for_name = JText::_("CROLE_EDIT_REG_VIEW");
		$creator_rule[4]->access_for_id = "C5";
		$creator_rule[5]->access_for_name = JText::_("CREATOR_EDIT_PUB_VIEW");
		$creator_rule[5]->access_for_id = "C6";
		$creator_rule[6]->access_for_name = JText::_("CROLE_EDIT_PUB_VIEW");
		$creator_rule[6]->access_for_id = "C7";
		$creator_rule[7]->access_for_name = JText::_("ACCESS_MANAGER_EDIT_CREATOR_VIEW");
		$creator_rule[7]->access_for_id = "C8";
		$creator_rule[8]->access_for_name = JText::_("ACCESS_MANAGER_EDIT_CROLE_VIEW");
		$creator_rule[8]->access_for_id = "C9";		
		switch ($access_for){
			case '0':  //all rule types to be used to validate "object type" values
				// check for demo version return

				if($session->get('demo_mode')){
					// limit users
					$this->_query = 'SELECT "joe" AS access_for_name,
				                              CONCAT("U",id) AS access_for_id
			           	              FROM #__users LIMIT 1';
					$user_result = $this->_getList( $this->_query );

					$this->_query = ' SELECT role_name AS access_for_name,
			           	                     CONCAT("R",id) AS access_for_id
			           	              FROM #__jgrid_roles';
					$role_result = $this->_getList( $this->_query );
					$this->_result = array_merge($user_result, $role_result);
					$this->_result_count = count($this->_result);

				} else
				{

					$this->_query = 'SELECT a.username AS access_for_name,
				                            CONCAT("U",a.id) AS access_for_id
			           	             FROM #__users a';
					$user_result = $this->_getList( $this->_query );

					$this->_query = ' SELECT b.role_name AS access_for_name,
			           	                     CONCAT("R",b.id) AS access_for_id
			           	          FROM #__jgrid_roles b';
					$role_result = $this->_getList( $this->_query );
					if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
					{
						$this->_query = ' SELECT c.usertype_name AS access_for_name,
			           	                         CONCAT("D",c.id) AS access_for_id
			           	                  FROM #__jgrid_user_type_defaults c
                                          WHERE c.version16 = 1 ';
					}
					else
					{
						$this->_query = 'SELECT c.usertype_name AS access_for_name,
			           	                        CONCAT("D",c.id) AS access_for_id
			           	                 FROM #__jgrid_user_type_defaults c
                                         WHERE c.version15 = 1';             
					}
					$default_result = $this->_getList( $this->_query );
					$this->_result = array_merge($user_result, $role_result, $default_result, $creator_rule);
					$this->_result_count = count($this->_result);
				}
					
				break;

			case '1':  //USER type
				// check for demo version return
				if($session->get('demo_mode')){
					// limit users
					$this->_query = 'SELECT "joe" AS access_for_name,
		                                CONCAT("U",id) AS access_for_id
			                     FROM #__users LIMIT 1;';
				} else
				{



					$this->_query = 'SELECT username AS access_for_name,
		                                CONCAT("U",id) AS access_for_id
			                     FROM #__users
			                     ORDER BY access_for_name';
				}
				$this->_result_count = $this->_getListCount($this->_query );
				$this->_result = $this->_getList( $this->_query );
				break;
					


			case '2':  //Role Type
				$this->_query = 'SELECT role_name AS access_for_name,
				                        CONCAT("R",id) AS access_for_id
			           	         FROM #__jgrid_roles
			           	         ORDER BY access_for_name';
				$this->_result_count = $this->_getListCount($this->_query );
				$this->_result = $this->_getList( $this->_query );
				break;
			case '3':  //User Type Default
				if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
				{
					$this->_query = 'SELECT a.usertype_name AS access_for_name,
				                        CONCAT("D",a.id) AS access_for_id
			           	             FROM #__jgrid_user_type_defaults a
                               WHERE a.version16 = 1 ';
				}
				else
				{
					$this->_query = 'SELECT a.usertype_name AS access_for_name,
				                        CONCAT("D",a.id) AS access_for_id
			           	              FROM #__jgrid_user_type_defaults a
                                WHERE a.version15 = 1
                                ORDER BY access_for_name';

				}
				$this->_result_count = $this->_getListCount($this->_query );
				$this->_result = $this->_getList( $this->_query );
				break;
			case '4':  //Creator Type Rules
				$this->_result_count = count($creator_rule);
				$this->_result = $creator_rule;
				break;				
		}

		if($this->_result)return array($this->_result_count,$this->_result);
		else return false;
	}

	/**
	 * Retrieves the "object type" id and name to add in combo box selector drop down
	 * @param string $access_type type of "User Access Rule" (All=0,Grid=1,Sheet=2,Column=3)
	 * @return array Array of objects containing the object id and name depending on the access type selection or false if no rules were found
	 */
	function get_combo_User_Access_Rule_Id_List($access_type)
	{
		$user =JFactory::getUser();
		// check for joomla version
		$version = new JVersion;
		$joomla = $version->getShortVersion();

		// check if default access control applies
		$this->_query='SELECT DISTINCT a.id
		                                FROM #__jgrid_grids a,
		                                     #__jgrid_security e, 
		                                     #__jgrid_role_userlist f
		                                WHERE ((e.access_for = 1 
		                                         AND 
		                                         e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.'))
		                                 AND (a.id = e.access_type_id
		                                      AND e.access_type = 1)';
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		$not_default_list='0';
		for($i=0;$i<$this->_result_count;$i++)
		{
			$not_default_list.=',';
			$not_default_list.=$this->_result[$i]->id;

		}
		$access_control=0;
		if(check_for_backend_admin_access_rights())
		{ // administrator
			$admin_user=1;
			$access_control=1;
			$remove_access_control=0;
		}


		switch ($access_type){
			case '0':  //all rule types to be used to validate "object type" values
				$this->_query = 'SELECT d.document_title AS access_type_name,
			           	          CONCAT("D",d.id) AS access_type_id
			           	     FROM #__jgrid_security a,
			           	          #__jgrid_grids b,
			           	          #__jgrid_document d
			           	     WHERE a.access_subtype_document_id = d.id
			           	      AND a.access_type="3"
			           	      AND b.id = d.grid_id';			           	          
				$document_result = $this->_getList( $this->_query );
				$this->_query = 'SELECT CONCAT(e.document_title,"-",f.header) AS access_type_name,
			           	          CONCAT("E",e.id,"-",g.id) AS access_type_id
			           	     FROM #__jgrid_security a,
			           	          #__jgrid_grids b,
                                  #__jgrid_document e,
                                  #__jgrid_columns f,
                                  #__jgrid_columngrid g	
			           	     WHERE a.access_subtype_document_id = e.id
			           	      AND a.access_subtype_column_id = f.id
			           	      AND f.id = g.column_id
			           	      AND a.access_type="4"
			           	      AND b.id = e.grid_id';
				$document_column_result = $this->_getList( $this->_query );
				$this->_result = array_merge($document_result, $document_column_result);
				$this->_result_count = count($this->_result);
				break;

			case '3':  //sheet  rule
				if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
				{
					$this->_query = 'SELECT DISTINCT a.document_title AS access_type_name,
				                        CONCAT("D",a.id) AS access_type_id
			           	         FROM #__jgrid_document a,
			           	              #__jgrid_grids b		           	         
			           	         WHERE b.id = a.grid_id
			          	           AND b.grid_application_name = "'.JRequest::getVar('grid_application_name').'"
			          	           AND b.id = '.JRequest::getVar('grid_id','','','INTEGER').'
			           	           AND (0 != (SELECT count(1) AS w
		                                FROM #__jgrid_security e, 
		                                     #__jgrid_role_userlist f,
		                                     #__jgrid_user_type_defaults g,
		                                     #__usergroups h,
		                                     #__user_usergroup_map i
		                           WHERE ((e.access_for = 1 
		                                         AND 
		                                         e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.')
		                                       OR
		                                       (e.access_for=3
                                                  AND e.access_type_id NOT IN ('.$not_default_list.')
		                                          AND e.access_for_id = g.id
		                                          AND g.usertype_name = h.title
		                                          AND i.user_id = '.$user->id.'
		                                          AND (h.id=i.group_id
		                                            OR (g.usertype_name = "Public"
		                                                 AND '.$user->id.' = 0))))             
		                           AND e.access_level > 4
		                           AND ((e.access_type = 1
		                                 AND 
		                                 e.access_type_id = a.grid_id)
		                                OR (e.access_type = 3
                                            AND
                                            e.access_type_id = a.id)))
                                OR '. $access_control.' = 1)';
				} else
				{
					$this->_query = 'SELECT DISTINCT a.document_title AS access_type_name,
				                        CONCAT("D",a.id) AS access_type_id
			           	         FROM #__jgrid_document a,
			           	              #__jgrid_grids b
			           	         WHERE b.id = a.grid_id
			          	           AND b.grid_application_name = "'.JRequest::getVar('grid_application_name').'"
			          	           AND b.id = '.JRequest::getVar('grid_id','','','INTEGER').'
			           	           AND (0 != (SELECT count(1) AS w
		                                FROM #__jgrid_security e, 
		                                     #__jgrid_role_userlist f,
		                                     #__jgrid_user_type_defaults g
		                           WHERE ((e.access_for = 1 
		                                         AND 
		                                         e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.')
		                                       OR
		                                       (e.access_for=3
                                                  AND e.access_type_id NOT IN ('.$not_default_list.')
		                                          AND e.access_for_id = g.id
		                                          AND (g.usertype_name ="'.$user->usertype.'"
		                                            OR (g.usertype_name = "Guest"
		                                                 AND '.$user->id.' = 0))))             
		                           AND e.access_level > 4
		                           AND ((e.access_type = 1
		                                 AND (e.access_type_id = a.grid_id
		                                 		OR e.access_type_id = -1))
		                                OR (e.access_type = 3
                                            AND
                                            e.access_type_id = a.id)))
                        OR '. $access_control.' = 1)';
				}
				$this->_result_count = $this->_getListCount( $this->_query );
				$this->_result = $this->_getList( $this->_query );
				break;


			case '4':  //Sheet-Column rule
				if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
				{
					$this->_query = 'SELECT DISTINCT CONCAT(a.document_title,"-",b.header) AS access_type_name,
				                        CONCAT("E",a.id,"-",c.id) AS access_type_id
			           	         FROM #__jgrid_document a,
			           	              #__jgrid_columns b, 
                                      #__jgrid_columngrid c,
			           	              #__jgrid_grids d
                                 WHERE d.id = a.grid_id
			          	           AND d.grid_application_name = "'.JRequest::getVar('grid_application_name').'"
			           	           AND d.id = c.grid_id
                                   AND b.id = c.column_id
                                   AND d.id = '.JRequest::getVar('grid_id','','','INTEGER').'
                                   AND (0 != (SELECT count(1) AS w
		                                FROM #__jgrid_security e, 
		                                     #__jgrid_role_userlist f,
		                                     #__jgrid_user_type_defaults g,
		                                     #__usergroups h,
		                                     #__user_usergroup_map i
		                           WHERE ((e.access_for = 1 
		                                         AND 
		                                         e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.')
		                                       OR
		                                       (e.access_for=3
                                                  AND e.access_type_id NOT IN ('.$not_default_list.')
		                                          AND e.access_for_id = g.id
		                                          AND g.usertype_name = h.title
		                                          AND i.user_id = '.$user->id.'
		                                          AND (h.id=i.group_id
		                                            OR (g.usertype_name = "Public"
		                                                 AND '.$user->id.' = 0))))
		                           AND e.access_level > 4
		                           AND ((e.access_type = 1
		                                   AND c.grid_id = e.access_type_id)		                                                
		                          OR  (e.access_type="2"
		                                AND e.access_subtype_grid_id=c.grid_id
                                        AND e.access_subtype_column_id=c.id)
		                          OR (e.access_type = 3
                                       AND
		                               e.access_type_id = a.id)     		                                                
		                          OR  (e.access_type="4" 
		                                AND e.access_subtype_document_id =a.id
                                        AND e.access_subtype_column_id=c.id)))
                         OR '. $access_control.' = 1)'; 				              
				}else
				{
					$this->_query = 'SELECT DISTINCT CONCAT(a.document_title,"-",b.header) AS access_type_name,
				                        CONCAT("E",a.id,"-",c.id) AS access_type_id
			           	         FROM #__jgrid_document a,
			           	              #__jgrid_columns b, 
                                      #__jgrid_columngrid c,			           	              
                                      #__jgrid_grids d
                                 WHERE d.id = a.grid_id
			          	           AND d.grid_application_name = "'.JRequest::getVar('grid_application_name').'"
			           	           AND d.id = c.grid_id
                                   AND b.id = c.column_id
                                   AND d.id = '.JRequest::getVar('grid_id','','','INTEGER').'
                                   AND (0 != (SELECT count(1) AS w
		                                FROM #__jgrid_security e, 
		                                     #__jgrid_role_userlist f,
		                                     #__jgrid_user_type_defaults g
		                           WHERE ((e.access_for = 1 
		                                         AND 
		                                         e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.')
		                                       OR
		                                       (e.access_for=3
                                                  AND e.access_type_id NOT IN ('.$not_default_list.')
		                                          AND e.access_for_id = g.id
		                                          AND (g.usertype_name ="'.$user->usertype.'"
		                                            OR (g.usertype_name = "Guest"
		                                                 AND '.$user->id.' = 0))))
		                           AND e.access_level > 4
		                           AND ((e.access_type = 1
		                                   AND c.grid_id = e.access_type_id)		                                                
		                          OR  (e.access_type="2"
		                                AND e.access_subtype_grid_id=c.grid_id
                                        AND e.access_subtype_column_id=c.id)
		                          OR (e.access_type = 3
                                       AND
		                               e.access_type_id = a.id)     		                                                
		                          OR  (e.access_type="4" 
		                                AND e.access_subtype_document_id =a.id
                                        AND e.access_subtype_column_id=c.id)))
                      OR '. $access_control.' = 1)';					 										                 
				}
//echo 'sql'.$this->_query;				
				$this->_result_count = $this->_getListCount( $this->_query );
				$this->_result = $this->_getList( $this->_query );
				break;
		}

// echo 'sql'.$this->_query.'sql'.$this->_result_count;
		if($this->_result)return array($this->_result_count,$this->_result);
		else return false;

	}

	/**
	 * Updates the   "Manager User Access" rule being edited in the  "Manager User Access" grid
	 * @var array $user array of objects defining the various Joomla user data, user->id used to define user assigning access rule
	 * @var array $row_data array of objects sent from the "Manager User Access" grid containing the values to be updated in the database
	 * @return array return the data that was just updated to the grid or false if rule not updated.
	 */
	function updateUserAccessRule()
	{
		$db =JFactory::getDBO();
		$user =JFactory::getUser();
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		$access_type = $row_data[0]['access_type'];
		$access_type_id = $row_data[0]['access_type_id'];
		$access_subtype_column_id = 0;
		$access_subtype_document_id = 0;
		$access_control=1;
		$remove_access_control=0;
		// check for joomla version
		$version = new JVersion;
		$joomla = $version->getShortVersion();
		
		// if leading character added to access_type_id remove it
		if($access_type_id[0] = 'G'
		    || $access_type_id[0] = 'C'
		    || $access_type_id[0] = 'D'
		    || $access_type_id[0] = 'E')
		{
			$access_type_id = substr($access_type_id,1);
		}

		// check if default access control applies
		$this->_query='SELECT DISTINCT a.id
		                                FROM #__jgrid_grids a,
		                                     #__jgrid_security e, 
		                                     #__jgrid_role_userlist f
		                                WHERE ((e.access_for = 1 
		                                         AND 
		                                         e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.'))
		                                 AND (a.id = e.access_type_id
		                                      AND e.access_type = 1)';
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		$not_default_list='0';
		for($i=0;$i<$this->_result_count;$i++)
		{
			$not_default_list.=',';
			$not_default_list.=$this->_result[$i]->id;

		}
		$access_control=0;
		if(check_for_backend_admin_access_rights())
		{ // administrator
			$admin_user=1;
			$access_control=1;
			$remove_access_control=0;
		}


		switch ($access_type)
		{
			//document level
			case '3':
				$access_subtype_document_id = $access_type_id;
				break;
				//document-column RMS problem here
			case '4':
				$access_subtype_document_id = substr($access_type_id,0,strpos($access_type_id,'-'));
				$access_subtype_column_id = substr($access_type_id,strpos($access_type_id,'-')+1);
				break;
		}
		IF($access_subtype_document_id>0)
		{
			
			//find grid id
			$this->_query = 'SELECT grid_id
			          FROM #__jgrid_document
			          WHERE id = '.$access_subtype_document_id;  				
			$db->setQuery($this->_query);
			$access_subtype_grid_id=$db->loadResult();

	  if(check_for_backend_admin_access_rights()==0)
	  {
	  	if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
	  	{
	  		// check security access of user
	  		$this->_query = 'SELECT count(1) AS w
		          FROM #__jgrid_document d,
                       #__jgrid_security e, 
		               #__jgrid_role_userlist f,
		               #__jgrid_user_type_defaults g,
		               #__usergroups h,
		               #__user_usergroup_map i
		           WHERE ((e.access_for = 1 
		             AND e.access_for_id = '.$user->id.')
		                  OR
		                 (e.access_for=2
		                  AND e.access_for_id = f.role_id
		                  AND f.userid ='.$user->id.')
		                 OR
		                      (e.access_for=3
                               AND e.access_type_id NOT IN ('.$not_default_list.')
		                        AND e.access_for_id = g.id
		                        AND g.usertype_name = h.title
		                        AND i.user_id = '.$user->id.'
		                        AND (h.id=i.group_id
		                         OR (g.usertype_name = "Public"
		                         AND '.$user->id.' = 0))))              
		          AND e.access_level > 4
		          AND d.id = '.$access_subtype_document_id.'		          
		          AND ((e.access_type = 1
		                  AND (d.grid_id = e.access_type_id
		                        OR e.access_type_id = -1))		                                                
		               OR (e.access_type = 3
                                 AND e.access_type_id = '.$access_subtype_document_id.'))
                OR '. $access_control.' = 1';                   
				} else
				{
	  		// check security access of user
	  		$this->_query = 'SELECT count(1) AS w
		          FROM #__jgrid_document d,
                       #__jgrid_security e, 
		               #__jgrid_role_userlist f,
		               #__jgrid_user_type_defaults g
		                           WHERE ((e.access_for = 1 
		                                         AND 
		                                         e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.')
		                                       OR
		                                       (e.access_for=3
                                                  AND e.access_type_id NOT IN ('.$not_default_list.')
		                                          AND e.access_for_id = g.id
		                                          AND (g.usertype_name ="'.$user->usertype.'"
		                                            OR (g.usertype_name = "Guest"
		                                                 AND '.$user->id.' = 0))))             
		          AND e.access_level > 4
		          AND d.id = '.$access_subtype_document_id.'		          
		          AND ((e.access_type = 1
		                  AND (d.grid_id = e.access_type_id
		                        OR e.access_type_id = -1))		                                                
		               OR (e.access_type = 3
                                 AND e.access_type_id = '.$access_subtype_document_id.'))
                OR '. $access_control.' = 1';  
				}
					
	  	$db->setQuery($this->_query);
	  	$access_control=$db->loadResult();
	  }

	  // check for user access overide to take away rights rights for grids or documents
	  $this->_query = 'SELECT count(1) AS q
		                 FROM #__jgrid_document d,
		                      #__jgrid_security g, 
		                      #__jgrid_role_userlist h
		                 WHERE ((g.access_for = 1 
		                          AND 
		                         g.access_for_id = '.$user->id.')
		                          OR
		                         (g.access_for=2
		                              AND g.access_for_id = h.role_id
		                              AND h.userid ='.$user->id.'))
		                 AND g.access_level = 0
		                 AND d.id = '.$access_subtype_document_id.'
		                 AND ((g.access_type = 1 
		                       AND (g.access_type_id = d.grid_id
		                       		OR g.access_type_id = -1))
		                      OR
		                      (g.access_type =  3
		                       AND g.access_type_id = '.$access_subtype_document_id.'))';


	  $db->setQuery($this->_query);
	  $remove_access_control=$db->loadResult();
		}else
		{
			$access_subtype_column_id=0;
			$access_subtype_document_id=0;
		}

		IF($access_control>0 && $remove_access_control ==0)
		{


			$this->_query =  'UPDATE  #__jgrid_security
			      SET userid_assigning_access = "'.$user->id.'",
			          access_for = "'.$row_data[0]['access_for'].'", 
			          access_for_name = "'.$row_data[0]['access_for_name'].'",
			          access_for_id = SUBSTR("'.$row_data[0]['access_for_id'].'",1), 
			          access_type = "'.$row_data[0]['access_type'].'", 
			          access_type_name = "'.$row_data[0]['access_type_name'].'",
			          access_type_id = "'.$access_type_id.'",
			          access_subtype_grid_id = "'.$access_subtype_grid_id.'",
			          access_subtype_column_id = "'.$access_subtype_column_id.'",
			          access_subtype_document_id = "'.$access_subtype_document_id.'",
			          access_level = "'.$row_data[0]['access_level'].'"
			      WHERE id = '.$row_data[0]['id'];

//echo 'sql'.$this->_query;
			$db->setQuery( $this->_query);
			if($db->query())return true;
			else return false;
		} else return false;
	}

	/**
	 * Creates new rule in the "Manager User Access" grid
	 * @var array $user array of objects defining the various Joomla user data, user->id used to default user new rule applies to
	 * @var array $row_data array of objects sent from the "Manager User Access" grid containing the values to be updated in the database
	 * @var integer $last_id the database row id of the new Access Rule to be returned to the grid
	 * @return array return the new rule data that was updated ($last_id, and $user->id) to the grid row false if new rule not created.
	 */
	function createUserAccessRule()
	{
		$db =JFactory::getDBO();
		$user =JFactory::getUser();
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		$access_type = $row_data[0]['access_type'];
		$access_type_id = $row_data[0]['access_type_id'];
		$access_subtype_column_id = 0;
		$access_subtype_document_id = 0;
		$access_control=1;
		$remove_access_control=0;
//echo 'sql4'.print_r($row_data[0]);
		// check for joomla version
		$version = new JVersion;
		$joomla = $version->getShortVersion();
		
		// if leading character added to access_type_id remove it
		if($access_type_id[0] = 'G'
		    || $access_type_id[0] = 'C'
		    || $access_type_id[0] = 'D'
		    || $access_type_id[0] = 'E')
		{
			$access_type_id = substr($access_type_id,1);
		}

		//find application id
		$this->_query = 'SELECT id
		          FROM #__jgrid_applications
		          WHERE grid_application_name = "'.JRequest::getVar("grid_application_name").'"';  				
		$db->setQuery($this->_query);
		$access_rule_application_id=$db->loadResult();
		


		// check if default access control applies
		$this->_query='SELECT DISTINCT a.id
		                                FROM #__jgrid_grids a,
		                                     #__jgrid_security e, 
		                                     #__jgrid_role_userlist f
		                                WHERE ((e.access_for = 1 
		                                         AND 
		                                         e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.'))
		                                 AND ((a.id = e.access_type_id
		                                 		OR e.access_type_id = -1)
		                                      AND e.access_type = 1)';
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		$not_default_list='0';
		for($i=0;$i<$this->_result_count;$i++)
		{
			$not_default_list.=',';
			$not_default_list.=$this->_result[$i]->id;

		}
		$access_control=0;
		if(check_for_backend_admin_access_rights())
		{ // administrator
			$admin_user=1;
			$access_control=1;
			$remove_access_control=0;
		}

		switch ($access_type)
		{
			//document level
			case '3':
				$access_subtype_document_id = $access_type_id;
				break;
				//document-column
			case '4':
				$access_subtype_document_id = substr($access_type_id,0,strpos($access_type_id,'-'));
				$access_subtype_column_id = substr($access_type_id,strpos($access_type_id,'-')+1);
				break;
		}		
		IF($access_subtype_document_id>0)
		{
			
			//find grid id
			$this->_query = 'SELECT grid_id
			          FROM #__jgrid_document
			          WHERE id = '.$access_subtype_document_id;  				
			$db->setQuery($this->_query);
			$access_subtype_grid_id=$db->loadResult();	

	  if(check_for_backend_admin_access_rights()==0)
	  {  	
	  	if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
	  	{
	  		// check security access of user
	  		$this->_query = 'SELECT count(1) AS w
		          FROM #__jgrid_document d,
                       #__jgrid_security e, 
		               #__jgrid_role_userlist f,
		               #__jgrid_user_type_defaults g,
		               #__usergroups h,
		               #__user_usergroup_map i
		           WHERE ((e.access_for = 1 
		             AND e.access_for_id = '.$user->id.')
		                  OR
		                 (e.access_for=2
		                  AND e.access_for_id = f.role_id
		                  AND f.userid ='.$user->id.')
		                 OR
		                      (e.access_for=3
                               AND e.access_type_id NOT IN ('.$not_default_list.')
		                        AND e.access_for_id = g.id
		                        AND g.usertype_name = h.title
		                        AND i.user_id = '.$user->id.'
		                        AND (h.id=i.group_id
		                         OR (g.usertype_name = "Public"
		                         AND '.$user->id.' = 0))))              
		          AND e.access_level > 4
		          AND d.id = '.$access_subtype_document_id.'		          
		          AND ((e.access_type = 1
		                  AND (d.grid_id = e.access_type_id
		                  		OR e.access_type_id = -1))		                                                
		               OR (e.access_type = 3
                                 AND e.access_type_id = '.$access_subtype_document_id.'))
                OR '. $access_control.' = 1';                   
				} else
				{
	  		// check security access of user
	  		$this->_query = 'SELECT count(1) AS w
		          FROM #__jgrid_document d,
                       #__jgrid_security e, 
		               #__jgrid_role_userlist f,
		               #__jgrid_user_type_defaults g
		                           WHERE ((e.access_for = 1 
		                                         AND 
		                                         e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.')
		                                       OR
		                                       (e.access_for=3
                                                  AND e.access_type_id NOT IN ('.$not_default_list.')
		                                          AND e.access_for_id = g.id
		                                          AND (g.usertype_name ="'.$user->usertype.'"
		                                            OR (g.usertype_name = "Guest"
		                                                 AND '.$user->id.' = 0))))             
		          AND e.access_level > 4
		          AND d.id = '.$access_subtype_document_id.'		          
		          AND ((e.access_type = 1
		                  AND (d.grid_id = e.access_type_id
		                  		OR e.access_type_id = -1))		                                                
		               OR (e.access_type = 3
                                 AND e.access_type_id = '.$access_subtype_document_id.'))
                OR '. $access_control.' = 1';  
				}
					
	  	$db->setQuery($this->_query);
	  	$access_control=$db->loadResult();
//echo 'sql'.$this->_query;	  	
	  }

	  // check for user access overide to take away rights rights for grids or documents
	  $this->_query = 'SELECT count(1) AS q
		                 FROM #__jgrid_document d,
		                      #__jgrid_security g, 
		                      #__jgrid_role_userlist h
		                 WHERE ((g.access_for = 1 
		                          AND 
		                         g.access_for_id = '.$user->id.')
		                          OR
		                         (g.access_for=2
		                              AND g.access_for_id = h.role_id
		                              AND h.userid ='.$user->id.'))
		                 AND g.access_level = 0
		                 AND d.id = '.$access_subtype_document_id.'
		                 AND ((g.access_type = 1 
		                       AND (g.access_type_id = d.grid_id
		                       		OR g.access_type_id = -1))
		                      OR
		                      (g.access_type =  3
		                       AND g.access_type_id = '.$access_subtype_document_id.'))';


	  $db->setQuery($this->_query);
	  $remove_access_control=$db->loadResult();
		}else
		{
			$access_subtype_column_id=0;
			$access_subtype_document_id=0;
		}
		//echo $access_control.'sql2'.$this->_query.'SQL'.$remove_access_control;
		IF($access_control>0 && $remove_access_control == 0)
		{
			$this->_query='INSERT  INTO #__jgrid_security
		                         (userid_assigning_access,
		                          access_rule_application_id, 
		                          access_for, 
		                          access_for_name, 
		                          access_for_id, 
		                          access_type,
		                          access_type_name, 
		                          access_type_id,
		                          access_subtype_grid_id,
                                  access_subtype_column_id,
                                  access_subtype_document_id,		                           
		                          access_level)
			              VALUES ("'.$user->id.'",
			                      '.$access_rule_application_id.',
			                      "'.$row_data[0]['access_for'].'",
			                      "'.$row_data[0]['access_for_name'].'",
			                      SUBSTR("'.$row_data[0]['access_for_id'].'",2),
			                      "'.$access_type.'",
			                      "'.$row_data[0]['access_type_name'].'",
			                      "'.$access_type_id.'",
			                      "'.$access_subtype_grid_id.'",
			                      "'.$access_subtype_column_id.'",
			                      "'.$access_subtype_document_id.'",
			                      "'.$row_data[0]['access_level'].'")';		
	 	$db->setQuery($this->_query);
	 	$this->_result = $db->query();
	 	$db->setQuery('SELECT last_insert_id() FROM #__jgrid_security');
	 	$last_id = $db->loadResult();
	 	$row_data[0]["id"]=$last_id;
	 	if($last_id) return $row_data[0];
	 	else return false;
		} else return false;
	}

	/**
	 * Deletes rule in the "Manager User Access" grid
	 * @return integer result true of rule deleted or false if delete failed
	 */
	function deleteUserAccessRule()
	{
		$user =JFactory::getUser();
		$db =JFactory::getDBO();

		$db->setQuery('DELETE FROM  #__jgrid_security
			                  WHERE id = '.JRequest::getVar('rows','','','INTEGER')); 
		if($db->query())return true;
		else return false;
	}

}