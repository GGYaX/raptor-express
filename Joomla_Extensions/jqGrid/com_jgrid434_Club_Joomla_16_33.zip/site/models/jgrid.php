<?php
/**
 * Jgrid_jgrid Model in Joomla/Components/models
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// Check to ensure this file is included in Joomla!
defined( '_JEXEC' ) or die( 'Restricted access' );

require_once(JPATH_BASE . '/administrator/components/com_jgrid/os/jgrid/functions.php' );
require_once(JPATH_BASE . '/administrator/components/com_jgrid/os/jgrid/searchParser.php' );
jimport( 'joomla.application.component.model' );
jimport('joomla.application.component.helper');

/**
 * Jgrid_jgrid model
 *
 * read,update,create,delete, user grid data in com_jgrid user data grids
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
 
if(!class_exists('RMWorksAroundJoomlaToGetAModel')) {
	if(interface_exists('JModel')) {
		abstract class RMWorksAroundJoomlaToGetAModel extends JModelLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAModel extends JModel {}
	}
}

class JgridModelJgrid extends RMWorksAroundJoomlaToGetAModel
{
	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The string containing the SQL call (query) that will retrieve the desired results
	 * @var string
	 */
	var $_query=null;

	/**
	 * Retrieves the "Columns assigned to grid" data
	 * @return array containing the "Columns assigned to grid" rows or false if no rows returned
	 *
	 */
	var $_data =NULL;



	/**
	 * Retrieves the user data grid row data
	 * @return array containing the sheets  or false if no rows returned
	 *
	 */
	function getGridRowData()
	{
		$db =JFactory::getDBO();
		$user=JFactory::getUser();
		$grid_id=JRequest::getVar('grid_id','','','INTEGER');
		$group=json_decode(JRequest::getVar('group','','','STRING'),TRUE);
		$sort=json_decode(JRequest::getVar('sort','','','STRING'),TRUE);
		$searchString = JRequest::getVar('searchString','','','STRING');
		$myroles=0;
		$user_document_security_level=0;
		$role_document_security_level=0;
		$creator_document_security_level=0;
		$column_security_level='';
		$current_document_id=0;
		$max_column_security_level = 0;
    $document_level_creator_rule=0;
    $wordarray = '';
		// check for joomla version
		$version = new JVersion;
		$joomla = $version->getShortVersion();
		//check to see if current document exists, if not update to the default document, always reset guest to default
		$session =JFactory::getSession();
		$temp_session_id = '"'.$session->getId().'"';
		$user_role_id = '0';
		
		// Find applicatin id for this grid_id
    	$query = 'SELECT 	b.id, 
    						a.select_type
		      	  FROM #__jgrid_grids a,
		      	       #__jgrid_applications b		                        
		          WHERE a.id = '.$grid_id.'
		            AND a.grid_application_name = b.grid_application_name';
		$db->setQuery($query);
		$grid_data = $db->loadObject();
		$access_rule_application_id = $grid_data->id;
		$select_type = $grid_data->select_type;
		

		//   Change documents to new_document_id for initial load
		if(JRequest::getVar('new_document_id','','','INTEGER')) {
			if(JRequest::getVar('new_document_id','','','INTEGER')!=0){
				$this->_query = 'update #__jgrid_current_user_grid_document
	    	   SET current_document_id ='. JRequest::getVar('new_document_id','','','INTEGER').',
	    	       previous_document_id1 ='. JRequest::getVar('last_document_id','','','INTEGER').' 
	    	   WHERE userid = '. $user->id .'
	    	   AND grid_id = '.$grid_id.'
	    	   AND session_id = '.$temp_session_id.'';
				$this->_db->setQuery($this->_query);
				$this->_result = $this->_db->query();
			}
		}

		// find document to display
		$current_document_id=0;
		$query='SELECT current_document_id,
					   DATEDIFF(NOW(), last_accessed) AS last_update
	                     FROM #__jgrid_current_user_grid_document 
	                     WHERE userid = ' . $user->id .'
	                        AND grid_id = '.$grid_id.'
	                        AND session_id = '.$temp_session_id;
		$db->setQuery($query);
		$current_document_array = $db->loadObjectList();
		if($current_document_array) 
		{
			$current_document_id = $current_document_array[0]->current_document_id;
			if($current_document_array[0]->last_update > 30)
			{
				
				$query='SELECT grid_id,
							   database_sql_name_id,
							   table_sql_name_id,
							   column_sql_name_id
	                     FROM #__jgrid_columngrid 
	                     WHERE primary_key_column = 1';
				$db->setQuery($query);
				$grid_sql_tables = $db->loadObjectList();
				// remove old sql JGrid table entries		
				for($i=0;$i<count($grid_sql_tables);$i++)
				{
					if($grid_sql_tables[$i]->column_sql_name_id&&$grid_sql_tables[$i]->table_s_name_id)
					{
						$db->setQuery('DELETE FROM #__jgrid_data 
		                               WHERE primary_key_value NOT IN 
		                               (SELECT '.$grid_sql_tables[$i]->column_sql_name_id.' 
		                                FROM '.$grid_sql_tables[$i]->database_sql_name_id.'.'.$grid_sql_tables[$i]->table_s_name_id.')');
		                                
						$db->query();
					}
				}
			}
		}
		if(!$current_document_array)
		{
			$db->setQuery('SELECT id
	                     FROM #__jgrid_document 
	                     WHERE grid_default_document_flag = 1
	                        AND grid_id = '.$grid_id);

			$current_document_id = $db->loadResult();

			//Set session ID to $session->getId()
			$temp_session_id = '"'.$session->getId().'"';

			//update current document for this guest user
			$db->setQuery('INSERT INTO #__jgrid_current_user_grid_document
		                             (current_document_id,
		                              previous_document_id1,
		                              userid,
		                              grid_id,
		                              session_id)
                           VALUES  ('.$current_document_id.',
                                    0,
                                    '.$user->id.',
	                                '.$grid_id.',
	                                '.$temp_session_id.')');
			$db->query();
		}


		// get grid data

		// add paging
		$session =JFactory::getSession();
		$number_of_grid_columns = $session->get('number_of_grid_columns');
		// set row count to 1 for sql type
		if($select_type > 1)
		{
			$number_of_grid_columns[$grid_id] = 1;
		}
	
		
		
		$start     = ((JRequest::getVar('start','','','INTEGER') != '') ? JRequest::getVar('start','','','INTEGER') : 0) * $number_of_grid_columns[$grid_id];
		$limit     = ((JRequest::getVar('limit','','','INTEGER') != '') ? JRequest::getVar('limit','','','INTEGER') : 30) * $number_of_grid_columns[$grid_id];
		// add filters
		$filter = JRequest::getVar('filter','','','RAW');
		
//echo 'sql223'.$grid_id;			
//echo 'sql3 '.print_r($filter);
		// if table type is JGRID		
	if ($filter||$searchString)
	{	// skip if no filter or search string
		$where = null;
		$j=0;
		$qs[$j] = '';
		// add search string first getting all values (consolidate in view-html when rows created
		if($searchString)
		{
			$jfield = array();
			// declare fields to check
			$jfield[0] = new stdClass(); 
			$jfield[0]->name = 'h.string_data';
			$jfield[0]->type = 'string';
			$jfield[1] = new stdClass; 
			$jfield[1]->name = 'h.int_data';
			$jfield[1]->type = 'number';
			$jfield[2] = new stdClass; 
			$jfield[2]->name = 'h.float_data';
			$jfield[2]->type = 'number';
			$searchString1 = str_replace(array(',', ';'), ' ' , $searchString);
			//$qs[$j] = ' AND (';
			$qs[$j] = ' AND ';
			list($searchString2,$wordarray) = searchParser($jfield, $searchString1, $select_type);
			$qs[$j] .= $searchString2;
			$j++;
		}	
	
	if($select_type < 2)
	{ 		
//echo 'sql3'.$qs[$j];
//return;		
		if (is_array($filter)) {
			for ($i=0;$i<count($filter);$i++){
				switch($filter[$i]['data']['type']){
					case 'string' :
						//$qs[$j] = ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.string_data LIKE "'.$filter[$i]['data']['value'].'")'; Break;
						$qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.string_data LIKE "%'.$filter[$i]['data']['value'].'%")'; Break;
						//$qs[$j] = ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND MATCH(h.string_data) AGAINST ("'.$filter[$i]['data']['value'].'" IN BOOLEAN MODE)'; Break;
	//echo 'sql22 '.$qs[$j];					
					case 'list' :
						// convert from list id to list string
    					$query = '	SELECT a.listboxvalues
		      	  					FROM #__jgrid_column_list_field_values a		                        
		          					WHERE a.id = '.$filter[$i]['data']['value'];
						$db->setQuery($query);
						$filter[$i]['data']['value'] = $db->loadResult();
						if (strstr($filter[$i]['data']['value'],',')){
							$fi = explode(',',$filter[$i]['data']['value']);
							for ($q=0;$q<count($fi);$q++){
								$fi[$q] = "'".$fi[$q]."'";
							}
							$filter[$i]['data']['value'] = implode(',',$fi);
							$qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.string_data IN ('.$filter[$i]['data']['value'].'))';
						}else{
							$qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.string_data = "'.$filter[$i]['data']['value'].'")';
						}
						Break;
					case 'boolean' : $qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.boolean_data = '.$filter[$i]['data']['value'].')'; Break;
					case 'numeric' :
						if(substr($filter[$i]['field'],0,1)=='I')
						{
							switch ($filter[$i]['data']['comparison']) {
								case 'ne' : $qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.int_data != '.$filter[$i]['data']['value'].')'; Break;
								case 'eq' : $qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.int_data = '.$filter[$i]['data']['value'].')'; Break;
								case 'lt' : $qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.int_data < '.$filter[$i]['data']['value'].')'; Break;
								case 'gt' : $qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.int_data > '.$filter[$i]['data']['value'].')'; Break;
							}
							if(substr($filter[$i]['field'],0,1)=='F')
							{
								switch ($filter[$i]['data']['comparison']) {
									case 'ne' : $qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.float_data != '.$filter[$i]['data']['value'].')'; Break;
									case 'eq' : $qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.float_data = '.$filter[$i]['data']['value'].')'; Break;
									case 'lt' : $qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.float_data < '.$filter[$i]['data']['value'].')'; Break;
									case 'gt' : $qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.float_data > '.$filter[$i]['data']['value'].')'; Break;
								}
							}
						}
						Break;
									case 'date' :
										switch ($filter[$i]['data']['comparison']) {
											case 'ne' : $qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.date_data != "'.date('Y-m-d',strtotime($filter[$i]['data']['value'])).'")'; Break;
											case 'eq' : $qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.date_data = "'.date('Y-m-d',strtotime($filter[$i]['data']['value'])).'")'; Break;
											case 'lt' : $qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.date_data < "'.date('Y-m-d',strtotime($filter[$i]['data']['value'])).'")'; Break;
											case 'gt' : $qs[$j] .= ' AND (h.columngrid_id = "'.substr($filter[$i]['field'],1).'" AND h.date_data > "'.date('Y-m-d',strtotime($filter[$i]['data']['value'])).'")'; Break;
										}
										Break;
				}
				$j++;
			}
		}
		if ($qs[0])
		{
			$where .= ' AND a.row_number IN (SELECT temp_table0.row_number
		                         FROM';
		    for($k=0;$k < $j; $k++)
		    {     
		    	
		        if($k != 0) $where .= ' JOIN ';             
		    	$where .= ' (SELECT h.row_number 
		                           FROM #__jgrid_columndata h, 
		                                #__jgrid_columngrid i
                                   WHERE i.id = h.columngrid_id
		                             AND i.grid_id = '.$grid_id.'	                                                                      
		                             AND h.document_id = '.$current_document_id.' '
		                              .$qs[$k] .')AS temp_table'.$k;
		    }
		    if($j > 1)
		    {
		    	for($k=1;$k < $j; $k++)
		    	{
		    		if($k == 1) $where .= ' ON temp_table0.row_number = temp_table1.row_number';
		    		else $where .= ' AND temp_table'.($k-1).'.row_number = temp_table'.$k.'.row_number';
		    	}
		    }                         
			$where .= ')';		
		}
	}
	else // select type is sql table
	{
		// GridFilters sends filters as an Array if not json encoded
		if (is_array($filter)) {
		    $encoded = false;
		} else {
		    $encoded = true;
		    $filter = json_decode($filter);
		}
		
		//$where = ' 0 = 0 ';
		//$qs[$j] = '';
		
		// loop through filters sent by client
		if (is_array($filter)) {
		    for ($i=0;$i<count($filter);$i++){		
		        // assign filter data (location depends if encoded or not)
		        if ($encoded) {
		            $field = $filter[$i]->field;
		            $value = $filter[$i]->value;
		            $compare = isset($filter[$i]->comparison) ? $filter[$i]->comparison : null;
		            $filterType = $filter[$i]->type;
		        } else {
		            $field = $filter[$i]['field'];
		            $value = $filter[$i]['data']['value'];
		            $compare = isset($filter[$i]['data']['comparison']) ? $filter[$i]['data']['comparison'] : null;
		            $filterType = $filter[$i]['data']['type'];
		        }
		
		        switch($filterType){
		            case 'string' : $qs[$j] .= " AND ".$field." LIKE '%".$value."%'"; Break;
		            case 'list' :
		                if (strstr($value,',')){
		                    $fi = explode(',',$value);
		                    for ($q=0;$q<count($fi);$q++){
		                        $fi[$q] = "'".$fi[$q]."'";
		                    }
		                    $value = implode(',',$fi);
		                    $qs[$j] .= " AND ".$field." IN (".$value.")";
		                }else{
		                    $qs[$j] .= " AND ".$field." = '".$value."'";
		                }
		            Break;
		            case 'boolean' : $qs[$j] .= " AND ".$field." = ".($value); Break;
		            case 'numeric' :
		                switch ($compare) {
		                    case 'eq' : $qs[$j] .= " AND ".$field." = ".$value; Break;
		                    case 'lt' : $qs[$j] .= " AND ".$field." < ".$value; Break;
		                    case 'gt' : $qs[$j] .= " AND ".$field." > ".$value; Break;
		                }
		            Break;
		            case 'date' :
		                switch ($compare) {
		                    case 'eq' : $qs[$j] .= " AND ".$field." = '".date('Y-m-d',strtotime($value))."'"; Break;
		                    case 'lt' : $qs[$j] .= " AND ".$field." < '".date('Y-m-d',strtotime($value))."'"; Break;
		                    case 'gt' : $qs[$j] .= " AND ".$field." > '".date('Y-m-d',strtotime($value))."'"; Break;
		                }
		            Break;
		        }
		        $j++;
		    }		   
		}
		if ($qs[0])
		{
			$where .= ' AND a.row_number IN (SELECT temp_table0.row_number
		                         FROM';
		    for($k=0;$k < $j; $k++)
		    {     
		    	
		        if($k != 0) $where .= ' JOIN ';             
		    	$where .= ' (SELECT h.row_number 
		                           FROM #__jgrid_columndata h, 
		                                #__jgrid_columngrid i
                                   WHERE i.id = h.columngrid_id
		                             AND i.grid_id = '.$grid_id.'	                                                                      
		                             AND h.document_id = '.$current_document_id.' '
		                              .$qs[$k] .')AS temp_table'.$k;
		    }
		    if($j > 1)
		    {
		    	for($k=1;$k < $j; $k++)
		    	{
		    		if($k == 1) $where .= ' ON temp_table0.row_number = temp_table1.row_number';
		    		else $where .= ' AND temp_table'.($k-1).'.row_number = temp_table'.$k.'.row_number';
		    	}
		    }                         
			$where .= ')';		
		}				
	  }
	}	
		
//echo 'where'.$where;
//return;		
		
		
		
		list($admin_user,$access_control,$remove_access_control,$document_security_level) = check_access_control($grid_id,$current_document_id,3);
//echo 'sql'.$document_security_level;
		if(!$remove_access_control) $remove_access_control = 0;
		if($admin_user==0)
		{ // normal user

			// Look for individual  sheet or Grid security level
			//look for document security levels for users
			$query = 'SELECT max(e.access_level)
		                   FROM #__jgrid_security e
		                   WHERE (e.access_for = 1 
		                           AND 
		                           e.access_for_id = '.$user->id.')
		                	 AND e.access_rule_application_id = '. $access_rule_application_id. '           
		                     AND ((e.access_type = 1                     
		                          AND (e.access_subtype_grid_id = '.$grid_id.'
		                       			OR
		                       		e.access_subtype_grid_id = -1))
		                        OR (e.access_type = 3                     
		                          AND e.access_subtype_document_id = '.$current_document_id.')		                        
		                        )';
			//echo 'sql'.$query;
			$db->setQuery($query);
			//echo 'sql'.$query;
			$user_document_security_level = $db->loadResult();



			//find document security levels for roles
			$query = 'SELECT max(e.access_level)
		                   FROM #__jgrid_security e, 
		                        #__jgrid_role_userlist f
		                   WHERE e.access_for=2
		                   AND e.access_rule_application_id = '. $access_rule_application_id. '
		                   AND e.access_for_id = f.role_id
		                   AND f.userid ='.$user->id.'   
		                     AND ((e.access_type = 1                                        
		                          AND (e.access_subtype_grid_id = '.$grid_id.'
		                       			OR
		                       		e.access_subtype_grid_id = -1))                      
		                        OR (e.access_type = 3                     
		                          AND e.access_subtype_document_id = '.$current_document_id.') 		                        
		                        )';
			$db->setQuery($query);
			$role_document_security_level = $db->loadResult();



			if($user_document_security_level!=0)
			{
				$document_security_level=$user_document_security_level;
			}
			else if($role_document_security_level!=0)
			{
				$document_security_level=$role_document_security_level;
			}

			if(!$document_security_level)
			{
				$document_security_level=0;
			}
			//Default Overall Sheet Security to 1 viewer or Sheet Manager 5 if user is sheet creator ?? probably never runs
			if($document_security_level==0)
			{
				$db->setQuery('SELECT (1)
		                   FROM #__jgrid_document a, 
		                        #__jgrid_current_user_grid_document b
		                   WHERE a.creator_userid = ' . $user->id .'
		                   AND a.id = b.current_document_id');
				$_result=0;
				$_result = $db->loadResult();
				if($_result!=0)
				{ // document creator
					$document_security_level='5';
				}
				else
				{ // Viewer
					$document_security_level='1';
				}
			}

			if($document_security_level<5)
			{
				//find document security types for creator lowest is most restrictive eg creator editable and viewable only to highest creator role editable public viewable
				$query = 'SELECT min(e.access_for_id)
		                   FROM #__jgrid_security e
		                   WHERE e.access_for=4
		                   	 AND e.access_rule_application_id = '. $access_rule_application_id. '  
		                     AND (((e.access_type = 1 OR e.access_type = 2    )                
		                          AND (e.access_subtype_grid_id = '.$grid_id.'
		                       			OR
		                       		e.access_subtype_grid_id = -1))  
		                        OR ((e.access_type = 3   OR e.access_type = 4       )           
		                          AND e.access_subtype_document_id = '.$current_document_id.') 		                        
		                        )';
				//echo 'sql'.$query;
				$db->setQuery($query);
				$creator_document_security_level = $db->loadResult();
				//echo 'sql'.$creator_document_security_level;
				if(!$creator_document_security_level)
				{
					$creator_document_security_level=0;
				}
				//echo 'sql'.$creator_document_security_level.'sql'.$query;
				if($creator_document_security_level!=0)
				{
					//find current user role
					$query = 'SELECT role_id
		                   FROM #__jgrid_role_userlist a 
		                   WHERE a.userid = '.$user->id;
					$db->setQuery($query);
					$user_role_id = $db->loadResult();
					if(!$user_role_id)
					{
						$user_role_id='0';
					}

					// find if min / most restrictive creator role is for column or overall document

					$query = 'SELECT count(1)
		                      FROM #__jgrid_security e 
		                      WHERE access_for = 4
		                        AND (e.access_type = 1
		                              OR e.access_type = 3)
		                        AND e.access_for_id = '. $creator_document_security_level;

					$db->setQuery($query);
					$document_level_creator_rule = $db->loadResult();
					//echo 'sql'.$document_level_creator_rule;
				}

			}
			// find columns that are view only
			if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
			{
				
				$this->_query = 'SELECT DISTINCT
		                  b.access_type_id,
		                  CONCAT(a.data_type,e.id) AS "dataindex"
		                  FROM #__jgrid_columns a, 
		                       #__jgrid_security b,
		                       #__jgrid_document c, 
		                       #__jgrid_current_user_grid_document d,
		                       #__jgrid_columngrid e,
		                       #__jgrid_role_userlist f,
		                       #__jgrid_user_type_defaults g,
		                       #__usergroups h,
		                       #__user_usergroup_map i 
		                  WHERE c.grid_id = e.grid_id
                          AND   a.id = e.column_id
                          AND   e.grid_id = '.$grid_id.'	                  
		                  AND ((b.access_for = 1 
		                                     AND 
		                                     b.access_for_id = '.$user->id.')
		                                  OR
		                                   (b.access_for=2
		                                      AND b.access_for_id = f.role_id
		                                      AND f.userid ='.$user->id.')
		                               OR
		                                   (b.access_for=3
		                                     AND b.access_for_id = g.id
                                             AND g.usertype_name = h.title
		                                     AND i.user_id = '.$user->id.'
		                                     AND (h.id=i.group_id
		                                       OR ('.$user->id.' = 0))))
                          AND (b.access_level = 1 OR b.access_level = -1) 
		                  AND a.id = b.access_type_id
		                  AND c.id = d.current_document_id
		                  AND  ((b.access_type=2
		                                AND b.access_subtype_grid_id=e.grid_id
                                        AND b.access_subtype_column_id=e.id)     		                                                
		                          OR  (b.access_type=4 
		                                AND b.access_subtype_document_id=c.id
                                        AND b.access_subtype_column_id=e.id))';
			}
			else
			{
				$this->_query = 'SELECT DISTINCT
		                  b.access_type_id,
		                  CONCAT(a.data_type,e.id) AS "dataindex"
		                  FROM #__jgrid_columns a, 
		                       #__jgrid_security b,
		                       #__jgrid_document c, 
		                       #__jgrid_current_user_grid_document d,
		                       #__jgrid_columngrid e,
		                       #__jgrid_role_userlist f,
		                       #__jgrid_user_type_defaults g 
		                  WHERE c.grid_id = e.grid_id
                          AND   a.id = e.column_id
                          AND   e.grid_id = '.$grid_id.'	                  
		                  AND ((b.access_for = 1 
		                                     AND 
		                                     b.access_for_id = '.$user->id.')
		                                  OR
		                                   (b.access_for=2
		                                      AND b.access_for_id = f.role_id
		                                      AND f.userid ='.$user->id.')
		                               OR
		                                   (b.access_for=3
		                                     AND b.access_for_id = g.id
		                                     AND (g.usertype_name ="'.$user->usertype.'"
		                                       OR ('.$user->id.' = 0))))
                          AND (b.access_level = 1 OR b.access_level = -1) 
		                  AND a.id = b.access_type_id
		                  AND c.id = d.current_document_id
		                  AND  ((b.access_type=2
		                                AND b.access_subtype_grid_id=e.grid_id
                                        AND b.access_subtype_column_id=e.id)     		                                                
		                          OR  (b.access_type=4 
		                                AND b.access_subtype_document_id=c.id
                                        AND b.access_subtype_column_id=e.id))';
			}
			$this->_result_count = $this->_getListCount( $this->_query );
			if($this->_result_count>0)
			{
				$this->_result = $this->_getList( $this->_query );
				for($i=0; $i<$this->_result_count;$i++)
				{
					$document_security_level .= '_V'.$this->_result[$i]->dataindex;
				}
			}

			// find columns that are CELL ROW Editable
			if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
			{
				$this->_query = 'SELECT DISTINCT
		                  b.access_type_id,
		                  CONCAT(a.data_type,e.id) AS "dataindex",
		                  b.access_level
		                  FROM #__jgrid_columns a, 
		                       #__jgrid_security b,
		                       #__jgrid_document c, 
		                       #__jgrid_current_user_grid_document d,
		                       #__jgrid_columngrid e,
		                       #__jgrid_role_userlist f,
		                       #__jgrid_user_type_defaults g,
                               #__usergroups h,
		                       #__user_usergroup_map i 
		                  WHERE c.grid_id = e.grid_id
                          AND   a.id = e.column_id
                          AND   e.grid_id = '.$grid_id.'	                  
		                  AND ((b.access_for = 1 
		                                     AND 
		                                     b.access_for_id = '.$user->id.')
		                                  OR
		                                   (b.access_for=2
		                                      AND b.access_for_id = f.role_id
		                                      AND f.userid ='.$user->id.')
		                                 OR
		                                   (b.access_for=3
		                                     AND b.access_for_id = g.id
                                             AND g.usertype_name = h.title
		                                     AND i.user_id = '.$user->id.'
		                                     AND (h.id=i.group_id		                                        
		                                       OR ('.$user->id.' = 0)))
		                                 OR b.access_for=4)
                          AND b.access_level > 1
		                  AND a.id = b.access_subtype_column_id
		                  AND c.id = d.current_document_id
		                  AND ((b.access_type=2
		                                AND b.access_subtype_grid_id=e.grid_id
                                        AND b.access_subtype_column_id=a.id)     		                                                
		                          OR  (b.access_type=4 
		                                AND b.access_subtype_document_id=c.id
                                        AND b.access_subtype_column_id=a.id))';
			}
			else
			{
				$this->_query = 'SELECT DISTINCT
		                  b.access_type_id,
		                  CONCAT(a.data_type,e.id) AS "dataindex",
		                  b.access_level
		                  FROM #__jgrid_columns a, 
		                       #__jgrid_security b,
		                       #__jgrid_document c, 
		                       #__jgrid_current_user_grid_document d,
		                       #__jgrid_columngrid e,
		                       #__jgrid_role_userlist f,
		                       #__jgrid_user_type_defaults g 
		                  WHERE c.grid_id = e.grid_id
                          AND   a.id = e.column_id
                          AND   e.grid_id = '.$grid_id.'	                  
		                  AND ((b.access_for = 1 
		                                     AND 
		                                     b.access_for_id = '.$user->id.')
		                                  OR
		                                   (b.access_for=2
		                                      AND b.access_for_id = f.role_id
		                                      AND f.userid ='.$user->id.')
		                                 OR
		                                   (b.access_for=3
		                                     AND b.access_for_id = g.id
		                                     AND (g.usertype_name ="'.$user->usertype.'"
		                                       OR ('.$user->id.' = 0)))
                                          OR b.access_for=4)		                      
                          AND b.access_level > 1
		                  AND a.id = b.access_subtype_column_id
		                  AND c.id = d.current_document_id
		                  AND ((b.access_type=2
		                                AND b.access_subtype_grid_id=e.grid_id
                                        AND b.access_subtype_column_id=a.id)     		                                                
		                          OR  (b.access_type=4 
		                                AND b.access_subtype_document_id=c.id
                                        AND b.access_subtype_column_id=a.id))';
			}
			$this->_result_count = $this->_getListCount( $this->_query );
			if($this->_result_count>0)
			{
				$this->_result = $this->_getList( $this->_query );
				for($i=0; $i<$this->_result_count;$i++)
				{
					$column_security_level .= '_C'.$this->_result[$i]->dataindex;
					if($this->_result[$i]->access_level > $max_column_security_level)
					{
						$max_column_security_level = $this->_result[$i]->access_level;
					} 
				}
			}


			// find users roles for rowediting test
			$this->_query = 'SELECT role_id
		                  FROM #__jgrid_role_userlist
		                  WHERE userid = ' . $user->id;
			$this->_result_count = $this->_getListCount( $this->_query );
			if($this->_result_count>0)
			{
				$this->_result = $this->_getList( $this->_query );
				$myroles = $this->_result[0]->role_id;
				for($i=1; $i<$this->_result_count;$i++)
				{
					$myroles .= ','.$this->_result[$i]->role_id;
				}
			}

		}


		// check for demo version return
		if($session->get('demo_mode')){
			// give full access as administrator
			$document_security_level='6';
		}
		if($admin_user!=0)
		{
		  $document_security_level = '6';
		}

		// check for remote sort and remote grouping
		if($group) $enableGroupBy =true;
		else $enableGroupBy=false;
		if($sort) $enableSortBy =true;
		else $enableSortBy =false;

		if($select_type < 2 && ($enableGroupBy || $enableSortBy))
		{
			//echo 'sql'.JRequest::getVar('enableGroupBy','','','INTEGER');
			// find group_by column
			if($enableGroupBy)
			{
				switch (substr($group[0]['property'],0,1))
				{
					//text
					case 'T':
						//List
					case 'L':
						//Picture
					case 'P':
						//URL
					case 'U':
						//EMail
					case 'E':						
						//Sheet Name
					case 'S':
						//Row ID
					case 'R':						
						$group_by_column="string_data";
						break;
						//Integer
					case 'I':
						$group_by_column="int_data";
						break;
						//Float
					case 'F':
						$group_by_column="float_data";
						break;
						//Boolean
					case 'B':
						$group_by_column="boolean_data";
						break;
						//date
					case 'D':
						$group_by_column="date_data";
						break;
				}
			}
			// find sort_by column
			if($enableSortBy)
			{
				switch (substr($sort[0]['property'],0,1))
				{
					//text
					case 'T':
						//List
					case 'L':
						//Picture
					case 'P':
						//URL
					case 'U':
						//Email
					case 'E':						
						//Sheet Name
					case 'S':
						$sort_by_column="string_data";
						break;
						//Integer
					case 'I':
						$sort_by_column="int_data";
						break;
						//Float
					case 'F':
						$sort_by_column="float_data";
						break;
						//Boolean
					case 'B':
						$sort_by_column="boolean_data";
						break;
						//date
					case 'D':
						$sort_by_column="date_data";
						break;
				}
			}
			// create insert string
			$insert_query = 'INSERT INTO  #__jgrid_temp_table (userid,
			                                                   session_id,
			                                                   row_id,
			                                                   temp_type';

			if ($enableGroupBy && $enableSortBy)
			{
				$insert_query .= ',group_name';
			}
			$insert_query .= ')';
			// create select
			$select_query = ' SELECT DISTINCT '.$user->id.' as userid,
                                              '.$temp_session_id.' as session_id,
	                                          a.row_number as row_id,
	                                          1 as temp_type';
			if ($enableGroupBy && $enableSortBy)
			{
				$select_query .= ',"'.$group_by_column.'" as group_name';
			}
			$select_query .= ' FROM  #__jgrid_columndata a
	              WHERE a.document_id = '.$current_document_id;
			if ($filter||$searchString) $select_query .= $where;
			if ($enableGroupBy)
			{
				$select_query .= ' AND a.columngrid_id='.substr($group[0]['property'],1).'
				 ORDER BY '.$group_by_column.' '.$group[0]['direction'].' ';
			}
			else if ($enableSortBy)
			{
				$select_query .= ' AND a.columngrid_id='.substr($sort[0]['property'],1).'
				  ORDER BY '.$sort_by_column.' '.$sort[0]['direction'].' ';
			}

			$this->_result_count = $this->_getListCount( $select_query );

			// if paging active
			if(JRequest::getVar('limit','','','INTEGER'))
			{
				$paging_result_count_rows=$this->_result_count;
				$select_query .= ' LIMIT '.$start.', '.$limit;
			}
			// create insert into select query
			$this->_query = $insert_query . $select_query;
			$db->setQuery($this->_query);
			$db->query();

			//echo 'sql'.$this->_query;
			// if both group by and sort by are active perform 2nd sort
			if($enableGroupBy && $enableSortBy)
			{
				// select sort columns and order within groups
				$this->_query = 'INSERT INTO #__jgrid_temp_table2 (userid,
			                                                       session_id,
			                                                       row_id,
			                                                       temp_type)
				                 SELECT  '.$user->id.' as userid,
                                                 '.$temp_session_id.' as session_id,
	                                             a.row_number as row_id,
	                                             2 as temp_type
	              FROM  #__jgrid_columndata a,
	                    #__jgrid_temp_table b
	              WHERE a.document_id = '.$current_document_id.'
                    AND a.row_number = b.row_id
                    AND a.columngrid_id='.substr($sort[0]['property'],1).'
                     ORDER BY b.group_name '.JRequest::getVar('groupDir','','','STRING').',
                              a.'.$sort_by_column.' '.$sort[0]['direction'];
				$db->setQuery($this->_query);
				$db->query();
			}
		}
		// check for hidden columns
		if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
		{
			$this->_query = 'SELECT DISTINCT e.access_subtype_column_id AS column_id
		                     FROM #__jgrid_security e, 
		                          #__jgrid_role_userlist f,
		                          #__jgrid_user_type_defaults g,
                                  #__usergroups h,
		                          #__user_usergroup_map i		                                     	                                     
		                     WHERE ((e.access_for = 1 
		                               AND e.access_for_id = '.$user->id.')
		                             OR
		                             (e.access_for=2
		                                AND f.role_id IS NOT NULL
		                                AND e.access_for_id = f.role_id
		                                AND f.userid ='.$user->id.')
		                             OR
		                             (e.access_for=3
		                                AND e.access_for_id = g.id
                                        AND g.usertype_name = h.title
		                                AND i.user_id = '.$user->id.'
		                                AND (h.id=i.group_id
		                                       OR ('.$user->id.' = 0))))
		                       AND e.access_level = 0
		                       AND ((e.access_type=2
		                                AND e.access_subtype_grid_id = '.$grid_id.')     		                                                
		                         OR  (e.access_type=4 
		                                AND e.access_subtype_document_id = '.$current_document_id.'))';
		}else
		{
			$this->_query = 'SELECT DISTINCT e.access_subtype_column_id AS column_id
		                     FROM #__jgrid_security e, 
		                          #__jgrid_role_userlist f,
		                          #__jgrid_user_type_defaults g	                                     
		                     WHERE ((e.access_for = 1 
		                               AND e.access_for_id = '.$user->id.')
		                            OR
		                            (e.access_for=2
		                                AND e.access_for_id = f.role_id
		                                AND f.userid ='.$user->id.')
		                           OR
		                            (e.access_for=3
		                               AND e.access_for_id = g.id
		                               AND (g.usertype_name ="'.$user->usertype.'"
		                                      OR ('.$user->id.' = 0))))
		                      AND e.access_level = 0
		                      AND ((e.access_type=2
		                              AND e.access_subtype_grid_id='.$grid_id.')     		                                                
		                           OR  (e.access_type=4 
		                                  AND e.access_subtype_document_id='.$current_document_id.'))';
		}

		$this->_result_count = $this->_getListCount( $this->_query );
		$hide_column_ids='0';
		if($this->_result_count)
		{
			$this->_result = $this->_getList( $this->_query );
			for($i=0;$i<$this->_result_count;$i++)
			{
				$hide_column_ids.=',';
				$hide_column_ids.=$this->_result[$i]->column_id;

			}
		}

	// if table type is JGRID
	if($select_type < 2 )
	{
		$this->_query = 'SELECT DISTINCT a.id,
			                        b.grid_id,
		                            a.userid, 
		                            a.column_id, 
		                            c.data_type,
		                            b.column_type,  
		                            CONCAT(c.data_type,a.columngrid_id) AS "dataindex", 
		                            a.row_number, 
		                            ROW.document_id, 
		                            a.string_data, 
		                            a.int_data, 
		                            a.float_data, 
		                            a.boolean_data, 
		                            a.date_data,
		                            a.listboxvaluerowcolor,
		                            b.row_color_pressidence,
		                            b.formula,
		                            ROW.row_access_id,';
		// get slvl string
		$this->_query .= getSlvlSqlString($admin_user,$document_security_level,$creator_document_security_level,$column_security_level,$document_level_creator_rule);
		$this->_query .= ' AS slvl,';		
		//get edit line string
		$this->_query .= getEditlineSqlString($creator_document_security_level,$admin_user,$document_security_level,$myroles, $max_column_security_level);
		$this->_query .= '  AS editable_line';
		
	     $this->_query .=   ' FROM  #__jgrid_columndata a, 
	                    #__jgrid_columngrid b, 
	                    #__jgrid_columns c, 
	                    #__jgrid_rows ROW ';		
		if(($creator_document_security_level==2 || $creator_document_security_level==3 || $creator_document_security_level==5 || $creator_document_security_level==7 || $creator_document_security_level==9)&&($admin_user==0&&$document_security_level<5))
		{
			$this->_query .= ' ,#__jgrid_role_userlist RUL';
		}
		
		if($enableGroupBy && $enableSortBy)
		{
			$this->_query .= ' ,#__jgrid_temp_table2 e
			           WHERE b.grid_id = '.$grid_id.'
			             AND ROW.id = e.row_id ';
		}
		else if($enableGroupBy || $enableSortBy)
		{
			$this->_query .= ' ,#__jgrid_temp_table e
			           WHERE b.grid_id = '.$grid_id.'
			             AND ROW.id = e.row_id ';
		}
		else
		{
			$this->_query .= ' WHERE b.grid_id = '.$grid_id;
		}
		$this->_query .= ' AND ROW.document_id = '.$current_document_id.'
	                           AND b.id = a.columngrid_id
                               AND c.id = b.column_id
                               AND 0 = '.$remove_access_control.'
                               AND ROW.id = a.row_number
                               AND a.columngrid_id NOT IN ('.$hide_column_ids.')';
		// add where clause
		if ($filter||$searchString) $this->_query .=  $where;

		$creatorJoin = getCreatorJoinSqlString($admin_user,$document_security_level,$creator_document_security_level,$user_role_id);
		// if creator rule and guest user no grid displayed
		if($creatorJoin == '999') $remove_access_control = 1; 
		else $this->_query .= $creatorJoin;
		//echo 'sql4'.$this->_query;

		// order by and or group by
		if($enableGroupBy || $enableSortBy)
		{
			$this->_query .= ' ORDER BY e.ordering, b.ordering';
		}
		else
		{
			$this->_query .= ' ORDER BY ROW.ordering, b.ordering';
		}
// echo 'sql ' . $this->_query;
// return;

	}	
	// if table type is  not JGRID
	else
	{ 	// table sql select
		// find table data
	  	$query = 'SELECT	a.sql_query,
  							a.validated,
  							a.jgrid_sql_query,
  							a.database_sql_name_id,
  							a.table_sql_name_id,
  							a.p_column_sql_name_id			
			      	  FROM #__jgrid_select_query a		                        
			          WHERE a.grid_id = '.$grid_id;
	  	
	  	
		$db->setQuery($query);
		$table_query = $db->loadObjectList();
		
		$this->_query = $table_query[0]->jgrid_sql_query;
		
		// create query replacing wild cards and document_id
        $this->_query = str_replace("@document_security_level",$document_security_level,$this->_query); // add current document number
		$this->_query = str_replace("@rslvl_id",1,$this->_query); // add current document number
		$this->_query = str_replace("@UserName",$user->name,$this->_query); // The name of the user. (e.g. Vint Cerf)
		$this->_query = str_replace("@UserID",$user->id,$this->_query); //  The unique, numerical user id. Use this when referencing the user record in other database tables.
		$this->_query = str_replace("@UserGroupID",$user->gid,$this->_query); //  Set to the user's group id, which corresponds to the usertype.		
		$this->_query = str_replace("@UserUsername",$user->username,$this->_query); // The login/screen name of the user. (e.g. shmuffin1979)
		$this->_query = str_replace("@UserEmail",$user->email,$this->_query); // The email address of the user. (e.g. crashoverride@hackers.com)
		$this->_query = str_replace("@UserType",$user->usertype,$this->_query); // The role of the user within Joomla!. (Super Administrator, Editor, etc...)
		$this->_query = str_replace("@UserRegisterDate",$user->registerDate,$this->_query); // Set to the date when the user was first registered.
		$this->_query = str_replace("@UserlastvisitDate",$user->lastvisitDate,$this->_query); //  Set to the date the user last visited the site.		
		$this->_query = str_replace("@CurrentDateTimeStamp",JFactory::getDate(),$this->_query); // add current document number

		
		// add slvl string
		$this->_query = str_replace("@document_security_level",getSlvlSqlString($admin_user,$document_security_level,$creator_document_security_level,$column_security_level,$document_level_creator_rule),$this->_query); // add current document number
		//get edit line string
		$this->_query = str_replace("@editable_line",getEditlineSqlString($creator_document_security_level,$admin_user,$document_security_level,$myroles,$max_column_security_level),$this->_query, $max_column_security_level); // add current document number
		// add creator join to sql
		$creatorJoin = getCreatorJoinSqlString($admin_user,$document_security_level,$creator_document_security_level,$user_role_id);
		// if creator rule and guest user no grid displayed
		if($creatorJoin == '999') $remove_access_control = 1; 
		else $this->_query = str_replace("AND document_id = @document_id"," AND document_id = @document_id ".$creatorJoin,$this->_query); // add current document number
		$this->_query = str_replace("@document_id",$current_document_id,$this->_query); // add current document number
		
//echo $this->_query;
		
		if(($creator_document_security_level==2 || $creator_document_security_level==3 ||$creator_document_security_level==5 || $creator_document_security_level==7 ||$creator_document_security_level==5 || $creator_document_security_level==7 || $creator_document_security_level==9)&&($admin_user==0&&$document_security_level<5))
		{
			$this->_query = str_replace("#__jgrid_data ROW","#__jgrid_data ROW, #__jgrid_role_userlist RUL ",$this->_query); // add current document number
		}
			
	    $this->_query = str_replace("ROW.row_access_id","rslvl_id",$this->_query); // replace ROW.row_access_id with rslvl_id to work with normal jgrid data, look at creator lator
        
		
		// add where clause
		if ($filter||$searchString) $this->_query .=  ' WHERE '. $where;
		
		if ($enableGroupBy)
		{
			$this->_query .= ','. $group[0]['property'] .' '.$group[0]['direction'].' ';
		}
		else if ($enableSortBy)
		{
			$this->_query .= ' SORT BY ' . $sort[0]['property'] .'  '.$sort[0]['direction'].' ';
		}
//echo 'sql ' . $this->_query;
//return;	

	}
			
	//JError::raiseError(1001, JText::_('sql'.$this->_query));
		 	//return;
		//echo 'sql'.$creator_document_security_level;
		$this->_result_count = $this->_getListCount( $this->_query );
		
		// if no access then send back blank row
		if($remove_access_control) $this->_result_count = 0;
		//echo 'sql'.	$this->_result_count. 'sql'.$creator_document_security_level;
//echo 'sql'.$this->_query;
		// if no rows insert one = 
		if($this->_result_count==0)
		{
			// if no rows returned and document creator then set to 4 so rows can be added by creator.
			if($creator_document_security_level>0)
			{
				if(!$user->guest&&$user->id!=0)
				{
					$document_security_level=4;
				}
				else
				{
					$document_security_level=1;
				}
			}
			
			if($select_type < 2)
			{
				$query = '  SELECT  DISTINCT 0 as id,
				                    '.$grid_id.' as grid_id,			                    			                   
	       	                        a.id,
	       	                        a.data_type,
	       	                        CONCAT(a.data_type,b.id) AS "dataindex",
	       	                        0 as row_number,
	       	                        '.$current_document_id.' as document_id,
	       	                        "" as string_data,
	       	                        0 as int_data,
	       	                        0 as float_data,
	       	                        0 as boolean_data,
	       	                        "" as date_data,
	       	                        "" as listboxvaluerowcolor,
		                            0 as row_color_pressidence,
		                            "" as formula,
		                            "U'.$user->id.'" as row_access_id,
		                            4 as creator_document_security_level,
		                            1 AS editable_line,
		                            "'.$document_security_level.'" AS slvl,
		                            '.$user->id.' AS userid                                   
	                        FROM  #__jgrid_columns a, 
	                              #__jgrid_columngrid b
		                    WHERE b.grid_id = '.$grid_id.'
		                       AND a.id = b.column_id';
			}
			else 
			{
							$query = '  SELECT  DISTINCT 0 as id,
				                    '.$grid_id.' as grid_id,			                    			                   
	       	                        0 as id,
	       	                        a.data_type,
	       	                        CONCAT(a.data_type,b.id) AS "dataindex",
	       	                        0 as row_number,
	       	                        '.$current_document_id.' as document_id,
	       	                        "" as string_data,
	       	                        0 as int_data,
	       	                        0 as float_data,
	       	                        0 as boolean_data,
	       	                        "" as date_data,
	       	                        "" as listboxvaluerowcolor,
		                            0 as row_color_pressidence,
		                            "" as formula,
		                            "U'.$user->id.'" as row_access_id,
		                            4 as creator_document_security_level,
		                            0 AS editable_line,
		                            "'.$document_security_level.'" AS slvl,
		                            '.$user->id.' AS userid                                  
	                        FROM  #__jgrid_columns a, 
	                              #__jgrid_columngrid b
		                    WHERE b.grid_id = '.$grid_id.'
		                       AND a.id = b.column_id
		                       LIMIT 1';
			}
			
			// echo 'sql'.$query ;
			$this->_result = $this->_getList( $query );
  
			return array($document_security_level.$column_security_level,$this->_result,$select_type,$hide_column_ids,$wordarray);
		}
		// if paging active
		if(JRequest::getVar('limit','','','INTEGER'))
		{
			$this->_query .= ' LIMIT '.$start.', '.$limit;
		}
		//echo 'sql2'.$this->_query;

		$this->_result = $this->_getList( $this->_query );
	
//echo 'sql'.print_r($this->_result);

		// if paging active
		if(JRequest::getVar('limit','','','INTEGER'))
		{
			if(!($enableGroupBy || $enableSortBy))
			{
				if($this->_result_count && $number_of_grid_columns[$grid_id]) $paging_result_count_rows=$this->_result_count/$number_of_grid_columns[$grid_id];
			}
			else $paging_result_count_rows = 30;
			if(class_exists('Jinput')) {
				$input = new Jinput;
				$input->set( 'paging_result_count_rows',$paging_result_count_rows);
			}
			else
			{
				JRequest::setVar('paging_result_count_rows', $paging_result_count_rows);
			}
	}


		// clean up temp tables
		$this->_query = 'DELETE FROM #__jgrid_temp_table
			   		             WHERE userid = ' . $user->id .'
			                       AND session_id = '.$temp_session_id.'';
		$db->setQuery($this->_query);
		$db->query();
		$this->_query = 'DELETE FROM #__jgrid_temp_table2
			   		             WHERE userid = ' . $user->id .'
			                       AND session_id = '.$temp_session_id.'';
		$db->setQuery($this->_query);
		$db->query();
			
		if($this->_result) return array($document_security_level.$column_security_level,$this->_result,$select_type,$hide_column_ids,$wordarray);
		else return array($document_security_level.$column_security_level,'',$select_type,$hide_column_ids,$wordarray);
	}

	/**
	 * Retrieves the jgrid data
	 * @return array Array of objects containing the data from the database
	 */
	function getGriddata()
	{
		$user=JFactory::getUser();
		$db =JFactory::getDBO();
		// check for joomla version
		$version = new JVersion;
		$joomla = $version->getShortVersion();
		$no_access_override_list='0';
		$global_grid_rule_override = 0;



		//check to see if current document exists, if not update to the default document, always reset guest to default
		$session =JFactory::getSession();
		$temp_session_id = '"'.$session->getId().'"';

		// Remove old sessions for guest users
		$this->_query= 'DELETE FROM #__jgrid_current_user_grid_document
                       WHERE NOT EXISTS (SELECT *
                                         FROM #__session
                                         WHERE #__jgrid_current_user_grid_document.session_id = #__session.session_id)';                 
		$db->setQuery($this->_query);
		$db->query();

		$this->_query='UPDATE #__jgrid_current_user_grid_document a,
		                      #__jgrid_document b		                      
		               SET a.current_document_id = b.id
		               WHERE b.grid_default_document_flag=1
		                 AND a.userid = ' . $user->id .'
		                 AND a.grid_id = b.grid_id
		                 AND a.session_id = '.$temp_session_id.'
		                 AND (0 =  (SELECT count(1) 		                                                    
		                            FROM #__jgrid_document c 		                                   
		                            WHERE a.current_document_id = c.id))';						               	
		$db->setQuery($this->_query);
		$db->query();
			
		//check to see if user has current document access if not assign user to default document
		// find document to display
		$this->_query='INSERT IGNORE INTO #__jgrid_current_user_grid_document (current_document_id,
		                                                                  userid,
		                                                                  grid_id,
		                                                                  session_id)                                                
		               SELECT a.id as current_document_id,
		                      ' . $user->id.' as userid,
		                       a.grid_id,
		                       '.$temp_session_id.' as session_id
	                   FROM  #__jgrid_document a
	                   WHERE a.grid_default_document_flag=1
		               AND   a.grid_id NOT IN (SELECT grid_id 
		                                FROM #__jgrid_current_user_grid_document b, 
		                                     #__jgrid_grids c
		                                WHERE b.userid = ' . $user->id .'
		                                AND b.grid_id = c.id
		                                AND b.session_id = '.$temp_session_id.'
		                                AND c.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'")'; 	
		//JError::raiseError(1001, JText::_('sql'.$this->_query));
		//  	return;
		$db->setQuery($this->_query);
		$db->query();

		// check for administrative type users
		$admin_user = check_for_backend_admin_access_rights();
	//JError::raiseError(1001, JText::_('sql'.$admin_user));

		if(!$admin_user)
		{
		  $admin_user = 0;
		    // check for all grid override for global grid rules applying to this user 
			$this->_query='SELECT count(1)
		                                FROM #__jgrid_grids a,
		                                     #__jgrid_security e, 
		                                     #__jgrid_role_userlist f
		                                WHERE ((e.access_for = 1 
		                                         AND e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2 
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.')
		                                        OR (e.access_for=4))
		                                 AND e.access_type_id = -1   
		                                 AND e.access_level > 0
		                                 AND a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"';
		    $db->setQuery($this->_query);
			$global_grid_rule_override = $db->loadResult();
			
			$no_access_override_list = '0';
		    if(!$global_grid_rule_override)
		    {
		    	$global_grid_rule_override = 0;
				// check for overrides for no access commands for specific roles or users
				$this->_query='SELECT DISTINCT a.id
			                                FROM #__jgrid_grids a,
			                                     #__jgrid_security e, 
			                                     #__jgrid_role_userlist f,
			                                     #__jgrid_document g
			                                WHERE ((e.access_for = 1 
			                                         AND e.access_for_id = '.$user->id.')
			                                       OR
			                                       (e.access_for=2 
			                                          AND e.access_for_id = f.role_id
			                                          AND f.userid ='.$user->id.')
			                                        OR (e.access_for=4))
			                                 AND ((a.id = e.access_type_id
			                                        OR e.access_type_id = -1) 
			                                       OR (a.id = g.grid_id)
			                                             AND g.grid_id = e.access_type_id)  
			                                AND ((e.access_level > 0
			                                       OR e.access_for=4)
			                                     OR  
			                                      (a.id = e.access_type_id
			                                         AND e.access_type = 1))
			                                 AND a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"';
				$this->_result_count = $this->_getListCount( $this->_query );
				$this->_result = $this->_getList( $this->_query );			
				for($i=0;$i<$this->_result_count;$i++)
				{
					$no_access_override_list.=',';
					$no_access_override_list.=$this->_result[$i]->id;
	
				}
		    }
		    


		}


		if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
		{
			$this->_query = 'SELECT   DISTINCT
		                          a.id,
		                          a.select_type,
		                          a.primary_key_column,
		                          a.grid_reference_id,
		                          a.ordering, 
		                          a.grid_application_name, 
		                          a.renderTo,
		                          a.title, 
		                          a.frame,
		                          a.print,
		                          a.number_width,
		                          a.number_header, 
		                          a.height, 
		                          a.width, 
		                          a.stripe_rows,
		                          a.enable_row_numbers,
		                          a.enableColumnMove,
		                          a.enableColumnResize,
		                          a.columnLines,
		                          a.enableRowEditor,
		                          a.enableGroupBy,
		                          a.enableGroupBySummary,
		                          a.groupByField,
		                          a.hideGroupedColumn,
		                          a.showGroupName,
		                          a.startCollapsed,
		                          a.enableSortBy, 
		                          a.sortByField,
		                          a.sortByDirection,
		                          a.enable_paging,
		                          a.paging_records,
		                          a.tabtip,
		                          a.cls,
		                          a.ctCls,
		                          b.current_document_id,
		                          b.previous_document_id1, 
		                          c.document_title
		                   FROM #__jgrid_grids a, 
		                        #__jgrid_current_user_grid_document b,
		                        #__jgrid_document c,
		                        #__jgrid_columngrid d
		                   WHERE a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"
		                   AND   a.id = b.grid_id
		                   AND   a.id = d.grid_id
		                   AND   c.id = b.current_document_id
		                   AND   b.userid = ' . $user->id .'
		                   AND   b.session_id = '.$temp_session_id.'		                       
                           AND   (a.id IN ('.$no_access_override_list.')
                           		   OR '.$admin_user.' > 0 		                       
                                   OR     0 = (SELECT count(1) 
		                                FROM #__jgrid_security e, 
		                                     #__jgrid_role_userlist f,
		                                     #__jgrid_user_type_defaults g,
		                                     #__usergroups h,
		                                     #__user_usergroup_map i
		                                WHERE ((e.access_for = 1 
		                                         AND 
		                                         e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.')
		                                       OR
		                                       (e.access_for=3
		                                          AND e.access_for_id = g.id
		                                          AND ((g.usertype_name = h.title
		                                                 AND i.user_id = '.$user->id.'
		                                                 AND h.id=i.group_id)
		                                               OR (e.access_for_id = 9 AND '.$user->id.' = 0))
		                                              )
		                                       )
		                                 AND e.access_level = 0
		                                 AND 0 = ' .$global_grid_rule_override . '
		                                 AND '.$admin_user.' = 0
		                                 AND ((a.id = e.access_type_id
		                                 		OR e.access_type_id = -1)
		                                      AND e.access_type = 1))
		                        )                  
                           ORDER BY a.ordering';
			//SELECT DISTINCT a.id, a.grid_reference_id, a.ordering, a.grid_application_name, a.renderTo, a.title, a.frame, a.print, a.height, a.width, a.stripe_rows, a.enable_row_numbers, a.enableColumnMove, a.enableColumnResize, a.columnLines, a.enableRowEditor, a.enableGroupBy, a.groupByField, a.sortByField, a.sortByDirection, a.enable_paging, a.paging_records, a.tabtip, b.current_document_id, b.previous_document_id1, c.document_title FROM `jos_jgrid_grids` a, `jos_jgrid_current_user_grid_document` b, `jos_jgrid_document` c, `jos_jgrid_columngrid` d WHERE a.grid_application_name = "com_jgrid" AND a.id = b.grid_id AND a.id = d.grid_id AND c.id = b.current_document_id AND b.userid = 42 AND b.session_id = "9e6d9012665a2565bc5233344a721968" AND 0 = (SELECT count(1) FROM `jos_jgrid_security` e, `jos_jgrid_role_userlist` f, `jos_jgrid_user_type_defaults` g, `jos_usergroups` h, `jos_user_usergroup_map` i WHERE ((e.access_for = 1 AND e.access_for_id = 42) OR (e.access_for=2 AND e.access_for_id = f.role_id AND f.userid =42) OR (e.access_for=3 AND e.access_type_id NOT IN (0) AND e.access_for_id = g.id AND g.usertype_name = h.title AND i.user_id = 42 AND h.id=i.group_id)) AND e.access_level = 0 AND (a.id = e.access_type_id AND e.access_type = 1)) ORDER BY a.ordering

//			JError::raiseError(1002,$this->_query);
//			return;
		}
		else
		{
			$this->_query = 'SELECT   DISTINCT
		                          a.id,
		                          a.select_type,
		                          a.primary_key_column,
		                          a.grid_reference_id,
		                          a.ordering, 
		                          a.grid_application_name, 
		                          a.renderTo,
		                          a.title, 
		                          a.frame,
		                          a.print,
		                          a.number_width,
		                          a.number_header,  
		                          a.height, 
		                          a.width, 
		                          a.stripe_rows,
		                          a.enable_row_numbers,
		                          a.enableColumnMove,
		                          a.enableColumnResize,
		                          a.columnLines,
		                          a.enableRowEditor,
		                          a.enableGroupBy,
		                          a.enableGroupBySummary,
		                          a.groupByField,
		                          a.groupDir,
		                          a.hideGroupedColumn,
		                          a.showGroupName,
		                          a.startCollapsed,
		                          a.enableSortBy, 
		                          a.sortByField,
		                          a.sortByDirection,
		                          a.enable_paging,
		                          a.paging_records,
		                          a.tabtip,
		                          a.cls,
		                          a.ctCls,		                          
		                          b.current_document_id,
		                          b.previous_document_id1, 
		                          c.document_title
		                   FROM #__jgrid_grids a, 
		                        #__jgrid_current_user_grid_document b,
		                        #__jgrid_document c,
		                        #__jgrid_columngrid d
		                   WHERE a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"
		                   AND   a.id = b.grid_id
		                   AND   a.id = d.grid_id
		                   AND   c.id = b.current_document_id
		                   AND   b.userid = ' . $user->id .'
		                   AND   b.session_id = '.$temp_session_id.'
		                   AND   (a.id IN ('.$no_access_override_list.')
		                   		   OR '.$admin_user.' > 0 		                       
                                   OR   0 = (SELECT count(1) 
		                                FROM #__jgrid_security e, 
		                                     #__jgrid_role_userlist f,
		                                     #__jgrid_user_type_defaults g
		                                WHERE ((e.access_for = 1 
		                                         AND 
		                                         e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.')
		                                       OR
		                                       (e.access_for=3
		                                          AND (e.access_for_id = g.id
		                                                OR 
		                                               (e.access_for_id = 1
		                                                  AND '.$user->id.' = 0))
		                                        )
		                                      )
		                                 AND e.access_level = 0
		                                 AND 0 = ' .$global_grid_rule_override . '
		                                 AND '.$admin_user.' = 0
		                                 AND ((a.id = e.access_type_id
		                                 		OR e.access_type_id = -1)
		                                      AND e.access_type = 1))
		                        )                  
                           ORDER BY a.ordering';
		}
	//JError::raiseError(1001, JText::_('sql'.$this->_query));
	//return;

		$this->_data = $this->_getList( $this->_query );

		// replace sort by and group by fields with column ID's
		//		for($j=0, $n=count($this->_data) ; $j<$n ;$j++)
		//		{
		//
		//			if($this->_data[$j]->enableGroupBy!=0)
		//			{
		//				// replace GroupByField With TypeColumnID
		//				$this->_query =   'SELECT DISTINCT
		//	                          CONCAT(c.data_type,
		//	                               b.column_id) AS "groupByField"
		//                         FROM  #__jgrid_grids a,
		//                               #__jgrid_columngrid b,
		//                               #__jgrid_columns c
		//                         WHERE a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"
		//                         AND   a.id = b.grid_id
		//                         AND   c.id = b.column_id
		//                         AND   c.dataindex = "'.$this->_data[$j]->groupByField.'"';
		//
		//				$db->setQuery($this->_query);
		//				$this->_data[$j]->groupByField=$db->loadResult();
		//			}
		//			if($this->_data[$j]->enableSortBy!=0)
		//			{
		//				// replace sortByField With TypeColumnID
		//				$this->_query =   'SELECT DISTINCT
		//	                          CONCAT(c.data_type,
		//	                               b.column_id) AS "groupByField"
		//                         FROM  #__jgrid_grids a,
		//                               #__jgrid_columngrid b,
		//                               #__jgrid_columns c
		//                         WHERE a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"
		//                         AND   a.id = b.grid_id
		//                         AND   c.id = b.column_id
		//                         AND   c.dataindex = "'.$this->_data[$j]->sortByField.'"';
		//				$db->setQuery($this->_query);
		//				$this->_data[$j]->sortByField=$db->loadResult();
		//			}
		//		}



		// select grids data transversing the linked list vs order by ordering column.
		//$this->_query = 'SELECT   DISTINCT
		//		                          a.id,
		//		                          a.grid_reference_id,
		//		                          a.ordering,
		//		                          a.grid_application_name,
		//		                          a.renderTo,
		//		                          a.title,
		//		                          a.frame,
		//                                a.print,
		//		                          a.height,
		//		                          a.width,
		//		                          a.stripe_rows,
		//		                          a.enable_row_numbers,
		//		                          a.enableColumnMove,
		//		                          a.enableColumnResize,
		//		                          a.columnLines,
		//		                          a.enableRowEditor,
		//		                          a.enableGroupBy,
		//		                          a.groupByField,
		//		                          a.sortByField,
		//		                          a.sortByDirection,
		//		                          a.enable_paging,
		//		                          a.paging_records,
		//		                          a.tabtip,
		//		                          b.current_document_id,
		//		                          b.previous_document_id1,
		//		                          c.document_title
		//		                   FROM (
		//		                          SELECT @r AS _parent,
		//                                            @r :=
		//                                            (
		//                                             SELECT  id
		//                                             FROM    #__jgrid_grids
		//                                             WHERE   parent_id = _parent
		//                                            ) AS id
		//	                              FROM  (
		//                                     SELECT  @r := 0
		//                                     ) vars,
		//                                     #__jgrid_grids
		//                                     WHERE @r IS NOT NULL
		//                                     )q
		//		          JOIN #__jgrid_grids a
		//                  ON a.id = q.id
		//                      AND a.grid_application_name = "'..JRequest::getVar('jgrid_application_name').'"
		//                  JOIN #__jgrid_columngrid d
		//                  ON a.id = d.grid_id
		//                  LEFT JOIN #__jgrid_current_user_grid_document b
		//                  ON a.id = b.grid_id
		//	                  AND b.userid = '.$user->id.'
		//	              LEFT JOIN #__jgrid_document c
		//		          ON c.id = b.current_document_id';
		//		$this->_data = $this->_getList( $this->_query );
//	JError::raiseError(1001, print_r($this->_data));
//	return;
		if($this->_data) return $this->_data;
		else return false;
	}
	/**
	 * Retrieves the jgrid data
	 * @return array Array of objects containing the data from the database
	 */
	function getColumndata()
	{
		$db =JFactory::getDBO();
		$user=JFactory::getUser();
		// check for joomla version
		$version = new JVersion;
		$joomla = $version->getShortVersion();
		$no_access_override_list='0';
		$global_grid_rule_override = 0;

		//	JError::raiseError(1001, JText::_('sql'.$user->id));
		//	return;


		// check for administrative type users
		$admin_user = check_for_backend_admin_access_rights();

		if(!$admin_user)
		{
		  $admin_user = 0;
		  	// check for all grid override for global grid rules applying to this user 
			$this->_query='SELECT count(1)
		                                FROM #__jgrid_grids a,
		                                     #__jgrid_security e, 
		                                     #__jgrid_role_userlist f
		                                WHERE ((e.access_for = 1 
		                                         AND e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2 
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.')
		                                        OR (e.access_for=4))
		                                 AND e.access_type_id = -1   
		                                 AND e.access_level > 0
		                                 AND a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"';
			$db->setQuery($this->_query);
			$global_grid_rule_override = $db->loadResult();
			$no_access_override_list = '0';
			if(!$global_grid_rule_override)
		    {
		    	$global_grid_rule_override = 0;
				// check for overrides for no access commands for specific roles or users
				$this->_query='SELECT DISTINCT a.id
			                                FROM #__jgrid_grids a,
			                                     #__jgrid_security e, 
			                                     #__jgrid_role_userlist f,
			                                     #__jgrid_document g
			                                WHERE ((e.access_for = 1 
			                                         AND e.access_for_id = '.$user->id.')
			                                       OR
			                                       (e.access_for=2 
			                                          AND e.access_for_id = f.role_id
			                                          AND f.userid ='.$user->id.')
			                                        OR (e.access_for=4))
			                                 AND ((a.id = e.access_type_id
			                                        OR e.access_type_id = -1)
			                                       OR (a.id = g.grid_id)
			                                             AND g.grid_id = e.access_type_id)  
			                                AND ((e.access_level > 0
			                                       OR e.access_for=4)
			                                     OR  
			                                      (a.id = e.access_type_id
			                                         AND e.access_type = 1))
			                                 AND a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"';
				$this->_result_count = $this->_getListCount( $this->_query );
				$this->_result = $this->_getList( $this->_query );
				for($i=0;$i<$this->_result_count;$i++)
				{
					$no_access_override_list.=',';
					$no_access_override_list.=$this->_result[$i]->id;
	
				}
	
			}
		}


		if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
		{
			$this->_query =   'SELECT DISTINCT
		                          b.id,
		                          b.parent_id,
		                          a.id AS aid,
		                          b.grid_id,
		                          a.parent_id as aparent_id,
	                              b.column_id,
		                          b.column_type, 
	                              b.ordering,
	                              c.header,
	                        CONCAT(c.data_type,b.id) AS "dataindex", 
	                               c.editable, 
	                               c.width, 
	                               c.data_type,  
	                               c.ddefault,
	                               c.align,
	                               c.css,
	                               c.tooltip,
	                               c.email_subject,
	                               c.freeze_column,
	                               c.dfilter,
	                               c.validation_type,
	                               c.sortable,
	                               c.summarycolumn,
                                   c.summarytype,
                                   c.summaryprefix,
                                   c.summarypostfix,
                                   b.formula 	                              
                         FROM  #__jgrid_grids a, 
                               #__jgrid_columngrid b,
                               #__jgrid_columns c 
                         WHERE a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"
                         AND   a.id = b.grid_id 
                         AND   c.id = b.column_id
                         AND (a.id IN ('.$no_access_override_list.')
                         	   OR '.$admin_user.' > 0 
                               OR 0 = (SELECT count(1) AS w
		                           FROM #__jgrid_security g, 
		                                #__jgrid_role_userlist h,
		                                #__jgrid_user_type_defaults i,
		                                #__usergroups j,
		                                #__user_usergroup_map k
		                           WHERE ((g.access_for = 1 
		                                     AND 
		                                     g.access_for_id = '.$user->id.')
		                                  OR
		                                   (g.access_for=2
		                                      AND g.access_for_id = h.role_id
		                                      AND h.userid ='.$user->id.')
		                                   OR
		                                       (g.access_for=3
		                                          AND g.access_for_id = i.id
		                                          AND ((i.usertype_name = j.title
		                                                 AND k.user_id = '.$user->id.'
		                                                 AND j.id=k.group_id)
		                                                 OR ('.$user->id.' = 0))))
		                           AND g.access_level = 0
		                           AND 0 = ' .$global_grid_rule_override . ' 
		                           AND '.$admin_user.' = 0 
				                   AND ((g.access_type=1 
				                          AND (g.access_type_id=b.grid_id
				                                OR g.access_type_id = -1))				        
		                                 OR  (g.access_type=2
		                                       AND g.access_subtype_grid_id=b.grid_id
                                               AND g.access_subtype_column_id=b.column_id)))
                              )                          
                         ORDER BY a.ordering, 
                                  b.grid_id, 
                                  b.ordering';
			
			//JError::raiseError(1001, JText::_('sql'.$this->_query));
			//return;			
			
		}
		else
		{
			$this->_query =   'SELECT DISTINCT
		                          b.id,
		                          b.parent_id,
		                          a.id AS aid,
		                          b.grid_id,
		                          a.parent_id as aparent_id,
	                              b.column_id,
		                          b.column_type, 
	                              b.ordering,
	                              c.header,
	                        	  CONCAT(c.data_type,b.id) AS "dataindex", 
	                               c.editable, 
	                               c.width, 
	                               c.data_type,  
	                               c.ddefault,
	                               c.align,
	                               c.css,	                               
	                               c.tooltip,
	                               c.email_subject,
	                               c.freeze_column,	                               
	                               c.dfilter,
	                               c.validation_type,
	                               c.sortable,
	                               c.summarycolumn,
                                   c.summarytype,
                                   c.summaryprefix,
                                   c.summarypostfix,
                                   b.formula 	                              
                         FROM  #__jgrid_grids a, 
                               #__jgrid_columngrid b,
                               #__jgrid_columns c 
                         WHERE a.grid_application_name = "'.JRequest::getVar('jgrid_application_name').'"
                         AND   a.id = b.grid_id 
                         AND   c.id = b.column_id
                         AND (a.id IN ('.$no_access_override_list.')
                         	    OR '.$admin_user.' > 0 
                         		OR 0 = (SELECT count(1) AS w
		                           FROM #__jgrid_security g, 
		                                #__jgrid_role_userlist h,
		                                #__jgrid_user_type_defaults i
		                           WHERE ((g.access_for = 1 
		                                     AND 
		                                     g.access_for_id = '.$user->id.')
		                                  OR
		                                   (g.access_for=2
		                                      AND g.access_for_id = h.role_id
		                                      AND h.userid ='.$user->id.')
		                                   OR
		                                       (g.access_for=3
		                                          AND g.access_for_id = i.id
		                                          AND ('.$user->id.' = 0)))
		                           AND g.access_level = 0
		                           AND 0 = ' .$global_grid_rule_override . '
		                           AND '.$admin_user.' = 0  
				                   AND ((g.access_type=1 
				                          AND (g.access_type_id=b.grid_id
				                            OR g.access_type_id = -1))				        
		                                 OR  (g.access_type=2
		                                       AND g.access_subtype_grid_id=b.grid_id
                                               AND g.access_subtype_column_id=b.column_id))))                          
                         ORDER BY a.ordering, 
                                  b.grid_id, 
                                  b.ordering';
		}
		$this->_data = $this->_getList($this->_query);
		// Select Transfersing the Grids table linked list and the columngrid linked lists in the recovery order rather than by using the order by on ordering columns
		//$this->_query =   'SELECT DISTINCT
		//		                          b.id,
		//		                          b.parent_id,
		//		                          a.id AS aid,
		//		                          b.grid_id,
		//		                          a.parent_id as aparent_id,
		//	                              b.column_id,
		//	                              b.ordering,
		//	                              c.header,
		//	                        CONCAT(c.data_type,
		//	                               b.column_id) AS "dataindex",
		//	                               c.editable,
		//	                               c.width,
		//	                               c.data_type,
		//	                               c.ddefault,
		//	                              c.tooltip
		//                         FROM    (
		//                         SELECT  @a AS _a,
		//                                 @b AS _b,
		//                                 @b :=
		//                                 (
		//                                 SELECT  id
		//                                 FROM    #__jgrid_columngrid b
		//                                 WHERE   b.grid_id = _a
		//                                     AND b.parent_id = _b
		//                                 UNION ALL
		//                                 SELECT  b.id
		//                                 FROM    #__jgrid_grids a
		//                                 JOIN    #__jgrid_columngrid b
		//                                 ON      b.grid_id = a.id
		//                                 WHERE   b.parent_id = 0
		//                                   AND a.parent_id = _a
		//                                 LIMIT 1
		//                                 ) AS bid,
		//                                 @b AS _nb,
		//                                 @a :=
		//                                 (
		//                                 SELECT  grid_id
		//                                 FROM    #__jgrid_columngrid b
		//                                 WHERE   b.id = _nb
		//                                 ) AS aid
		//                                  FROM    (
		//                                          SELECT  @a := a.id, @b := 0
		//                                          FROM    #__jgrid_grids a
		//                                          WHERE   parent_id = 0
		//                                          ) vars,
		//                                         #__jgrid_grids a
		//                                 JOIN    #__jgrid_columngrid b
		//                                 ON      b.grid_id = a.id
		//                                 ) q
		//                     JOIN    #__jgrid_grids a
		//                     ON      a.id = aid
		//                       AND a.grid_application_name = "'..JRequest::getVar('jgrid_application_name').'"
		//                     JOIN    #__jgrid_columngrid b
		//                     ON      b.id = bid
		//                       AND   a.id = b.grid_id
		//                     LEFT JOIN #__jgrid_columns c
		//	                 ON c.id = b.column_id';


		// get column data  loop column data for each grid and also store number of columns for each grid
		// find the number of columns for each grid

		$current_grid = $this->_data[0]->grid_id;
		$number_of_grid_columns[$current_grid] = 0;
		for ($i=0, $j=0 , $n=count( $this->_data ); $i < $n; $i++)	{
			if($this->_data[$i]->grid_id == $current_grid) $number_of_grid_columns[$current_grid]++ ;
			else
			{
				$current_grid = $this->_data[$i]->grid_id;
				$j++;
				$number_of_grid_columns[$current_grid]=1;
			}
		}
		// save number of grid columns in session variable
		$session =JFactory::getSession();
		$session->set('number_of_grid_columns', $number_of_grid_columns );
		if($this->_data) return $this->_data;
		else return false;
	}


	/**
	 * Updates the   "user grids" data being edited
	 * @return integer return true if row updated or false if update failed.
	 */
	function updateGridRow()
	{
		$db =JFactory::getDBO();
		$user=JFactory::getUser();

		$row_data_array=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		
	//echo 'sql'.print_r($row_data_array);
		// test to see if one row or multiple rows are to be updated
		$json_string = JRequest::getVar('rows','','','STRING');
		if($json_string[0]=='[')
		{
			//$array_dimensions = array_depth($row_data_array);
		 // $array_dimensions = array_depth($row_data_array);
		 //echo 'sql1 '.$array_dimensions.' slq2 '. print_r($row_data_array);
			$array_dimensions = count($row_data_array);
			$multi_dimensions= true;
		}
		else
		{
			$array_dimensions = 1;
			$multi_dimensions= false;
		}

		$grid_id = JRequest::getVar('grid_id','','','INTEGER');
		
		// Find applicatin id for this grid_id
    	$query = 'SELECT b.id, a.select_type
		      	  FROM #__jgrid_grids a,
		      	       #__jgrid_applications b		                        
		          WHERE a.id = '.$grid_id.'
		            AND a.grid_application_name = b.grid_application_name';
		$db->setQuery($query);
		$grids_data = $db->loadObjectList();
		
		$access_rule_application_id = $grids_data[0]->id;
		$select_type = $grids_data[0]->select_type;
		
		$access_control_column=0;
		$remove_access_control_column=0;
		$current_document_id=0;
		$row_color_update=0;
		// check for joomla version
		$version = new JVersion;
		$joomla = $version->getShortVersion();

		//check to see if current document exists, if not update to the default document, always reset guest to default
		$session =JFactory::getSession();
		$temp_session_id = '"'.$session->getId().'"';

		// get current document ID
		$this->_query = 'SELECT g.current_document_id
	   		             FROM #__jgrid_current_user_grid_document g
	   		             WHERE g.userid = ' . $user->id .'
	                       AND g.grid_id = '.$grid_id.'
	                       AND g.session_id = '.$temp_session_id.'';
		$db->setQuery($this->_query);
		$current_document_id=$db->loadResult();

		$not_default = check_defaut_values_apply($grid_id, $current_document_id);


		list($admin_user,$access_control,$remove_access_control,$document_security_level) = check_access_control($grid_id,$current_document_id,2);
		//echo 'sql'.print_r($row_data_array).sql.count($row_data_array);
		for($j=0;$j<$array_dimensions;$j++)
		{
			//	    echo 'sql'.$array_dimensions;
			if($multi_dimensions==true)
			{
				$row_data=$row_data_array[$j];
			}
			else
			{
				$row_data=$row_data_array;
			}
			$row_id=$row_data["id"];
			if($row_id==0) // if 0 row in blank grid then add row and get new row id
			{
				//check to see if rows exist and if they do add to last row of list if they don't add as first row
				// find last row number and its ordering
				$query = 'SELECT id, max(ordering)
			              FROM #__jgrid_rows
			              WHERE grid_id = '.$grid_id.'
			                AND document_id = '.$current_document_id.'
			                AND ordering != 999999
			                GROUP BY ordering DESC
			                LIMIT 1';
				$db->setQuery($query);
				if($selected_row_number = $db->loadResult())
				{
					$row_insert_position = ADD_ROW_BELOW;
				}
				else
				{
					$row_insert_position = FIRSTROW;
					$selected_row_number = 0;
				}
					
					$new_row_data	= createGridRow('#__jgrid_rows',$grid_id,$row_insert_position,$selected_row_number);
					$row_id= $new_row_data["id"];	
			}

			//find row access_id
			if($select_type<2)
			{	
				$query = 'SELECT row_access_id
		                   FROM #__jgrid_rows 
		                   WHERE id = '.$row_id;
			}
			else 
			{ // sql table type
				$query = 'SELECT row_access_id
		                   FROM #__jgrid_data 
		                   WHERE primary_key_value = "'.$row_id.'"
			               	AND document_id = '.$current_document_id.'
			             	AND grid_id = '.JRequest::getVar('grid_id','','','INTEGER');
			}

			$db->setQuery($query);
			$rslvl_id = $db->loadResult();
			//	echo 'sql'.$rslvl_id;
			if(!$rslvl_id)
			{
				$rslvl_id = 'D';
			}


//echo 'sql '.print_r($row_data);
//return;

			//Update cell at selected row and column with proper data type
			foreach( $row_data as $key => $value)
			{
				$access_control_column=0;
				$remove_access_control_column=0;
				$creator_column_security_level=0;
				$creator_document_security_level=0;
				$creator_access_control=0;
				// check for user access rights for each row updated if creator type
				if($document_security_level<5)
				{
					//find document security types for creator lowest is most restrictive eg creator editable and viewable only to highest creator role editable public viewable
					$query = 'SELECT min(e.access_for_id)
		                   FROM #__jgrid_security e, 
		                        #__jgrid_role_userlist f
		                   WHERE e.access_for=4
		                   	 AND e.access_rule_application_id = '. $access_rule_application_id. '  
		                     AND ((e.access_type = 1                     
		                          AND (e.access_subtype_grid_id = '.$grid_id.'
		                       			OR
		                       		e.access_subtype_grid_id = -1)) 
		                        OR (e.access_type = 3                     
		                          AND e.access_subtype_document_id = '.$current_document_id.') 		                        
		                        )';

					$db->setQuery($query);
					$creator_document_security_level = $db->loadResult();
					// check for column level creator security
					if($creator_document_security_level==0)
					{
						$query = 'SELECT min(e.access_for_id)
		                   FROM #__jgrid_security e, 
		                        #__jgrid_role_userlist f
		                   WHERE e.access_for=4  
		                     AND ((e.access_type = 2                     
		                          AND e.access_subtype_grid_id = '.$grid_id.'
		                          AND e.access_subtype_column_id = "' . substr($key,1) .'")
		                        OR (e.access_type = 4                     
		                          AND e.access_subtype_document_id = '.$current_document_id.'
		                          AND e.access_subtype_column_id = "' . substr($key,1) .'") 		                        
		                        )';
						$db->setQuery($query);
						$creator_document_security_level = $db->loadResult();

					}

					if($creator_document_security_level!=0)
					{
						switch ($creator_document_security_level)
						{
							// CREATOR_PRIVATE
							case '1':
								// CREATOR_ROLE_VIEWABLE
							case '3':
								// REGISTERED_VIEWABLE Creator Editable
							case '4':
								// PUblic_VIEWABLE Creator Editable
							case '6':
								// creator view only
							case '8':	
								// find if min / most restrictive creator role is for column or overall document
								$query = 'SELECT count(1)
		                              FROM #__jgrid_rows d 
		                              WHERE d.creator_userid = '.$user->id.'
		                                AND d.id = '.$row_id;
								$db->setQuery($query);
								$creator_access_control = $db->loadResult();
								break;
								// CREATOR_ROLE_PRIVATE
							case '2':
								// REGISTERED_VIEWABLE Role Editable
							case '5':
								// PUBLIC_VIEWABLE Role Editable
							case '7':
								// crole view only
							case '9':	
							
								//find current user role
								$query = 'SELECT role_id
		                              FROM #__jgrid_role_userlist a 
		                              WHERE a.userid = '.$user->id;
								$db->setQuery($query);
								$user_role_id = $db->loadResult();

								$query = 'SELECT count(1)
		                              FROM #__jgrid_rows d,
		                                   #__jgrid_role_userlist a 
		                              WHERE d.creator_userid = a.userid
		                                AND a.role_id = '.$user_role_id .'
		                                AND d.id = '.$row_id;
								$db->setQuery($query);
								$creator_access_control = $db->loadResult();

								break;


						}
						if($creator_access_control !=0)
						{
							$access_control=$creator_access_control;
						}

					}
				}


				// check for user access rights for each column updated
				if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
				{
					$this->_query = 'SELECT count(1) AS q
		                 FROM #__jgrid_security e, 
		                      #__jgrid_role_userlist f,
		                      #__jgrid_user_type_defaults i,
		                      #__usergroups j,
		                      #__user_usergroup_map k
		                 WHERE ((e.access_for = 1 
		                          AND 
		                         e.access_for_id = '.$user->id.')
		                          OR
		                         (e.access_for=2
		                              AND e.access_for_id = f.role_id
		                              AND f.userid ='.$user->id.')
		                             OR
		                           (e.access_for=3
		                             AND e.access_for_id = i.id
		                             AND 0 = '.$not_default.'
		                             AND i.usertype_name = j.title
		                             AND k.user_id = '.$user->id.'
		                             AND (j.id=k.group_id		                                        
		                               OR (i.usertype_name = "Public"
		                                                 AND '.$user->id.' = 0))))
		                 AND e.access_level > 2
		                 AND ((e.access_type = 2 
		                       AND e.access_type_id = '.$grid_id.')
		                      OR
		                      (e.access_type =  4
		                       AND e.access_type_id = '.$current_document_id.'))';
				}
				else
				{
					$this->_query = 'SELECT count(1) AS q
		                 FROM #__jgrid_security e, 
		                      #__jgrid_role_userlist f,
		                      #__jgrid_user_type_defaults i
		                 WHERE ((e.access_for = 1 
		                          AND 
		                         e.access_for_id = '.$user->id.')
		                          OR
		                         (e.access_for=2
		                              AND e.access_for_id = f.role_id
		                              AND f.userid ='.$user->id.')
		                             OR
		                           (e.access_for=3
		                             AND e.access_for_id = i.id
		                             AND 0 = '.$not_default.'
		                             AND (i.usertype_name ="'.$user->usertype.'"	
		                               OR (i.usertype_name = "Guest"
		                                    AND '.$user->id.' = 0))))
		                 AND e.access_level > 2
		                 AND ((e.access_type = 2 
		                       AND e.access_type_id = '.$grid_id.')
		                      OR
		                      (e.access_type =  4
		                       AND e.access_type_id = '.$current_document_id.'))';
				}
				$db->setQuery($this->_query);
				$access_control_column=$db->loadResult();


				// check for user access overide to take away rights for each column updated
				if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
				{
					$this->_query = 'SELECT count(1) AS q
		                 FROM #__jgrid_security e, 
		                      #__jgrid_role_userlist f,
		                      #__jgrid_user_type_defaults i,
		                      #__usergroups j,
		                      #__user_usergroup_map k
		                 WHERE ((e.access_for = 1 
		                          AND 
		                         e.access_for_id = '.$user->id.')
		                          OR
		                         (e.access_for=2
		                              AND e.access_for_id = f.role_id
		                              AND f.userid ='.$user->id.')
		                             OR
		                           (e.access_for=3
		                             AND e.access_for_id = i.id
		                             AND 0 = '.$not_default.'
		                             AND i.usertype_name = j.title
		                             AND k.user_id = '.$user->id.'
		                             AND (j.id=k.group_id		                           
		                               OR (i.usertype_name = "Public"
		                                    AND '.$user->id.' = 0))))
		                 AND e.access_level > 2
		                 AND ((e.access_type = 2 
		                       AND e.access_type_id = '.$grid_id.')
		                      OR
		                      (e.access_type =  4
		                       AND e.access_type_id = '.$current_document_id.'))';
				}
				else
				{
					$this->_query = 'SELECT count(1) AS q
		                 FROM #__jgrid_security e,
		                      #__jgrid_role_userlist f,
		                      #__jgrid_user_type_defaults i
		                 WHERE ((e.access_for = 1 
		                          AND 
		                         e.access_for_id = '.$user->id.')
		                          OR
		                         (e.access_for=2
		                              AND e.access_for_id = f.role_id
		                              AND f.userid ='.$user->id.')
		                             OR
		                           (e.access_for=3
		                             AND e.access_for_id = i.id
		                             AND 0 = '.$not_default.'
		                             AND (i.usertype_name ="'.$user->usertype.'"	
		                               OR (i.usertype_name = "Guest"
		                                    AND '.$user->id.' = 0))))
		                 AND e.access_level =0
		                 AND ((e.access_type = 2
		                           AND e.access_subtype_grid_id = '.$grid_id.'
		                           AND e.access_subtype_column_id = "' . substr($key,1) .'")
		                         OR (e.access_type = 4
		                           AND e.access_subtype_document_id = '.$current_document_id.' 
		                           AND e.access_subtype_column_id = "' . substr($key,1) .'"))';	
				}
				$db->setQuery($this->_query);
				$remove_access_control_column=$db->loadResult();
				
				if($key!='id'&&$key!='rslvl_id')
				{
					if($select_type<2)
					{
						// Check That cell exists and if not create it

						$this->_query = 'SELECT id
			   		             FROM #__jgrid_columndata a
				                 WHERE columngrid_id = ' . substr($key,1) .'
				                   AND row_number = ' . $row_id .'
				                   AND document_id = '.$current_document_id;
						$db->setQuery($this->_query);
						$cell_id=$db->loadResult();
						if(!$cell_id)
						{
								// Insert cell records into the columndata row
								$query = 'INSERT into #__jgrid_columndata (document_id,
				                                       column_id,
				                                       columngrid_id,
				                                       column_header, 
				                                       userid, 
				                                       row_number,
				                                       string_data,
		                                               int_data,
		                                               float_data,
		                                               boolean_data,
		                                               date_data)
		       	                 SELECT  '.$current_document_id.',
		       	                          a.id,
		       	                          b.id, 
		       	                          a.header,
		       	                          "' . $user->id . '",
		       	                          "' . $row_id .'",
		       	                          IF((a.data_type="T" OR a.data_type="L") ,a.ddefault,NULL),
		       	                          CASE a.data_type WHEN "I" THEN a.ddefault WHEN "R" THEN "' . $row_id .'" ELSE NULL END,
		       	                          IF(a.data_type="F",a.ddefault,NULL),
		       	                          IF(a.data_type="B",a.ddefault,NULL),
		       	                          IF(a.data_type="D",a.ddefault,NULL)
		                        FROM  #__jgrid_columns a, 
		                              #__jgrid_columngrid b
			                    WHERE b.grid_id = '.$grid_id.'
			                       AND a.id = b.column_id';
			
								$db->setQuery($query);
								$_result = $db->query();
						}
						
						
						switch (substr($key,0,1))
						{
								// Integer
							case 'I':
								$this->_query = 'UPDATE  #__jgrid_columndata
		   		                      SET int_data = "' . $value .'" 
		                              WHERE columngrid_id = "' . substr($key,1) .'" 
		                                  AND row_number = ' . $row_id .'
		                                 AND document_id = '.$current_document_id.'
		                                 AND ('.$remove_access_control.'=0
		                                       AND '.$remove_access_control_column.'=0)
			                             AND ('.$access_control.'>0                                       
							                      OR '.$access_control_column.'>0)';   
								break;
								// Date
							case 'D':
								// clean up date data
								//$value = substr($value,0,15);
								//if(strstr($value,'T'))
								//{
								//  $value = substr($value,0,10);
								//	}
								//	$dateinteger = strtotime($value);
								//	$value = date('Y-m-d',$dateinteger);
	
	
								//echo 'sql1 '.$value;
								//echo 'sql2 '. count($tab);
								//                                if(count($tab)==1)
								//                                {
								//                                	$temp_date = $value; //for date format 2011-12-04T00:00:00
								//                                }
								//                                else if(count($tab)==6)
								//                                {
								//                                     $temp_date = $tab[5]."-".$tab[1]."-".$tab[2];   //for date format Thu Jun 3 00:00:00 EDT 2010
								//                                }
								//                                else if(count($tab)==9)
								//                                {
								//                                	$temp_date = $tab[3]."-".$tab[1]."-".$tab[2]; // for date format Fri Feb 03 2012 00:00:00 GMT-0500 (Eastern Standard Time)",'%d-%m-%Y'
								//                                }
								//                                else
								//                                {
								//                                	$temp_date = $value; // default
								//                                }
	
								date_default_timezone_set('UTC');
								$value_date = date('Y-m-d', strtotime($value));
								//echo 'sql5'	.$value_date ;
								// if strtotime fails look for 1970-01-01 default and try some other conversions
								if($value_date=='1970-01-01'||$value_date==false||$value_date==-1) // failure results based on PHP Version
								{
									$tab = explode (" ", $value); // look for this format Fri Feb 03 2012 00:00:00 GMT-0500 (Eastern Standard Time)",'%d-%m-%Y'
									// or Thu Jun 3 00:00:00 EDT 2010
									if(count($tab)==6)
									{
										$temp_date = $tab[5]."-".$tab[1]."-".$tab[2];   //for date format Thu Jun 3 00:00:00 EDT 2010
									}
									else if(count($tab)==9)
									{
										$temp_date = $tab[3]."-".$tab[1]."-".$tab[2]; // for date format Fri Feb 03 2012 00:00:00 GMT-0500 (Eastern Standard Time)",'%d-%m-%Y'
									}
									else
									{
										$temp_date = $value; // default
									}
									$temp_date = strtotime($temp_date);
									$value_date = ($temp_date === false) ? '0000-00-00' : date('Y-m-d', $temp_date);
								}
	
	
								//echo 'sql'.$value_date;
								$this->_query = 'UPDATE  #__jgrid_columndata SET date_data = STR_TO_DATE("'.$value_date.'","%Y-%m-%d")
		   		                      WHERE columngrid_id = "' . substr($key,1) .'" 
		   		                          AND row_number = ' . $row_id .' 
		                                 AND document_id = '.$current_document_id.'
		                                 AND ('.$remove_access_control.'=0
		                                       AND '.$remove_access_control_column.'=0)
			                             AND ('.$access_control.'>0                                       
							                      OR '.$access_control_column.'>0)'; 
								//echo 'sql'.$this->_query;
								break;
								// Boolean
							case 'B':
								$this->_query = 'UPDATE  #__jgrid_columndata SET boolean_data = "' . ($value ? '1' : '0') .'"
		   		                      WHERE columngrid_id = "' . substr($key,1) .	'" 
		                                  AND row_number = ' . $row_id .' 
		                                 AND document_id = '.$current_document_id.'
		                                 AND ('.$remove_access_control.'=0
		                                       AND '.$remove_access_control_column.'=0)
			                             AND ('.$access_control.'>0                                       
							                      OR '.$access_control_column.'>0)'; 
								break;
								// Float
							case 'F':
								$this->_query = 'UPDATE  #__jgrid_columndata SET float_data = "' . $value .'"
		   		                      WHERE columngrid_id = "' . substr($key,1) .'" 
		   		                          AND row_number = ' . $row_id .' 
		                                 AND document_id = '.$current_document_id.'
		                                 AND ('.$remove_access_control.'=0
		                                       AND '.$remove_access_control_column.'=0)
			                             AND ('.$access_control.'>0                                       
							                      OR '.$access_control_column.'>0)'; 
								break;
								//list
							case 'L':
	
								//search for color of updated value
								$this->_query = 'SELECT listboxvaluerowcolor
				                 FROM #__jgrid_column_list_field_values a,
				                 	  #__jgrid_columngrid b
				                 WHERE b.id = "' . substr($key,1) .'"
				                 	AND a.column_id = b.column_id
				                   AND a.listboxvalues = "' . $value .'"
				                   LIMIT 1';		                      
								$this->_db->setQuery($this->_query);
								$listbox_color_value = $this->_db->loadResult();
	
								$this->_query = 'UPDATE  #__jgrid_columndata
							                SET string_data = "' . addslashes($value) .'",					
							                    listboxvaluerowcolor = "'.$listbox_color_value.'"						                
	                                     WHERE columngrid_id = "' . substr($key,1) .'"
		                                 AND row_number = ' . $row_id .' 
		                                 AND document_id = '.$current_document_id.'
		                                 AND ('.$remove_access_control.'=0
		                                       AND '.$remove_access_control_column.'=0)
			                             AND ('.$access_control.'>0                                       
							                      OR '.$access_control_column.'>0)';						
								break;
								//Row ID
							case 'R':
								$this->_query = 'UPDATE  #__jgrid_columndata
							                SET string_data = "' . $value .'"						                
	                                     WHERE columngrid_id = "' . substr($key,1) .'"
		                                 AND row_number = ' . $row_id .' 
		                                 AND document_id = '.$current_document_id.'
		                                 AND ('.$remove_access_control.'=0
		                                       AND '.$remove_access_control_column.'=0)
			                             AND ('.$access_control.'>0                                       
							                      OR '.$access_control_column.'>0)';						
								break;
								//Picture
							case 'P':
								$this->_query = 'UPDATE  #__jgrid_columndata SET string_data = "' . $value .'"
	                                  WHERE columngrid_id = "' . substr($key,1) .'"
		                                 AND row_number = ' . $row_id .' 
		                                 AND document_id = '.$current_document_id.'
		                                 AND ('.$remove_access_control.'=0
		                                       AND '.$remove_access_control_column.'=0)
			                             AND ('.$access_control.'>0                                       
							                      OR '.$access_control_column.'>0)'; 
								if(JRequest::getVar('delete_image','','','INTEGER')==1)
								{
									delete_images('C',
									JRequest::getVar('grid_id','','','INTEGER'),
									JRequest::getVar('document_id','','','INTEGER'),
									JRequest::getVar('column_id','','','INTEGER'),
									JRequest::getVar('row_id','','','INTEGER'));
								}
								break;
							//text
							case 'T':
								//URL
							case 'U':
								//EMail
							case 'E':								
								//Grid Sheet
							case 'S':
								//$this->_query = 'UPDATE  #__jgrid_columndata SET string_data = "' . mysqli_real_escape_string($value) .'"
								$this->_query = 'UPDATE  #__jgrid_columndata SET string_data = "' . addslashes($value) .'"
	                                  WHERE columngrid_id = "' . substr($key,1) .'"
		                                 AND row_number = ' . $row_id .' 
		                                 AND document_id = '.$current_document_id.'
		                                 AND ('.$remove_access_control.'=0
		                                       AND '.$remove_access_control_column.'=0)
			                             AND ('.$access_control.'>0                                       
							                      OR '.$access_control_column.'>0)'; 
								break;
						}
						$this->_db->setQuery($this->_query);
						$this->_result = $this->_db->query();
					}
					else // select_type is table
					{
											
						$this->_query = 'SELECT a.jgrid_data_column
										 FROM #__jgrid_columngrid a
										 WHERE a.id = ' . substr($key,1);
						$this->_db->setQuery($this->_query);
						$jgrid_data_column = $db->loadResult();
						// if no column exists assign one to cover upgrades from previous verion
						if(!$jgrid_data_column)
						{
							// find the next data column available
							$jgrid_data_column = getNextDataColumn($grid_id,$key[0]);
							$this->_query = 'UPDATE #__jgrid_columngrid  SET jgrid_data_column = "'.$jgrid_data_column.'"
											     WHERE id = ' . substr($key,1);
							$this->_db->setQuery($this->_query);
							$this->_result = $this->_db->query();
							
						}
						// check to see if row exists
						$this->_query = 'SELECT id
										 FROM #__jgrid_data a
										WHERE primary_key_value = '.$row_id.'
			                                 AND document_id = '.$current_document_id.'
			                                 AND grid_id = '.JRequest::getVar('grid_id','','','INTEGER');
							
						
						$this->_db->setQuery($this->_query);
						$jgrid_data_id = $db->loadResult();
						
						// add insert update
						if(($remove_access_control==0&&$remove_access_control_column==0)&&($access_control>0||$access_control_column>0))
						{
							
							if($jgrid_data_id)
							{	
								// escape data if string type
								if($jgrid_data_column[0] === 'T' || $jgrid_data_column[0] === 'L')
								{
									//$value = mysqli_real_escape_string($value);
									$value = addslashes($value);
								}
								
								$this->_query = 'UPDATE #__jgrid_data SET 	'.$jgrid_data_column.' = "' . $value .'",
																			creator_userid = ' . $user->id.'
											     WHERE id = '. $jgrid_data_id;
							}
							else 
							{
								$this->_query = 'INSERT INTO  #__jgrid_data (	'.$jgrid_data_column.',
																				creator_userid,
																				primary_key_value,
																				document_id,
																				grid_id
																			)
			                                                   VALUES (	"' . $value .'",
			                                                   			' . $user->id.',
			                                                   			'.$row_id.',
			                                                   			'.$current_document_id.',
			                                                   			'.JRequest::getVar('grid_id','','','INTEGER').'
			                                                   		  )';
							}
							
							
							
							$this->_db->setQuery($this->_query);
							$this->_result = $this->_db->query();
							if(!$jgrid_data_id)
							{
								$this->_db->setQuery('SELECT last_insert_id() FROM #__jgrid_data');
								$jgrid_data_id = $this->_db->loadResult();
							}
							// if list type set color of jgrid_data row find color key pressidence and set color
							if(substr($key,0,1)=='L')
							{
								// find list of rows in pressident order
								$this->_query = 'SELECT a.jgrid_data_column,
														a.column_id
				                 				 FROM 	#__jgrid_columngrid a,
				                 				 		#__jgrid_columns b
				                 				 WHERE a.grid_id = '.$grid_id.'		
				                 				 	AND a.column_id = b.id
				                 				 	AND b.data_type = "L"
												ORDER BY a.row_color_pressidence ASC';
								$db->setQuery($this->_query);
								$list_column_array = $db->loadObjectList();
								$new_color_value = '';
								for($i=0;$i<count($list_column_array);$i++)
								{		
									// select values for list columns
									$this->_query = '	SELECT b.listboxvaluerowcolor														
				                 				 		FROM 	#__jgrid_data a,
				                 				 				#__jgrid_column_list_field_values b
				                 				 		WHERE b.column_id = '.$list_column_array[$i]->column_id .'
				                 				 			AND a.id = '.$jgrid_data_id.'
				                 				 			AND b.listboxvalues = a.'.$list_column_array[$i]->jgrid_data_column;
									$db->setQuery($this->_query);
									$new_color_value = $this->_db->loadResult();
									if($new_color_value) break;
								}	
								//set color of updated value		
								$this->_query = 'UPDATE  #__jgrid_data
								                 SET row_color = "' . $new_color_value .'"						                
		                                     	WHERE id = '.$jgrid_data_id;								
							}							
						}
					}
//echo 'sql '	.$this->_query;
//return;				
					
				}

			// IF row access set
			if($key=='rslvl_id')
			{
				if($value) {
					$rslvl_id = $value;
					if($select_type<2)
					{
						$this->_query = 'UPDATE  #__jgrid_rows SET row_access_id = "' . $rslvl_id .'"';
						// also update creator ID if user selected
						if(substr($rslvl_id,0,1)=="U")
						{
							$this->_query .=   ' ,creator_userid = '.substr($rslvl_id,1);
						}
						$this->_query .= ' WHERE id = ' . $row_id .'
			                                 AND document_id = '.$current_document_id;
					}
					else 
					{
						$this->_query = 'UPDATE  #__jgrid_data SET row_access_id = "' . $rslvl_id .'"';
						// also update creator ID if user selected
						if(substr($rslvl_id,0,1)=="U")
						{
							$this->_query .=   ' ,creator_userid = '.substr($rslvl_id,1);
						}
						$this->_query .= ' WHERE id = ' . $jgrid_data_id;
						
					} 
					$this->_db->setQuery($this->_query);
					$this->_result = $this->_db->query();
					if(!$this->_result) return false;
				}	
				// if new row color return priority color
			}
			}// if new row color return priority color
			if($select_type<2)
			{
				$this->_query = 'SELECT min(a.row_color_pressidence),
				                        b.listboxvaluerowcolor
				                 FROM #__jgrid_columngrid a,
				                      #__jgrid_columndata b
				                 WHERE b.columngrid_id = a.id
				                   AND b.row_number = '.$row_id.'
				                   AND b.listboxvaluerowcolor != ""';
			}
			else
			{
					$this->_query = 'SELECT a.row_color as listboxvaluerowcolor
				                 FROM #__jgrid_data a
				                 WHERE  a.id = '.$jgrid_data_id;				
			}								                      			
			$this->_result_count = $this->_getListCount( $this->_query );
			if($this->_result_count>0)
			{
				$this->_result = $this->_getList( $this->_query );
				$row_color = $this->_result[0]->listboxvaluerowcolor;
			}

		}
		if($this->_result)
		{
			if(!$this->_result[0]->listboxvaluerowcolor)$this->_result[0]->listboxvaluerowcolor = 0;
			$return_array["row_color"]=$this->_result[0]->listboxvaluerowcolor;
			$return_array["id"] = $row_id;
			return array($this->_result_count,$return_array);
		}
		else return array(1,"~~");
	}


	/**
	 * insert a row into the user grid at selected location
	 * @var number row_number of inserted row
	 * @var integer identifies where to insert the row key == 1 is first new row, key == 3 is above current selected row , key == 4 is below
	 * @var integer keyID is the selected row number that will be used along with the key to find the new row number to insert
	 * @return if new row inserted return number new_row_number , or integer false if row not inserted
	 */

	function createRow()
	{
		$db =JFactory::getDBO();
		$user=JFactory::getUser();
		//check to see if current document exists, if not update to the default document, always reset guest to default
		$session =JFactory::getSession();
		$temp_session_id = '"'.$session->getId().'"';
		$grid_id = JRequest::getVar('grid_id','','','INTEGER');

		// get current document ID
		$this->_query = 'SELECT g.current_document_id
	   		             FROM #__jgrid_current_user_grid_document g
	   		             WHERE g.userid = ' . $user->id .'
	                       AND g.grid_id = '.$grid_id.'
	                       AND g.session_id = '.$temp_session_id.'';		
		$db->setQuery($this->_query);
		$current_document_id=$db->loadResult();
		list($admin_user,$access_control,$remove_access_control,$document_security_level) = check_access_control($grid_id,$current_document_id,3);
		if($access_control==0 || $remove_access_control>0)	 return false;

		return createGridRow('#__jgrid_rows',
		JRequest::getVar('grid_id','','','INTEGER'),
		JRequest::getVar('row_insert_position','','','INTEGER'),
		JRequest::getVar('selected_row_number','','','INTEGER'));
	}


	/**
	 * Moves grid order in  "Data Grid Settings" grid
	 * @return integer result true if grid moved or false if move failed
	 */
	function moveRow()
	{
		$db =JFactory::getDBO();
		$user=JFactory::getUser();

		//check to see if current document exists, if not update to the default document, always reset guest to default
		$session =JFactory::getSession();
		$temp_session_id = '"'.$session->getId().'"';
		$grid_id = JRequest::getVar('grid_id','','','INTEGER');

		// get current document ID
		$this->_query = 'SELECT g.current_document_id
	   		             FROM #__jgrid_current_user_grid_document g
	   		             WHERE g.userid = ' . $user->id .'
	                       AND g.grid_id = '.$grid_id.'
	                       AND g.session_id = '.$temp_session_id.'';
		$db->setQuery($this->_query);
		$current_document_id=$db->loadResult();
		list($admin_user,$access_control,$remove_access_control,$document_security_level) = check_access_control($grid_id,$current_document_id,3);
		if($access_control==0 || $remove_access_control>0)	 return false;

		return moveGridRow('#__jgrid_rows',
		JRequest::getVar('grid_id','','','INTEGER'),
		JRequest::getVar("number_of_records","","","INTEGER"),
		JRequest::getVar('new_above_record_id','','','INTEGER'),
		JRequest::getVar('new_record_below_id','','','INTEGER'),
		JRequest::getVar('first_record_id','','','INTEGER'),
		JRequest::getVar('last_record_id','','','INTEGER'));
	}

	/**
	 * Copy grid order in  "Data Grid Settings" grid
	 * @return integer result true if grid moved or false if move failed
	 */
	function copyRow()
	{
		$db =JFactory::getDBO();
		$user=JFactory::getUser();
		
		//check to see if current document exists, if not update to the default document, always reset guest to default
		$session =JFactory::getSession();
		$temp_session_id = '"'.$session->getId().'"';
    $grid_id = JRequest::getVar('grid_id','','','INTEGER');

		// get current document ID
		$this->_query = 'SELECT g.current_document_id
	   		             FROM #__jgrid_current_user_grid_document g
	   		             WHERE g.userid = ' . $user->id .'
	                       AND g.grid_id = '.$grid_id.'
	                       AND g.session_id = '.$temp_session_id.'';
		$db->setQuery($this->_query);
		$current_document_id=$db->loadResult();

		list($admin_user,$access_control,$remove_access_control,$document_security_level) = check_access_control($grid_id,$current_document_id,3);

		if($access_control==0 || $remove_access_control>0)	 return false;

		$this->_result=copyGridRow('#__jgrid_rows',
		JRequest::getVar('grid_id','','','INTEGER'),
		JRequest::getVar("number_of_records","","","INTEGER"),
		JRequest::getVar('new_above_record_id','','','INTEGER'),
		JRequest::getVar('new_record_below_id','','','INTEGER'),
		JRequest::getVar('first_record_id','','','INTEGER'),
		JRequest::getVar('last_record_id','','','INTEGER'));
		if($this->_result) return array(JRequest::getVar("number_of_records","","","INTEGER"),$this->_result);
		else return false;
	}



	/**
	 * Removes row from the data grid row and all associated data from grid
	 * @return integer result true if sheet removed or false if remove failed
	 */
	function deleteGridRow()
	{
		$db =JFactory::getDBO();
		$user=JFactory::getUser();
		//check to see if current document exists, if not update to the default document, always reset guest to default
		$session =JFactory::getSession();
		$temp_session_id = '"'.$session->getId().'"';
		$grid_id = JRequest::getVar('grid_id','','','INTEGER');


		// get current document ID
		$this->_query = 'SELECT g.current_document_id
	   		             FROM #__jgrid_current_user_grid_document g
	   		             WHERE g.userid = ' . $user->id .'
	                       AND g.grid_id = '.$grid_id.'
	                       AND g.session_id = '.$temp_session_id.'';
		$db->setQuery($this->_query);
		$current_document_id=$db->loadResult();
		list($admin_user,$access_control,$remove_access_control,$document_security_level) = check_access_control($grid_id,$current_document_id,3);


		if($access_control==0 || $remove_access_control>0)	 return false;

		$this->_result=deleteRow($grid_id,
		$current_document_id,
		json_decode(JRequest::getVar('rows','','','STRING'),TRUE));
		if($this->_result) return $this->_result;
		else return false;
	}

	/**
	 * Retrieves the List of Valid column values for "List Box type Column" in the "Columns Setting data_type popup" grid
	 * @return array containing the "List values" grid rows or false if no values returned
	 *
	 */
	function read_listBoxValues()
	{
		$this->_query = 'SELECT a.id,
		                        a.column_id, 
		                        a.listboxvalues,
		                        a.listboxvaluerowcolor
	                      FROM  #__jgrid_column_list_field_values a
	                      WHERE a.column_id = '.JRequest::getVar('column_id','','','INTEGER').'
	                      ORDER BY listboxvalues';		
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;

	}

	/**
	 * Retrieves the List of Valid user and role values for "List Box type Column" in the "Columns Setting data_type popup" grid
	 * @return array containing the "List values" grid rows or false if no values returned
	 *
	 */
	function read_role_or_user()
	{
		// check for demo version return
		$session =JFactory::getSession();
		if($session->get('demo_mode')){
			// limit users to roles
			$this->_query = 'SELECT role_name AS role_or_user,
		                         CONCAT("R",id) AS "rslvl_id"
			           	         FROM #__jgrid_roles
		                 UNION 
		                        (SELECT "Default" AS role_or_user,
		                        "D" AS "rslvl_id"
			           	        FROM #__jgrid_roles
			           	        LIMIT 1)';
		} else
		{


			$this->_query = 'SELECT username AS role_or_user,
		                          CONCAT("U",id) AS "rslvl_id"
		  	           	          FROM #__users
			           	   UNION
		                        SELECT role_name AS role_or_user,
		                        CONCAT("R",id) AS "rslvl_id"
			           	        FROM #__jgrid_roles
		                   UNION 
		                        (SELECT "Default" AS role_or_user,
		                        "D" AS "rslvl_id"
			           	        FROM #__jgrid_roles
			           	        LIMIT 1)';
		}
		$this->_result_count = $this->_getListCount($this->_query);
		$this->_result = $this->_getList( $this->_query );
		if($this->_result)return array($this->_result_count,$this->_result);
		else return false;

	}
	
	static function VerifyMailAddress($email) 
	{
		if(preg_match("/^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$/", $email))
			return true;
		return false;
	}

	//  send email
	function send_email_msg()
	{
		$db =JFactory::getDBO();
		$user =JFactory::getUser();
		$session = JFactory::getSession();
		$session_id = $session->getId();
		$mailer = JFactory::getMailer();
		//$config = JFactory::getConfig();
		
		// do not allow non registered users to send email for security reasons
	    if($user->id==0) return array(false,'send_email 1001 User must login to site to send emails');
		
		
		$grid_id=JRequest::getVar('grid_id','','','INTEGER');
		$sender_name = JRequest::getVar('email_from_name','','','STRING');
		$sender_email = JRequest::getVar('email_from_address','','','STRING');
		$to_email = JRequest::getVar('email_to_address','','','STRING');
		$email_subject = JRequest::getVar('email_subject','','','STRING');
		$body=JRequest::getVar('email_message','','','STRING');	
		
		// must be a vaild email to send
	    if(!JgridModelJgrid::VerifyMailAddress($to_email)) return array(false,'send_email 1002 EMail TO address '.$to_email.' is not valid format');
		
		// set sender
		if(!$sender_name) $sender_name = $user->name;
		if(!$sender_email) $sender_email = $user->email;
	    if(!JgridModelJgrid::VerifyMailAddress($sender_email)) return array(false,'send_email 1003 FROM EMail address '.$sender_email.' is not valid format');
		
		$sender = array( 
	    	$sender_email,
	    	$sender_name 
    	);
		$mailer->setSender($sender);
		
		
		
		// add email recipients
		//$recipient = array( 'person1@domain.com', 'person2@domain.com', 'person3@domain.com' );
		$recipient = array( $to_email );
        $mailer->addRecipient($recipient);
		$mailer->setSubject($email_subject);
		
		if (!$body) {
			return array(false,"Email Body Not Created");
		}
		$mailer->setBody($body);
		
		// Optional file attached
		if (isset($_FILES))
		{
			$mailer->addAttachment($_FILES['data']['tmp_name'],$_FILES['data']['name']);
		}


//		$body   = '<h2>Our mail</h2>'
//    				. '<div>A message to our dear readers'
//    				. '<img src="cid:logo_id" alt="logo"/></div>';
//		$mailer->isHTML(true);
//		$mailer->Encoding = 'base64';
//		$mailer->setBody($body);
		// Optionally add embedded image
//		$mailer->AddEmbeddedImage( JPATH_COMPONENT.DS.'assets'.DS.'logo128.jpg', 'logo_id', 'logo.jpg', 'base64', 'image/jpeg' );
        
		$send = $mailer->Send();
		if ( $send !== true ) {
	    	return array(false,'send_email 1004 Email Not sent');
		} else {
	    	return array(true,'email sent');	
		}
	
	}

}
