<?php
/*
 *  Initalize.php  in joomla/Components/com_jgrid/views/jgrid/js/app
 *
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */

// no direct access
defined('_JEXEC') or die('Restricted access');

for($i=0;$i<$gridCount;$i++) {
	// setup last document stack
	echo 'JGrid.documentIdStack['.$i.'] = new Array();
		  JGrid.documentIdStack['.$i.'].push('.$griditems[$i]->previous_document_id1.');  
		  JGrid.documentIdStack['.$i.'].push('.$griditems[$i]->current_document_id.');';
}


// add tooltip handler RMS check issue 
//echo 'Ext.ToolTip.prototype.onTargetOver =
//    	Ext.ToolTip.prototype.onTargetOver.createInterceptor(function(e) {
//    		this.baseTarget = e.getTarget();
//    	});
//    Ext.ToolTip.prototype.onMouseMove =
//    	Ext.ToolTip.prototype.onMouseMove.createInterceptor(function(e) {
//    		if (!e.within(this.baseTarget)) {
//    			this.onTargetOver(e);
//    			return false;
//    		}
//    	})';

?>
