<?php
 /*
 *  JGridModels.php  in joomla/Components/com_jgrid/views/jgrid/js/app/model
 *
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

$current_grid = $columnitems[0]->grid_id;
echo 'Ext.define("JGrid.model.JGridModel0", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridModel0",
    id:"JGridModel0",
    fields: [{name: "id", type: "int"}';
for ($i=0, $j=0, $n=$columnCount; $i < $n; $i++)	{
	if($columnitems[$i]->grid_id != $current_grid) {
		echo ' ,{name: "editable_line"}'; 
		echo ' ,{name: "slvl"}';
		echo ' ,{name: "row_color"}';
		echo ' ,{name: "formula"}';
		echo ' ,{name: "rslvl_id", defaultValue: "D"}]});';
		 // set global variable for image_win
 		//echo 'JGrid.dsModel[' . $j . '] = Ext.getCmp("JGridModel' . $j . '");';
		$j++;
		echo 'Ext.define("JGrid.model.JGridModel' . $j . '", {
		    extend: "Ext.data.Model",
		    alias : "widget.JGridModel' . $j . '",
		    id:"JGridModel' . $j . '",
		    fields: [{name: "id", type: "int"}';
		$current_grid = $columnitems[$i]->grid_id;
	}
	if(!$columnitems[$i]->dataindex) continue;
	echo ',{name: "';
	echo $columnitems[$i]->dataindex;
    switch ($columnitems[$i]->data_type)
		    {
			    // text
			    case 'T':
			    //List Box	
			    case 'L':
				// Thumbnail Picture
			    case 'P':
				// URL
			    case 'U':
				// EMail
			    case 'E':
				//Sheet Name
				case 'S':			    					    					    				    				    	
			    	echo '", type: "string"}';
				    break;
				// Integer
			    case 'I':
			    	echo '", type: "int"}';
			    	break;
				// Unique Row ID
			    case 'R':
			    	echo '", type: "string",
			    			mapping: "id"}';
			    	break;			    	
				// Date
			    case 'D':
			    	echo '", type: "date"
		                   , dateFormat: "Y-m-d"}';
			    	break;
				// Boolean
			    case 'B':
			    	echo '", type: "bool"}';
			     	break;
				// Float
			    case 'F':
			    	echo '", type: "float"}';
			    	break;		    			    				    	
	}	
	
}
echo ' ,{name: "editable_line"}'; 
echo ' ,{name: "slvl"}';
echo ' ,{name: "row_color"}';
echo ' ,{name: "formula"}';
echo ' ,{name: "rslvl_id", defaultValue: "D"}]});';

for ($j=0; $j<$gridCount;  $j++)	{
	echo 'JGrid.dsModel[' . $j . '] = Ext.create("JGrid.model.JGridModel' . $j . '");';
}	


?>

// manage grid user access jgrid_security administrator screen xtype: "editorgrid"
Ext.define("JGrid.model.JGridModelAccess", {
    extend: "Ext.data.Model",  
	alias : "widget.JGridModelAccess",
    id: "JGridModelAccess",
    fields: [	{name: 'id', type: 'int'},
             	{name: 'userid_assigning_access', type: 'int'}, 
             	{name: 'access_for', type: 'int'}, 
         		{name: 'access_for_id', type: 'string'}, 
         		{name: 'access_for_name', type: 'string'}, 
              	{name: 'access_type', type: 'int'},
           		{name: 'access_type_id', type: 'string'},
               	{name: 'access_type_name', type: 'string'},
              	{name: 'access_level', type: 'int'},
              	{name: 'last_updated', type: 'date'}
           ]
});
JGrid.dsModel.ds_model_access = Ext.create("JGrid.model.JGridModelAccess");


