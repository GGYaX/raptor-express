<?php
 /*
 *  JGridUploadWin.php  in joomla/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */ 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>

function createDataChart(grid_id,new_document_id,last_document_id,chartBodyObj,itemIndex)
{ 
			
			var chartObj;	
			Ext.Ajax.request({
								waitMsg:"<?php echo JText::_("CREATING_SHEET")?>",
								url:"<?php echo JURI::base()?>index.php?option=com_jgrid&task=read_chart_setting&controller=jgrid_documents&format=ajax",					                   
			                 	params: {
			                         task: "read_chart_setting",
			                         option: "com_jgrid",
			                         grid_id:grid_id,
			                         new_document_id: new_document_id,
			                         last_document_id: last_document_id
			                 	},
								method: "POST",
								failure: function (response, options) {										 
									
								},
								success: function (response, options) {					                
									var server_response = Ext.decode(response.responseText);
				                    if (!server_response.success) {                                                      
										
									} 
									else 
									{									
										var legend;
										if(!Ext.isEmpty(server_response.legend) && server_response.legend.length>0)
										{
											legend={};
											//Adding position
											if(!Ext.isEmpty(server_response.legend[0].position)){
											
												legend.position=server_response.legend[0].position;
												if(server_response.legend[0].position=="relative"){
													legend.x=parseInt(server_response.legend[0].x);
													legend.y=parseInt(server_response.legend[0].y);
												}
											
											}
											if(!Ext.isEmpty(server_response.legend[0].padding)){
												legend.padding=parseInt(server_response.legend[0].padding);
											}
											if(!Ext.isEmpty(server_response.legend[0].itemSpacing)){
												legend.itemSpacing=parseInt(server_response.legend[0].itemSpacing);
											}
											if(!Ext.isEmpty(server_response.legend[0].boxFill)){
												legend.boxFill=server_response.legend[0].boxFill;
											}
											if(!Ext.isEmpty(server_response.legend[0].labelFont)){
												//legend.labelFont=server_response.legend[0].labelFont;
											}
										}
										else{
											 legend=false;
										}
										//Creating Chart
										if(chartObj!=""){
											chartObj="";
										}
										chartObj=Ext.create("Ext.chart.Chart",{
               									//animate: true,
               									legend :legend,
												store:  JGrid.store[itemIndex]
										});
										
										JGrid.store[itemIndex].reload();		
								/* 								
								 *Chart Serise configuration
								 */
								switch(server_response.rows[0].chart_category)
								{
								    
									case "cartesian":		
									 //Creating Chart Category Config
									if(!Ext.isEmpty(server_response.category_axes) && server_response.category_axes.length>0 ){
										
										chartObj.axes.add({
						            		type: "Category",
						            		grid:(server_response.numeric_axes[0].gridbackgroundId == "true") ? true : false,
						            		position:server_response.category_axes[0].position,
						            		title:server_response.category_axes[0].title,
						            		minimum: 0,						            		
						            		fields: [server_response.category_axes[0].cfields],
						            		label:{						            		 	
						            		 	rotate: {
	                    							degrees: parseInt(server_response.category_axes[0].label_dgree_rotate)	                    							
	                							}
						            		 }
					        			});									
									}									
									if(!Ext.isEmpty(server_response.chart_radial_axes) && server_response.chart_radial_axes.length>0 ){
										chartObj.axes.add({
						            		type: "Radial",
						            		position:"radial",
						            		label:{						            		 	
						            		 	display: true
						            		 }
					        			});									
									}
									/*
									 *Configuring Numeric axes if exists
									 */
									 if(!Ext.isEmpty(server_response.numeric_axes) && server_response.numeric_axes.length>0 ){
									   var fieldStr=[];
                                       for(var i=0;i< server_response.numeric_axes[0].fields.length;i++){
                                       		fieldStr.push(server_response.numeric_axes[0].fields[i].field_value);
                                       }                                                                             
                                       chartObj.axes.add({
				            				type: "Numeric",				            		
				            				title:server_response.numeric_axes[0].title,
				            				minimum: server_response.numeric_axes[0].minimum,
				            				position: server_response.numeric_axes[0].position,
				            				fields: fieldStr,
				            				minorTickSteps: server_response.numeric_axes[0].minorTickSteps,
				            				majorTickSteps:server_response.numeric_axes[0].majorTickSteps,
				            				grid:(server_response.numeric_axes[0].gridbackgroundId == "true") ? true : false
				            				
				        				});
									 }
									        
								     for(j=0;j < server_response.chart_series.length;j++){
											var temp_xField    = server_response.chart_series[j].xField;
											var temp_chartType = server_response.chart_series[j].type;
											var series_yField=[];
											var series_labelTitle=[];
										   	for(var i=0;i< server_response.chart_series[j].yField.length;i++){
	                                       		series_yField.push(server_response.chart_series[j].yField[i].field_value);
	                                       		//Mapping dataindex with header for label title
	                                       		
	                                       		for(var k=0;k < JGrid.columns[itemIndex].length;k++){
	                                       			if(JGrid.columns[itemIndex][k].dataIndex==server_response.chart_series[j].yField[i].field_value){
	                                       					
	                                       				series_labelTitle.push(JGrid.columns[itemIndex][k].header);
	                                       			}	                                       		
	                                       		}
	                                       	}	
	                                       //	alert(server_response.chart_series[j].xField);
										chartObj.series.add({
												type: server_response.chart_series[j].type,
												axis: server_response.chart_series[j].axis,
												highlight: server_response.chart_series[j].highlight,
												title:series_labelTitle,																				
												tips: {
													trackMouse: true,
													width: 140,
													height: 28,
													renderer: function(storeItem, item) {
											        	if(temp_chartType=="area"){
											          		this.setTitle(storeItem.get(temp_xField)+":"+storeItem.get(item.storeField));
											          	}else{
											          	 this.setTitle(storeItem.get(temp_xField) + ':'+String(item.value[1]));
														}
													}
												},											
												xField:server_response.chart_series[j].xField,
												yField:series_yField,
												stacked:server_response.chart_series[j].stacked										
										});	
									}
								break;
								case "pie":
										 for(j=0;j < server_response.chart_series.length;j++){
											var temp_xField    = server_response.chart_series[j].xField;
											var temp_chartType = server_response.chart_series[j].type;
											var series_yField=[];
											var series_labelTitle=[];
										   	for(var i=0;i< server_response.chart_series[j].yField.length;i++){																								
	                                       		series_yField.push(server_response.chart_series[j].yField[i].field_value);
	                                       		//Mapping dataindex with header for label title
	                                       		
	                                       		for(var k=0;k < JGrid.columns[itemIndex].length;k++){
	                                       			if(JGrid.columns[itemIndex][k].dataIndex==server_response.chart_series[j].yField[i].field_value){
	                                       					
	                                       				series_labelTitle.push(JGrid.columns[itemIndex][k].header);
	                                       			}	                                       		
	                                       		}
	                                       	}	
										chartObj.series.add({
												//type: server_response.chart_series[j].type,
												type: 'pie',
												highlight: server_response.chart_series[j].highlight,
												showInLegend: true,
												label: {
													field: server_response.chart_series[j].xField,
													display: 'rotate',
													contrast: true,
													font: '18px Arial'
												},
												highlight: {
													segment: {
														margin: 40
													}
												},												
												field:series_yField
																						
										});	
									}
									
									break;
								case "radar":
																		
								  	chartObj.axes.add({
						            		type: "Radial",
						            		position: 'radial',
						            		label:{						            		 	
						            		 	display: true						            		 	
						            		 }
					        			});
					        			
					        		for(j=0;j < server_response.chart_series.length;j++){
											var temp_xField    = server_response.chart_series[j].xField;
											var temp_chartType = server_response.chart_series[j].type;
											var series_yField=[];
											var series_labelTitle=[];
										   	for(var i=0;i< server_response.chart_series[j].yField.length;i++){
	                                       		series_yField.push(server_response.chart_series[j].yField[i].field_value);
	                                       		//Mapping dataindex with header for label title
	                                       		
	                                       		for(var k=0;k < JGrid.columns[itemIndex].length;k++){
	                                       			if(JGrid.columns[itemIndex][k].dataIndex==server_response.chart_series[j].yField[i].field_value){
	                                       					
	                                       				series_labelTitle.push(JGrid.columns[itemIndex][k].header);
	                                       			}	                                       		
	                                       		}
	                                       	}	
										chartObj.series.add({
												type: server_response.chart_series[j].type,
												xField:server_response.chart_series[j].xField,
												yField:series_yField,					
												highlight:server_response.chart_series[j].highlight,
												showMarkers:true,
												markerConfig:{
													radius: 4
												},
												style: {
													'stroke-width': 2,
													fill: 'none'
												}
												
												
										});	
									}						        				
								break;									
								default:								
								break;									
							}   //End of Switch
							chartBodyObj.add(chartObj);
						}
					},
				scope: this
				});			
	
}
     
