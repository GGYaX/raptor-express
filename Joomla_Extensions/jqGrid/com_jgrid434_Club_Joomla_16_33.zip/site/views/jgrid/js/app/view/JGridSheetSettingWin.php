<?php
 /*
 *  JGridSheetSettingWin.php  in joomla/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */ 
// no direct access
defined('_JEXEC') or die('Restricted access');
$fversion = $params->get ('fversion');
?>
Ext.require(['Ext.data.*']);

Ext.define('Writer.chartSeries', {
    extend: 'Ext.data.Model',
    fields: [
		{name: 'series_type',type: 'string'},
    	{name:'series_axis',type: 'string'}, 
    	{name:'series_xaxis',type: 'string'}, 
    	{name:'series_yaxis',type: 'string'},
    	{name:'stacked_opt',type:'boolean'},
    	{name:'highlight',type:'boolean'}
    ]
});
// The data store containing the list of axis
//Creating dynamic array
var arrField=[];
var series_gridStore =Ext.create('Ext.data.Store', {
    fields: [{name:'series_id',type: 'int'},
    	{name:'series_type',type: 'string'},
    	{name:'series_axis',type: 'string'}, 
    	{name:'series_xaxis',type: 'string'}, 
    	{name:'series_yaxis',type: 'string'},
    	{name:'stacked_opt',type:'boolean'},
    	{name:'highlight',type:'boolean'}]
});


for(var i=1;i < JGrid.columns[0].length;i++)
{
	if((JGrid.columns[0][i].dataIndex).substr(0,1)!="I" || JGrid.columns[0][i].dataIndex.substr(0,1)!="F" )
	  continue;
	 var obj={
			'dataIndexVal':JGrid.columns[0][i].dataIndex,
			'text':JGrid.columns[0][i].header
	 }
	 arrField.push(obj);
}

var stackedCb =Ext.create('Ext.data.Store', {fields: [{name:'stackedId',type: 'boolean'}, {name:'stackedVal'}],
		data:[{"stackedId":true, "stackedVal":"<?php echo JText::_("TTRUE")?>"}, {" stackedId":false, "stackedVal":"<?php echo JText::_("FFALSE")?>"}]
});
var highlightCb  =Ext.create('Ext.data.Store', {
    fields: [{name:'highlightId',type: 'boolean'}, {name:'highlightVal'}],
    data : [
        {"highlightId":true, "highlightVal":"<?php echo JText::_("TTRUE")?>"},
        {"highlightId":false, "highlightVal":"<?php echo JText::_("FFALSE")?>"}
    ]
});

var states = Ext.create('Ext.data.Store', {
    fields: [{name:'type'},{name:'type_name'}],
    data :[
		{"type":"bar", "type_name":"<?php echo JText::_("BAR_CHART")?>"},
        {"type":"column", "type_name":"<?php echo JText::_("COLUMN_CHART")?>"},
        {"type":"line", "type_name":"<?php echo JText::_("LINE_CHART")?>"},
        {"type":"area", "type_name":"<?php echo JText::_("AREA_CHART")?>"},
        {"type":"scatter", "type_name":"<?php echo JText::_("SCATTER_CHART")?>"},
        {"type":"pie", "type_name":"<?php echo JText::_("PIE_CHART")?>"},
        {"type":"radar", "type_name":"<?php echo JText::_("RADAR_CHART")?>"}
    ]
});


var series_chart_type = Ext.create('Ext.data.Store', {
    fields: [{name:'type'},{name:'type_name'}],
    data :[
		{"type":"bar", "type_name":"<?php echo JText::_("BAR_CHART")?>"},
        {"type":"column", "type_name":"<?php echo JText::_("COLUMN_CHART")?>"},
        {"type":"line", "type_name":"<?php echo JText::_("LINE_CHART")?>"},
        {"type":"area", "type_name":"<?php echo JText::_("AREA_CHART")?>"},
        {"type":"scatter", "type_name":"<?php echo JText::_("SCATTER_CHART")?>"},
        {"type":"pie", "type_name":"<?php echo JText::_("PIE_CHART")?>"},
        {"type":"radar", "type_name":"<?php echo JText::_("RADAR_CHART")?>"}
    ]
});


/**Numeric Category Fields store **/
var numFieldCb = Ext.create('Ext.data.Store', {
    id:'numFieldCbId',
    autoLoad: false,
    fields: ['dataIndexVal', 'text']
});

/*
 *Category Fields Store
 */
var catFieldCb = Ext.create('Ext.data.Store', {
    id:'catFieldCbId',
    autoLoad: false,
    fields: ['dataIndexVal', 'text']
});


var naxesCb = Ext.create('Ext.data.Store', {
    id:'naxesCb',
    fields: ['pid', 'pval'],
    data :[
        {"pid":"bottom", "pval":"<?php echo JText::_("BOTTOM")?>"},
        {"pid":"top", "pval":"<?php echo JText::_("TOP")?>"},
        {"pid":"left", "pval":"<?php echo JText::_("LEFT")?>"},
        {"pid":"right", "pval":"<?php echo JText::_("RIGHT")?>"}
    ]
});

var legendCb = Ext.create('Ext.data.Store', {
    id:'legendCb',
    fields: ['legendid','legendVal'],
    data :[
        {"legendid":"bottom", "legendVal":"<?php echo JText::_("BOTTOM")?>"},
        {"legendid":"top",    "legendVal":"<?php echo JText::_("TOP")?>"},
        {"legendid":"left",   "legendVal":"<?php echo JText::_("LEFT")?>"},
        {"legendid":"right",  "legendVal":"<?php echo JText::_("RIGHT")?>"},
        {"legendid":"relative","legendVal":"<?php echo JText::_("RELATIVE")?>"},
        {"legendid":"hidden","legendVal":"<?php echo JText::_("HIDDEN")?>"}
    ]
});


var chartCategoryCb = Ext.create('Ext.data.Store', {
    id:'naxesCb',
    fields: ['chart_cat', 'chart_catVal'],
    data :[
        {"chart_cat":"cartesian", "chart_catVal":"<?php echo JText::_("CARTESIAN")?>"},
        {"chart_cat":"pie",		  "chart_catVal":"<?php echo JText::_("PIE")?>"},
        {"chart_cat":"radar",     "chart_catVal":"<?php echo JText::_("RADAR")?>"}
    ]
});

var catPosStore = Ext.create('Ext.data.Store', {
    id:'catPosStore',
    fields:['cat_pid', 'cat_pval'],
    data :[
        {"cat_pid":"bottom", "cat_pval":"<?php echo JText::_("BOTTOM")?>"},
        {"cat_pid":"top", "cat_pval":"<?php echo JText::_("TOP")?>"},
        {"cat_pid":"left", "cat_pval":"<?php echo JText::_("LEFT")?>"},
        {"cat_pid":"right", "cat_pval":"<?php echo JText::_("RIGHT")?>"}
    ]
});

var catLableStore = Ext.create('Ext.data.Store', {
    id:'catLableStoreId',
    fields:['cat_ldgree', 'cat_ldgreeVal'],
    data :[
        {"cat_ldgree":45, "cat_ldgreeVal":"45"},
        {"cat_ldgree":90, "cat_ldgreeVal":"90"},
        {"cat_ldgree":135, "cat_ldgreeVal":"135"},
        {"cat_ldgree":180, "cat_ldgreeVal":"180"},
        {"cat_ldgree":225, "cat_ldgreeVal":"225"},
        {"cat_ldgree":270, "cat_ldgreeVal":"270"},
        {"cat_ldgree":315, "cat_ldgreeVal":"315"},
        {"cat_ldgree":360, "cat_ldgreeVal":"360"}
    ]
});

Ext.define("JGrid.view.JGridSheetSettingWin", {
	extend:"Ext.window.Window",
	alias:"widget.JGridSheetSettingWin",
	<?php    
    if($params->get ('jgrid_renderTo'))
	{
		echo 'renderTo: "'.$params->get ('jgrid_renderTo').'", ';
	} 
	else echo 'renderTo: "jgrid_component",';
   	if($params->get ('jgrid_sheet_setting_win_width') > 0)
    {
    	echo 'width: '.$params->get ('jgrid_sheet_setting_win_width').',';
    } 
    else echo 'width:950,';
    if($params->get ('jgrid_sheet_setting_win_height') > 0)
    {
    	echo 'height: '.$params->get ('jgrid_sheet_setting_win_height').',';
    }
    echo 'height:650,';       
    if($params->get ('jgrid_sheet_setting_win_x') > 0)
    {
   	 	echo 'x: '.$params->get ('jgrid_sheet_setting_win_x').',';
    }
    if($params->get ('jgrid_sheet_setting_win_y') > 0)
    {
    	if($params->get ('jgrid_sheet_setting_win_y') < 30) echo 'y: 30,';
    	else echo 'y: '.$params->get ('jgrid_sheet_setting_win_y').',';
    }
    else echo 'y: 30,';
?> 
	id: "JGridSheetSettingWinId",
	config:{
		selectedId:null,
		grid_reference_id:null,
		documentIdStack:null,
		array_index:null,
		task:null,
		selectedSheetId:null
				
	},	
	constructor:function(config){
	  this.callParent(arguments);
	  this.initConfig(config);
	},	
	listeners: {		
		close:function(obj,opt){
			obj.destroy();		
		},
		afterrender:function(obj,opt){			
			var arrField=[];
			var tbl_gridId=parseInt(obj.selectedId);
			var gridIndex=parseInt(obj.array_index);
			numFieldCb.removeAll();
			catFieldCb.removeAll();
			var configTask=obj.task;
			var configSelectedSheetId=obj.selectedSheetId;								
			for(var i=1; i < JGrid.columns[gridIndex].length; i++){			    
			    // Adding record in Numeric axes
			    if((JGrid.columns[gridIndex][i].dataIndex).substr(0,1)=="I"){
			    	var obj={
						'dataIndexVal':JGrid.columns[gridIndex][i].dataIndex,
						'text':JGrid.columns[gridIndex][i].header
				 }
					numFieldCb.add(obj);
					//Only Adding default first Item
					if(Ext.isEmpty(Ext.getCmp('nFieldId').getValue())){
						Ext.getCmp('nFieldId').setValue(JGrid.columns[gridIndex][i].dataIndex);
						
					}
			    }
			    if((JGrid.columns[gridIndex][i].dataIndex).substr(0,1)=="F"){
			    	var obj={
						'dataIndexVal':JGrid.columns[gridIndex][i].dataIndex,
						'text':JGrid.columns[gridIndex][i].header
					}
					numFieldCb.add(obj);
					//Only Adding First item as a default
					if(Ext.isEmpty(Ext.getCmp('nFieldId').getValue())){
						Ext.getCmp('nFieldId').setValue(JGrid.columns[gridIndex][i].dataIndex);
					}	
			    }			    
			    if((JGrid.columns[gridIndex][i].dataIndex).substr(0,1)=="T" || (JGrid.columns[gridIndex][i].dataIndex).substr(0,1)=="L"){
			    	var obj={
						'dataIndexVal':JGrid.columns[gridIndex][i].dataIndex,
						'text':JGrid.columns[gridIndex][i].header
					}
					catFieldCb.add(obj);
					if(Ext.isEmpty(Ext.getCmp('catField').getValue())){
						Ext.getCmp('catField').setValue(JGrid.columns[gridIndex][i].dataIndex);
					}
			    }			    				    				 
			
			}
			var mydata1 = [];		
			var tempDefault=new Array();
				tempDefault.push(1);
				tempDefault.push("column");
				tempDefault.push("left");
				tempDefault.push(Ext.getCmp('catField').getValue());
				tempDefault.push(Ext.getCmp('nFieldId').getValue());
				tempDefault.push(true);
				tempDefault.push(true);
				mydata1.push(tempDefault);
				series_gridStore.removeAll();
				series_gridStore.loadData(mydata1, false);
			if(configTask=="Edit"){
				//Edit Option 			
				Ext.getCmp('sheettype_chart_rd').setValue(true);
				Ext.getCmp('chartConfigId').setVisible(true);	
				
				
				
					
				Ext.Ajax.request({
								<?php           
									echo 'waitMsg: "'.JText::_("CREATING_SHEET").'",';		            
									echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=read_chart_setting&controller=jgrid_documents&format=ajax",';
								?>                     
								method :'POST',										                     
								params :{
									'task'		:'read_chart_setting',
									'option'	:'com_jgrid',
									'grid_id'	: tbl_gridId,
									'new_document_id':configSelectedSheetId									  
								 },
								success: function (response){
									var server_response = Ext.decode(response.responseText);
									if(server_response.rows.lengt > 0){
										
										//Load Old setting to the form	
										Ext.getCmp('new_document_name').setValue(server_response.rows[0].document_title);
									if(server_response.rows[0].chart_category!="non_chart_sheet")
									{	
										Ext.getCmp('chart_category').setValue(server_response.rows[0].chart_category);
										//Setting Chart Legend option										
											Ext.getCmp('legendCbId').setValue(server_response.legend[0].position);
											Ext.getCmp('lable_padding').setValue(server_response.legend[0].padding);
											Ext.getCmp('colorpicker').setValue(server_response.legend[0].boxFill);
											Ext.getCmp('lable_x').setValue(server_response.legend[0].x);
											Ext.getCmp('lable_y').setValue(server_response.legend[0].y);
											if(server_response.legend[0].position=="relative"){
												Ext.getCmp('lable_x').setVisible(true);
												Ext.getCmp('lable_y').setVisible(true);
											}
											else{
												Ext.getCmp('lable_x').setVisible(false);
												Ext.getCmp('lable_y').setVisible(false);
											}
											
										//End of Chart Legend option
										//Traversing Chart series data
										if(server_response.chart_series.length>0)
										{
											var mydata = [];											
											for(var i=0; i < server_response.chart_series.length; i++){
												
												var temp = Array();
												var tempYaxis=Array();
												temp.push(server_response.chart_series[i].series_id);
												temp.push(server_response.chart_series[i].type);
												temp.push(server_response.chart_series[i].axis);
												temp.push(server_response.chart_series[i].xField);
												for(var j=0;j < server_response.chart_series[i].yField.length;j++){
													tempYaxis.push(server_response.chart_series[i].yField[j].field_value);											
													
												}																								
												temp.push(tempYaxis.toString());
												temp.push(server_response.chart_series[i].stacked);
												temp.push(server_response.chart_series[i].highlight);
												mydata.push(temp);
											}
											series_gridStore.loadData(mydata, false); 																	
										}										
										switch(server_response.rows[0].chart_category)
										{
											case "cartesian":
													Ext.getCmp('numAxesConf').setVisible(true);
													Ext.getCmp('catAxesConf').setVisible(true);													
													Ext.getCmp('naxes_position').setValue(server_response.numeric_axes[0].position);
													Ext.getCmp('naxes_title').setValue(server_response.numeric_axes[0].title);
													var tempNumericAxes = new Array();
													for(var k=0;k < server_response.numeric_axes[0].fields.length;k++){														
														if(!Ext.isEmpty(server_response.numeric_axes[0].fields[k].field_value)){
															tempNumericAxes.push(server_response.numeric_axes[0].fields[k].field_value);	
														}
														Ext.getCmp('nFieldId').setValue(tempNumericAxes);
																																					
													}
													Ext.getCmp('caxes_position').setValue(server_response.category_axes[0].position);
													Ext.getCmp('ctitle').setValue(server_response.category_axes[0].title);
													//alert(server_response.category_axes[0].label_dgree_rotate);
													Ext.getCmp('label_dgree_rotate').setValue(server_response.category_axes[0].label_dgree_rotate);
													Ext.getCmp('catField').setValue(server_response.category_axes[0].cfields);													
													break;
												case "pie":													
													Ext.getCmp('numAxesConf').setVisible(false);
													Ext.getCmp('catAxesConf').setVisible(false);	
													break;
												case "radar":
													Ext.getCmp('numAxesConf').setVisible(false);
													Ext.getCmp('catAxesConf').setVisible(false);
													break;
										}									
									}
									}
									
								 }
				});		
			
			}
			
						
		}
		
	},
	<?php 	
	 	echo 'title: "'.JText::_("CREATE_NEW_SHEET").'",';
	?>
    border: false,
    closeAction:"hide",
   	items:[{
		xtype: 'form',
		id: "JGridSheetSettingFm",
		fileUpload: true,
	 	buttonAlign: "center",
	  	//width: 450,
	 	frame: true,
	 	style: "margin: 0 auto;",
	 	dockedItems: [{
	 		xtype: 'toolbar',
	 		dock: 'bottom',
	 		ui: 'footer',
	 		items: [
	 					{
	 						xtype: 'button', text: 'Save',
	 						handler:function(){	 						
	 							//IF True use old code to create Grid Sheet								
								var tbl_gridId           = parseInt(Ext.getCmp('JGridSheetSettingWinId').getSelectedId());
	 							var jgrid_id    		 = parseInt(Ext.getCmp('JGridSheetSettingWinId').getArray_index());
		 						var getGrid_reference_id = Ext.getCmp('JGridSheetSettingWinId').getGrid_reference_id();
		 						var document_name 		 = Ext.getCmp('new_document_name').getValue();
	 							var documentIdStack		 = Ext.getCmp('JGridSheetSettingWinId').getDocumentIdStack();
	 							var array_index 		 = parseInt(Ext.getCmp('JGridSheetSettingWinId').getArray_index());
		 						var arr_documentIdStack  = JGrid.documentIdStack[jgrid_id];
	 							var last_document_id     = JGrid.documentIdStack[arr_documentIdStack.length - 1];
	 							var sub_task             = Ext.getCmp('JGridSheetSettingWinId').getTask();
	 							var selected_sheetId     = Ext.getCmp('JGridSheetSettingWinId').getSelectedSheetId();	 							
	 							//IF grid document radio is selected
	 							if(Ext.isEmpty(Ext.getCmp('new_document_name').getValue())){
<?php 	 							
									echo'Ext.MessageBox.alert("'. JText::_("ALERT").'", "'. JText::_("PLEASE_ENTER_SHEET_NAME").'");';
?>								
									Ext.getCmp('new_document_name').focus();
									return false;
								}
	 							if(Ext.getCmp('sheettype_grid_rd').getValue()){	 							
		 							jgrid_create_grid_document(tbl_gridId, getGrid_reference_id, JGrid.documentIdStack[array_index], array_index,document_name);
		 							Ext.getCmp('JGridSheetSettingWinId').close();	 							
	 							}
	 							else if(Ext.getCmp('sheettype_chart_rd').getValue()){	 							
	 							 	// IF chart sheet option is selected 
								 	// Logic for saving config values	 
								 	
								 	//Fetching Legend configoption
								 	
								 	
								 	var l_position = Ext.getCmp('legendCbId').getValue();
								 	var l_padding  = Ext.getCmp('lable_padding').getValue();
								 	var l_colorpicker  = Ext.getCmp('colorpicker').getValue();
								 	var l_lable_x  = Ext.getCmp('lable_x').getValue();
								 	var l_lable_y  = Ext.getCmp('lable_y').getValue();								 	
								 	var legendJsonStr = '{"position":"'+l_position+'","padding":"'+l_padding+'","boxFill":"'+l_colorpicker+'","x":"'+l_lable_x+'","y":"'+l_lable_y+'","labelFont":"Times New Roman"}';							 	
								 	//END				
								 	var bgLine=false;
	 								var new_document_name = Ext.util.Format.stripTags(document_name);	 								 							
	 							 	switch(Ext.getCmp('chart_category').getValue()){
	 							 	 	case "cartesian":	 							 			
	 							 			//Getting Numeric axes configuration data
	 							 			
	 							 			var naxes_position = Ext.getCmp('naxes_position').getValue();
											var naxes_title    = Ext.getCmp('naxes_title').getValue();
											var gridbackgroundId =false;
											var nFieldId		 = Ext.getCmp('nFieldId').getValue();	
											var cat_ldgree       = Ext.getCmp('label_dgree_rotate').getValue();
											var series_data_string;											
											if(Ext.getCmp('cgrid1').getValue()){
	 											gridbackgroundId=true;
	 										}
				 							else if(Ext.getCmp('cgrid2').getValue()){
				 								gridbackgroundId=false;
				 							}
											
											//Getting Category axes configuration data											
											var caxes_position  = Ext.getCmp('caxes_position').getValue();
											var ctitle			= Ext.getCmp('ctitle').getValue();
											var catField		= Ext.getCmp('catField').getValue();
	 							 			var seriesSettingArray=[];	 							 			
	 							 			if(series_gridStore.getCount()<=0){
<?php 	 							 															
	 							 				echo 'Ext.MessageBox.alert("'. JText::_("ALERT").'", "'. JText::_("PLEASE_ENTER_CHART_SERIES_FIRST").'");';
?>		 							 				
	 							 				return false;
	 							 			}
	 							 			else{			 			
												var series_records = new Array()       
												var series_data = series_gridStore.each(function(rec){
													
													var series_type   =rec.get('series_type');
													var series_axis   =rec.get('series_axis');
													var series_xaxis  =rec.get('series_xaxis');
													var series_yaxis  =rec.get('series_yaxis');
													var stacked_opt   =rec.get('stacked_opt');
													var highlight     =rec.get('highlight');
													var series_string ='{"series_type":"'+series_type+'","series_axis":"'+series_axis+'","series_xaxis":"'+series_xaxis+'","series_yaxis":"'+series_yaxis+'","stacked_opt":"'+stacked_opt+'","highlight":"'+highlight+'"}';
													series_records.push(series_string);															
												});
	 							 			    if(series_records.length>0){
	 							 			    	series_data_string = "["+series_records.join()+"]";	 							 			    	
	 							 			    }
	 							 			
	 							 			}
											Ext.Ajax.request({
										        <?php           
					                				echo 'waitMsg: "'.JText::_("CREATING_SHEET").'",';		            
							                		echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=create_chart_document&controller=jgrid_documents&format=ajax",';
								      			?>                     
										        method :'POST',										                     
										        params :{
										        	 'task'                 :'create_chart_document',
										        	 'option'				:'com_jgrid',
					                         		 'grid_id'				:tbl_gridId,
					                         		 'sub_task'             :sub_task, 
					                         		 'selected_sheetId'     :selected_sheetId, 
					                         		 'last_document_id'		:last_document_id,
					                         		 'gridbackgroundId'     :gridbackgroundId,
					                         		 'new_document_name'	:new_document_name,
										        	 'chart_category'       :Ext.getCmp('chart_category').getValue(),
										        	 'legendJsonStr'		:legendJsonStr,
										        	 'numeric_axes_config'  :'{"naxes_position":"'+naxes_position+'","naxes_title":"'+naxes_title+'","nFieldId":"'+nFieldId+'"}',
										        	 'category_axes_config' :'{"caxes_position":"'+caxes_position+'","ctitle":"'+ctitle+'","catField":"'+catField+'","cat_ldgree":"'+cat_ldgree+'"}',
										        	 'series_data_config'   :series_data_string  
										         },
										        success: function (response){										          
										           var server_response = Ext.decode(response.responseText);
				                         			if (!server_response.success){                                                      
														<?php 
															  echo 'Ext.MessageBox.alert("'. JText::_("CREATE_FAILED").'", "'. JText::_("SHEET_CREATE_WAS_NOT_SUCCESSFULL").'");';													      
														?>    
														 Ext.getCmp('JGridSheetSettingWinId').close();                                    
				                         			} 
				                         			else {
														var pgrid = Ext.ComponentMgr.get(getGrid_reference_id);
														var new_document_id = parseInt(server_response.rows.new_document_id);
				                             			var combo_record =	{id: new_document_id,document_title: new_document_name};
				                             			JGrid.documentStore[array_index-1].add(combo_record);
				                             			var documentid=getGrid_reference_id+"_document";
				                             			Ext.ComponentMgr.get(documentid).setValue(new_document_id);
				                             			Ext.ComponentMgr.get(documentid).setRawValue(new_document_name);			                            				
				                             			JGrid.documentIdStack[array_index-1].push(new_document_id);
				                          	 			pgrid.store.reload({
					                          				params:{
					                                    	 	new_document_id: new_document_id,
					                                     		last_document_id: last_document_id
					                    					}
				                        				});					                
				                        				<?php 
													      echo 'Ext.MessageBox.alert("'. JText::_("CREATE_SUCCESS").'", "'. JText::_("SHEET_CREATE_WAS_SUCCESSFULL").'");';													      
														?> 
				                        				Ext.getCmp('JGridSheetSettingWinId').close();
									                }
										        },
											   failure: function (response) {
													<?php 
															echo 'Ext.MessageBox.alert("'. JText::_("CREATE_FAILED").'", "'. JText::_("SHEET_CREATE_WAS_NOT_SUCCESSFULL").'");';
													?> 
													Ext.getCmp('JGridSheetSettingWinId').close();  
										        }
										    });
										 break;
	 							 	 	
	 							 	 	case "pie":
	 							 	 		var series_data_string;
	 							 	 		if(series_gridStore.getCount()<=0){
	 							 				<?php 
													echo 'Ext.MessageBox.alert("'. JText::_("CREATE_ALERT").'", "'. JText::_("PLEASE_ENTER_CHART_SERIES").'");';
												?>
												return;
	 							 			}
	 							 			else{			 			
												var series_records = new Array()       
												var series_data = series_gridStore.each(function(rec){
													//alert(rec.get('series_type'));
													var series_type   =rec.get('series_type');
													var series_axis   =rec.get('series_axis');
													var series_xaxis  =rec.get('series_xaxis');
													var series_yaxis  =rec.get('series_yaxis');
													var stacked_opt   =rec.get('stacked_opt');
													var highlight     =rec.get('highlight');
													if(series_yaxis==""){
<?php 
															echo 'Ext.MessageBox.alert("'. JText::_("CREATE_ALERT").'", "'. JText::_("PLEASE_ENTER_CHART_SERIES").'");';
?>
														return;
													}
													else if(series_yaxis!=""){
																										
														if(series_yaxis.split(",").length>1){
<?php 
																echo 'Ext.MessageBox.alert("'. JText::_("CREATE_ALERT").'", "'. JText::_("ONLY_ONE_FIELD_REQUIRED").'");';
?>	
															return false;
														} 
													}
													var series_string ='{"series_type":"'+series_type+'","series_axis":"'+series_axis+'","series_xaxis":"'+series_xaxis+'","series_yaxis":"'+series_yaxis+'","stacked_opt":"'+stacked_opt+'","highlight":"'+highlight+'"}';
													series_records.push(series_string);															
												});
	 							 			    if(series_records.length>0){
	 							 			    	series_data_string = "["+series_records.join()+"]";
	 							 			    }	 							 			
	 							 			}	 							 				 							 			
	 							 			Ext.Ajax.request({
										        <?php           
					                				echo 'waitMsg: "'.JText::_("CREATING_SHEET").'",';		            
							                		echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=create_chart_document&controller=jgrid_documents&format=ajax",';
								      			?>                     
										        method :'POST',										                     
										        params :{
										        	 'task'                 :'create_chart_document',
										        	 'option'				:'com_jgrid',
					                         		 'grid_id'				: tbl_gridId,
					                         		 'sub_task'             :sub_task, 
					                         		 'selected_sheetId'     :selected_sheetId, 
					                         		 'last_document_id'		:last_document_id,
					                         		 'new_document_name'	:new_document_name,
					                         		 'legendJsonStr'		:legendJsonStr,
										        	 'chart_category'       :Ext.getCmp('chart_category').getValue(),										        	 
										        	 'series_data_config'   :series_data_string  

										         },
										        success: function (response, options){
										           var server_response = Ext.decode(response.responseText);
				                         			if (!server_response.success) {                                                      
<?php 
													      echo 'Ext.MessageBox.alert("'. JText::_("CREATE_FAILED").'", "'. JText::_("SHEET_CREATE_WAS_NOT_SUCCESSFULL").'");';
													      
?>    
													 Ext.getCmp('JGridSheetSettingWinId').close();                                    
				                         			} else {
														 var pgrid = Ext.ComponentMgr.get(getGrid_reference_id);
														var new_document_id = parseInt(server_response.rows.new_document_id);
				                             			var combo_record =	{id: new_document_id,document_title: new_document_name};
				                             			JGrid.documentStore[array_index-1].add(combo_record);
				                             			var documentid=getGrid_reference_id+"_document";
				                             			Ext.ComponentMgr.get(documentid).setValue(new_document_id);
				                             			Ext.ComponentMgr.get(documentid).setRawValue(new_document_name);			                            				
				                             			JGrid.documentIdStack[array_index-1].push(new_document_id);
				                          	 			pgrid.store.reload({
					                          				params:{
					                                    	 	new_document_id: new_document_id,
					                                     		last_document_id: last_document_id
					                    					}
				                        				});					                
<?php 
													      echo 'Ext.MessageBox.alert("'. JText::_("CREATE_SUCCESS").'", "'. JText::_("SHEET_CREATE_WAS_SUCCESSFULL").'");';
													      
?> 
				                        				Ext.getCmp('JGridSheetSettingWinId').close();
									                }
										        },
											   failure: function (response) {
													<?php 
															echo 'Ext.MessageBox.alert("'. JText::_("CREATE_FAILED").'", "'. JText::_("SHEET_CREATE_WAS_NOT_SUCCESSFULL").'");';
													?> 
													Ext.getCmp('JGridSheetSettingWinId').close();  
										        }
										    });
	 							 	 	break;
	 							 	 	case "radar":
	 							 	 		var series_data_string;
	 							 	 		if(series_gridStore.getCount()<=0){
<?php
	 							 				echo 'Ext.MessageBox.alert("'. JText::_("ALERT").'", "'. JText::_("PLEASE_ENTER_CHART_SERIES_FIRST").'");';
?>	 							 			
	 							 			}
	 							 			else{			 			
												var series_records = new Array()       
												var series_data = series_gridStore.each(function(rec){
													//alert(rec.get('series_type'));
													var series_type   =rec.get('series_type');
													var series_axis   =rec.get('series_axis');
													var series_xaxis  =rec.get('series_xaxis');
													var series_yaxis  =rec.get('series_yaxis');
													var stacked_opt   =rec.get('stacked_opt');
													var highlight     =rec.get('highlight');
													var series_string ='{"series_type":"'+series_type+'","series_axis":"'+series_axis+'","series_xaxis":"'+series_xaxis+'","series_yaxis":"'+series_yaxis+'","stacked_opt":"'+stacked_opt+'","highlight":"'+highlight+'"}';
													series_records.push(series_string);															
												});
	 							 			    if(series_records.length>0){
	 							 			    	series_data_string = "["+series_records.join()+"]";
	 							 			    	//alert(series_data_string);
	 							 			    }	 							 			
	 							 			}
	 							 				 							 			
	 							 			Ext.Ajax.request({
										        <?php           
					                				echo 'waitMsg: "'.JText::_("CREATING_SHEET").'",';		            
							                		echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=create_chart_document&controller=jgrid_documents&format=ajax",';
								      			?>                     
										        method :'POST',										                     
										        params :{
										        	 'task'                 :'create_chart_document',
										        	 'option'				:'com_jgrid',
					                         		 'grid_id'				: tbl_gridId,
					                         		 'sub_task'             :sub_task, 
					                         		 'selected_sheetId'     :selected_sheetId, 
					                         		 'last_document_id'		:last_document_id,
					                         		 'new_document_name'	:new_document_name,
					                         		 'legendJsonStr'		:legendJsonStr,
										        	 'chart_category'       :Ext.getCmp('chart_category').getValue(),										        	 
										        	 'series_data_config'   :series_data_string  
										         },
										        success: function (response){
										          
										           var server_response = Ext.decode(response.responseText);
				                         			if (!server_response.success) {                                                      
													<?php 
													      echo 'Ext.MessageBox.alert("'. JText::_("CREATE_FAILED").'", "'. JText::_("SHEET_CREATE_WAS_NOT_SUCCESSFULL").'");';													      
													?>    
													 Ext.getCmp('JGridSheetSettingWinId').close();                                    
				                         			} else {
														 var pgrid = Ext.ComponentMgr.get(getGrid_reference_id);
														var new_document_id = parseInt(server_response.rows.new_document_id);
				                             			var combo_record =	{id: new_document_id,document_title: new_document_name};
				                             			JGrid.documentStore[array_index-1].add(combo_record);
				                             			var documentid=getGrid_reference_id+"_document";
				                             			Ext.ComponentMgr.get(documentid).setValue(new_document_id);
				                             			Ext.ComponentMgr.get(documentid).setRawValue(new_document_name);			                            				
				                             			JGrid.documentIdStack[array_index-1].push(new_document_id);
				                          	 			pgrid.store.reload({
					                          				params:{
					                                    	 	new_document_id: new_document_id,
					                                     		last_document_id: last_document_id
					                    					}
				                        				});					                
				                        				<?php 
													      echo 'Ext.MessageBox.alert("'. JText::_("CREATE_SUCCESS").'", "'. JText::_("SHEET_CREATE_WAS_SUCCESSFULL").'");';													      
														?> 
				                        				Ext.getCmp('JGridSheetSettingWinId').close();
									                }
										        },
											   failure: function (response) {
													<?php 
															echo 'Ext.MessageBox.alert("'. JText::_("CREATE_FAILED").'", "'. JText::_("SHEET_CREATE_WAS_NOT_SUCCESSFULL").'");';
													?> 
													Ext.getCmp('JGridSheetSettingWinId').close();  
										        }
										    });	 							 	 		
	 							 	 		break;
	 							 	} 
	 							}	
	 						}	 						
	 					},
	 					{
							xtype: 'button', 
							text: 'Cancle',
							handler:function(){
									Ext.getCmp('JGridSheetSettingWinId').close();
							}
							
	 					}
	 					]
	 	}],
		<?php 	
			//echo 'title: "'.JText::_("CREATE_NEW_SHEET").'",';
		?>
		autoHeight: true,
	 	bodyStyle: "padding: 5px 5px 0px 5px;",
		labelWidth: 250,
	  	defaults:{
	    	anchor: "100%",
	      	allowBlank: true,
	      	msgTarget: "side"
		},
		items:[{
        	xtype:'textfield',
        	name:'new_document_name',
        	id: 'new_document_name',
        	fieldLabel: '<?php echo JText::_("PLEASE_ENTER_NEW_DOCUMENT_NAME");?>',
        	value:'<?php echo JText::_("DEFAULT_CHART_SHEET");?>',
        	allowBlank: false  // requires a non-empty value
    	},
    	{
            xtype      : 'fieldcontainer',
            fieldLabel : '<?php echo JText::_("SHEET_TYPE");?>',
            defaultType: 'radiofield',
            defaults:{
                flex:1
            },
            layout:'hbox',
            items:[
                {
                    boxLabel  : '<?php echo JText::_("GRID_FORMAT");?>',
                    name      : 'sheettype',
                    inputValue: 'g',
                    checked   :true,
                    id        : 'sheettype_grid_rd'  
                }
<?php                
            
                echo ',{
                    boxLabel  : "'.JText::_("CHART_FORMAT").'",
                    name      : "sheettype",
                    inputValue: "c",
                    checked   :false,
                    id        : "sheettype_chart_rd",
                    handler:function(){
                    	if(this.getValue()){
                    		Ext.getCmp("chartConfigId").setVisible(true);	
                    	}
                    	else{
                    		Ext.getCmp("chartConfigId").setVisible(false);
                    	}
                    }                    
                }';

?>            
            ]
        },        
        {        
        		layout:'auto',
        		xtype:'panel',
        		id:'chartConfigId',
        		hidden:true,
        		title: '<?php echo JText::_("CHART_CONFIGURATION");?>',
	        	items:[
	        		{
	        			fieldLabel: '<?php echo JText::_("CHART_CATEGORY");?>',
			         	name:'chart_category',
			         	id:'chart_category',
			         	emptyText:'<?php echo JText::_("CHART_CATEGORY");?>',
			         	xtype:'combo',
			         	store:chartCategoryCb,
			         	value:'cartesian',
			         	displayField:'chart_catVal',
    					valueField:'chart_cat',
    					listeners: {
		                    	select: {
		                            fn: function (combo, records, eOpts) {
		                          		 if(combo.getValue()=="cartesian"){
		                          		  	/*
		                          		  	 *IF category is cartesian then 
		                          		  	 *Show numeric & category Axes
		                          		  	 */
		                          		  	 
		                     	  			Ext.getCmp('numAxesConf').setVisible(true);
		                     	  			Ext.getCmp('catAxesConf').setVisible(true);
		                          		  }
		                          		  else{
											Ext.getCmp('numAxesConf').setVisible(false);
											Ext.getCmp('catAxesConf').setVisible(false);	 
										}
		                            }
		                          },
		                          afterrender:{
									fn: function (combo,eOpts) {
										//show Numeric config option if chart type is cartisian
										if(this.getValue()=="cartesian"){											
											Ext.getCmp('numAxesConf').setVisible(true);											
		                     	  			Ext.getCmp('catAxesConf').setVisible(true);	                     	  			   		  	
										}
									}								
								}
		            	}	        	
	        		},{						
						xtype:'panel',
						layout:'column',
						height:30,
						items:[{
							columnWidth:0.14,
							xtype:'combo',
							fieldLabel:'<?php echo JText::_("LEGEND");?>',
							labelWidth:50,
							id:'legendCbId',
							store:legendCb,
							displayField:'legendVal',
							valueField:'legendid',
							value:'left',
							listeners:{
								select:{
									fn: function (combo, records, eOpts) {
										//alert(combo.getValue())
										if(combo.getValue()=="relative"){
											Ext.getCmp('lable_x').setVisible(true);
											Ext.getCmp('lable_y').setVisible(true);	
										}
										
										
									}
								} 
							}							
						},
						{
							columnWidth: 0.18,
							name:'lable_padding',
							id:'lable_padding',
							fieldLabel:'<?php echo JText::_("PADDING_IN_PX");?>',
							xtype:'numberfield',
							value: 10,
							maxValue:100,
							minValue:0
						},
						{
							columnWidth: 0.18,
							xtype:'pickerfield',
							fieldLabel:'<?php echo JText::_("BOX_FILL");?>',	
							labelWidth:50,						
							id :'colorpicker',
							value:'#000000', 
							createPicker:function() {
								return Ext.create('Ext.picker.Color', {
								resizable :true,
								floating: true,
								value:'000000', 
								frame:true,
								select: function(selColor) {
										Ext.getCmp('colorpicker').setValue("#"+ selColor); 
										var  x = Ext.getCmp('colorpicker').getValue();
										Ext.getCmp('colorpicker').setFieldStyle('background-color:'+x+' ;background-image: none;');
									}
								});
						}						
						},
						{
							columnWidth: 0.14,
							name:'lable_x',
							id:'lable_x',
							hidden:true,
							labelWidth:30,
							fieldLabel:'<?php echo JText::_("JX");?>',							
							xtype:'numberfield',
							value:0,
							maxValue:1000,
							minValue:0
						},
						{   
							columnWidth:0.14,
							name:'lable_y',
							id:'lable_y',
							hidden:true,
							labelWidth:30,							
							fieldLabel:'<?php echo JText::_("JY");?>',
							xtype:'numberfield',
							maxValue:1000,
							value:0,
							minValue:0
						}
						]		
					},	        		
	        		{
						xtype:'panel',
						layout:'column',
						items:[{
								columnWidth: 0.5,
								xtype:'fieldset',
								id:'numAxesConf',
								hidden:false,
								title:'Numeric Axes Configuration',
								defaults: {anchor:'100%'},
								layout: 'anchor',
								defaultType: 'textfield',
								items :[{      
										fieldLabel: '<?php echo JText::_("AXES_POSITION");?>',
										name:'naxes_position',
										id:'naxes_position',
										emptyText:'<?php echo JText::_("PLEASE_SELECT_NUMERIC_AXES");?>',
										xtype:'combo',
										store:naxesCb,
										value:'left',
										displayField: 'pval',
										valueField: 'pid'
									},
									{
										fieldLabel: '<?php echo JText::_("TITLE");?>',
										name: 'naxes_title',
										id:'naxes_title',
										xtype:'textfield',
										value:'<?php echo JText::_("NUMERIC_AXES_NAME");?>',
										emptyText:'<?php echo JText::_("NUMERIC_AXES_NAME");?>'
									},
									{
										xtype  		:'fieldcontainer',
										name   		:'gridbackgroundId',
										id     		:'gridbackgroundId',
										fieldLabel  : '<?php echo JText::_("GRID_BACKGROUND");?>',
										defaultType : 'radiofield',
										defaults:{
											flex: 1
										},
										layout: 'hbox',
										items: [{
												boxLabel  : '<?php echo JText::_("JYES");?>',
												name      : 'cgrid',
												inputValue: true,
												checked   :true,
												id        :'cgrid1'
											},{
												boxLabel  : '<?php echo JText::_("JNO");?>',
												name      : 'cgrid',
												inputValue: false,
												id        : 'cgrid2'
											}
										]
									},
									{
										fieldLabel  : '<?php echo JText::_("FIELDS");?>',
										xtype		:'combo',        					
										displayField:'text',
										id			:'nFieldId',
										name		:'nFieldId',
										queryMode	:'local',
										multiSelect	:true, 
										valueField	:'dataIndexVal',
										store		:numFieldCb
									}

								]
							},
							{
								columnWidth: 0.5,
								xtype:'fieldset',
								hidden:false,
								title: '<?php echo JText::_("CATEGORY_AXES_CONFIGURATION");?>',
								id:'catAxesConf',
								defaultType: 'textfield',
								items :[{      
									fieldLabel:'<?php echo JText::_("AXES_POSITION");?>',
									emptyText:'<?php echo JText::_("PLEASE_SELECT_AXES");?>',
									name:'caxes_position',
									value:'bottom',	
									id:'caxes_position',
									xtype:'combo',
									store:catPosStore,
									displayField:'cat_pval',
									valueField: 'cat_pid'		         	    
								},
								{
									fieldLabel:'<?php echo JText::_("TITLE");?>',
									name:'ctitle',
									id:'ctitle',
									xtype:'textfield',
									value:'<?php echo JText::_("CATEGORY_AXES_NAME");?>',	
									emptyText:'<?php echo JText::_("CATEGORY_AXES_NAME");?>'
								},
								{
									fieldLabel:'<?php echo JText::_("CATEGORY_LABLE_ALIGNMENT");?>',
									name:'label_dgree_rotate',
									id:'label_dgree_rotate',
									xtype:'combo',
									valueField:'cat_ldgree',
									displayField:'cat_ldgreeVal',
									value:90,
									store		:catLableStore,
									emptyText	:'<?php echo JText::_("SELECT_DEGREE_TO_ROTATE");?>'
								},
								{
									fieldLabel:'<?php echo JText::_("FIELDS");?>',
									xtype:'combo',
									id:'catField',
									name:'catField',        					
									displayField:'text',
									queryMode:'local',
									multiSelect:true, 
									valueField:'dataIndexVal',
									store:catFieldCb
								}]	
							}]						
					},	        	
					{	xtype:'panel',
	        		title:'Chart Series Configuration',
	        		items:[{
	        			xtype:'gridpanel',
	        			height:150,
	        			id:'series_grid',
	        			store:series_gridStore,        		
	        			plugins:[
        						Ext.create('Ext.grid.plugin.RowEditing', {
            					clicksToEdit: 1,
            					listeners:{
            						edit:function(editor, e, eOpts ){
            							//alert(e.record.get('series_type'));
            							e.record.commit();            							
            							//Ext.getCmp('series_grid').getStore().reload();          							
            						},
            						beforeedit:function(editor, e, eOpts){
										//alert("asdasd 3333"+Ext.getCmp('chart_category').getValue());
										 
										
										
										 
									}	
            					}
        					})
    					],
	        			dockedItems: [{
    					xtype: 'toolbar',
    					dock: 'top',
    					items: [{	xtype: 'button', 
	        						text: 'Add Series to grid',
	        						handler:function(){        								
        								  var rec = new Writer.chartSeries({
								            series_type: '',
								          	series_axis: '',
								           	series_xaxis: '',
								          	stacked_opt: '',
								           	highlight: ''
        								});
        								Ext.getCmp('series_grid').getStore().insert(0, rec);    
        								//Ext.getCmp('series_grid').getStore().commite();
        								//Ext.getCmp('series_grid').getStore().reload();   						
        							}       						
        						 },
        						 '-',
        						 {
									xtype: 'button', 
	        						text: 'Remove',
	        						handler:function(){ 
										var pgrid = Ext.getCmp('series_grid');
										var sm = pgrid.getSelectionModel();  
										pgrid.getView().refresh();  
										if (sm.hasSelection()) {	
										    var sels = sm.getSelection();									
											var remove_sels = new Array();
											Ext.Msg.show({
												title: "Remove Row",
												buttons: Ext.MessageBox.YESNOCANCEL,
												msg: "Remove Selected Rows?",
												fn: function (btn) {
													if (btn == "yes"){          
														// Multiple row delete
														for(var i = 0, j = 0; i < sels.length; i++){ 
															r = sels[i];
															series_gridStore.remove(r); 
														}														
														pgrid.getView().refresh();             
													}
												}
											});
										}
									}
	        							
								 }
        					 ]
						}],
	        			columns:[
							{  header:'Series type', 
						       editor:Ext.create('Ext.form.ComboBox', {
						          			id:'series_chat_type',
						        			name:'series_chat_type',
						        			emptyText:'<?php echo JText::_("SELECT_CHART_TYPE");?>',
						        			store:series_chart_type,
						        			displayField:'type_name',
						    				valueField:'type',
						    				listeners: {
												focus:{
													fn:function(combo, records, eOpts){
														if(Ext.getCmp('chart_category').getValue()=="cartesian"){	
															series_chart_type.filterBy(function (record) {
																if(record.get('type')=="pie" || record.get('type')=="radar"){
																	return false;
																}
																else{
																	return true;
																}	
															});
														}
														else if(Ext.getCmp('chart_category').getValue()=="pie"){
															series_chart_type.filterBy(function (record) {
																if(record.get('type')=="pie"){
																	return true;
																}
																else{
																	return false;
																}	
															});
														}
														else if(Ext.getCmp('chart_category').getValue()=="radar"){
															series_chart_type.filterBy(function (record) {
																if(record.get('type')=="radar"){
																	return true;
																}
																else{
																	return false;
																}	
															});
														}	
													}
												},
						                    	select: {
						                            fn: function (combo, records, eOpts) {
														
														 
						                          		 if(combo.getValue()=="bar" || combo.getValue()=="column"){
															
						                          		  }
						                          		  else if(combo.getValue()=="pie"){
						                          		  	//Ext.MessageBox.alert("Alert","Pie type selected");
						                          		  }
						                            }
						                          }
						            		}
					          
					          
					          }),	
					          dataIndex: 'series_type'
					        },
					        { 		header: 'Series axis', 
  					        		dataIndex: 'series_axis', 
  					        		editor:Ext.create('Ext.form.ComboBox', {
  								    	name:'serise_chart_axisId',
		        						id:'serise_chart_axisId',
		        						emptyText:'<?php echo JText::_("PLEASE_SELECT_AXIS");?>',
		        						store:naxesCb,
										displayField:'pval',
		    							valueField: 'pid'
					          		})
					        	 
					        },
					        { 	header: 'Series xAxis Fields', 
  					        	dataIndex:'series_xaxis',
  					        	editor:Ext.create('Ext.form.ComboBox', {
  									id:'series_chart_xField',
	        						name		:'series_chart_xField',       					
	        						displayField:'text',
	        						queryMode	:'local',
	        						multiSelect	:true, 
	    							valueField	:'dataIndexVal',
	        						store		:catFieldCb
					          	}) 
					        },
					        {   text:'Series yAxis Fields', 
  					        	dataIndex:'series_yaxis',
  					        	editor:Ext.create('Ext.form.ComboBox',{
  									id:'series_chart_yField',
									name:'series_chart_yField',          					
		        					displayField:'text',
		        					queryMode:'local',
		        					multiSelect:true, 
		    						valueField:'dataIndexVal',
		        					store:numFieldCb
					          	}) 
					        	
					        },
					        { 
  					        	text: 'Stacked', 
  					        	dataIndex: 'stacked_opt',
  					        	editor:Ext.create('Ext.form.ComboBox', {
  								  id:'series_stackedCb_chart_Fld',
		        				  emptyText:'<?php echo JText::_("SELECT_TYPE");?>',
		        				  store:stackedCb,
					         	  displayField: 'stackedVal',
  		    					  valueField: 'stackedId',
  		    					  value:false
					          	})
					        },
					        {   
                      text:'highlight', 
  					        	dataIndex: 'highlight',
  					        	editor:Ext.create('Ext.form.ComboBox', {
  								id:'series_highlightCbFld',
          						emptyText:'<?php echo JText::_("PLEASE_SELECT_TYPE");?>',
          						store:highlightCb,
								displayField: 'highlightVal',
      								valueField: 'highlightId',
      								value:true
					          	})
					        }
    					]
    					
	        		
	        		}]
	        	
	        	}]
        	}
		]
	}]  
});


     
