<?php
 /*
 *  JGridImageWin.php  in joomla/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>

JGrid.flash_window = Ext.create("JGrid.view.JGridFlashWin", {
	extend : "Ext.window.Window",
	alias : "widget.JGridFlashWin",
	id: "JGridFlashWin",
	loadMask: true,
    closeAction: "hide",
    resizable: true, 
    minimizable: true,
     style: {
            ZIndex:100001
        },
    width: JGrid.thumbnailImage["width"]+5,
    height: JGrid.thumbnailImage["height"]+5, 
    maximizable: true,
<?php	
	  if($params->get ('jgrid_renderTo'))
	  {
	 	echo 'renderTo: "'.$params->get ('jgrid_renderTo').'", ';
	  } 
	  else echo 'renderTo: "jgrid_component",';
      echo 'title: "'.JText::_("URL").'",';     
      if($params->get ('jgrid_image_win_x') > 0)
      {
        echo 'x: '.$params->get ('jgrid_image_win_x').',';
      } 
      if($params->get ('jgrid_image_win_y') > 0)
      {
        echo 'y: '.$params->get ('jgrid_image_win_y').',';
      }
?>          
     items: [{
        xtype: "flash",
        id: "flash_win_id",
        wmode: "transparent",
        pinned:true,
        expressInstall: true,
        preserveRatio: true,
        fit: true,
<?php        
      // echo 'url: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid//noite.swf",';
      echo 'url: JGrid.flash_url,';
?>        
      // width: JGrid.thumbnailImage["width"], 
       //height: JGrid.thumbnailImage["height"]
        height: "100%"
    }],
    buttons: [{
      id: "go_to_url2",
<?php      
      echo 'text: "'.JText::_("GO_TO_URL").'",';
?>	
      handler: function(){ 
        window.open(JGrid.thumbnailImage["hyper_url"], "image_window");            
      }                                           
     },
     {
      id: "go_to_email2",
<?php      
      echo 'text: "'.JText::_("GO_TO_EMAIL").'",';
?>	
      handler: function(){ 
      //RMS  add subject later
      	JGrid.thumbnailImage["email_subject"] = '';
        show_email_window();           
      }                                           
     },     
     
     
     {
       id: "go_to_sheet2",
<?php              
       echo 'text: "'.JText::_("GO_TO_SHEET").'",';
?>       	
       handler: function(){
       
         new_document_array = JGrid.thumbnailImage["hyper_grid_sheet"].split("-");
         new_grid_id = "Grid-"+new_document_array[0];
         new_grid_index = JGrid.crossGridIdRef[new_grid_id];
         current_document_id_stack=JGrid.document_id_stack[new_grid_index];
         new_document_id = new_document_array[1];
         last_document_id = 0;
         grid_tabpanel  = Ext.ComponentMgr.get("grid_tabpanel");
         if (new_document_id==0||new_document_id==null) {
            current_document_id_stack.push(last_document_id);
<?php            
            echo 'Ext.Msg.alert("'. JText::_("GRID_SHEET_NOT_FOUND").'", "'. JText::_("THIS_HYPER_LINK_IS_NOT_ACTIVE_PLEASE_CONTACT_YOUR_ADMINISTRATOR").'");';
?> 
            return;
         }
         else {
           	grid_tabpanel.setActiveTab(new_grid_id);
            last_document_id = current_document_id_stack[current_document_id_stack.length - 1];
            current_document_id_stack.push(new_document_id);
         }
         last_grid_id_stack.push(JGrid.thumbnailImage["grid_reference_id"]);
         Ext.ComponentMgr.get(new_grid_id).store.reload({
            params: {
              new_document_id: new_document_id,
              last_document_id: last_document_id
            }
         });
         Ext.ComponentMgr.get(cross_return_button_id_ref[new_grid_index]).show();
         image_win.hide();
       }                                           
     }
<?php      
   if($params->get('allow_image_download',1)==1)
   {         	
     echo ',{
            id: "download_button2",
           
            text: "'.JText::_("DOWNLOAD_IMAGE").'" ,	
            handler: function(){              
            	window.open( "'.JURI::base().'index.php?option=com_jgrid&task=download_images&controller=jgrid_images&format=ajax&grid_id="+JGrid.thumbnailImage["grid_id"]+"&document_id="+JGrid.thumbnailImage["document_id"]+"&column_id="+JGrid.thumbnailImage["column_id"]+"&row_id="+JGrid.thumbnailImage["row_id"]+"");  
            }                                           
    }';        
   }
?>     
 ]});
 
     
