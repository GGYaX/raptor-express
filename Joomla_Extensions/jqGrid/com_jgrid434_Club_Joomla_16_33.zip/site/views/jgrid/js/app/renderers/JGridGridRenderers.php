<?php
/*
 *  JGridGridRenderers.php in joomla/Components/com_jgrid/r/jgrid/js/app/renderers
 *
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

for($i=0;$i<$gridCount;$i++) {
	// define access_level array variables
	echo 'var access_level_array'.$i.' = "";';
		
	//RMS set to defalut variable
	echo 'JGrid.editMode['.$i.'] = false;';
	
	// set table join column for table type grids
	echo 'JGrid.primary_key_column['.$i.'] = "'.$griditems[$i]->primary_key_column.'";'; 
	if($griditems[$j]->enableRowEditor  == true)
	{ 
		echo 'JGrid.row_edit_enabled['.$i.']=true;';        	
	}
	else echo 'JGrid.row_edit_enabled['.$i.']=false;';
	echo 'JGrid.editor['.$i.'] = Ext.create("Ext.grid.plugin.RowEditing", {
    	saveText: "Update",
	  	errorSummary: false,
        listeners: 
        {		  
        	beforeedit: function(thisEditor,rowdata) 
        	{ 
        		if(JGrid.editMode['.$i.']==false)
                { 
                	JGrid.editor['.$i.'].cancelEdit();
	                return(false);
                }
	            var grid =  Ext.ComponentMgr.get("' . $griditems[$i]->grid_reference_id  . '");                                                                        
	            var grid_columns = grid.columns;      
	            editor_columns = this.editor.query("textfield");
	            var editable_line = rowdata.record.get("editable_line");
	            var id = rowdata.record.get("id");
//	            if(id == 0) 
//	            {
//	            	thisEditor.cancelEdit();
//	            	return (false);
//	            }

		     	if(access_level_array'.$i.'[0]=="6")
	         	{
	         		//grid_columns[JGrid.columnCount['.$i.']+5].show();	         		
	         		editor_columns[editor_columns.length-1].setDisabled(false);
        			//thisEditor.query("textfield")[thisEditor.query("textfield").length-1].setDisabled(false);
	          	}
	         	else
	          	{
	          		//grid_columns[JGrid.columnCount['.$i.']+5].hide();	
		        	if(editable_line!=true)
		           	{
		      			thisEditor.cancelEdit();
		          		return(false);
		          	}  
	      		}       		        
            	// If sheet access level is view only as default look for columns and rows that are editable to shit user   
	            // if no edit button and no access array cancle
            	if(!access_level_array'.$i.') {
            		thisEditor.cancelEdit();
	                return(false);
            	}
				 // hide editable column from editor rms problem
	             // grid_columns[JGrid.columnCount['.$i.']+2].hide();
 
	            // cell and column rule edit            	
            	if(access_level_array'.$i.'[0]<"3") 
	            {
	              //	current_grid.editingPlugin.editor.query("textfield")[i].setDisabled(true);
	              // look for columns that are "cell edit"	
	              for(var i=1;i<access_level_array'.$i.'.length;i++)
	              {
	                if(access_level_array'.$i.'[i].substr(0,1)=="C"&&(editable_line==true)) 
	                {
						// find column index
	                	for(j=1;j<editor_columns.length;j++)
	                	{
	                		my_column = editor_columns[j].name;
	                		if(my_column != undefined && my_column)
	                		{
	                			if(my_column.substr(1) == access_level_array'.$i.'[i].substr(2))
	                			{
	                				editor_columns[j].setDisabled(false);
	                			}	                			
	               			}
	                 		// grid_columns.setEditable(grid_columns.getIndexById(access_level_array'.$i.'[i].substr(1)),true);
	                	}
					}
	              }
				}
	            else
	            {
	            if(grid.editingPlugin.editor)
	            {
			        for(var i=0;i < grid.editingPlugin.editor.query("textfield").length;i++)
			        {
			             textfield = grid.editingPlugin.editor.query("textfield")[i];   
			             if(textfield.name.substr(0,1)=="P")
			             {
			             	textfield.setDisabled(true);
			    			 //grid_columns.setEditable(i,false);
			             }
			             else
			             {
			             	textfield.setDisabled(false);
			     			//grid_columns.setEditable(i,true);
			             }
			             
			        }	              
				}
	          }  

return true;	   //RMS makes editor work until sencha fixes       
	            // look for picture columns and hide from editor
	            for(var i=1;i<JGrid.columnCount['.$i.']+1;i++)
	            {
	              if(grid_columns[i].dataIndex.substr(0,1)=="P")
	              {
	                grid_columns[i].hide(); 
	              } 
	            } 
	        
   
	                                                                                              
	        },
          	//afteredit: function(thisEditor, obj, rec, index) 
          	completeEdit: function(thisEditor, obj, rec, index)
          	{ 
	            var grid_columns = Ext.ComponentMgr.get("' . $griditems[$i]->grid_reference_id  . '").columns;
	            if(access_level_array'.$i.'[0]<"3") 
	            {
                   	// first set all columns back to active
//	              	for(j=1;j<grid_columns.length;j++)
//	                {
//	                	grid_columns[i].setDisabled(false);	
//	                }                                               
	            }
	            // reshow editable column
	            grid_columns[JGrid.columnCount['.$i.']+2].show();
	            for(var i=1;i<=JGrid.columnCount['.$i.']+1;i++)
	            {
	              if(grid_columns[i].dataIndex.substr(0,1)=="P")
	              {
	                grid_columns[i].show(); 
	              } 
	            } 
	                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                       
	        },
          	canceledit: function(thisEditor, obj, rec, index) 
          	{ 
	            var grid_columns = Ext.ComponentMgr.get("' . $griditems[$i]->grid_reference_id  . '").columns;
	            // look for picture columns and hide from editor
	            // reshow editable column
	            grid_columns[JGrid.columnCount['.$i.']+2].show();
	            for(var i=1;i<=JGrid.columnCount['.$i.'];i++)
	            {
	              if(grid_columns[i].dataIndex.substr(0,1)=="P")
	              {
	                grid_columns[i].show(); 
	              } 
	            } 
          	}
		} 
	});
	
	JGrid.rslvlCombo['.$i.'] = {
		xtype: "combobox",
	    typeAhead: true,
		emptyText: "'. JText::_("SELECT_A_TYPE").'",
	    lazyRender: true,
	    forceSelection: true,
		valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",                           
		mode: "local",
	    store: JGrid.combo_store[50],
	    valueField: "rslvl_id",
	    displayField: "role_or_user",
	    selectOnFocus: true,
	    typeAhead: true,
	    editable: true,
	    triggerAction: "all"
	}; '; 
	
   }
?>    
    