<?php
/*
 *  JGridComboStores.php in joomla/Components/com_jgrid/views/jgrid/js/app/store
 *
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

<?php
echo 'JGrid.grid_application_name= "'.$griditems[0]->grid_application_name.'";';
?>


// combo box for application-grid-sheet
Ext.define("JGrid.store.JGridComboStore1", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridComboModel1",    
	model: "JGrid.model.JGridComboModel1",
	alias : "widget.JGridComboStore1",
	id:"JGridComboStore1",
     proxy: {
        type: "ajax",
<?php
    	echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=get_combo_Application_Grid_Sheet&controller=jgrid_documents&grid_application_name='.$griditems[0]->grid_application_name.'&format=ajax",';
?>  
	    reader: new Ext.data.JsonReader({
	        fields: [{name: 'grid_sheet_id', type: 'string'}, 
	                 {name: 'grid_sheet_title', type: 'string'}, {name: 'document_type', type: 'int'}],                 
	        root: 'rows',
	        totalProperty: 'results',
	        id: 'id'
	    })
    }
});
JGrid.combo_store[1] = Ext.create("JGrid.store.JGridComboStore1");

// combo for upload or download deliminator selection	
	Ext.define("JGrid.store.JGridCStore2", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel2",   
	model: "JGrid.model.JGridCModel2",
	alias : "widget.JGridCStore2",
	storeId:"JGridCStore2",
	id:"JGridCStore2",
	autoLoad: false,
<?php 	
  	echo' data: [	{"delimiter": ",", "delimiter_description": "'. JText::_("COMMA").'"}, 
		         	{"delimiter": ";", "delimiter_description": "'. JText::_("SEMICOLON").'"},
		         	{"delimiter": "\t", "delimiter_description": "'. JText::_("TAB").'"},
		          	{"delimiter": "|", "delimiter_description": "'. JText::_("PIPE").'"},               
		         	{"delimiter": ":", "delimiter_description": "'. JText::_("COLON").'"}';
?>         	
 	]//comboData
});
JGrid.combo_store[2] = Ext.create("JGrid.store.JGridCStore2");


// combo boxs for popup image jump to sheet sheets
	Ext.define("JGrid.store.JGridCStore3", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel3",   
	model: "JGrid.model.JGridCModel3",
	alias : "widget.JGridCStore3",
	storeId:"JGridCStore3",
	id:"JGridCStore3",
	autoLoad: true,
	proxy: {
   		type: "ajax",
<?php
    	echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=get_combo_Application_Grid_Sheet&controller=jgrid_documents&grid_application_name='.$griditems[0]->grid_application_name.'&format=ajax",';
?>   	
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[3]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[3] = Ext.create("JGrid.store.JGridCStore3");

// combo boxs for security access for type role or user	
	Ext.define("JGrid.store.JGridCStore40", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel40",   
	model: "JGrid.model.JGridCModel40",
	alias : "widget.JGridCStore40",
	storeId:"JGridCStore40",
	id:"JGridCStore40",
	autoLoad: false,
<?php 	
  	echo' data: [	{"access_for":"1", "Type":"'. JText::_("USER").'"},
       		{"access_for":"3", "Type":"'. JText::_("ROLE").'"},
    		{"access_for":"3", "Type":"'. JText::_("DEFAULT").'"},
        	{"access_for":"4", "Type":"'. JText::_("CREATOR").'"}';
?>         	
 	]//comboData
});
JGrid.combo_store[40] = Ext.create("JGrid.store.JGridCStore40");


// combo boxs for security role or user	
	Ext.define("JGrid.store.JGridCStore41", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel41",   
	model: "JGrid.model.JGridCModel41",
	alias : "widget.JGridCStore41",
	storeId:"JGridCStore41",
	id:"JGridCStore41",
	autoLoad: true,
	proxy: {
   		type: "ajax",
<?php
    echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=access_for_name_id&controller=jgrid_security&grid_application_name='.$griditems[0]->grid_application_name.'&format=ajax",';
?>    	
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[41]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[41] = Ext.create("JGrid.store.JGridCStore41");
JGrid.combo_store[41].on('load', function () {
	//JGrid.JGridSecurity.getView().refresh();   
});	

// combo boxs for user access type grid, sheet, or column type
	Ext.define("JGrid.store.JGridCStore42", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel42",   
	model: "JGrid.model.JGridCModel42",
	alias : "widget.JGridCStore42",
	storeId:"JGridCStore42",
	id:"JGridCStore42",
	autoLoad: false,
<?php 	
  	echo' data: [	{"access_type":"1", "Type":"'. JText::_("GRID").'"},
       		{"access_type":"3", "Type":"'. JText::_("GRID_COLUMN").'"},
    		{"access_type":"3", "Type":"'. JText::_("SHEET").'"},
        	{"access_type":"4", "Type":"'. JText::_("SHEET_COLUMN").'"}';
?>         	
 	]//comboData
});
JGrid.combo_store[42] = Ext.create("JGrid.store.JGridCStore42"); 

// combo boxs for access type name
	Ext.define("JGrid.store.JGridCStore43", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel43",   
	model: "JGrid.model.JGridCModel43",
	alias : "widget.JGridCStore43",
	storeId:"JGridCStore43",
	id:"JGridCStore43",
	autoLoad: true,
	proxy: {
   		type: "ajax",
<?php
    echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=access_type_name_id&controller=jgrid_security&grid_application_name='.$griditems[0]->grid_application_name.'&grid_id="+JGrid.gCurrentGridId+"&format=ajax",';
?> 
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[43]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[43] = Ext.create("JGrid.store.JGridCStore43");


// combo boxs for acess level
	Ext.define("JGrid.store.JGridCStore44", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel44",   
	model: "JGrid.model.JGridCModel44",
	alias : "widget.JGridCStore44",
	storeId:"JGridCStore44",
	id:"JGridCStore44",
	autoLoad: false,
<?php 	
  	echo' data: [	{"access_level":"0", "Type":"'. JText::_("JNO_ACCESS").'"},
       				{"access_level":"1", "Type":"'. JText::_("VIEWER").'"},
    				{"access_level":"-1", "Type":"'. JText::_("VIEW_DOWNLOAD").'"},
        			{"access_level":"2", "Type":"'. JText::_("CELL_EDIT").'"},
  					{"access_level":"3", "Type":"'. JText::_("ROW_EDITOR").'"},
       				{"access_level":"4", "Type":"'. JText::_("ADD_DELETE_ROWS").'"},
    				{"access_level":"5", "Type":"'. JText::_("SHEET_MANAGER").'"},
        			{"access_level":"6", "Type":"'. JText::_("ACCESS_MANAGER").'"}';
?>         	
 	]//comboData
});
JGrid.combo_store[44] = Ext.create("JGrid.store.JGridCStore44"); 

// combo boxs for security role or user
	Ext.define("JGrid.store.JGridCStore50", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel50",   
	model: "JGrid.model.JGridCModel50",
	alias : "widget.JGridCStore50",
	storeId:"JGridCStore50",
	id:"JGridCStore50",
	autoLoad: true,
	proxy: {
   		type: "ajax",
<?php	
    echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=read_role_or_user&format=ajax",';
?> 
		reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[50]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[50] = Ext.create("JGrid.store.JGridCStore50");
JGrid.combo_store[50].load();


// combo boxs for security role or user	 
	Ext.define("JGrid.store.JGridCStore411", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel411",   
	model: "JGrid.model.JGridCModel411",
	alias : "widget.JGridCStore411",
	storeId:"JGridCStore411",
	id:"JGridCStore411",
	autoLoad: true,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=access_for_name_id&controller=jgrid_security&format=ajax&access_for=0",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[411]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[411] = Ext.create("JGrid.store.JGridCStore411");

// combo boxs for user access grid, sheet, or column 
	Ext.define("JGrid.store.JGridCStore431", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel431",   
	model: "JGrid.model.JGridCModel431",
	alias : "widget.JGridCStore431",
	storeId:"JGridCStore431",
	id:"JGridCStore431",
	autoLoad: true,
	proxy: {
   		type: "ajax",
<?php
    echo 'url: "index.php?option=com_jgrid&task=access_type_name_id&controller=jgrid_security&grid_application_name='.$griditems[0]->grid_application_name.'&grid_id="+JGrid.gCurrentGridId+"&format=ajax",';
?> 
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[431]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[431] = Ext.create("JGrid.store.JGridCStore431");
	



