<?php
/*
 *  JGridColumns.php in joomla/Components/com_jgrid/r/jgrid/js/app/renderers
 *
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
$user =JFactory::getUser();

// define the grid columns
$current_grid = $columnitems[0]->grid_id;
echo 'JGrid.columns[0]=[';
if($griditems[0]->enable_row_numbers  == true)
{
    echo 'Ext.create("Ext.grid.RowNumberer", {defaultWidth: '. $griditems[0]->number_width .  ',								
		   									  width: '. $griditems[0]->number_width . ',
		   									  minWidth: '. $griditems[0]->number_width . ',
		         							  maxWidth: '. $griditems[0]->number_width . ', 	
    								          layout: "anchor", 
                                              header: "'. $griditems[0]->number_header .  '"}),';
}
else
{
    echo'{dummy: "", 
          hidden: true
          },';
}
$has_filters[0]=false;
for ($i=0, $j=0, $k=0, $n=$columnCount; $i < $n; $i++)	{
	if($columnitems[$i]->grid_id != $current_grid) {
		echo ' ,{id: "editable_line' . $j . '", 
		         header: "'. JText::_("EDITABLE").'",
		         dataIndex: "editable_line",
		         hidden: true,
		         minWidth: 30,
		         maxWidth: 40,
		         width: 40,
		         defaultWidth: 40,
                 xtype: "booleancolumn",
                 align: "center",
                 trueText: "<img src=\"'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_edit.png\" alt=\"Editable\" />",
                 falseText: "",
                 tooltip: "'. JText::_("ROW_EDITABLE_TOOLTIP").'"
	           }';
		echo ' ,{id: "slvl' . $j . '", 
		         header: "Access Level", 
		         dataIndex: "slvl", 
		         hidden: true}';
		echo ' ,{id: "row_color' . $j . '", 
		         header: "Row Color", 
		         dataIndex: "row_color", 
		         hidden: true}';
		echo ' ,{
		          id: "rslvl_id' . $j . '", 
                  header: "'. JText::_("EDIT_USER_ROLE").'",
                  dataIndex: "rslvl_id",
                  tooltip: "'. JText::_("EDIT_USER_ROLE_TOOLTIP").'",
renderer:  function (value) {
			var r = JGrid.combo_store[50].findRecord("rslvl_id", value);
		  	if (Ext.isEmpty(r)) {
	        	return "'. JText::_("VALUE_NOT_FOUND").'";
		  	}
	    	return r.data.role_or_user;
    	},                    
                  
                  editor: JGrid.rslvlCombo['.$j.'],
                  hidden: true
                 }
        ];';
		echo 'JGrid.columnCount[' . $j . ']='.($k-1).';';
		$k=0;		
		$j++;
		$has_filters[$j]=false;
		echo 'JGrid.columns[' . $j . ']=[';
		if($griditems[$j]->enable_row_numbers  == true)
		{
		   echo 'Ext.create("Ext.grid.RowNumberer", {defaultWidth: '. $griditems[$j]->number_width . ',
		   															 width: '. $griditems[$j]->number_width . ',
		   													         minWidth: '. $griditems[$j]->number_width . ', 
		         													 maxWidth: '. $griditems[$j]->number_width . ',
		         													 layout: "anchor", 
                                           header: "'. $griditems[$j]->number_header .  '"}),';
		}
		else
		{
		      echo'{dummy: "", 
                  hidden: true
                 },';
		}
		$current_grid = $columnitems[$i]->grid_id;
	}
	else  if($i != 0) echo ',';
	//count columns k
    $k++;
	echo '{
	id: "'.   $columnitems[$i]->dataindex   .  '",
                        header: "'. $columnitems[$i]->header .  '",
                        dataIndex:"'.$columnitems[$i]->dataindex . '",
                        defaultWidth: '.$columnitems[$i]->width . ',
                        draggable: true,
                        width: '.$columnitems[$i]->width . ',                                     
                        tooltip: "'. $columnitems[$i]->tooltip .  '"';
	
		if($columnitems[$i]->freeze_column == true) {                       
                        echo ',locked: true';
		}
		if($griditems[$j]->enableColumnResize != true) {                       
                        echo ',resizable: false';
		}	
		if($columnitems[$i]->sortable == true) {                       
                        echo ',sortable: true';
		}
		if($columnitems[$i]->summarycolumn == true) {
  			echo ',summaryType:"'.$columnitems[$i]->summarytype.'"';
   			echo ',summaryRenderer: function(value){
    			return Ext.String.format("<b>'.$columnitems[$i]->summaryprefix.' {0} '.$columnitems[$i]->summarypostfix.'</b>",
    			value, value !== 1 ? "s" : "");
   			}';
		}	
		// define field type				
		switch ($columnitems[$i]->data_type)
		{
		    // text
			case 'T':
			// URL
			case 'U':
			// Email
			case 'E':				
			// Grid Sheet
			case 'S':
			// List Box
			case 'L':													
			   echo ',xtype: "gridcolumn"';
		        break;	        
		    // Integer
			case 'I':
			    echo ',xtype: "numbercolumn"';
			    break;
			// Date
			case 'D':
			    echo ',xtype: "datecolumn",
			          format: "'. $columnitems[$i]->validation_type .  '"';
			    break;
		    // Boolean
			case 'B':
			    echo ',xtype: "booleancolumn",
			           align: "center",			           
                       trueText: "'. JText::_("JYES").'",
                       falseText: "'. JText::_("JNO").'"';
			    break;
		    // Float
			case 'F':
			    echo ',xtype: "numbercolumn"';
			    break;
			// Thumbnail Picture
			case 'P':
			   // echo ',xtype: "gridcolumn"';		    	
			    break;			    
			// Unique Row ID
			case 'R':
			    echo ',xtype: "gridcolumn"';		    	
			    break;			    
		}
		if($columnitems[$i]->dfilter == true) {			
			$has_filters[$j]=true;		
		    switch ($columnitems[$i]->data_type)
		    {
			    // text
			    case 'T':
			    // Thumbnail Picture
			    case 'P':
			    // URL
			    case 'U':
				// Email
				case 'E':			    	
			    // Grid Sheet
		    	case 'S':			    				    				    	
			    	echo ',filter: {type: "string"}';
				    break;
				// Integer
			    case 'I':
			    	echo ',filter: {type: "numeric"}';
			    	break;
				// Date
			    case 'D':
			    	echo ',filter: {type: "date"}';
			    	break;
				// Boolean
			    case 'B':
			    	echo ',filter: {type: "boolean"}';
			     	break;
				// Float
			    case 'F':
			    	echo ',filter: {type: "numeric"}';
			    	break;		    	
			    //List Box	
			    case 'L':
			    	//echo ',filter: {type: "list", phpMode: true, options: [], labelField: "listboxvalues"}';
			    	echo ',filter: {type: "list", phpMode: true, labelField: "listboxvalues", store: jgrid_list_box_combo_store_'.$j.'_'.$i.'}';
			    	//echo ',filter: {type: "list", phpMode: true,  options:[{id: "1", listboxvalues: "a"},{id: "2", listboxvalues: "b"}], labelField: "listboxvalues", loadOnShow : true}';			    	
			    	//echo ',filter: {type: "list", phpMode: true, options: []}';
			    break;		    				    				    	
		}
	}

	if($columnitems[$i]->align != ''&&$columnitems[$i]->data_type!='B') {
	  echo ',align: "'.$columnitems[$i]->align.'"';
	}
	if($columnitems[$i]->css != '') {
	  echo ',css: "'.$columnitems[$i]->css.'"';
	}
	// if url type color text blue
    if($columnitems[$i]->validation_type == "url"||($columnitems[$i]->validation_type == "email" && $user->id != 0))
    {    
	     echo ' ,renderer: function(value){
	     	return "<span style=\"color:blue;\">" + value + "</span>"
	     }';
                      
               
    }
    // add editors if editable column eg Jgrid type but not mysql table or formula type
	if($columnitems[$i]->editable == true&&$columnitems[$i]->column_type<2) { 

		switch ($columnitems[$i]->data_type)
		{
			// text
			case 'T':
				// Thumbnail Picture
			case 'P':
				echo ',field: {
											xtype: "textfield",
    										allowBlank: true, 
    										maxLength: 5000 , email_subject: "'. $columnitems[$i]->email_subject .  '"';
				if($columnitems[$i]->validation_type != "none") {                       
           			echo ',vtype: "'. $columnitems[$i]->validation_type .  '"';
		     	}
				echo '}';
				break;
			case 'S':												
				echo ',field: {
											xtype: "textfield",
    										allowBlank: true, 
    										maxLength: 5000';
				if($columnitems[$i]->validation_type != "none") {                       
           			echo ',vtype: "'. $columnitems[$i]->validation_type .  '"';
		     	}
				echo '}';
				break;
			    // URL
			case 'U':
				echo ',field: { xtype: "textfield", allowBlank: true,format: "'. $columnitems[$i]->validation_type .  '"';                      
           		//	echo ',vtype: "url"';
				echo '}';
				break;				
			// Email
			case 'E':								
				echo ',field: { xtype: "textfield", allowBlank: true, maxLength: 254, email_subject: "'. $columnitems[$i]->email_subject .  '"';                      
           			echo ',vtype: "email"';
				echo '}';
				break;					
				// Integer
			case 'I':
				echo ',field: { xtype: "numberfield", allowNegative: true,vtype: "decimal",allowBlank: true}';
				break;
				// Unique Row ID not editable
			case 'R':
				break;				
				// Date
			case 'D':
				echo ',field: { xtype: "datefield", allowBlank: true,format: "'. $columnitems[$i]->validation_type .  '"}';
				break;
				// Boolean
			case 'B':
				echo ',field: { xtype: "checkbox"}';
				break;
				// Float
			case 'F':				
				echo ',field: { xtype: "numberfield", allowNegative: true,vtype: "numeric" ,allowBlank: true}';
				break;			
				// List Box
			case 'L':
	//			echo ',editor: jgrid_list_box_combo_'.$j.'_'.$i.', renderer: Ext.util.Format.comboRenderer(jgrid_list_box_combo['.$j.']['.$i.'])}';
	            echo ',editor: jgrid_list_box_combo_'.$j.'_'.$i;
				break;								
		}
	}    
	// add renderers
	switch ($columnitems[$i]->data_type)
	{
		// text
		case 'T':
		// List Box
		case 'L':		    	
		// Grid Sheet
		case 'S':
			echo ',renderer: function (value){
    				return \'<div style="white-space:normal !important;">\'+ value +\'</div>\';
			}';							
			break;
		// URL
		case 'U': 
			echo ',renderer: function (value){
					var index =value.indexOf("^"); // add ^ url data to url string not visible in cell after ^
					if(index != -1) {
						value = value.substr(0, index);
					}
					
    				return \'<div style="white-space:normal; color:blue; text-decoration: underline !important;">\'+ value +\'</div>\';
			}';	
			break;
		// Email
		case 'E':
			echo ',renderer: function (value){
    				return \'<div style="white-space:normal; color:blue; text-decoration: underline !important;">\'+ value +\'</div>\';
			}';				
			break;				
			
		// Integer
		case 'I':
			if(trim($columnitems[$i]->formula) != '')
			{
				echo ',renderer: function(value, metaData, record, rowIdx, colIdx, store, view)
				{
					return JGrid.formulaCalculator['.$i.'].calculate("'.trim($columnitems[$i]->formula).'",record); 
				}';
			}
			break;
		// Unique Row ID not editable
		case 'R':
				echo ',renderer: function(value, metaData, record, rowIdx, colIdx, store, view)
				{
					return record.data.id; 
				}';
			break;				
		// Date
		case 'D':
			echo ',renderer: Ext.util.Format.dateRenderer("'. $columnitems[$i]->validation_type .  '")';
			break;
		// Boolean
		case 'B':
			break;
		// Float
		case 'F':
			if(trim($columnitems[$i]->formula) != '')
			{
				echo ',renderer: function(value, metaData, record, rowIdx, colIdx, store, view)
				{
					return JGrid.formulaCalculator['.$i.'].calculate("'.trim($columnitems[$i]->formula).'",record); 
				}';
			}				
			break;
		// Thumbnail Picture
		case 'P':
			echo ',renderer: renderThumbnail_'.$j.'_'.$i;
			break;						    								
		}
		echo '}'; // close line		
}
// {id: "T1", header: "Title", dataIndex: 'title',  tooltip : 'COLUMN ID TOOLTIP',editor: title_edit}
echo ' ,{id: "editable_line' . $j . '", header: "'. JText::_("EDITABLE").'",  xtype: "booleancolumn", align: "center",trueText: "<img src=\"'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/table_edit.png\" alt=\"Editable\" />", dataIndex: "editable_line", hidden: true}';
echo ' ,{id: "slvl' . $j . '", header: "Access Level", dataIndex: "slvl", hidden: true}';
echo ' ,{id: "row_color' . $j . '", header: "Row Color", dataIndex: "row_color", hidden: true}';
echo ' ,{
		          id: "rslvl_id' . $j . '", 
                  header: "'. JText::_("EDIT_USER_ROLE").'",
                  dataIndex: "rslvl_id",
 renderer:  function (value) {
			var r = JGrid.combo_store[50].findRecord("rslvl_id", value);
		  	if (Ext.isEmpty(r)) {
	        	return "'. JText::_("VALUE_NOT_FOUND").'";
		  	}
	    	return r.data.role_or_user;
    	},                 
                  tooltip: "'. JText::_("EDIT_USER_ROLE_TOOLTIP").'",
                  editor: JGrid.rslvlCombo['.$j.'],
                  hidden: true
                 } ];';
echo 'JGrid.columnCount[' . $j . ']='.($k-1).';';


echo 'JGrid.columns_access = [{
    header: "'. JText::_("ID").'",
    dataIndex: "id",
    hidden: false,
    tooltip: "'. JText::_("ACCESS_RULE_ID_TOOLTIP").'",
    allowBlank: true
},
{
    header: "'. JText::_("ACCESS_FOR").'",
    dataIndex: "access_for",
    renderer:  function (value) {
            var r = JGrid.combo_store[40].findRecord("access_for", value)
            if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
            }
            return r.data.Type;
    },
    tooltip: "'. JText::_("ACCESS_FOR_TOOLTIP").'"
},
{
    header: "'. JText::_("USER_ROLE_NAME").'",
    dataIndex: "access_for_id",
    renderer: function (value) {
            var r = JGrid.combo_store[41].findRecord("access_for_id", value)
            if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
            }
            return r.data.access_for_name;
    },
    tooltip: "'. JText::_("USER_NAME_TOOLTIP").'"
},
{
    header: "'. JText::_("ACCESS_TYPE").'",
    dataIndex: "access_type",
    renderer: function (value) {
            var r = JGrid.combo_store[42].findRecord("access_type", value)
            if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
            }
            return r.data.Type;
    },
    tooltip: "'. JText::_("ACCESS_TYPE_TOOLTIP").'"
},
{
    header: "'. JText::_("OBJECT_NAME").'",
    dataIndex: "access_type_id",
    renderer: function (value) {
            var r = JGrid.combo_store[43].findRecord("access_type_id", value)
            if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
            }
            return r.data.access_type_name;
    },
    tooltip: "'. JText::_("OBJECT_NAME_TOOLTIP").'",
    width: 200
},
{
    header: "'. JText::_("ACCESS_LEVEL").'",
    dataIndex: "access_level",
    renderer: function (value) {
            var r = JGrid.combo_store[44].findRecord("access_level", value)
            if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
            }
            return r.data.Type;
    },
    tooltip: "'. JText::_("ACCESS_LEVEL_TOOLTIP").'"
},
{
    header: "'. JText::_("USERID_ASSIGNING_ACCESS").'",
    dataIndex: "userid_assigning_access",
    tooltip: "'. JText::_("USERID_ASSIGNING_ACCESS_TOOLTIP").'",
    hidden: true
},
{
    header: "'. JText::_("LAST_UPDATED").'",
    dataIndex: "last_updated",
    tooltip: "'. JText::_("LAST_UPDATED_TOOLTIP").'",
    hidden: true
}];';

?>

  
    