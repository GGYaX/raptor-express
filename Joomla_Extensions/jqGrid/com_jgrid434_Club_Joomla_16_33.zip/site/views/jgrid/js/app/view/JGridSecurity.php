<?php
 /*
 *  JGridSecurity.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');

echo 'Ext.define("JGrid.view.Security", {
	extend : "Ext.window.Window",
	alias : "widget.Security",
	requires : [ "JGrid.view.JGridToolbarSecurity"],
	id: "Security", 
	closeAction: "hide",
	tbar: {xtype: "JGridToolbarSecurity"},		    
	frame: true,
	stripeRows: true,
	enableColumnResize: true,
	columnLines: true,
	layout: "fit",
    autoHeight: true,';
    if($params->get ('jgrid_renderTo'))
    {
   		echo 'renderTo: "'.$params->get ('jgrid_renderTo').'", ';
	} 
  	else echo 'renderTo: "jgrid_component", ';
    if($params->get ('jgrid_access_win_width') > 0)
    {
      echo 'width: '.$params->get ('jgrid_access_win_width').',';
    } 
    else echo 'width: 725,'; 
    if($params->get ('jgrid_access_win_height') > 0)
    {
      echo 'height: '.$params->get ('jgrid_access_win_height').',';
    } 
    else echo 'height: 500,';      
    if($params->get ('jgrid_access_win_x') > 0)
    {
      echo 'x: '.$params->get ('jgrid_access_win_x').',';
    }
    if($params->get ('jgrid_access_win_y') > 0)
    {
      echo 'y: '.$params->get ('jgrid_access_win_y').',';
    }
  	echo 'plain: true,    
	items:  [
	{        
		xtype: "grid", 
   		id: "jgrid_security",
   		layout: "fit",
    	autoHeight: true,	
	  	title: "'. JText::_("MANAGE_USER_ACCESS").'",
	   	tabTip: "'. JText::_("MANAGE_USER_ACCESS_TABTIP").'",
	    beforeRender: function() {
      		JGrid.JGridSecurity = Ext.ComponentMgr.get("jgrid_security");
        },';    	
//	    if($params->get ('jgrid_access_win_width'))
//	    {
//	      echo 'width: '.$params->get ('jgrid_access_win_width').',';
//	    } 
//	    else echo 'width: 700,'; 
//	    if($params->get ('jgrid_access_win_height'))
//	    {
//	      echo 'height: '.$params->get ('jgrid_access_win_height').',';
//	    } 
//	    else echo 'height: 500,'; 
	  	echo '
		store: JGrid.store_access,
	 	columns: JGrid.columns_access	    
	}]                              	
});

';
?>
