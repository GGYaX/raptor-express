<?php
 /*
 *  Config.php  in joomla/Components/com_jgrid/views/jgrid/js/app
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */

// no direct access
defined('_JEXEC') or die('Restricted access');
require_once(JPATH_BASE . '/administrator/components/com_jgrid/os/jgrid/functions.php' );
$user =JFactory::getUser();
// check for joomla version
$version = new JVersion;
$joomla = $version->getShortVersion();
  // if extension is a not a module then set global variables to allow module to see global grid and column data
 if(JRequest::getVar('application_type')!='MODULE')
 {
    $columnitems = $this->columnitems;
    $griditems = $this->griditems;
 }
 $gridCount = count($griditems);
 $columnCount = count($columnitems);
// set express installswf property 
echo 'Ext.flash.Component.EXPRESS_INSTALL_URL = "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/expressInstall.swf";'; 


?>


// add a row to the jgrid
var FIRSTROWW = 1;			
var ADD_ROW_ABOVEE = 2;
var ADD_ROW_BELOWW = 3;

JGrid = {
 	 // Define global JGrid varibles
 	grids: new Array(),
 	formulaCalculator: new Array(),
  	columns: new Array(),
  	store: new Array(),
	dsModel: new Array(),
	dsCModel: new Array(),
    dsDocumentModel: new Array(),
    dsComboModel: new Array(),
    ds_model_access: new Array(),
    documentStore: new Array(),
    columnCount: new Array(),
    editMode: new Array(),
    rslvlCombo: new Array(),
    editor: new Array(),
    proxy: new Array(),
    combo_store: new Array(),
    thumbnailImage:new Array(),
    csvUpload: new Array(),
    csvDownload: new Array(), 
    documentIdStack: new Array(),
    lastGridIdStack: new Array(),
    crossGridIdRef: new Array(),
    crossReturnButtonIdRef: new Array(),
    help: new Array(),
    copy: new Array(),
    searchstring: new Array(),
    dslvl: new Array(),
    selectType: new Array(),
    primary_key_column: new Array(),
    proxy_access: '',
    store_access: '',
    HelpAccess: '',
    columns_access: '',
    JGridSecurity: '',
    JGridSecurityWin: '',
    JGridAccessRules: '',
    row_rslvl_combo: '',
    application_name: '',
    application_id: 0,
    row_edit_enabled: new Array(),
<?php    
    echo 'cacheState: new Array('.$gridCount.'),
    gridCount: '.$gridCount.',
    sender_name: "'.$user->name.'", 
    sender_email: "'.$user->email.'", 
 	flash_url: "",';
    if($user->id == 0) echo 'public_user: true,';
    else echo 'public_user: false,';
?>  
    selectedGridId: 0,
    gCurrentGridId: 0,
    initialize: false,
	currentEditGrid: '',
	thumbnail_win: '',
	chartObj: '',
	image_win: '',
	flash_win: '',
	email_win: '',
	email_form: '',
	upload_win: '',
	download_win: '',
	data_downloader: '',
	data_loader: '',
	thumbnail_loader: '',
	user_role_store: '',
	JGridGridSettings: '',
  
  
  
  
  // add a row to the jgrid
  add_row: function (add_row_direction, jgrid_id, id, jgridindex) {
	var pgrid = Ext.ComponentMgr.get(id);
    var sm = pgrid.getSelectionModel();
    currenteditgrid = pgrid;
    var current_row_count = pgrid.store.getCount();
    var transaction_id = FIRSTROWW;
    var selection_data_id = 1;
    var new_row_location = 0;
    if (current_row_count === 0) 
    {
        var transaction_id = FIRSTROWW;
    } else {
        if (sm.hasSelection()) {
            var sel = sm.getSelection();
            var selectedRowIndex = sm.lastSelected.index; // from exjs but only accurate for first row
            var selection_data_id =  sel[0].get('id');
            if(selection_data_id == '' || selection_data_id == 0) {
<?php 
			echo 'Ext.Msg.alert("'. JText::_("PLEASE").'", "'. JText::_("WAIT_FOR_PREVIOUS_INSERT_TO_COMPLETE").'");';
?>
		    	return;
            }
            // find index, extjs index is not accurate
            for(var i=0;i < current_row_count; i++){ 
                if(sel[0].data.id == pgrid.store.data.items[i].data.id) {  // search for correct selected index
                    selectedRowIndex = i;
                    break;
                }
               }               

            if (add_row_direction === ADD_ROW_BELOWW) {
                if (sel[0].data.id == "") 
                {
                   transaction_id = FIRSTROWW;
                }   
                else {              
                        transaction_id = ADD_ROW_BELOWW;
                        if(selectedRowIndex) {
                          new_row_location = selectedRowIndex +1 ;
                        } else {
                        	new_row_location = current_row_count -1;
                        }
               }     
            } 
            else 
            {
                // add row above
                if (sel[0].data.id == "") 
                {
                    transaction_id = FIRSTROWW;
                }    
                else 
                {
                        transaction_id = ADD_ROW_ABOVEE;
                        if(selectedRowIndex) {
                          new_row_location = selectedRowIndex;
                        } else {
                        	new_row_location = current_row_count -1;
                        }
                }
            }
            <!-- pgrid.getView().refresh(); -->
        } 
        else
        {
<?php 
			echo 'Ext.Msg.alert("'. JText::_("PLEASE").'", "'. JText::_("SELECT_ROW_BEFORE_ADD").'");';
?>
		    	return;
		}
	 }
<?PHP
     for ($j=0 , $n=$gridCount; $j < $n; $j++)
     {	 

             
        echo 'if(jgridindex==='.$j.')
        {
           // JGrid.editor['.$j.'].stopEditing();       
     	    jgrid_newrowcolumns'.$j.'(pgrid,
                                      new_row_location,
                                      "",
                                      selection_data_id,
                                      transaction_id,
                                      jgrid_id);
           pgrid.getView().refresh();
           sm.select(new_row_location);                                                                                                          
           //JGrid.editor['.$j.'].startEdit(new_row_location);
       }';
     } 
?>    		    
  }
};

// remove a row from the jgrid
function jgrid_remove_row(jgrid_id, id) {
    var pgrid = Ext.ComponentMgr.get(id);
    JGrid.currentEditGrid = pgrid;
    var sm = pgrid.getSelectionModel();   
    var transaction_id = 5;
    //pgrid.stopEditing();
    pgrid.getView().refresh(); 
    if (sm.hasSelection()) {
        var sels = sm.getSelection();
    	// If row not editable for at least one row then return
    	for(var i = 0, editable_lines = false; i < sels.length; i++){ 
	    	if(sels[i].data.editable_line==true)
	    	{    
	       		editable_lines = true;
	    	}
    	}
    	if(editable_lines==false) return(false);
    	var remove_sels = new Array();
        Ext.Msg.show({
            title: "Remove Row",
            buttons: Ext.MessageBox.YESNOCANCEL,
            msg: "Remove Selected Rows?",
            fn: function (btn) {
                if (btn == "yes") {           
                    // Multiple row delete
                    for(var i = 0, j = 0; i < sels.length; i++){ 
                       	r = sels[i];
                     	if(r.data.editable_line==true)
	    				{    
	    				    remove_sels[j] = r;
	    				    j++;     
                       	}
                    }
                    pgrid.getStore().remove(remove_sels); 
                    pgrid.getView().refresh();             
                }
           }
        });
    } else
    {
<?php           
         echo 'Ext.MessageBox.alert("'.JText::_("PLEASE").'", "'.JText::_("SELECT_ROW_TO_REMOVE").'");';
?>    
    }
}


// Create a new sheet etc document for this grid old
function jgrid_create_document(jgrid_id, id, document_id_stack, array_index) {
    var pgrid = Ext.ComponentMgr.get(id);
    Ext.Msg.prompt(
<?php           
        echo '"'.JText::_("CREATE_NEW_SHEET").'",
             "'.JText::_("PLEASE_ENTER_NEW_DOCUMENT_NAME").'",';
?>         
            function (btn, text) {
            if (btn == "ok") {
                var last_document_id = document_id_stack[document_id_stack.length - 1];
                var new_document_name = Ext.util.Format.stripTags(text);
                 Ext.Ajax.request({
<?php           
                                echo 'waitMsg: "'.JText::_("CREATING_SHEET").'",';
            
                     echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=create_document&controller=jgrid_documents&format=ajax",';
?>                     
                     params: {
                         task: "create_document",
                         option: "com_jgrid",
                         grid_id: jgrid_id,
                         last_document_id: last_document_id,
                         new_document_name: new_document_name
                     },
                     method: "POST",
                     failure: function (response, options) {
<?php 
                            echo 'Ext.MessageBox.alert("'. JText::_("CREATE_FAILED").'", "'. JText::_("SHEET_CREATE_WAS_NOT_SUCCESSFULL").'");';
?> 
                     },
                     success: function (response, options) {
                         var server_response = Ext.decode(response.responseText);
                         if (!server_response.success) {                                                      
<?php 
                            echo 'Ext.MessageBox.alert("'. JText::_("CREATE_FAILED").'", "'. JText::_("SHEET_CREATE_WAS_NOT_SUCCESSFULL").'");';
?>
                                        
                         } else {
                             var new_document_id = parseInt(server_response.rows.new_document_id);
                             var combo_record = 	{id: new_document_id, 
                                                	document_title: new_document_name};						
                            JGrid.documentStore[array_index].add(combo_record);
                             var documentid=id + "_document";
                             var new_document_title = JGrid.documentStore[array_index].findRecord("id", new_document_id).data.document_title;						                          
                             Ext.ComponentMgr.get(documentid).setValue(new_document_title);
                             document_id_stack.push(new_document_id);
                          	pgrid.store.reload({
	                          	params: {
	                                     new_document_id: new_document_id,
	                                     last_document_id: last_document_id
	                    		}
                        	});
                         }
                },
                scope: this
              });
            }
       });
}

// Create a new sheet etc document for this grid new
function jgrid_create_grid_document(jgrid_id, id, document_id_stack, array_index,new_document_name)
{
     var pgrid = Ext.ComponentMgr.get(id);
	 var last_document_id = document_id_stack[document_id_stack.length - 1];
               var new_document_name = Ext.util.Format.stripTags(new_document_name);
                 Ext.Ajax.request({
				 <?php           
                              echo 'waitMsg: "'.JText::_("CREATING_SHEET").'",';		            
		                     echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=create_document&controller=jgrid_documents&format=ajax",';
			      ?>                     
                     params: {
                         task: "create_document",
                         option: "com_jgrid",
                         grid_id: jgrid_id,
                         last_document_id: last_document_id,
                         new_document_name: new_document_name
                     },
                     method: "POST",
                     failure: function (response, options) {
						<?php 
						     echo 'Ext.MessageBox.alert("'. JText::_("CREATE_FAILED").'", "'. JText::_("SHEET_CREATE_WAS_NOT_SUCCESSFULL").'");';
						?> 
                     },
                     success: function (response, options) {
                         var server_response = Ext.decode(response.responseText);
                         if (!server_response.success) {                                                      
							<?php 
							      echo 'Ext.MessageBox.alert("'. JText::_("CREATE_FAILED").'", "'. JText::_("SHEET_CREATE_WAS_NOT_SUCCESSFULL").'");';
							?>                                        
                         } else {
                             var new_document_id = parseInt(server_response.rows.new_document_id);
                             var combo_record = 	{id: new_document_id, 
                                                	document_title: new_document_name};						
                           
                             JGrid.documentStore[array_index].add(combo_record);
                             var documentid=id +"_document";
                             var new_document_title = JGrid.documentStore[array_index].findRecord("id", new_document_id).data.document_title;						                                                   
                             Ext.ComponentMgr.get(documentid).setValue(new_document_title);
                             Ext.ComponentMgr.get(documentid).setRawValue(new_document_name);
                             document_id_stack.push(new_document_id);
                          	 pgrid.store.reload({
	                          	params: {
	                                     new_document_id: new_document_id,
	                                     last_document_id: last_document_id
	                    		}
                        	});
                         }
                },
                scope: this
              });
}



// remove a document from the jgrid and child grid if exists
function jgrid_remove_document(jgrid_id, id, document_id_stack, array_index) {
    var pgrid = Ext.ComponentMgr.get(id);
    
    Ext.Msg.show({
<?php           
        echo 'title: "'.JText::_("DELETE_CURRENT_SHEET").'",
        tooltip: "'. JText::_("DELETE_CURRENT_SHEET_TOOLTIP").'",    
        buttons: Ext.MessageBox.YESNOCANCEL,          
        msg: "'.JText::_("REMOVE_CURRENT_SHEET").'",';
?>         
        fn: function (btn) {
            if (btn == "yes") {
                var last_document_id = document_id_stack.pop();
                var new_document = document_id_stack[document_id_stack.length - 1];
                var previous_document = document_id_stack[document_id_stack.length - 2];
                if(!new_document) new_document=0;
                if(!previous_document) previous_document=0;

              Ext.Ajax.request({
<?php           
                                echo 'waitMsg: "'.JText::_("DELETING_SHEET").'",';
            
                echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=remove_document&controller=jgrid_documents&format=ajax",';
?>               
                params: {
                    task: "remove_document",
                    option: "com_jgrid",
                    grid_id: jgrid_id,
                    last_document_id: last_document_id,
                    new_document_id: new_document,
                    previous_document_id: previous_document
                },
                method: "POST",
                failure: function (response, options) {
                    document_id_stack.push(last_document_id);
<?php                    
                   echo 'Ext.Msg.alert("'. JText::_("LAST_DOCUMENT_CAN_NOT_BE_DELETED").'", "'. JText::_("FIRST_CREATE_A_NEW_DOCUMENT_THEN_CURRENT_DOCUMENT_DELETABLE").'");';
?>               
                },
                success: function (response, options) {
                    var server_response = Ext.decode(response.responseText);
                    if (!server_response.success) {
                        document_id_stack.pop();                                            
<?php 
                       echo 'Ext.MessageBox.alert("'. JText::_("SHEET_CAN_NOT_BE_DELETED").'", "'. JText::_("DELETE_DATA_AND_OR_CREATE_A_NEW_SHEET").'");';
?>                                         
                    } else {
                        var new_document_id = parseInt(server_response.rows.new_document_id);
                        var new_document_title = JGrid.documentStore[array_index].findRecord("id", new_document_id).data.document_title;
						var documentid=id + "_document";
                        Ext.ComponentMgr.get(documentid).setValue(new_document_title);
                        if(new_document_id!=document_id_stack[document_id_stack.length - 1]) document_id_stack.push(new_document_id);
                        var previous_document = document_id_stack[document_id_stack.length - 2];
                        if(!previous_document) previous_document=0;
                        pgrid.store.reload({
                          params: {
                                     new_document_id: new_document_id,
                                     last_document_id: previous_document
                                  }
                        }); 
                        JGrid.documentStore[array_index].load();         
                    }
                },
                scope: this
            });
          }  

        }
    });

}
					
// Make a copy of document from the jgrid and child grid if exists
function jgrid_copy_document(jgrid_id, id, document_id_stack, array_index) {
    var pgrid = Ext.ComponentMgr.get(id);
    Ext.Msg.prompt(
<?php           
        echo '"'.JText::_("MAKE_A_COPY_OF_CURRENT_SHEET").'",
             "'.JText::_("PLEASE_ENTER_NEW_DOCUMENT_NAME").'",';
?>         
            function (btn, text) {
            if (btn == "ok") {
                var last_document_id = document_id_stack[document_id_stack.length - 1];
                var new_document_name =  Ext.util.Format.stripTags(text);
                 Ext.Ajax.request({
<?php           
                                echo 'waitMsg: "'.JText::_("COPYING_SHEET").'",';
            
                     echo' url: "'.JURI::base().'index.php?option=com_jgrid&task=copy_document&controller=jgrid_documents&format=ajax",';
?>                     
                     params: {
                         task: "copy_document",
                         option: "com_jgrid",
                         grid_id: jgrid_id,
                         last_document_id: last_document_id,
                         new_document_name: new_document_name
                     },
                     method: "POST",
                     failure: function (response, options) {
<?php 
                            echo 'Ext.MessageBox.alert("'. JText::_("COPY_FAILED").'", "'. JText::_("SHEET_COPY_WAS_NOT_SUCCESSFULL").'");';
?> 
                     },
                     success: function (response, options) {
                         var server_response = Ext.decode(response.responseText);
                         if (!server_response.success) {                                                      
<?php 
                            echo 'Ext.MessageBox.alert("'. JText::_("COPY_FAILED").'", "'. JText::_("SHEET_COPY_WAS_NOT_SUCCESSFULL").'");';
?>
                                        
                         } else {
                             var new_document_id = parseInt(server_response.rows.new_document_id);
                             var combo_record = {id:	new_document_id, 
                                                 document_title: new_document_name};						
                             JGrid.documentStore[array_index].add(combo_record);
                             var documentid=id + "_document";
                             var new_document_title = JGrid.documentStore[array_index].findRecord("id", new_document_id).data.document_title;						
                             Ext.ComponentMgr.get(documentid).setValue(new_document_title);                           
                             document_id_stack.push(new_document_id);
                             pgrid.store.reload( {
								params: {
                                     new_document_id: new_document_id,
                                     last_document_id: last_document_id
                                }     
                    		});	
                         }
                },
                scope: this
              });
            }
       });
}
		
// Rename document from the jgrid and child grid if exists
function jgrid_rename_document(jgrid_id, id, document_id_stack, array_index) {
    var pgrid = Ext.ComponentMgr.get(id);
    Ext.Msg.prompt(
<?php           
        echo '"'.JText::_("RENAME_CURRENT_SHEET").'",
             "'.JText::_("PLEASE_ENTER_NEW_DOCUMENT_NAME").'",';
?>               
            function (btn, text) {
            if (btn == "ok") {                
              var last_document_id = document_id_stack[document_id_stack.length - 1];
              var new_document_name = Ext.util.Format.stripTags(text);           
              Ext.Ajax.request({
<?php           
                                echo 'waitMsg: "'.JText::_("RENAMING_SHEET").'",';
            
                echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=rename_document&controller=jgrid_documents&format=ajax",';
?>                
                params: {
                    task: "rename_document",
                    option: "com_jgrid",
                    grid_id: jgrid_id,
                    last_document_id: last_document_id,
                    new_document_name: new_document_name
                },
                method: "POST",
                failure: function (response, options) {  
<?php 
                    echo 'Ext.MessageBox.alert("'. JText::_("RENAME_FAILED").'", "'. JText::_("LAST_DOCUMENT_CAN_NOT_BE_RENAMED").'");';
?>                                 
                },
                success: function (response, options) {
                    var server_response = Ext.decode(response.responseText);
                    if (!server_response.success) {
<?php 
                       echo 'Ext.MessageBox.alert("'. JText::_("RENAME_FAILED").'", "'. JText::_("LAST_DOCUMENT_CAN_NOT_BE_RENAMED").'");';
?>                                         
                    } else {
                        // rename current document
                         var current_record = JGrid.documentStore[array_index].findRecord("id", last_document_id);
                         current_record.data.document_title=new_document_name;                     
                         var documentid=id + "_document";
                         Ext.ComponentMgr.get(documentid).setValue(new_document_name);
       
                    }
                },
                scope: this
            });
         }
     });
}

// set access of grid and sheets
function set_access_levels(grid_id,grid_reference_id,Manage_Sheet_Access,Manage_Sheets,Add_Row_Above,Edit_Row,edit_mode)
{
    var grid_columns = Ext.ComponentMgr.get(grid_reference_id).columns;
    var current_grid = Ext.ComponentMgr.get(grid_reference_id);
    access_level = JGrid.dslvl[grid_id];
    if(!access_level) // error fix
    {
     access_level = "1";
    }
    access_level_array = access_level.split("_");
     //check for creator user id edits by administrator
    if (access_level==6)
    {
       grid_columns[JGrid.columnCount[grid_id]+5].show();
    }
    else
    {
      grid_columns[JGrid.columnCount[grid_id]+5].hide();
    }
    // set all columns to not editable if sheet access_level less than 2 
    if(access_level_array[0] < "3" ||edit_mode==true) 
    {
        grid_columns[JGrid.columnCount[grid_id]+2].hide();
        if(JGrid.row_edit_enabled[grid_id]==true)
        {
        	
        	if(current_grid.editingPlugin.editor)
        	{
		        for(var i=1;i < current_grid.editingPlugin.editor.query("textfield").length;i++)
		        {   
		        	current_grid.editingPlugin.editor.query("textfield")[i].setDisabled(true);
					// grid_columns.setEditable(i,false);
		        }
	       	}
	    }
	    else
	    {
			// first set all columns disabled
	     	for(i=1; i < grid_columns.length; i++)
	    	{
	      		grid_columns[i].setDisabled(true);	
	  		}
	    }
        if(access_level_array[0]=="2")
        {
        	grid_columns[JGrid.columnCount[grid_id]+2].show();
        }
    }
    // set access level of all columns as editable except image columns
    else
    { 
    	grid_columns[JGrid.columnCount[grid_id]+2].show();
    	if(current_grid.editingPlugin.editor)
    	{
	        for(var i=1;i < current_grid.editingPlugin.editor.query("textfield").length;i++)
	        {   
	        	textfield =  current_grid.editingPlugin.editor.query("textfield")[i];
	             if(textfield.name.substr(0,1)=="P")
	             {
	             	current_grid.editingPlugin.editor.query("textfield")[i].setDisabled(true);
	    			 //grid_columns.setEditable(i,false);
	             }
	             else
	             {
	             	current_grid.editingPlugin.editor.query("textfield")[i].setDisabled(false);
	     			//grid_columns.setEditable(i,true);
	             }
	        }	        
        }
        else
        {
			for(i=1; i < grid_columns.length; i++)
	     	{
	            if(grid_columns[i].dataIndex.substr(0,1)=="P")
	            {
		        	grid_columns[i].setDisabled(true);
				}
				else
				{
					grid_columns[i].setDisabled(true);
				}			                			
			}
        }            
    }
    // look for column rules that remove edit rights to this sheet for current user and disable edit
    for(var i=1;i< access_level_array.length;i++)
    {
        if(access_level_array[i].substr(0,1)=="V") {
        	if(current_grid.editingPlugin.editor)
    		{
        		current_grid.editingPlugin.editor.query("textfield")[getIndexById(access_level_array[i].substr(1))].setDisabled(true);
 			}
<!-- 			else-->
<!-- 			{-->
<!-- 			}-->
 			//grid_columns.setEditable(grid_columns.getIndexById(access_level_array[i].substr(1)),false);
        }
    }
    if(access_level_array[0]<"4"||edit_mode==false)
    {
         Ext.ComponentMgr.get(Edit_Row).hide();
    }
    else
    {
        Ext.ComponentMgr.get(Edit_Row).show();     
    }
    if(access_level_array[0]<"4"||edit_mode==false||JGrid.selectType[grid_id]>1)
    {
         Ext.ComponentMgr.get(Add_Row_Above).hide();
    }
    else
    {
        Ext.ComponentMgr.get(Add_Row_Above).show();     
    }
    if(access_level_array[0]<"5"||edit_mode==false)
    {
         Ext.ComponentMgr.get(Manage_Sheets).hide();
    }
    else
    {
        Ext.ComponentMgr.get(Manage_Sheets).show();     
    }
    if(access_level_array[0]<"6"||edit_mode==false)
    {
    	grid_columns[JGrid.columnCount[grid_id]+5].hide();
<?php       
  		if($fversion == 0) 
  		{      
  			echo 'Ext.ComponentMgr.get(Manage_Sheet_Access).hide();';
  		}
?>       
	}
<?php   
	if($fversion == 0)
	{     
	    echo 'else
	    {
	   
	       grid_columns[JGrid.columnCount[grid_id]+2].show();       
	       Ext.ComponentMgr.get(Manage_Sheet_Access).show();       
	  
	    }';	    
	}
?>
   return access_level_array;
}






    
<?php

    if($params->get ('jgrid_image_win_width'))
    {
      echo 'JGrid.thumbnailImage["width"]='.$params->get ('jgrid_image_win_width').';';
    } 
    else echo 'JGrid.thumbnailImage["width"]=490;'; 
    if($params->get ('jgrid_image_win_height'))
    {
      echo 'JGrid.thumbnailImage["height"]='.$params->get ('jgrid_image_win_height').';';
    } 
    else echo 'JGrid.thumbnailImage["height"]=650;';
    
//JError::raiseError(10015,$columnCount);
//return;    
    // create the columns and defaults for new rows
$current_grid = $columnitems[0]->grid_id;
for ($i=0, $j=0, $n=$columnCount; $i < $n; $i++)
{
	if($i===0 || $columnitems[$i]->grid_id != $current_grid )
	{
		if($columnitems[$i]->grid_id != $current_grid) {
			
			echo '	,editable_line: 1
      				,slvl: 3
      				,rslvl_id: "D"}); pgrid.getView().refresh();}';
			$j++;
			$current_grid = $columnitems[$i]->grid_id;
		}
		echo 'function jgrid_newrowcolumns'.$j.'(pgrid,
		                                         new_row_location,
		                                         new_row_number,
		                                         selection_data_id,
		                                         transaction_id,
		                                         jgrid_id)
	          {
		          JGrid.proxy['.$j.'].api.create = "'.JURI::base().'index.php?option=com_jgrid&task=create&format=ajax&selected_row_number="+selection_data_id+"&row_insert_position="+transaction_id+"&grid_id="+jgrid_id;               
		          pgrid.getStore().insert(new_row_location, { ';	        
	}
	else if ($i!=0) echo ',';
	echo $columnitems[$i]->dataindex . ':';
	if($columnitems[$i]->data_type == 'I' || 'B') echo '"'.$columnitems[$i]->ddefault.'"';
	else echo $columnitems[$i]->ddefault;	// for T D F
};
if($i!=0)
{ 
echo ',editable_line: 1
      ,slvl: 3
      ,rslvl_id: "D"});
  pgrid.getView().refresh();}';
}    


?>


  // set row color	
  function set_row_color( row, index, rowParams, store) {
		color_code = row.data.row_color;
		if (color_code == "" || color_code == null) {
			return "";
			// return "green-row";
		} else {
			var current_color_array = color_code.split("~", 3);
			cssname = 'css' + current_color_array[0];
			if (!Ext.util.CSS.getRule(cssname)) {
			    var cssDef = '.' + cssname + ' .x-grid-cell{ background-color: #' + current_color_array[0] + '; }';
				Ext.util.CSS.createStyleSheet(cssDef);
				if (current_color_array[1] != '' && current_color_array[2] != '') {
					var selCssDef = '.x-grid-row-selected.' + cssname + ' { background-color: #' + current_color_array[2] + ' !important; color: #'
							+ current_color_array[1] + '; }';
					Ext.util.CSS.createStyleSheet(selCssDef);
				}
			}
			return cssname;
		}
  };

Ext.util.Format.comboRenderer = function (combo) {
    return function (value) {
        var record = combo.findRecord(combo.valueField, value);
        return record ? record.get(combo.displayField) : combo.valueNotFoundText;
    }
};




//joomla template css fixes
Ext.util.CSS.createStyleSheet(".x-grid3-cell-inner {white-space:normal;}"); //RMS???

<?php
   //echo 'Ext.ux.GridPrinter.stylesheetPath = "'.JURI::base().'administrator/components/com_jgrid/os/ext/ux/stylesheets/print.css";';
   if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
   {
    if($params->get ('joomla16_template_fix')<2)
    {
    // eliminiat multiple lines between grid rows
      echo 'Ext.util.CSS.updateRule(".x-grid3-row", "border", "0px solid");
      Ext.util.CSS.updateRule("#main ul", "list-style-type", "none");'; // Remove black tab boxes on firefox update layout.css (line 495) from Joomla template 
    }
   }

   
?>

function add_access_menu() {
	if(!JGrid.JGridAccessRules)
  	{
 		JGrid.JGridAccessRules = Ext.create("JGrid.view.JGridAccessRules");
   	}
  	JGrid.JGridAccessRules.show();
	Ext.ComponentMgr.get("formpanel3").getForm().setValues({
         'access_rule_id': ''
     });
     JGrid.selectedgridid=0;
     combo40.clearValue();
     combo411.clearValue();
     combo42.clearValue();
     combo431.clearValue();
     combo44.clearValue(); 
}



function edit_access_menu() {
	var sm = JGrid.JGridSecurity.getSelectionModel();
	if (sm.hasSelection()) {
		var sel = sm.getSelection();
	    JGrid.selectedgridid = sel[0].get('id'); 
	    if(!JGrid.JGridAccessRules)
	  	{
	 		JGrid.JGridAccessRules = Ext.create("JGrid.view.JGridAccessRules");
	   	}
	  	JGrid.JGridAccessRules.show();	    
	   	if (JGrid.selectedgridid) {
			if(record = JGrid.store_access.findRecord("id", JGrid.selectedgridid))
		 	{
				Ext.ComponentMgr.get("formpanel3").getForm().setValues({
	         		'access_rule_id': JGrid.selectedgridid
	       		});
				combo40.setValue(String(record.get("access_for")));
	       		combo411.setValue(String(record.get("access_for_id")));
	       		combo42.setValue(String(record.get("access_type")));
			  	combo431.setValue(String(record.get("access_type_id")));
			 	combo44.setValue(String(record.get("access_level")));
	  		}
	     	//Ext.ComponentMgr.get("formpanel3").form.title = 'Edit Access Rule '+JGrid.selectedgridid;
		}
	}
	else 
	{
<?php 
		echo 'Ext.MessageBox.alert("'. JText::_("PLEASE").'", "'. JText::_("SELECT_RULE_FIRST_TO_MODIFY_SETTINGS").'");';
?>    
	}  
}


// create flash window
function create_flash_window() {

	var flashwindow = Ext.create("Ext.window.Window", {
		alias : "widget.JGridFlashWin",
		id: "JGridFlashWin",
		loadMask: true,
	    closeAction: "destroy",
	    resizable: true, 
	    minimizable: true,
	     style: {
	            ZIndex:100001
	        },
	    width: JGrid.thumbnailImage["width"]+5,
	    height: JGrid.thumbnailImage["height"]+5, 
	    maximizable: true,
<?php	
		  if($params->get ('jgrid_renderTo'))
		  {
		 	echo 'renderTo: "'.$params->get ('jgrid_renderTo').'", ';
		  } 
		  else echo 'renderTo: "jgrid_component",';
	      echo 'title: "'.JText::_("URL").'",';     
	      if($params->get ('jgrid_image_win_x'))
	      {
	        echo 'x: '.$params->get ('jgrid_image_win_x').',';
	      } 
	      else echo 'x: 35,'; 
	      if($params->get ('jgrid_image_win_y'))
	      {
	        echo 'y: '.$params->get ('jgrid_image_win_y').',';
	      } 
	      else echo 'y: 100,';
?>          
	     items: [{
	        xtype: "flash",
	        id: "flash_win_id",
	        wmode: "transparent",
	        pinned:true,
	        expressInstall: true,
	        preserveRatio: true,
	        fit: true,
<?php        
	      // echo 'url: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid//noite.swf",';
	      echo 'url: JGrid.flash_url,';
?>        
	      // width: JGrid.thumbnailImage["width"], 
	       //height: JGrid.thumbnailImage["height"]
	        height: "100%"
	    }],
	    buttons: [{
	      id: "go_to_url2",
<?php      
	      echo 'text: "'.JText::_("GO_TO_URL").'",';
?>	
	      handler: function(){ 
	        window.open(JGrid.thumbnailImage["hyper_url"], "image_window");            
	      }                                           
	     },
	     {
	       id: "go_to_sheet2",
<?php              
	       echo 'text: "'.JText::_("GO_TO_SHEET").'",';
?>       	
	       handler: function(){
	       
	         new_document_array = JGrid.thumbnailImage["hyper_grid_sheet"].split("-");
	         new_grid_id = "Grid-"+new_document_array[0];
	         new_grid_index = JGrid.crossGridIdRef[new_grid_id];
	         current_document_id_stack=JGrid.documentIdStack[new_grid_index];
	         new_document_id = new_document_array[1];
	         last_document_id = 0;
	         grid_tabpanel  = Ext.ComponentMgr.get("grid_tabpanel");
	         if (new_document_id==0||new_document_id==null) {
	            current_document_id_stack.push(last_document_id);
<?php            
	            echo 'Ext.Msg.alert("'. JText::_("GRID_SHEET_NOT_FOUND").'", "'. JText::_("THIS_HYPER_LINK_IS_NOT_ACTIVE_PLEASE_CONTACT_YOUR_ADMINISTRATOR").'");';
?> 
	            return;
	         }
	         else {
	           	grid_tabpanel.setActiveTab(new_grid_id);
	            last_document_id = current_document_id_stack[current_document_id_stack.length - 1];
	            current_document_id_stack.push(new_document_id);
	         }
	         last_grid_id_stack.push(JGrid.thumbnailImage["grid_reference_id"]);
	         Ext.ComponentMgr.get(new_grid_id).store.reload({
	            params: {
	              new_document_id: new_document_id,
	              last_document_id: last_document_id
	            }
	         });
	         Ext.ComponentMgr.get(cross_return_button_id_ref[new_grid_index]).show();
	         image_win.hide();
	       }                                           
	     }
<?php      
	   if($params->get('allow_image_download',1)==1)
	   {         	
	     echo ',{
	            id: "download_button2",
	           
	            text: "'.JText::_("DOWNLOAD_FLASH_FILE").'" ,	
	            handler: function(){              
	            	window.open( "'.JURI::base().'index.php?option=com_jgrid&task=download_images&controller=jgrid_images&format=ajax&grid_id="+JGrid.thumbnailImage["grid_id"]+"&document_id="+JGrid.thumbnailImage["document_id"]+"&column_id="+JGrid.thumbnailImage["column_id"]+"&row_id="+JGrid.thumbnailImage["row_id"]+"");  
	            }                                           
	    }';        
	   }
?>     
	 ]});
 	return (flashwindow);
 }

// show email window
function show_email_window() {

	if(!JGrid.email_win)
	{
		JGrid.email_win = Ext.create("JGrid.view.JGridEmailWin");
		JGrid.email_form = Ext.getCmp("JGridEmailFm");	
	} 
	//Ext.getCmp("email_win_id").load(img_path);
	var emailform = JGrid.email_form.getForm();
	emailform.findField("email_to_address").setValue(JGrid.thumbnailImage["email"]); 
 	if(!emailform.findField("email_from_address").getValue()) emailform.findField("email_from_address").setValue(JGrid.sender_email);
  	if(!emailform.findField("email_from_name").getValue()) emailform.findField("email_from_name").setValue(JGrid.sender_name); 
	// if(!emailform.findField("email_subject_name").getValue()) emailform.findField("email_subject_name").setValue(JGrid.thumbnailImage["email_subject"]);
	emailform.findField("email_subject_name").setValue(JGrid.thumbnailImage["email_subject"]);  
    						    	                 
	JGrid.email_win.show();
 	return true;
 }

// replace wildcards with column data in email_subject and URL strings
function insertColumnData(data, record) {
	var updatedData = data;
	if(updatedData.indexOf("@!ROWID") != -1) {
		updatedData = updatedData.replace("@!ROWID", String(record.data.id));
	}
	var ptr = updatedData;
	while(ptr.indexOf("@!") != -1) {
		var index = ptr.indexOf("@!");
		var columnId = ptr.substr(index+2, 1);
		var i = 0;
       	while(!isNaN(ptr[index+3+i])) {
          	columnId += ptr[index+3+i];
			i++;
			if(i >= 6) break;
		}
		ptr = ptr.substr(index+2); // skip for next loop if not replaced
		if(columnId.length < 6) {
			if(record.data[columnId]) {
				updatedData = updatedData.replace("@!"+columnId, record.data[columnId]);
			}
		}
	}
	if(updatedData) {
		return updatedData;
	} else {
		return data;
	}
}
