<?php
/**
 * Jgrid_view.ajax View in
 *  Joomla/Components/Views/jgrid
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
//defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view' );


/**
 * Jgrid_ajax View
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid "sheets" screens
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */

if(!class_exists('RMWorksAroundJoomlaToGetAView')) {
	if(interface_exists('JView')) {
		abstract class RMWorksAroundJoomlaToGetAView extends JViewLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAView extends JView {}
	}
}

class jgridViewjgrid extends RMWorksAroundJoomlaToGetAView
{
	/**
	 * The column data values from column data assigned to the view from the controller
	 * @var columndata_values
	 * @var integer
	 */

	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The string containing the constructed row data that will be returned to the grid
	 * @var string
	 */
	var $_jdata=null;
	
	/**
	 * adds escape characters to an array
	 * @var
	 * @return escapped array
	 */
	function filterData($data) {
		$db = JFactory::getDbo();
		if (is_array($data)) {
			foreach ($data as $elem) {
				filterData($elem);
			}
		} else {
			$data = trim(htmlentities(strip_tags($data)));
			if (get_magic_quotes_gpc())
				$data = stripslashes($data);
	 
			//$data = mysql_real_escape_string($data);
			$data = addslashes($data);
		}
	 
	    return $data;
}
	

	/**
	 * converts an array of values to CSV
	 * @var
	 * @return csv string json string or false if no row returned
	 */
	function array_to_scv($array, $header_row = true, $col_sep, $row_sep = "\r\n", $qut = '"',$skip_keys)
	{
		//return print_r($array);
		//if (!is_array($array) or !is_array($array[0])) return false;
		//Header row.


		if ($header_row)
		{
			foreach ($array[0] as $key => $val)
			{
				// skip keys that should not be included in CSV
				if(in_array($key,$skip_keys)) continue;
				//Escaping quotes.
				$key = str_replace($qut, "$qut$qut", $key);
				$output .= "$col_sep$qut$key$qut";
			}
			$output = substr($output, 1).$row_sep;
		}
		//Data rows.
		foreach ($array as $key => $val)
		{
			$tmp = '';
			foreach ($val as $cell_key => $cell_val)
			{
								// skip keys that should not be included in CSV
				if(in_array($cell_key,$skip_keys)) continue;
				//Escaping quotes.
				$cell_val = str_replace($qut, "$qut$qut", $cell_val);
				$tmp .= "$col_sep$qut$cell_val$qut";
			}
			$output .= substr($tmp, 1).$row_sep;
		}
		return $output;
	}	
	
	

	/**
	 * Displays the Data Rows for the grid columns the "sheets " data
	 * @var
	 * @return string json string containing the "Row Data" for grid rows or false if no row returned
	 */
	function display($tpl = NULL)
	{
		$db = JFactory::getDBO();
		$user =JFactory::getUser();
		$session =  JFactory::getSession();
		$session_id = $session->getId();
		$grid_id=JRequest::getVar('grid_id','','','INTEGER');
		$delimiter=JRequest::getVar('delimiter','','','STRING');
		$filename=JRequest::getVar('filename','','','STRING');
		$ext="csv";
		$skip_keys = array('slvl','editable_line','rslvl_id','row_color');
		$download_csv_document=false;
		$download_csv_document = JRequest::getVar('download_csv_document','','','INTEGER');
		$first_element = true;
		$word_found = array();
		$this->_result_count=1;
//echo "sql123 ".print_r($this->wordarray);
//return;	
		// set search string logic
		if($this->wordarray)
		{
			for($k=0, $j=0;$k<count($this->wordarray);$k++)
			{
				$word = $this->wordarray[$k];
				if($word == 'and' )
				{
					
					$word_logic[$j] = 'and';
					continue;
				}
				else if($word == 'or')
				{
					$word_logic[$j] = 'or';
					continue;
				}
				else if($word == 'not')
				{
					$word_logic[$j] = 'not';
					continue;
				}
				else 
				{
					$word_name[$j] = $this->wordarray[$k];
					if(!$word_logic[$j]) $word_logic[$j] = 'or'; //default to or					
					$j++;
				}				 
			}
			
		} 
//echo 'sql'.print_r($word_logic);		
		$max_slvl=$this->columndata_values[0]->slvl;	
		if($this->select_type > 1) // table select data
		{ 		
				$this->_query = 'SELECT b.id,
										CONCAT(b.data_type,a.id) AS "dataindex",
										a.row_color_pressidence
	                       FROM #__jgrid_columngrid a, 
	                       		#__jgrid_columns b
	                       WHERE a.grid_id = '.$grid_id.'
	                         AND a.column_type = 1
	                         AND a.column_id = b.id';
					$db->setQuery($this->_query);
					$jgrid_data_id_column_array = $db->loadObjectList();
				if($this->hide_column_ids)
				{
					// remove data from columns that are $hide_column_ids
					$hide_column_ids_array = explode(',',$this->hide_column_ids);
					// replace column_ids with columgrid dataindex
					for ($i=0 ; $i<count( $hide_column_ids_array );$i++)
					{
						for ($j=0; $j<count( $jgrid_data_id_column_array );$j++)
						{						
							if($hide_column_ids_array[$i] == substr($jgrid_data_id_column_array[$j]->dataindex,1))
							{
								$hide_column_ids_array[$i] = $jgrid_data_id_column_array[$j]->dataindex;
								break;
								
							}
						}
					}
				}
			// process data to add row numbers and remove data from hidden columns
			for ($i=0 ; $i<count( $this->columndata_values );$i++)
			{
				// hide data from hidden columns
				for ($j=0 ; $j<count( $hide_column_ids_array );$j++)
				{
				  	$this->columndata_values[$i]->{$hide_column_ids_array[$j]} = '';
				  	// find and set dslvl
					if($this->columndata_values[$i]->slvl > $max_slvl)
			      	{ 
			           		$max_slvl  = $this->columndata_values[$i]->slvl;
			      	}
				}				
			}
	}
	else 
	{ 
		$rows = $this->columndata_values[0];
		if($download_csv_document==false)
		{
			$full_rows_data = '[';
		}	 
		$currentrow_number = $rows->row_number;
		$first_row = true;
		if($download_csv_document==true)
		{
			$this->_jdata="";
		}
		else
		{
			$row_access_id = $rows->row_access_id;
			$this->_jdata = '{"id":';
			$this->_jdata .= $rows->row_number;
			$this->_jdata .= ',';
		}
			 $temp_slvl=$rows->slvl;
			 $max_slvl = $temp_slvl;
			 $temp_rslvl_id=$rows->row_access_id;
			 $temp_editable_line=$rows->editable_line;
			 $row_color='';
			 $row_color_pressidence=0;
			 $delimiter=',';

		
		
			 if($download_csv_document==true)
			 {
			 	// find document to display
			 	$document_id=0;
			 	$query='SELECT current_document_id
			                     FROM #__jgrid_current_user_grid_document 
			                     WHERE userid = ' . $user->id .'
			                        AND grid_id = '.$grid_id.'
			                        AND session_id = "'.$session_id.'"';
			 	$db->setQuery($query);
			 	$document_id = $db->loadResult();
			 	if($document_id==0) return array(false);
			 }
		
		
			 if(!$temp_slvl)
			 {
			 	$temp_slvl = 1;
			 }
		
			 $access_level = preg_split('/_\n/',$this->columndata_values[0]->slvl, -1, PREG_SPLIT_NO_EMPTY);	 
		
			 for ($i=0 , $n=count( $this->columndata_values ); $i < $n; $i++)
			 {
			 	$rows = $this->columndata_values[$i];
				 //Check for row change and add closing bracket to string
				 if($currentrow_number != $rows->row_number)
				 {
				 	$currentrow_number = $rows->row_number;
				 	$temp_slvl=$rows->slvl;
				 	if($temp_slvl > $max_slvl)
		      		{ 
		           		$max_slvl  = $temp_slvl;
		      		}
				 	$access_level = preg_split('/_\n/',$temp_slvl, -1, PREG_SPLIT_NO_EMPTY);
				 	if($download_csv_document==false)
				 	{
				 		$this->_jdata .= ',"slvl":"';
				 		$this->_jdata .= $temp_slvl;
				 		$this->_jdata .= '"';
				 		$this->_jdata .= ',"row_color":"';
				 		$this->_jdata .= $row_color;
				 		$this->_jdata .= '"';
				 		$this->_jdata .= ',"rslvl_id":"';
				 		$this->_jdata .= $temp_rslvl_id;
				 		$this->_jdata .= '"';
				 		$this->_jdata .= ',"editable_line":';
				 		$this->_jdata .= $temp_editable_line;
				 		$this->_result_count++;
				 		$this->_jdata .= '}';
				 		// end line
				 		// check to see if keep line
				 		if($this->wordarray)
				 		{
				 			$skip = false;
					 		for($k=0;$k<count($word_logic);$k++)// if any nots then skip line
					 		{					 			
					 			if($word_found[$k]==true&&$word_logic[$k]== 'not')
					 			{
					 				$skip = true;
					 				break; // skip this line
					 			} 
					 		}
					 		if($skip == false)
					 		{
					 			for($k=0;$k<count($word_logic);$k++)// if any ands missing then skip line
					 			{					 			
					 			
						 			if($word_found[$k]==false&&$word_logic[$k]=='and')
						 			{
						 				$skip = true;
						 				break; // skip this line
						 			}
					 			}
					 		}
					 		if($skip == false)
					 		{	
					 			$skip = true; // by default skip if or not found
					 			for($k=0;$k<count($word_logic);$k++)// if any or's then include line
					 			{					 		
							 		if($word_found[$k]==true&&$word_logic[$k]=='or')
							 		{
										$skip = false;
							 			break;
							 		}
					 			}
					 		}					 					 				
					 		if($skip == false)
					 		{
					 			$full_rows_data .= $this->_jdata;
					 			$first_row = false;
					 		} 
				 		}
				 		else 
				 		{
				 			$full_rows_data .= $this->_jdata;
				 			$first_row = false;
				 		}
 				 			 		
				 		// Start new line
				 		for($k=0;$k<count($word_found);$k++)
					 	{
							$word_found[$k]=0;
						}
				 		if($first_row == false) $this->_jdata = ',{"id":';
				 		else $this->_jdata = '{"id":';				 		
				 		$this->_jdata .= $rows->row_number;
				 		$this->_jdata .= ',';
				 		$row_color='';
				 		$row_color_pressidence=0;
				 		$temp_rslvl_id=$rows->row_access_id;
				 		$temp_editable_line=$rows->editable_line;
				 		$row_access_id = $rows->row_access_id;
				 	}
				 	else
				 	{
				 		$this->_jdata .="\r\n";
				 		if($this->wordarray)
				 		{
				 			$skip = false;
					 		for($k=0;$k<count($word_logic);$k++)// if any nots then skip line
					 		{					 			
					 			if($word_found[$k]==true&&$word_logic[$k]== 'not')
					 			{
					 				$skip = true;
					 				break; // skip this line
					 			} 
					 		}
					 		if($skip == false)
					 		{
					 			for($k=0;$k<count($word_logic);$k++)// if any ands missing then skip line
					 			{					 			
					 			
						 			if($word_found[$k]==false&&$word_logic[$k]=='and')
						 			{
						 				$skip = true;
						 				break; // skip this line
						 			}
					 			}
					 		}
					 		if($skip == false)
					 		{	
					 			$skip = true; // by default skip if or not found
					 			for($k=0;$k<count($word_logic);$k++)// if any ors then include line
					 			{					 		
							 		if($word_found[$k]==true&&$word_logic[$k]=='or')
							 		{
										$skip = false;
							 			break;
							 		}
					 			}
					 		}					 					 				
					 		if($skip == false)
					 		{
					 			$full_rows_data .= $this->_jdata;
					 			$first_row = false;
					 		} 
				 		}
				 		else 
				 		{
				 			$full_rows_data .= $this->_jdata;
				 			$first_row = false;
				 		}
				 		$this->_jdata = '';
				 	}
				 	$first_element = true;
				 	
				 }
				 if($download_csv_document==true)
				 {
				 	
				 	if($rows->data_type=='P') continue;
				 }
				 if($first_element == false)
				 {
				 	$this->_jdata .= $delimiter;
				 }
				 else
				 {
				 	$first_element = false;
				 }
				 if($download_csv_document==false)
				 {
				 	$this->_jdata .= '"';
				 	$this->_jdata .= $rows->dataindex;
				 	$this->_jdata .= '":';
				 }
				 // check to see if creator column edit and remove data from all columns that are not creators.
				 if((count($access_level)>1)&&substr($access_level[1],0,1)=="C")
				 {
//echo 'sql'	.$access_level;
//return;			 	
				 	switch ($rows->creator_document_security_level)
				 	{
				 		// CREATOR_PRIVATE
				 		case '1':
				 			// CREATOR_ROLE_PRIVATE
				 		case '2':
				 			// CREATOR_ROLE_VIEWABLE
				 		case '3':
				 			// CREATOR_VIEWABLE no edit
				 		case '8':
				 			// CREATOR_ROLE_VIEWABLE no edit
				 		case '9':				 							 			
				 			// blank out data if not viewable
				 			$this->_jdata .= "";
				 			continue;
				 			// REGISTERED_VIEWABLE Creator Editable
				 		case '4':
				 			// REGISTERED_VIEWABLE Role Editable
				 		case '5':
				 			// not registered user
				 			if($user->id == 0)
				 			{
				 				// blank out data if not viewable
				 				$this->_jdata .= "";
				 			}
				 			continue;
				 			// PUblic_VIEWABLE Creator Editable
				 		case '6':
				 			// PUBLIC_VIEWABLE Role Editable
				 		case '7 ':
				 			break;
				 	}
				 }
				 
				 switch ($rows->data_type)
				 {
						//text
					case 'T':
						//Picture
					case 'P':
						//URL
					case 'U':
						//EMail
					case 'E':						
						//Sheet Name
					case 'S':
				 		$this->_jdata .= '"';
				 		$this->_jdata .= addslashes($rows->string_data);
				 		$this->_jdata .= '"';
				 		if($this->wordarray)
				 		{			 		
				 			for($k=0;$k<count($word_name);$k++)
				 			{
		 				
				 				if(stripos($rows->string_data, $word_name[$k])!== false)
				 				{
				 					$word_found[$k] = true;
//echo $rows->string_data.'='	.$word_name[$k].'='.$word_found[$k] .'='.$k	;
				 				} 
				 				
				 				
				 			}
				 		}				 		
				 		break;
				 		// Integer
				 	case 'I':
				 		// Integer
				 	case 'R':		 		
				 		$this->_jdata .= $rows->int_data;
				 		if($this->wordarray)
				 		{
				 			for($k=0;$k<count($word_name);$k++)
				 			{
				 				if(is_numeric($word_name[$k]))
				 				{
				 					if(strpos($rows->int_data, $word_name[$k]!== false)) $word_found[$k] = true;
				 				}
				 			}
				 		}
				 		break;
				 		//Date
				 	case 'D':
				 		$this->_jdata .= '"';
				 		if($rows->date_data != '0000-00-00')
				 		{
				 			$this->_jdata .= $rows->date_data;
				 		}
				 		$this->_jdata .= '"';
				 		break;
				 		// Boolean
				 	case 'B':
				 		$this->_jdata .= $rows->boolean_data;
				 		break;
				   // Float
				 	case 'F':
				 		$this->_jdata .= '"';
				 		$this->_jdata .= $rows->float_data;
				 		$this->_jdata .= '"';
				 		if($this->wordarray)
				 		{
				 			for($k=0;$k<count($word_name);$k++)
				 			{
				 				if(is_numeric($word_name[$k]))
				 				{
				 					if(strpos($rows->float_data, $word_name[$k])!== false) $word_found[$k] = true;
				 				}
				 			}
				 		}
				 		break;
				   // List Box Values
				 	case 'L':
				 		$this->_jdata .= '"';
				 		$this->_jdata .= $rows->string_data;
				 		$this->_jdata .= '"';
				 		//set row_color based on column color priority
				 		if($rows->listboxvaluerowcolor!=''&&($color_pressidence==0||($rows->row_color_pressidence!=''&&$row_color_pressidence<=$rows->row_color_pressidence)))
				 		{
				 			$row_color=$rows->listboxvaluerowcolor;
				 			if($color_pressidence==0)
				 			{
				 				$row_color_pressidence=1;
				 			}
				 			else
				 			{
				 				$row_color_pressidence=$rows->row_color_pressidence;
				 			}
				 		}
				 		if($this->wordarray)
				 		{
				 			for($k=0;$k<count($word_name);$k++)
				 			{
				 				if(strpos($rows->string_data, $word_name[$k])!== false) $word_found[$k] = true;
				 			}
				 		}
				 		break;		 		
				 }
			 }// end or for loop
			 if($download_csv_document==true)
			 {
			 	$this->_jdata .="\r\n";
			 	$full_rows_data .= $this->_jdata;
			 	// send the headers
			 	header("Content-type: application/csv");
			 	header("Content-Disposition: attachment; filename=\"$filename.$ext\"");
			 	header("Pragma: no-cache");
			 	header("Expires: 0");
			 	//header("Content-Transfer-Encoding: ASCII\r\n");
			 	echo $full_rows_data;
			 } else
			 {
			 	$this->_jdata .= ',"slvl":"';
			 	$this->_jdata .= $temp_slvl;
			 	$this->_jdata .= '"';
			 	$this->_jdata .= ',"row_color":"';
			 	$this->_jdata .= $row_color;
			 	$this->_jdata .= '"';
			 	$this->_jdata .= ',"rslvl_id":"';
			 	$this->_jdata .= $temp_rslvl_id;
			 	$this->_jdata .= '"';
			 	$this->_jdata .= ',"editable_line":';
			 	$this->_jdata .= $temp_editable_line;
			 	$this->_jdata .= '}';
			 	
			 	if($this->wordarray)
				{
				 	$skip = false;
					for($k=0;$k<count($word_logic);$k++)// if any nots then skip line
					{					 			
						if($word_found[$k]==true&&$word_logic[$k]== 'not')
						{
					 		$skip = true;
					 		break; // skip this line
					 	} 
					}
					if($skip == false)
					{
						for($k=0;$k<count($word_logic);$k++)// if any ands missing then skip line
						{					 					
						 	if($word_found[$k]==false&&$word_logic[$k]=='and')
							{
						 		$skip = true;
								break; // skip this line
							}
						}
					}
					if($skip == false)
					{	
						$skip = true; // by default skip if or not found
					 	for($k=0;$k<count($word_logic);$k++)// if any ors then include line
					 	{					 		
							if($word_found[$k]==true&&$word_logic[$k]=='or')
							{
								$skip = false;
								break;
							}
						}
					}					 					 				
					if($skip == false)
					{
					 	$full_rows_data .= $this->_jdata;
						$first_row = false;
					} 
				}
				else 
				{
					$full_rows_data .= $this->_jdata;
				 	$first_row = false;
				}
				$full_rows_data .= ']';
			 	$return_result_count=$this->_result_count;
			 	if($this->select_type<2) // jgrid type data
			 	{
				 	if(JRequest::getVar('limit','','','INTEGER'))
				 	{
				 		$return_result_count=JRequest::getVar('paging_result_count_rows','','','INTEGER');
				 	}
				 	if($n!=0)Echo '{success:true,total:'.$return_result_count.',dslvl:"'.$max_slvl.'",select_type:"'.$this->select_type.'",rows:'. $full_rows_data .'}';
				 	else Echo '{success:false,dslvl:0}';
			 	}
			 }
	}	
		if($this->select_type > 1) 
		{ 
			 if($download_csv_document==true)
			 {
			 	// send the headers
			 	header("Content-type: application/csv");
			 	header("Content-Disposition: attachment; filename=\"$filename.$ext\"");
			 	header("Pragma: no-cache");
			 	header("Expires: 0");
			 	//header("Content-Transfer-Encoding: ASCII\r\n");
			 	$csv_file = $this->array_to_scv($this->columndata_values, $header_row = true, $delimiter, "\r\n", '"',$skip_keys);					
			 	echo $csv_file;
			 } 
			 else
			 {
				// table select data
			 		if(JRequest::getVar('limit','','','INTEGER'))
				 	{
				 		$return_result_count=JRequest::getVar('paging_result_count_rows','','','INTEGER');
				 	}
				 	else $return_result_count = count($this->columndata_values);
				//if($return_result_count)Echo '{success:true,total:'.$return_result_count.',dslvl:"'.$max_slvl.'",select_type:"'.$this->select_type.'",rows:'. json_encode(filterData($this->columndata_values)) .'}';
				if($return_result_count)Echo '{success:true,total:'.$return_result_count.',dslvl:"'.$max_slvl.'",select_type:"'.$this->select_type.'",rows:'. json_encode($this->columndata_values) .'}';
				else echo '{success:false,dslvl:0}';
			 }
		}
	}
}