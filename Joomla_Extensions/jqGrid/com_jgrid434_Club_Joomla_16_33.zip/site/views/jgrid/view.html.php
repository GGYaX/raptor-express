<?php
/**
 * Jgrid view in Joomla/Components/view
 *
 * @version		$id$ V4.0
 * @package     flower Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://J.ClubsAreUs.org
 * This Software is for Sealogix internal use only and 
 * is not intended for sale, free sharing or any other re-distribution.
 * Viloaters will be prosecuted!! 
 *   
 */

defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.view');


/**
 * Jgrid View
 *
 * HTML View Class to display javascript view
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */

if(!class_exists('RMWorksAroundJoomlaToGetAView')) {
	if(interface_exists('JView')) {
		abstract class RMWorksAroundJoomlaToGetAView extends JViewLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAView extends JView {}
	}
}

class JgridViewJgrid extends RMWorksAroundJoomlaToGetAView
{
	function display($tpl = null)
	{

		$griditems= $this->get('Griddata');	
		if($griditems==false)
		{
			JError::raiseNotice(1001, JText::_("NO_DATA_GRIDS_AVAILABLE_TO_USER_PLEASE_CONTACT_ADMINISTRATOR_TO_ASSIGN_DATA_GRID_ACCESS"));
			return;
		}
		$this->assignRef('griditems', $griditems);
		$columnitems= $this->get( 'Columndata');
		
		if($columnitems==false)
		{
			JError::raiseNotice(1002, JText::_("NO_DATA_GRIDS_AVAILABLE_TO_USER_PLEASE_CONTACT_ADMINISTRATOR_TO_ASSIGN_DATA_GRID_ACCESS"));
			return;
		}
		$this->assignRef('columnitems', $columnitems);

		 
		parent::display($tpl);
	}
}
?>
