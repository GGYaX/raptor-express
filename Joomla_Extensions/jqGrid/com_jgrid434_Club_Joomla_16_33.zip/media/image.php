<?php
/**
 * image in Joomla/Administrator/Components/os/jgrid
 *
 * @version		$id$ V2.4
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2011 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */
?>
<html>
<body>

<?php
$name = $_GET['name'];
$new_w = $_GET['width']-50;
$new_h = $_GET['height']-18;
$demo= $_GET['demo'];  
if(preg_match("/([0-9])/",$name))
{
	$name_array = explode("_", $name);
	if($demo==1)
	{
	  $image_path = './demo_images/grid_'.$name_array[0].'/document_'.$name_array[1].'/'.$name_array[2].'_'.$name_array[3].'_'.$name_array[4].'_'.$name_array[5].'_orig.'.$name_array[6];
	}
	else
	{
	  $image_path = './grid_'.$name_array[0].'/document_'.$name_array[1].'/'.$name_array[2].'_'.$name_array[3].'_'.$name_array[4].'_'.$name_array[5].'_orig.'.$name_array[6];
  }
  //echo $image_path;
//	echo '<img style="max-width:100%;min-width:100%;min-height:30%;max-height:30%" src="'.$image_path.'" width="'.$new_w.'"  lastmod="'.filemtime($image_path).'">';

		echo '<img style="max-width:100%;min-width:100%;min-height:30%;max-height:30%" src="'.$image_path.'" width="'.$new_w.'"  lastmod="'.filemtime($image_path).'">';
}
else echo 'not found';
?>

</body>
</html>
