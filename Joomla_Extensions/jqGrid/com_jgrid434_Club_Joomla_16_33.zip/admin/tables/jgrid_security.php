<?php
/**
 * Jgrid_security Table  in Joomla/Components/Tables
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_security Table Class
 *
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class TableJgrid_security extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id = null;

	/**
	 * @var int
	 */
	var $parent_id = null;
	
	/**
	 * @var int
	 */
	var $access_rule_application_id = null;	

	/**
	 * @var int
	 */
	var $userid_assigning_access = null;

	/**
	 * @var int
	 */
	var $access_for = null;

	/**
	 * @var string
	 */
	var $access_for_name = null;

	/**
	 * @var int
	 */
	var $access_for_id = null;

	/**
	 * @var int
	 */
	var $access_type = null;

	/**
	 * @var string
	 */
	var $access_type_name = null;

	/**
	 * @var string
	 */
	var $access_type_id = null;

	/**
	 * @var int
	 */
	var $access_subtype_grid_id = null;

	/**
	 * @var int
	 */
	var $access_subtype_column_id = null;

	/**
	 * @var int
	 */
	var $access_subtype_document_id = null;

	/**
	 * @var int
	 */
	var $access_level = null;

	/**
	 * @var timestamp
	 */
	var $last_updated = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableJgrid_security(& $db) {
		parent::__construct('#__jgrid_security
		', 'id', $db);
	}
}