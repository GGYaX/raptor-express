<?php
/**
 * Jgrid_columngrid Table  in Joomla/Components/Tables
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2014 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_columngrid Table Class
 *
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class TableJgrid_columngrid extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id = null;

	/**
	 * @var int
	 */
	var $parent_id = null;

	/**
	 * @var string
	 */
	var $column_id = null;
	
	/**
	 * @var int
	 */
	var $column_type = null;	
	
	/**
	 * @var string
	 */
	var $grid_id = null;

	/**
	 * @var int
	 */
	var $ordering = null;

	/**
	 * @var int
	 */
	var $row_color_pressidence = null;
	
	/**
	 * @var string
	 */
	var $database_sql_name_id = null;

	/**
	 * @var string
	 */
	var $table_sql_name_id = null;
  
	/**
	 * @var string
	 */
	var $column_sql_name_id = null;

	/**
	 * @var string
	 */
	var $jgrid_data_column = null;
  
	/**
	 * @var boolean
	 */
	var $primary_key_column = null;    	
	
	/**
	 * @var string
	 */
	var $formula = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableJgrid_columngrid(& $db) {
		parent::__construct('#__jgrid_columngrid', 'id', $db);
	}
}