<?php
 /*
 *  JGridToolbar4.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');




echo 'Ext.define("JGrid.view.JGridToolbar4.php", {
	extend : "Ext.toolbar.Toolbar",
	requires : [ "JGrid.view.JGridHelp2"],	
	alias : "widget.JGridToolbar4",
	id : "JGridToolbar4",
	items : [{
                text: "'. JText::_("ADD_ACCESS_RULE").'",
                icon: "components/com_jgrid/os/jgrid/icons/table_add.png",
                cls: "x-btn-text-icon",
                tooltip: "'. JText::_("ADD_ACCESS_RULE_TOOLTIP").'",
               	handler: add_access_menu
            },
            {
                text: "'. JText::_("EDIT_ACCESS_RULE").'",
                icon: "components/com_jgrid/os/jgrid/icons/table_edit.png",
                cls: "x-btn-text-icon",
                tooltip: "'. JText::_("EDIT_ACCESS_RULE_TOOLTIP").'",
               	handler: edit_access_menu
            },
            {
                text: "'. JText::_("DELETE_ACCESS_RULE").'",
                icon: "components/com_jgrid/os/jgrid/icons/table_delete.png",
                cls: "x-btn-text-icon",
                tooltip: "'. JText::_("DELETE_ACCESS_RULE_TOOLTIP").'",
                handler: function () {
                   // editor4.stopEditing();
                    JGrid.currenteditgrid = Ext.ComponentMgr.get("jgrid_security");
                    var sm = JGrid.currenteditgrid.getSelectionModel();
                    var sel = sm.getSelection();
                    if (sm.hasSelection()) {
                        Ext.Msg.show({
                            title: "'. JText::_("REMOVE_ACCESS_RULE").'",
                            buttons: Ext.MessageBox.YESNOCANCEL,
                            msg: "'. JText::_("REMOVE_RULE").'",
                            fn: function (btn) {
                                if (btn == "yes") {
                                    JGrid.store[4].remove(sel[0]);
                                }
                            }
                        })
                    }
                }
            },
            {
                text: "'. JText::_("MODIFY_DEFAULT_GROUP").'",
                icon: "components/com_jgrid/os/jgrid/icons/application_edit.png",
                cls: "x-btn-text-icon",
                tooltip: "'. JText::_("MODIFY_DEFAULT_GROUP_TOOLTIP").'",
           		handler: function () {
	                if(!JGrid.JGridDefaultGroupRights)
	    			{
	    				JGrid.JGridDefaultGroupRights = Ext.create("JGrid.view.JGridDefaultGroupRights");
	    				JGrid.store[9].load();
	    			}
	    			JGrid.JGridDefaultGroupRights.show();
	    		}  
            },
             {    
                        id: "user_help_access",                   
                        text: "<b>'. JText::_("HELP").'</b>",
                        icon: "components/com_jgrid/os/jgrid/icons/help.png",
                        tooltip: "'. JText::_("INSTRUCTIONS_DESCRIBING_GRID_OPERATION_TOOLTIP").'",
                        handler: function () {                              
                        	if(!JGrid.help[2])
    						{
    							JGrid.help[2] = Ext.create("JGrid.view.JGridHelp2");
    						}
    						JGrid.help[2].show();  
                        }                            	
        }]
});';
?>

