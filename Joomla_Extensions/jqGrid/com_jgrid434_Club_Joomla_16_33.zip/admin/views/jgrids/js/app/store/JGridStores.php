<?php
/*
 *  JGridStores.php in joomla/administrator/components/com_jgrid/views/jgrid/js/app/store
 *
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>
  
//Create Proxys		
JGrid.proxy[0] = Ext.create("Ext.data.HttpProxy", {
	type: "ajax",
	id: "proxy0",
	api: {
			read: 'index.php?option=com_jgrid&task=read&format=ajax',
	        create: 'index.php?option=com_jgrid&task=create&format=ajax',
	        update: 'index.php?option=com_jgrid&task=update&format=ajax',
	        destroy: 'index.php?option=com_jgrid&task=destroy&format=ajax'
	},
	actionMethods: {
			create : "POST",
			read   : "GET",
			update : "POST",
			destroy: "POST"
	},
	reader: new Ext.data.JsonReader({
		root:"rows",
		totalProperty: "total",
		successProperty: "success",
		id:"id" 
	},JGrid.dsModel[0]),
	writer: {
		type: "json",
		encode: true,
	  	root:"rows",
	 	writeAllFields : false,  //just send changed fields
	  	allowSingle :false,      //always wrap in an array
    	returnJson: true //RMS check this if needed
	}    
});

JGrid.proxy[1] = Ext.create("Ext.data.HttpProxy", {
	type: "ajax",
	id: "proxy1",
	api: {
        read: 'index.php?option=com_jgrid&task=read&controller=jgrid_columns&format=ajax',
        create: 'index.php?option=com_jgrid&task=create&controller=jgrid_columns&format=ajax',
        update: 'index.php?option=com_jgrid&task=update&controller=jgrid_columns&format=ajax',
        destroy: 'index.php?option=com_jgrid&task=destroy&controller=jgrid_columns&format=ajax'
	},
	actionMethods: {
			create : "POST",
			read   : "GET",
			update : "POST",
			destroy: "POST"
	},
	reader: new Ext.data.JsonReader({
		root:"rows",
		totalProperty: "total",
		successProperty: "success",
		id:"id" 
	},JGrid.dsModel[1]),
	writer: {
		type: "json",
		encode: true,
	  	root:"rows",
	 	writeAllFields : false,  //just send changed fields
	  	allowSingle :false,      //always wrap in an array
    	returnJson: true //RMS check this if needed
	}    
});

// adding a column to a grid jgrid_columngrid. Pop up grid called from "Data Grid Settings" screen xtype: "editorgrid"
JGrid.proxy[2] = Ext.create("Ext.data.HttpProxy", {
	type: "ajax",
	id: "proxy2",
	api: {
        read: 'index.php?option=com_jgrid&task=read&controller=jgrid_columngrid&format=ajax',
        create: 'index.php?option=com_jgrid&task=create&controller=jgrid_columngrid&format=ajax',
        update: 'index.php?option=com_jgrid&task=update&controller=jgrid_columngrid&format=ajax',
        destroy: 'index.php?option=com_jgrid&task=destroy&controller=jgrid_columngrid&format=ajax'
	},
	actionMethods: {
			create : "POST",
			read   : "GET",
			update : "POST",
			destroy: "POST"
	},
	reader: new Ext.data.JsonReader({
		root:"rows",
		totalProperty: "total",
		successProperty: "success",
		id:"id" 
	},JGrid.dsModel[2]),
	writer: {
		type: "json",
		encode: true,
	  	root:"rows",
	 	writeAllFields : true,  // send all  fields
	  	allowSingle :false,      //always wrap in an array
    	returnJson: true //RMS check this if needed
	}    
});

// manage grid user access jgrid_security administrator screen xtype: "editorgrid"
JGrid.proxy[4] = Ext.create("Ext.data.HttpProxy", {
	type: "ajax",
	id: "proxy4",
	api: {
        read: 'index.php?option=com_jgrid&task=read&controller=jgrid_security&format=ajax',
        create: 'index.php?option=com_jgrid&task=create&controller=jgrid_security&format=ajax',
        update: 'index.php?option=com_jgrid&task=update&controller=jgrid_security&format=ajax',
        destroy: 'index.php?option=com_jgrid&task=destroy&controller=jgrid_security&format=ajax'
	},
	actionMethods: {
			create : "POST",
			read   : "GET",
			update : "POST",
			destroy: "POST"
	},
	reader: new Ext.data.JsonReader({
		root:"rows",
		totalProperty: "total",
		successProperty: "success",
		id:"id" 
	},JGrid.dsModel[4]),
	writer: {
		type: "json",
		encode: true,
	  	root:"rows",
	 	writeAllFields : true,  //just send changed fields
	  	allowSingle :false,      //always wrap in an array
    	returnJson: true //RMS check this if needed
	}    
});

JGrid.proxy[7] = Ext.create("Ext.data.HttpProxy", {
	type: "ajax",
	id: "proxy7",
	api: {
        read: 'index.php?option=com_jgrid&task=read&controller=jgrid_users&format=ajax',
        create: 'index.php?option=com_jgrid&task=create&controller=jgrid_users&format=ajax',
        update: 'index.php?option=com_jgrid&task=update&controller=jgrid_users&format=ajax',
        destroy: 'index.php?option=com_jgrid&task=destroy&controller=jgrid_users&format=ajax'
	},
	actionMethods: {
			create : "POST",
			read   : "GET",
			update : "POST",
			destroy: "POST"
	},
	reader: new Ext.data.JsonReader({
		root:"rows",
		totalProperty: "total",
		successProperty: "success",
		id:"id" 
	},JGrid.dsModel[7]),
	writer: {
		type: "json",
		encode: true,
	  	root:"rows",
	 	writeAllFields : false,  //just send changed fields
	  	allowSingle :false,      //always wrap in an array
    	returnJson: true //RMS check this if needed
	}    
});

JGrid.proxy[8] = Ext.create("Ext.data.HttpProxy", {
	type: "ajax",
	id: "proxy8",
	api: {
        read: 'index.php?option=com_jgrid&task=read&controller=jgrid_roles&format=ajax',
        create: 'index.php?option=com_jgrid&task=create&controller=jgrid_roles&format=ajax',
        update: 'index.php?option=com_jgrid&task=update&controller=jgrid_roles&format=ajax',
        destroy: 'index.php?option=com_jgrid&task=destroy&controller=jgrid_roles&format=ajax'
	},
	actionMethods: {
			create : "POST",
			read   : "GET",
			update : "POST",
			destroy: "POST"
	},
	reader: new Ext.data.JsonReader({
		root:"rows",
		totalProperty: "total",
		successProperty: "success",
		id:"id" 
	},JGrid.dsModel[8]),
	writer: {
		type: "json",
		encode: true,
	  	root:"rows",
	 	writeAllFields : false,  //just send changed fields
	  	allowSingle :false,      //always wrap in an array
    	returnJson: true //RMS check this if needed
	}    
});

// default group access rights
JGrid.proxy[9] = Ext.create("Ext.data.HttpProxy", {
	type: "ajax",
	id: "proxy9",
	api: {
        read: 'index.php?option=com_jgrid&task=read_default_group&controller=jgrid_security&format=ajax',
        update: 'index.php?option=com_jgrid&task=update_default_group&controller=jgrid_security&format=ajax'
	},
	actionMethods: {
			read   : "GET",
			update : "POST"
	},
	reader: new Ext.data.JsonReader({
		root:"rows",
		totalProperty: "total",
		successProperty: "success",
		id:"id" 
	},JGrid.dsModel[9]),
	writer: {
		type: "json",
		encode: true,
	  	root:"rows",
	 	writeAllFields : false,  //just send changed fields
	  	allowSingle :false,      //always wrap in an array
    	returnJson: true //RMS check this if needed
	}    
});

// Add Values for list box valid types (user defined)  screenxtype "editorgrid" 
JGrid.proxy[12] = Ext.create("Ext.data.HttpProxy", {
	type: "ajax",
	id: "proxy12",
	api: {
        read: 'index.php?option=com_jgrid&controller=jgrid_columnslistboxvalues&task=read_listBoxValues&format=ajax',
        create: 'index.php?option=com_jgrid&controller=jgrid_columnslistboxvalues&task=create_listBoxValues&format=ajax',
        update: 'index.php?option=com_jgrid&controller=jgrid_columnslistboxvalues&task=update_listBoxValues&format=ajax',
        destroy: 'index.php?option=com_jgrid&controller=jgrid_columnslistboxvalues&task=destroy_listBoxValues&format=ajax'
	},
	actionMethods: {
			create : "POST",
			read   : "POST",
			update : "POST",
			destroy: "POST"
	},
	reader: new Ext.data.JsonReader({
		root:"rows",
		totalProperty: "total",
		successProperty: "success",
		id:"id" 
	},JGrid.dsModel[12]),
	writer: {
		type: "json",
		encode: true,
	  	root:"rows",
	 	writeAllFields : false,  //just send changed fields
	  	allowSingle :false,      //always wrap in an array
    	returnJson: true //RMS check this if needed
	},
	listeners: {
   		load: {
            fn: function()
            {
                win12.show();
            }
        }
    }    
});

// Database Select Query
JGrid.proxy[13] = Ext.create("Ext.data.HttpProxy", {
	type: "ajax",
	id: "proxy13",
	api: {
        read: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=read_jgrid_select_query&format=ajax',
        create: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=update_jgrid_select_query&format=ajax',
        update: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=update_jgrid_select_query&format=ajax',
        destroy: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=destroy_jgrid_select_query&format=ajax'
	},
	actionMethods: {
			create : "POST",
			read   : "POST",
			update : "POST",
			destroy: "POST"
	},
	reader: new Ext.data.JsonReader({
		root:"rows",
		totalProperty: "total",
		successProperty: "success",
		id:"id" 
	},JGrid.dsModel[13]),
	writer: {
		type: "json",
		encode: true,
	  	root:"rows",
	 	writeAllFields : true,  
	  	allowSingle :false,      //always wrap in an array
    	returnJson: true //RMS check this if needed
	}    
});

// Custom SQL Select Query Saved in Database
JGrid.proxy[14] = Ext.create("Ext.data.HttpProxy", {
	type: "ajax",
	id: "proxy14",
	api: {
        read: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=read_jgrid_custom_sql_query&format=ajax',
        create: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=update_jgrid_custom_sql_query&format=ajax',
        update: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=update_jgrid_custom_sql_query&format=ajax',
        destroy: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=destroy_jgrid_custom_sql_query&format=ajax'
	},
	actionMethods: {
			create : "POST",
			read   : "POST",
			update : "POST",
			destroy: "POST"
	},
	reader: new Ext.data.JsonReader({
		root:"rows",
		totalProperty: "total",
		successProperty: "success",
		id:"id" 
	},JGrid.dsModel[14]),
	writer: {
		type: "json",
		encode: true,
	  	root:"rows",
	 	writeAllFields : true, 
	  	allowSingle :false,      //always wrap in an array
    	returnJson: true //RMS check this if needed
	}    
});


// Where Clause Dependencies 
JGrid.proxy[15] = Ext.create("Ext.data.HttpProxy", {
	type: "ajax",
	id: "proxy15",
	api: {
        read: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=readJoinCriteria&format=ajax',
        create: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=createJoinCriteria&format=ajax',
        update: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=updateJoinCriteria&format=ajax',
        destroy: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=destroyJoinCriteria&format=ajax'
	},
	actionMethods: {
			create : "POST",
			read   : "POST",
			update : "POST",
			destroy: "POST"
	},
	reader: new Ext.data.JsonReader({
		root:"rows",
		totalProperty: "total",
		successProperty: "success",
		id:"id" 
	},JGrid.dsModel[15]),
	writer: {
		type: "json",
		encode: true,
	  	root:"rows",
	 	writeAllFields : true,  //send all fields
	  	allowSingle :false,      //always wrap in an array
    	returnJson: true //RMS check this if needed
	},
    listeners: {
    	beforeload: function(store, operation, eOpts ) {
    		store.getProxy().extraParams = {selected_grid_id: JGrid.selectedgridid};
    	}
    }    
});

// Custom Where Clause Depedencies
JGrid.proxy[16] = Ext.create("Ext.data.HttpProxy", {
	type: "ajax",
	id: "proxy16",
	api: {
        read: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=read_jgrid_select_custom_criteria&format=ajax',
        create: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=update_jgrid_select_custom_criteria&format=ajax',
        update: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=update_jgrid_select_custom_criteria&format=ajax',
        destroy: 'index.php?option=com_jgrid&controller=jgrid_columngrid&task=destroy_jgrid_select_custom_criteria&format=ajax'
	},
	actionMethods: {
			create : "POST",
			read   : "POST",
			update : "POST",
			destroy: "POST"
	},
	reader: new Ext.data.JsonReader({
		root:"rows",
		totalProperty: "total",
		successProperty: "success",
		id:"id" 
	},JGrid.dsModel[16]),
	writer: {
		type: "json",
		encode: true,
	  	root:"rows",
	 	writeAllFields : true,
	  	allowSingle :false,      //always wrap in an array
    	returnJson: true //RMS check this if needed
	}    
});
		 
// create new grids	jgrid_grids administrator screen store
Ext.define("JGrid.store.JGridStore0", {
	    extend: "Ext.data.Store",
	    requires: "JGrid.model.JGridModel0",    
	    model: "JGrid.model.JGridModel0",
	    alias : "widget.JGridStore0",
	    storeId:"JGridStore0",
	    id:"JGridStore0",
	    autoSync: true,
	    autoLoad: false,      
		autoSave: true,
		proxy: JGrid.proxy[0]	
	 });
	 
JGrid.store[0] = Ext.create("JGrid.store.JGridStore0");		

// create new grids	jgrid_grids administrator screen store
Ext.define("JGrid.store.JGridStore1", {
	    extend: "Ext.data.Store",
	    requires: "JGrid.model.JGridModel1",    
	    model: "JGrid.model.JGridModel1",
	    alias : "widget.JGridStore1",
	    storeId:"JGridStore1",
	    id:"JGridStore1",
	    autoSync: true,
	    autoLoad: false,      
		autoSave: true,
		proxy: JGrid.proxy[1]	
	 });	 
JGrid.store[1] = Ext.create("JGrid.store.JGridStore1");
      JGrid.store[1].on('beforeload', function () {
        JGrid.combo_store[13].load({
          params: {
            data_type: "0"
          }
       });
});    
JGrid.store[1].on('write', function () {
	JGrid.combo_store[13].load({
  		params: {
      		access_type: "0"
       	}
	});     
});		

// adding a column to a grid jgrid_columngrid. Pop up grid called from "Data Grid Settings" screen xtype: "editorgrid"
Ext.define("JGrid.store.JGridStore2", {
	    extend: "Ext.data.Store",
	    requires: "JGrid.model.JGridModel2",    
	    model: "JGrid.model.JGridModel2",
	    alias : "widget.JGridStore2",
	    storeId:"JGridStore2",
	    id:"JGridStore2",
	    autoSync: true,
	    autoLoad: false,      
		autoSave: true,
		proxy: JGrid.proxy[2],
	listeners: {
   		update: {
            fn: function( mystore, opts )
            {
            	primaryKeySet = false;
	            numberOfColumns = mystore.getCount();	            
            	if(typeof opts.modified.primary_key_column === 'undefined')
            	{         	
	                // check to see if primary key field set if not set to first sql field
	                  //updatedRecords = mystore.getUpdatedRecords( );
	                  for(i=0;i < numberOfColumns; i++)
	                  {
	                    currentRecord = mystore.getAt(i);
	                    if(currentRecord.get('column_type')== 1) continue;
	                    if(currentRecord.get('primary_key_column')==true)
	                    {
	                    	primaryKeySet = true;
	                     	break;
	                    }
	                  }
	                  if(primaryKeySet == false)
	                  {
		                  //set first primary key as true
		                  for(i=0;i < numberOfColumns; i++)
		                  {
		                    currentRecord = mystore.getAt(i);
		                    if(currentRecord.get('column_type')== 1) continue;
		                    if(currentRecord) currentRecord.set('primary_key_column', true);
		                    primaryKeySet = true;
		                    break;
		                  }
	                  }
	              }
	              else if(opts.data.primary_key_column == true)
	              {
	              	// if primary set to true set rest to false
	              	if(numberOfColumns > 1)
	              	{
		              	for(i=0; i < numberOfColumns; i++)
		                {
		                  	if (i == opts.index) continue;
		                    currentRecord = mystore.getAt(i);
		                    if(currentRecord)
		                    {
		                    	currentRecord.set('primary_key_column', false);
		                    	//window.alert("got here");
		                    }	                  
		                 }
	                 }
	                 return true;	
	              }
	              else if(opts.modified.primary_key_column == true && opts.data.primary_key_column == false) 
	              {  
	                // first check to see of others are true
	               	for(i=0;i < numberOfColumns; i++)
	                 {
	                  	if (i == opts.index) continue;
	                    currentRecord = mystore.getAt(i);
	                    if(currentRecord.get('column_type')== 1) continue;
	                    if(currentRecord.get('primary_key_column')== true) return true;	                  
	                }
	                // you can not turn a key false only set another to true
	              	opts.data.primary_key_column = true;	
	              }
	              return true;	
                  //window.alert("got here");
            }
        }
    }	
	 });	 
JGrid.store[2] = Ext.create("JGrid.store.JGridStore2");

first_load = true;
JGrid.store[2].on('load', function () {
	if(first_load === true)
	{
		JGrid.store[2].on('datachanged', function ( store, eOpts ) {
			if(JGrid.store[15]) multiple_database_check();
			build_sql();
			if(Ext.ComponentMgr.get("where_clause_dependencies"))
				Ext.ComponentMgr.get("where_clause_dependencies").getView().refresh();   
		});
		first_load = false;
	}
	build_sql();
	JGrid.store[15].load({
            params: {
                selected_grid_id: JGrid.selectedgridid 
            }
	});
	Ext.ComponentMgr.get("gridcolumns_data").getView().refresh();   
});

// manage grid user access jgrid_security administrator screen xtype: "editorgrid"
Ext.define("JGrid.store.JGridStore4", {
	    extend: "Ext.data.Store",
	    requires: "JGrid.model.JGridModel4",    
	    model: "JGrid.model.JGridModel4",
	    alias : "widget.JGridStore4",
	    storeId:"JGridStore4",
	    id:"JGridStore4",
	    autoSync: true,
	    autoLoad: false,      
		autoSave: true,
		proxy: JGrid.proxy[4],
		sortInfo: {
        	field: 'access_for_id',
        	direction: 'ASC'
    	},
    	groupField: 'access_for_id'
<!--    	,-->
<!--	    listeners: {-->
<!--	    	datachanged: function(store,  eOpts ) {-->
<!--	    		var access_type = combo42.getValue();-->
<!--    			var application_id = combo45.getValue();-->
<!--	    		store.getProxy().extraParams = {access_type: access_type, application_id: application_id};-->
<!--	    	}-->
<!--	    }	-->
	 });	 
JGrid.store[4] = Ext.create("JGrid.store.JGridStore4");
JGrid.store[4].on('write', function () {
	  if(JGrid.JGridAccessRules) JGrid.JGridAccessRules.hide();
      Ext.ComponentMgr.get("jgrid_security").getView().refresh();   
});
<!--JGrid.store[4].on('load', function () {-->
<!--   JGrid.combo_store[41].load({-->
<!--        params: {-->
<!--            access_for: "0"-->
<!--        }-->
<!--    });-->
<!--   JGrid.combo_store[43].load({-->
<!--        params: {-->
<!--            access_type: "0"-->
<!--        }-->
<!--    });-->
<!--       JGrid.combo_store[411].load({-->
<!--        params: {-->
<!--            access_for: "0"-->
<!--        }-->
<!--    });-->
<!--   JGrid.combo_store[431].load({-->
<!--        params: {-->
<!--            access_type: "0"-->
<!--        }-->
<!--    });-->
<!--});-->

Ext.define("JGrid.store.JGridStore7", {
	    extend: "Ext.data.Store",
	    requires: "JGrid.model.JGridModel7",    
	    model: "JGrid.model.JGridModel7",
	    alias : "widget.JGridStore7",
	    storeId:"JGridStore7",
	    id:"JGridStore7",
	    autoSync: true,
	    autoLoad: false,      
		autoSave: true,
		proxy: JGrid.proxy[7],
		sortInfo: {
       		field: 'userid',
        	direction: 'ASC'
    	},
    	groupField: 'userid'	
	 });	 
JGrid.store[7] = Ext.create("JGrid.store.JGridStore7");
JGrid.store[7].on('beforeload', function () {
	JGrid.combo_store[71].load();
	JGrid.combo_store[73].load();
});

Ext.define("JGrid.store.JGridStore8", {
	    extend: "Ext.data.Store",
	    requires: "JGrid.model.JGridModel8",    
	    model: "JGrid.model.JGridModel8",
	    alias : "widget.JGridStore8",
	    storeId:"JGridStore8",
	    id:"JGridStore8",
	    autoSync: true,
	    autoLoad: false,      
		autoSave: true,
		proxy: JGrid.proxy[8],
		sortInfo: {
        	field: 'role_name',
       	 	direction: 'ASC'
   		},
   		groupField: 'role_name'	
});	 
JGrid.store[8] = Ext.create("JGrid.store.JGridStore8");

Ext.define("JGrid.store.JGridStore9", {
	    extend: "Ext.data.Store",
	    requires: "JGrid.model.JGridModel9",    
	    model: "JGrid.model.JGridModel9",
	    alias : "widget.JGridStore9",
	    storeId:"JGridStore9",
	    id:"JGridStore9",
	    autoSync: true,
	    autoLoad: false,      
		autoSave: true,
		proxy: JGrid.proxy[9]	
});	 
JGrid.store[9] = Ext.create("JGrid.store.JGridStore9");
JGrid.store[9].on('load', function () {
	Ext.ComponentMgr.get("default_groups").getView().refresh();   
});

// Add Values for list box valid types (user defined)  screenxtype "editorgrid"
	Ext.define("JGrid.store.JGridStore12", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridModel12",   
	model: "JGrid.model.JGridModel12",
	alias : "widget.JGridStore12",
	storeId:"JGridStore12",
	id:"JGridStore12",
	autoLoad: false,
	autoSync: true,
	proxy: JGrid.proxy[12]
});
JGrid.store[12] = Ext.create("JGrid.store.JGridStore12");

// database_select_query
Ext.define("JGrid.store.JGridStore13", {
	    extend: "Ext.data.Store",
	    requires: "JGrid.model.JGridModel13",    
	    model: "JGrid.model.JGridModel13",
	    alias : "widget.JGridStore13",
	    storeId:"JGridStore13",
	    id:"JGridStore13",
	    autoSync: true,
	    autoLoad: false,      
		autoSave: true,
		proxy: JGrid.proxy[13]	
});	 
JGrid.store[13] = Ext.create("JGrid.store.JGridStore13");
JGrid.store[13].on('load', function () {
	var crecord = JGrid.store[13].findRecord('grid_id', JGrid.selectedgridid );
	if(JGrid.select_type!="4") 
	{
		if(crecord) Ext.ComponentMgr.get("north_select_query").setValue(crecord.get("sql_query")); 
	} 
});

// CUSTOM_select_query stored in database
Ext.define("JGrid.store.JGridStore14", {
	    extend: "Ext.data.Store",
	    requires: "JGrid.model.JGridModel14",    
	    model: "JGrid.model.JGridModel14",
	    alias : "widget.JGridStore14",
	    storeId:"JGridStore14",
	    id:"JGridStore14",
	    autoSync: true,
	    autoLoad: false,      
		autoSave: true,
		proxy: JGrid.proxy[14]	
});	 
JGrid.store[14] = Ext.create("JGrid.store.JGridStore14");
JGrid.store[14].on('load', function () {
	var crecord = JGrid.store[14].findRecord('grid_id', JGrid.selectedgridid );
	if(JGrid.select_type=="4") 
	{
		if(crecord) Ext.ComponentMgr.get("north_select_query").setValue(crecord.get("sql_query")); 
	}
});


//Where Clause Dependencies
Ext.define("JGrid.store.JGridStore15", {
	    extend: "Ext.data.Store",
	    requires: "JGrid.model.JGridModel15",    
	    model: "JGrid.model.JGridModel15",
	    alias : "widget.JGridStore15",
	    storeId:"JGridStore15",
	    id:"JGridStore15",
	    autoSync: true,
	    autoLoad: false,      
		autoSave: true,
		proxy: JGrid.proxy[15]	
});	 
JGrid.store[15] = Ext.create("JGrid.store.JGridStore15");
JGrid.store[15].on('datachanged', function ( store, eOpts ) {
	multiple_database_check();
	build_sql();
	if(Ext.ComponentMgr.get("where_clause_dependencies"))
		Ext.ComponentMgr.get("where_clause_dependencies").getView().refresh();   
});


// Custom Where Clause Depedencies
Ext.define("JGrid.store.JGridStore16", {
	    extend: "Ext.data.Store",
	    requires: "JGrid.model.JGridModel16",    
	    model: "JGrid.model.JGridModel16",
	    alias : "widget.JGridStore16",
	    storeId:"JGridStore16",
	    id:"JGridStore16",
	    autoSync: true,
	    autoLoad: false,      
		autoSave: true,
		proxy: JGrid.proxy[16]	
});	 
JGrid.store[16] = Ext.create("JGrid.store.JGridStore16");
JGrid.store[16].on('load', function () {
	var crecord = JGrid.store[16].findRecord('grid_id', JGrid.selectedgridid );
	if(crecord) Ext.ComponentMgr.get("custom_where_clause").setValue(crecord.get('custom_where_query'));
});






