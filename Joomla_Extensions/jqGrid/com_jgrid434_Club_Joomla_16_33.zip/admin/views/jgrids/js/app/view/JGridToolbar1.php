<?php
 /*
 *  JGridToolbar0.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');




echo 'Ext.define("JGrid.view.JGridToolbar1.php", {
	extend : "Ext.toolbar.Toolbar",
	requires : [ "JGrid.view.JGridHelp1"],	
	alias : "widget.JGridToolbar1",
	id : "JGridToolbar1",
	items : [{
                text: "'. JText::_("ADD_NEW_COLUMN").'",
                icon: "components/com_jgrid/os/jgrid/icons/table_add.png",
                cls: "x-btn-text-icon",
                tooltip: "'. JText::_("ADD_NEW_COLUMN_TOOLTIP").'",
                handler: function () {
                 //   editor1.stopEditing();
                 //   var newrowlocation = JGrid.store[1].getCount();
                    var newrowlocation = 0;
                    var jgrid_newrowcolumns1 = {
                        id: "",
                        header: "'. JText::_("ENTER_YOUR_COLUMN_NAME").'",
                        dataindex: "'. JText::_("ENTER_UNIQUE_COLUMN_INDEX").'",
                        editable: 1,
                        width: "25",
                        data_type: "T",
                        validation_type: "none",
                        dfilter: 1,
                        sortable: 1,
                        ddefault: "",
                        align: "",
                        css: "",
                        tooltip: "'. JText::_("ENTER_YOUR_COLUMN_HELP_TEXT").'"
                    };
                    JGrid.store[1].insert(newrowlocation, jgrid_newrowcolumns1);
                    JGrid.currenteditgrid = Ext.ComponentMgr.get("grids_data");
                    JGrid.currenteditgrid.getView().refresh();
                    // JGrid.store[1].commitChanges();
                    // var sm = JGrid.currenteditgrid.getSelectionModel();
                    // sm.selectRow(newrowlocation);
                    // var sel = sm.getSelected();
                    //editor1.startEditing(newrowlocation);  // allows the new id number to render
                }
            },            {
                text: "'. JText::_("DELETE_GRID_COLUMN").'",
                icon: "components/com_jgrid/os/jgrid/icons/table_delete.png",
                cls: "x-btn-text-icon",
                tooltip: "'. JText::_("DELETE_GRID_COLUMN_TOOLTIP").'",
                handler: function () {
                 //   editor1.stopEditing();
                    JGrid.currenteditgrid = Ext.ComponentMgr.get("columns_data");
                    var sm = JGrid.currenteditgrid.getSelectionModel();
                    var sel = sm.getSelection();
                    if (sm.hasSelection()) {
                        Ext.Msg.show({
                            title: "'. JText::_("DELETE_GRID_COLUMN").'",
                            buttons: Ext.MessageBox.YESNOCANCEL,
                            msg: "Remove Column on all Grids?",
                            fn: function (btn) {
                                if (btn == "yes") {
                                    JGrid.store[1].remove(sel[0]);
                                }
                            }
                        })
                    } else Ext.Msg.alert("'. JText::_("PLEASE").'", "'. JText::_("SELECT_GRID_FIRST_TO_MODIFY_SETTINGS").'");
                }
            },
            {
                text: "'. JText::_("MODIFY_LISTS").'",
                icon: "components/com_jgrid/os/jgrid/icons/text_list_bullets.png",
                cls: "x-btn-text-icon",
                tooltip: "'. JText::_("MODIFY_LISTS_TOOLTIP").'",
                handler: function () {
                   // editor1.stopEditing();
                    JGrid.currenteditgrid = Ext.ComponentMgr.get("columns_data");
                    var sm = JGrid.currenteditgrid.getSelectionModel();
                    var sel = sm.getSelection();                   
                    if (sm.hasSelection()&&sel[0].get("data_type")=="L") {
                      JGrid.store[12].load({
                        params: {
                          column_id: sel[0].get("id")
                       }
                      });
                      if(!JGrid.modifyListsWin)
                      {
                      	JGrid.modifyListsWin = Ext.create("JGrid.view.JGridmodifyListsWin");
                      }
                      JGrid.modifyListsWin.show();      
                    } 
                    else 
                    {
                      Ext.Msg.alert("'. JText::_("PLEASE").'", "'. JText::_("SELECT_LIST_TYPE_COLUMN_FIRST_TO_MODIFY_SETTINGS").'");
                    }  
                }
            },
            {    
                        id: "user_help_columns",                   
                        text: "<b>'. JText::_("HELP").'</b>",
                        icon: "components/com_jgrid/os/jgrid/icons/help.png",
                        tooltip: "'. JText::_("INSTRUCTIONS_DESCRIBING_GRID_OPERATION").'",
                        handler: function () {
	                        if(!JGrid.help[1])
				    		{
				    			JGrid.help[1] = Ext.create("JGrid.view.JGridHelp1");
				    		}
							JGrid.help[1].show();  
                        }          
      		}]
});';
?>

