<?php
 /*
 *  JGridToolbar2.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');

echo 'Ext.define("JGrid.view.JGridToolbar2.php", {
	extend : "Ext.toolbar.Toolbar",	
	alias : "widget.JGridToolbar2",
	id : "JGridToolbar2",
	items : [{
		xtype: "combo",
		id: "columnid",
		fieldLabel: "'. JText::_("ADD_COLUMN").'",
		growToLongestValue: false,
		width: 300,
		hiddenName: "columngridid",           
		emptyText: "'. JText::_("SELECT_A_COLUMN_TO_ADD").'",  
		store: JGrid.combo_store[21],
		displayField: "header",
		valueField: "id",
		selectOnFocus: true,
		queryMode: "remote",
		typeAhead: true,
		hideTrigger : false,
		lastquery : "",
 		editable: false,
 		triggerAction: "all",
		listeners: {
			select: {
				fn: function (combo, records, eOpts) {
					JGrid.newcolumnrecord = records[0];
				}
			}
		}
	},
	{
 		text: "'. JText::_("ADD_NEW_GRID_COLUMN").'",
    	tooltip: "'. JText::_("ADD_NEW_GRID_COLUMN_TOOLTIP").'",               
       	icon: "components/com_jgrid/os/jgrid/icons/table_add.png",
      	cls: "x-btn-text-icon",
     	handler: function () {
       		if(!JGrid.newcolumnrecord)
          	{ 
            	window.alert("'. JText::_("FIRST_SELECT_A_COLUMN_FROM_THE_PULLDOWN_LIST").'");

          	} 
          	else 
          	{
           		var newrowlocation = JGrid.store[2].getCount();
              	var jgrid_newrowcolumns = {
               		id: "",
                   	title: JGrid.gridname,
                 	header: JGrid.newcolumnrecord.data.header,
                 	row_color_pressidence: "",
                 	ordering: newrowlocation + 1,
                  	grid_id: JGrid.selectedgridid,
                  	column_id: JGrid.newcolumnrecord.data.id,
                  	column_type: "",
               		database_sql_name: "",
               		table_sql_name: "",
               		column_sql_name: "",
               		primary_key_column: ""  	
        		};
          		if(newrowlocation==0) var last_record_id=0;
              	else var last_record_id=JGrid.store[2].data.items[newrowlocation-1].data.id;
              	JGrid.proxy[2].api.create="index.php?option=com_jgrid&task=create&controller=jgrid_columngrid&format=ajax&last_record_id="+last_record_id;   
              	JGrid.store[2].insert(newrowlocation, jgrid_newrowcolumns);
               	JGrid.currenteditgrid = Ext.ComponentMgr.get("gridcolumns_data");
               	JGrid.currenteditgrid.getView().refresh();
               	Ext.ComponentMgr.get("columnid").clearValue();
              	//JGrid.combo_store[21].remove(JGrid.newcolumnrecord);
            	JGrid.newcolumnrecord=null;
        	}    
      	}
	},
	{         
    	text: "'. JText::_("REMOVE_COLUMN").'",
      	tooltip: "'. JText::_("REMOVE_COLUMN_TOOLTIP").'",            
     	icon: "components/com_jgrid/os/jgrid/icons/table_delete.png",
       	cls: "x-btn-text-icon",
     	handler: function () {
        	JGrid.currenteditgrid = Ext.ComponentMgr.get("gridcolumns_data");
          	var sm = JGrid.currenteditgrid.getSelectionModel();
          	if (sm.hasSelection()) {
            	Ext.Msg.show({         
               		title: "'. JText::_("REMOVE_COLUMN").'",                                    
                 	buttons: Ext.MessageBox.YESNOCANCEL, 
              		msg: "'. JText::_("REMOVE_SELECTED_COLUMN_QUESTION").'",                          
                  	fn: function (btn) {
                    	if (btn == "yes") {
                       		var sels = sm.getSelection();
                          	// Multiple row delete
                        	for(var i = 0, r; r = sels[i]; i++){             
                         		JGrid.currenteditgrid.getStore().remove(r);
                         	}
                     	}
                	}
         		})
          	}
	  	}
	}]
});';
?>

