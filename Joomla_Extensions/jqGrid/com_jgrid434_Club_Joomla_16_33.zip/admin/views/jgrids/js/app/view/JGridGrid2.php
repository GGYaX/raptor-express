<?php
 /*
 *  JGridAddColumnsToGrid.php  in joomla/Administrator/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
$app = JFactory::getApplication();
?>
 
Ext.define("JGrid.view.JGridGrid2", {
	extend : "Ext.grid.Panel",
	alias : "widget.JGridGrid2",
	id: "gridcolumns_data",
	requires : [ "JGrid.view.JGridToolbar2", "JGrid.store.JGridStore2"  ],
	closeAction: 'hide',
 	height: 400,
	//width: 1250, 
  	plain: true,    
<?php 
            echo 'title: "'. JText::_("ADD_COLUMNS_TO_SELECTED_GRID").'"+JGrid.gridname,
            tooltip: "'. JText::_("ADD_COLUMNS_TO_SELECTED_GRID_TOOLTIP").'",           
            xtype: "editorgrid",                 
            enableDragDrop: true,
          	plugins: [	Ext.create("Ext.grid.plugin.RowEditing", {
    			saveText: "Update",
	  			errorSummary: false,
	  			listeners: {
					validateedit: function(e){
        				e.value = Ext.util.Format.stripTags(e.value);
        			}
      			}
	  		})
			],
            tbar: {xtype: "JGridToolbar2"},        
			viewConfig: {
                  	plugins: {
                  		ddGroup: "grid_columns_data-dd",
                  		ptype: "gridviewdragdrop",
                  		enableDrag: true,
                  		enableDrop: true,
                  		allowCopy: false,
                  		copy: false                		
                  	},
                  	listeners: {
                  		drop: function(objThis, dragData, dropData, position) {
                  			dragData.copy = false;              		                      
            				if(dragData.records.length===0) return;
             				if (dropData.index==0)
              				{
               					// ordering at index 0 which is above index 1 shown on drop index
                   				var new_above_record_id=-1;
                   				var new_record_below_id = dropData.data.id;
            				}
               				else if(dropData.index==this.all.elements.length-1)
               				{
               					// At last record of view
               					var new_above_record_id = dropData.data.id;
               					var new_record_below_id=0;
               				}
               				else
               				{ 
               					// Has records above and below
               					if(position == "before")
            					{
            						var new_above_record_id = -2;
               						var new_record_below_id = dropData.data.id;
            					}
            					else
            					{
            						var new_above_record_id = dropData.data.id;
               						var new_record_below_id = -3;
            					}

             				}    
               				Ext.Ajax.request({
               					waitMsg: "'.JText::_("MOVING_COLUMN").'",                                  
           						url: "index.php?option=com_jgrid&task=moveColumn&format=ajax",
             					params: {
				                	grid_id: JGrid.selectedgridid, 
				                  	first_record_id: dragData.records[0].data.id,
				                   	last_record_id: dragData.records[dragData.records.length-1].data.id,
				                   	new_above_record_id: new_above_record_id,
				                   	new_record_below_id: new_record_below_id,                                                       
				                   	number_of_records: dragData.records.length,
				                   	oldIndex: dragData.item.viewIndex,
				                   	newIndex: dropData.index  	
				              	},
				               	method: "POST",
				              	failure: function (response, options) {
				               		Ext.Msg.alert("'.JText::_("COLUMN_WAS_NOT_MOVED_IN_DATABASE").'");                                                                                                            
				            	},
				            	success: function (response, options) {
				               	},
				              	scope: this
			           		});
				       	}
				    }
          	},
            enableColumnMove: false,
            store: JGrid.store[2],
            columns: JGrid.columns[2],';
?>             
  listeners: {
            	activate: function ( panel, layout, opts)
            	{
            		// add column assignments to actual rendered combo objects
            		combo22 = Ext.getCmp("combo22");
					combo23 = Ext.getCmp("combo23");
					
					combo24 = Ext.getCmp("combo24");
					combo24.on('expand', function () {
					    var database_sql_name = combo23.getValue();
					    if (database_sql_name=="") 
					    {
					      combo24.collapse();
					<?php 
					             echo 'window.alert("'. JText::_("DATABASE_NAME_NOT_SELECTED").'", "'. JText::_("PLEASE_SELECT_A_DATABASE").'");';
					?> 
					      return false;
					    } 
					    JGrid.combo_store[24].load({
					    })
					});
					combo24 = Ext.getCmp("combo24");
					
					combo25 = Ext.getCmp("combo25");
					combo25.on('expand', function () {
					    var table_sql_name = combo24.getValue();
					    if (table_sql_name=="") 
					    {
					      combo25.collapse();
					<?php 
					             echo 'window.alert("'. JText::_("TABLE_NAME_NOT_SELECTED").'", "'. JText::_("PLEASE_SELECT_A_TABLE").'");';
					?> 
					      return false;
					    } 
					    JGrid.combo_store[25].load({});
					});
					
					combo27 = Ext.getCmp("column_select_type");
            	},    
<?php 
     echo '     beforeedit: function (thisEditor,e)
            	{
            		var reditor = Ext.ComponentMgr.get("gridcolumns_data");
            		if(reditor) reditor.editingPlugin.cancelEdit();
                    var cgrid = Ext.ComponentMgr.get("gridcolumns_data");
					JGrid.ceditor = cgrid.editingPlugin.editor;
    				sm = cgrid.getSelectionModel();
    				if (sm.hasSelection()) {
			            JGrid.cselection = sm.getSelection();
			            JGrid.column_selection = sm.getSelection();
			            
			         	var cvalue = JGrid.column_selection[0].get("column_type");
						combo27.setValue(cvalue);
						if(JGrid.select_type=="1")
						{
							switch(cvalue)
							{
		            			case 1:
		            			case 2:	            	
		            			case 3:	            			
		            			case 4:
									cgrid.columns[5].hide();
			    					cgrid.columns[6].hide();
			    					cgrid.columns[7].hide();
			    					cgrid.columns[8].hide();
			    					if(cvalue=="1") cgrid.columns[9].hide();
			    					else cgrid.columns[9].show();
		            				break;
							}
						}
						else
						{
							switch(cvalue) 
							{
		            			case 1:
		            			case 4:
									cgrid.columns[5].hide();
			    					cgrid.columns[6].hide();
			    					cgrid.columns[7].hide();
			    					cgrid.columns[8].hide();
			    					if(cvalue=="1") cgrid.columns[9].hide();
			    					else cgrid.columns[9].show();
			    					break;		            				            	
		            			case 2:
		            				combo23.store.add({database_sql_name_id:"'.$app->getCfg("db").'", database_sql_name:"'.$app->getCfg("db").'"});
			    					combo23.setValue("'.$app->getCfg("db").'");		            			
									cgrid.columns[5].hide();
									cgrid.columns[6].show();
			    					cgrid.columns[7].show();
			    					cgrid.columns[8].show();
			    					cgrid.columns[9].hide();
			    					break;		            			
		            			case 3:
		            				currentDatabase = JGrid.column_selection[0].get("database_sql_name_id");
		            				if(currentDatabase)
		            				{
					            		combo23.store.add({database_sql_name_id:currentDatabase, database_sql_name:currentDatabase});
				    					cgrid.columns[5].show();
				    					combo23.setValue(currentDatabase);
				    				}
				    				else
				    				{
				    					combo23.store.add({database_sql_name_id:"'.$app->getCfg("db").'", database_sql_name:"'.$app->getCfg("db").'"});
				    					combo23.setValue("'.$app->getCfg("db").'");
				    				}
									cgrid.columns[6].show();
			    					cgrid.columns[7].show();
			    					cgrid.columns[8].show();
			    					cgrid.columns[9].hide();
		            				break;
							}							
						}						
						var cvalue = JGrid.column_selection[0].get("table_sql_name_id");
			            combo24.store.add({table_sql_name_id:cvalue, table_sql_name:cvalue});
						combo24.setValue(cvalue);
						
						var cvalue = JGrid.column_selection[0].get("column_sql_name_id");
			            combo25.store.add({column_sql_name_id:cvalue, column_sql_name:cvalue});
						combo25.setValue(cvalue);
						
			        }
			        else JGrid.cselection = "";
			        
			        
			        
                    //JGrid.store[2].save();
                },
                validateedit: function (editor, e) {
                    //editor2.stopEditing();
                    multiple_database_check();
                    var gridcolumns_data = Ext.ComponentMgr.get("gridcolumns_data");
                    if(JGrid.select_type=="1") 
                    {
	            		gridcolumns_data.columns[3].show();
	            		gridcolumns_data.columns[5].hide();
	            		gridcolumns_data.columns[6].hide();
	            		gridcolumns_data.columns[7].hide();
	            		gridcolumns_data.columns[8].hide();		            		
	            		gridcolumns_data.columns[9].show();           			            		
	            	}
	            	else
	            	{
	            		gridcolumns_data.columns[3].show();
	            		gridcolumns_data.columns[4].show();
	            		if(JGrid.multiple_databases==true) gridcolumns_data.columns[5].show();
	            		else gridcolumns_data.columns[5].hide();
	            		gridcolumns_data.columns[6].show();
	            		gridcolumns_data.columns[7].show();
	            		gridcolumns_data.columns[8].show();
	            		gridcolumns_data.columns[9].show(); 
	            		// set sql columns as null
	            		if(combo27.getValue()==1)
	            		{
	    					//JGrid.column_selection[0].set("database_sql_name_id","'.$app->getCfg("db").'");
	    					//JGrid.column_selection[0].set("table_sql_name_id","");
	    					combo23.setValue("'.$app->getCfg("db").'");
	    					combo24.setValue("");
	    					combo25.setValue("");
	    					//JGrid.column_selection[0].set("column_sql_name_id","");
	    					
	    				}
	    				multiple_database_check();
	    				if(JGrid.multiple_databases==true) gridcolumns_data.columns[5].show();
	            		else gridcolumns_data.columns[5].hide();           	
	            	}
	            	if(e.store.data.items.length===1)
	            	{
	            		e.newValues.primary_key_column = true;
	            	}
	            	else if(e.newValues.primary_key_column == true)
	            	{
	            		while(crecord = JGrid.store[2].findRecord("primary_key_column", true ))
	            		{	
							crecord.set("primary_key_column",false);
						} 
	            	}
	            	formula_str = editor.editor.items.items[9].value;
	            	for(i=0;i<e.store.data.items.length;i++)
	            	{
	            		if(e.store.data.items[0].data["dataindex"][0]=="I"||e.store.data.items[0].data["dataindex"][0]=="F")
	            		{
	            			continue;
	            		}
		            	if(formula_str.search(e.store.data.items[0].data["dataindex"])!=-1)
		            	{
		            		window.alert("'. JText::_("NON_NUMBER_DATAINDEX_NOT_ALLOWED_IN_FORMULA").' "+e.store.data.items[0].data["dataindex"]);
		            		return false;
		            	}
	            	}
                    //JGrid.store[2].save();
                   editor.grid.getView().refresh();
                },
                failure: function (response, options) {

                    window.alert("'. JText::_("COLUMN_WAS_NOT_MOVED_IN_DATABASE").'");
                  
                },
               // Took out was looping on first record edited ??
               // success: function (response, options) {
               //     var server_response = Ext.decode(response.responseText);
               // window.alert(response.responseText);
               //JGrid.store[2].commitChanges();
               // editor.grid.getView().refresh();
               // },
                scope: this

            },
          	sm: new Ext.selection.RowModel({
                    singleSelect: false
            }),
            keys: [{
                key: 46,
                fn: function () {
                    JGrid.currenteditgrid = Ext.ComponentMgr.get("gridcolumns_data");
                    var sm = JGrid.currenteditgrid.getSelectionModel();
                    if (sm.hasSelection()) {
                        Ext.Msg.show({
                            title: "' .JText::_("REMOVE_ROW"). '",
                            buttons: Ext.MessageBox.YESNOCANCEL,
                            msg: "' .JText::_("REMOVE_SELECTED_COLUMN_QUESTION"). '",';
?>             
                            fn: function (btn) {
                                if (btn == "yes") {
                                  //JGrid.currenteditgrid.stopEditing();
                                  var sels = sm.getSelection();
                                  // Multiple row delete
                                  for(var i = 0, r; r = sels[i]; i++){             
                                    JGrid.currenteditgrid.getStore().remove(r);
                                  }
                                }
                            }
                        })
                    }
                },
                ctrl: false,
                stopEvent: true
            }]
});
     


    
