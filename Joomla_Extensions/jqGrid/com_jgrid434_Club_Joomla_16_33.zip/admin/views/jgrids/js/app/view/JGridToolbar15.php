<?php
 /*
 *  JGridToolbar15.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');


echo 'Ext.define("JGrid.view.JGridToolbar15.php", {
	extend : "Ext.toolbar.Toolbar",	
	alias : "widget.JGridToolbar15",
	id : "JGridToolbar15",
	items : [{
                text: "'. JText::_("ADD_SELECT_DEPENDENCY").'",
                icon: "components/com_jgrid/os/jgrid/icons/table_add.png",
                cls: "x-btn-text-icon",
                tooltip: "'. JText::_("ADD_SELECT_DEPENDENCIE_TOOLTIP").'",
                handler: function () {
                    var newrowlocation = JGrid.store[15].getCount();
                    var jgrid_newrowcolumns15 = {
                        id: "",
                        grid_id: JGrid.selectedgridid,
                        criteria_type_id: "",
                        sdatabase_sql_name: "",
                        stable_sql_name: "",
                        scolumn_sql_name: "",
                        jdatabase_sql_name: "",
                        jtable_sql_name: "",
                        jcolumn_sql_name: "",
                      	select_wildcard_id: "",
                        criteria_value: ""
                    };                
                    if (newrowlocation == null) newrowlocation = 0;                  
                    JGrid.store[15].insert(newrowlocation, jgrid_newrowcolumns15);
                    JGrid.currenteditgrid = Ext.ComponentMgr.get("where_clause_dependencies");
          			JGrid.currenteditgrid.getView().refresh();
             
               }
            },
            {
                text: "'. JText::_("REMOVE_WHERE_CLAUSE_DEPENDENCY").'",
                icon: "components/com_jgrid/os/jgrid/icons/table_delete.png",
                cls: "x-btn-text-icon",
                tooltip: "'. JText::_("REMOVE_WHERE_CLAUSE_DEPENDENCY_TOOLTIP").'",
                handler: function () {
                    JGrid.currenteditgrid = Ext.ComponentMgr.get("where_clause_dependencies");
                    var sm = JGrid.currenteditgrid.getSelectionModel();
                    var sel = sm.getSelection();
                    if (sm.hasSelection()) {
                        Ext.Msg.show({
                            title: "'. JText::_("REMOVE_WHERE_CLAUSE").'",
                            buttons: Ext.MessageBox.YESNOCANCEL,
                            msg: "'. JText::_("REMOVE_WHERE_CLAUSE_QUESTION").'",
                            fn: function (btn) {
                                if (btn == "yes") {
                                    JGrid.store[15].remove(sel[0]);
                                }
                            }
                        })
                    }
                }
            }]
});';
?>

