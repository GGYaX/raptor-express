<?php
/**
 * JGridControllers.php in joomla/Components/views/jgrid/js/app/controller
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

//require_once(JPATH_BASE . '/administrator/components/com_jgrid/os/jgrid/functions.php' );

	

// define controller for each grid in panel

	echo 'Ext.define("JGrid.controller.JGridController0", {
	    extend: "Ext.app.Controller",   
	    models: ["JGridModel0"],
	    stores: ["JGridStore0"],
//	    refs: [{
//	        ref: "JGridController0",
//	        selector: "JGridController0"
//	    }],  
	    init: function() {
	        var me = this;
	        var myJGridStore0 = me.getJGridStore0Store();	        	        
	        this.control({
	            "viewport > panel": {
	                //render: this.onPanelRendered
	            }
	        });
	    }    
	 });'; 

	
    
   
    
?>
