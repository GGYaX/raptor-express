<?php
/*
 *  JGridColumns.php in joomla/administrator/components/com_jgrid/r/jgrid/js/app/renderers
 *
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
 
// define the grid columns 
echo 'JGrid.columns[0] = [{
    header: "'. JText::_("ID").'",
    dataIndex: "id",
    hidden: false,
    tooltip: "'. JText::_("GRID_ID_TOOLTIP").'",
    allowBlank: true
},
{
    header: "'. JText::_("GRID_APPLICATION_NAME").'",
    dataIndex: "grid_application_name",
    tooltip: "'. JText::_("GRID_APPLICATION_NAME_TOOLTIP").'",
    editor: combo101
 
},
{
    header: "'. JText::_("RENDERTO").'",
    dataIndex: "renderto",
    tooltip: "'. JText::_("RENDERTO_TOOLTIP").'",
    hidden: true
},
{
    header: "grid_reference_id",
    dataIndex: "grid_reference_id",
    hidden: true
},
{
    header: "'. JText::_("TITLE").'",
    dataIndex: "title",
    width:200,
    tooltip: "'. JText::_("TITLE_TOOLTIP").'",   
    field: {
		xtype: "textfield"
    }
},
{
    header: "'. JText::_("HEIGHT").'",
    dataIndex: "height",
    tooltip: "'. JText::_("HEIGHT_TOOLTIP").'",
    field: {
		xtype: "numberfield"
    }
},
{
    header: "'. JText::_("WIDTH").'",
    dataIndex: "width",
    tooltip: "'. JText::_("WIDTH_TOOLTIP").'",
    field: {
		xtype: "numberfield"
    }
},
{
    header: "'. JText::_("GRID_TAB_ORDER").'",
    dataIndex: "ordering",
    hidden: true,
    tooltip: "'. JText::_("GRID_TAB_ORDER_TOOLTIP").'"
}
];'; 
	        
echo 'JGrid.columns[1] = [{
    header: "'. JText::_("ID").'",
    dataIndex: "id",
    width: 25,
    hidden: false,
    tooltip: "'. JText::_("COLUMN_ID_TOOLTIP").'",
    allowBlank: true
},
{
    header: "'. JText::_("COLUMN_TITLE").'",
    dataIndex: "header",
    width: 150,
    tooltip: "'. JText::_("COLUMN_TITLE_TOOLTIP").'",
    field: {
		xtype: "textfield"
    }
},
{
    header: "'. JText::_("EDIT_ROW").'",
    dataIndex: "editable",
    xtype: "booleancolumn",
    align: "center",
    width: 50,
    trueText: "'. JText::_("JYES").'",
    falseText: "'. JText::_("JNO").'",
    tooltip: "'. JText::_("EDITABLE_TOOLTIP").'",
    field: {
		xtype: "checkbox"
    }
},
{
    header: "'. JText::_("WIDTH").'",
    dataIndex: "width",
    width: 50,
    tooltip: "'. JText::_("WIDTH_TOOLTIP").'",
    field: {
		xtype: "numberfield"
    }
},
{
    header: "'. JText::_("DATA_TYPE").'",
    dataIndex: "data_type",
    width: 75,
    tooltip: "'. JText::_("DATA_TYPE_TOOLTIP").'",
    editor: combo11
},
{
    header: "'. JText::_("DEFAULT").'",
    dataIndex: "ddefault",
    width: 150,
    tooltip: "'. JText::_("DEFAULT_TOOLTIP").'",
    field: {
		xtype: "textfield"
    }
},
{
    header: "'. JText::_("FORMAT_VALIDATE").'",
    dataIndex: "validation_type",
    width: 90,
    tooltip: "'. JText::_("VALIDATION_TYPE_TOOLTIP").'",   
    editor: combo13
},
{
    header: "'. JText::_("ALIGNMENT").'",
    dataIndex: "align",
    width: 60,
    tooltip: "'. JText::_("ALIGNMENT_TOOLTIP").'",   
    editor: combo14
},
{
    header: "'. JText::_("FORMAT").'",
    dataIndex: "css",
    width: 50,
    tooltip: "'. JText::_("FORMAT_TOOLTIP").'",   
    field: {
		xtype: "textfield"
    }
},
{
    header: "'. JText::_("FILTER").'",
    dataIndex: "dfilter",
    width: 50,
    xtype: "booleancolumn",
    align: "center",
    trueText: "'. JText::_("JYES").'",
    falseText: "'. JText::_("JNO").'",
    tooltip: "'. JText::_("FILTER_TOOLTIP").'",
    field: {
		xtype: "checkbox"
    }
},
{
    header: "'. JText::_("SORTABLE").'",
    dataIndex: "sortable",
    width: 50,
    xtype: "booleancolumn",
    align: "center",
    trueText: "'. JText::_("JYES").'",
    tooltip: "'. JText::_("SORTABLE_TOOLTIP").'",
    field: {
		xtype: "checkbox"
    }
},
{
    header: "'. JText::_("TOOL_TIP").'",
    dataIndex: "tooltip",
    width: 100,
    tooltip: "'. JText::_("TOOL_TIP_TOOLTIP").'",
    field: {
		xtype: "textfield"
    }
},
{
    header: "'. JText::_("EMAIL_SUBJECT").'",
    dataIndex: "email_subject",
    width: 150,
    tooltip: "'. JText::_("EMAIL_SUBJECT_TOOLTIP").'",
    field: {
		xtype: "textfield"
    }
},
{
    header: "'. JText::_("FREEZE_COLUMN").'",
    dataIndex: "freeze_column",
    width: 90,
    xtype: "booleancolumn",
    align: "center",
    trueText: "'. JText::_("JYES").'",
    tooltip: "'. JText::_("FREEZE_COLUMN_TOOLTIP").'",
    field: {
		xtype: "checkbox"
    }
},
{
    header: "'. JText::_("SUMMARYCOLUMN").'",
    dataIndex: "summarycolumn",
    width: 100,
    xtype: "booleancolumn",
    align: "center",
    trueText: "'. JText::_("JYES").'",
    tooltip: "'. JText::_("SUMMARYCOLUMN_TOOLTIP").'",
    field: {
		xtype: "checkbox"
    }
},{
    header: "'. JText::_("SUMMARYTYPE").'",
    dataIndex: "summarytype",
    width: 80,
    tooltip: "'. JText::_("SUMMARYTYPE_TOOLTIP").'",
    editor: comboSummarytype

},{
    header: "'. JText::_("SUMMARYPREFIX").'",
    dataIndex: "summaryprefix",
    width: 100,
    tooltip: "'. JText::_("SUMMARYPREFIX_TOOLTIP").'",
    field: {
		xtype: "textfield"
    }

},{
    header: "'. JText::_("SUMMARYPOSTFIX").'",
    dataIndex: "summarypostfix",
    width: 100,
    tooltip: "'. JText::_("SUMMARYPOSTFIX_TOOLTIP").'",
    field: {
		xtype: "textfield"
    }

}];';
	        
echo 'JGrid.columns[2] = [{
    header: "'. JText::_("ID").'",
    tooltip: "'. JText::_("COLUMNGRID_ID_TOOLTIP").'",
    dataIndex: "id",
    width: 25,
    hidden: false,
    allowBlank: true
},
{
    header: "'. JText::_("GRID_NAME").'",
    tooltip: "'. JText::_("GRID_NAME_TOOLTIP").'",
    width: 150,
    dataIndex: "title",
    hidden: true
},
{
    header: "'. JText::_("COLUMN_NAME").'",
    tooltip: "'. JText::_("COLUMN_NAME_TOOLTIP").'",
    width: 150,
    dataIndex: "header"
},
{
    header: "'. JText::_("DATAINDEX").'",
    dataIndex: "dataindex",
    width: 75,
    tooltip: "'. JText::_("DATAINDEX_TOOLTIP").'"
},
{
    header: "'. JText::_("COLUMN_SELECT_TYPE").'",
    tooltip: "'. JText::_("COLUMN_SELECT_TYPE_TOOLTIP").'",
    width: 115,
    hidden: false,
    dataIndex: "column_type",
 	renderer: function (value) {
            var r = JGrid.combo_store[27].findRecord("column_type", value)
            if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
            }
            return r.data.column_type_name;
    },
	editor: combo27
},
{
    header: "'. JText::_("MYSQL_DATABASE_NAME").'",
    tooltip: "'. JText::_("MYSQL_DATABASE_NAME_TOOLTIP").'",
    width: 150,
    hidden: true,
    dataIndex: "database_sql_name_id",
	editor: combo23
},
{
    header: "'. JText::_("MYSQL_TABLE_NAME").'",
    tooltip: "'. JText::_("MYSQL_TABLE_NAME_TOOLTIP").'",
    width: 150,
    hidden: true,
    dataIndex: "table_sql_name_id",
	editor: combo24 
},
{
    header: "'. JText::_("MYSQL_COLUMN_NAME").'",
    tooltip: "'. JText::_("MYSQL_COLUMN_NAME_TOOLTIP").'",
    width: 150,
    hidden: true,
    dataIndex: "column_sql_name_id",
	editor: combo25   
},
{
    header: "'. JText::_("MYSQL_PRIMARY_KEY_COLUMN").'",
    tooltip: "'. JText::_("MYSQL_PRIMARY_KEY_COLUMN_TOOLTIP").'",
    width: 115,
    hidden: true,
	xtype: "booleancolumn",
	align: "center",			           
	trueText: "'. JText::_("JYES").'",
	falseText: "'. JText::_("JNO").'",
    dataIndex: "primary_key_column",
    editor: new Ext.form.Checkbox({})    
},
{
    header: "'. JText::_("COLUMN_FORMULA").'",
    tooltip: "'. JText::_("COLUMN_FORMULA_TOOLTIP").'",
    dataIndex: "formula",
    width: 400,
    hidden: true,
    field: {
		xtype: "textfield"
    }
},
{
    header: "'. JText::_("COLUMN_COLOR_PRIORITY").'",
    tooltip: "'. JText::_("COLUMN_COLOR_PRIORITY_TOOLTIP").'",
    dataIndex: "row_color_pressidence",
    //width: 75,	   
    renderer: function (value) {
            var r = JGrid.combo_store[22].findRecord("row_color_pressidence", value)
            if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
            }
            return r.data.Color_Priority;
    },
	editor: combo22
},
{
    header: "'. JText::_("COLUMN_ORDER").'",
    tooltip: "'. JText::_("COLUMN_ORDER_TOOLTIP").'",
    dataIndex: "ordering",
    hidden: true
},
{
    header: "'. JText::_("GRID_ID").'",
    tooltip: "'. JText::_("GRID_ID_TOOLTIP").'",
    dataIndex: "grid_id",
    hidden: true
},
{
    header: "'. JText::_("COLUMN_ID").'",
    tooltip: "'. JText::_("COLUMN_ID_TOOLTIP").'",
    dataIndex: "column_id",
    hidden: true
}

];'; 
	        
echo 'JGrid.columns[4] = [{
    header: "'. JText::_("ID").'",
    dataIndex: "id",
    hidden: false,
    tooltip: "'. JText::_("ACCESS_RULE_ID_TOOLTIP").'",
    allowBlank: true
},
{
    header: "'. JText::_("APPLICATION").'",
    dataIndex: "access_rule_application_id",
    renderer: function (value) {
            var r = JGrid.combo_store[45].findRecord("access_rule_application_id", value)
            if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
            }
            return r.data.access_rule_application;
    },
    tooltip: "'. JText::_("APPLICATION_RULE_TOOLTIP").'"
},
{
    header: "'. JText::_("ACCESS_FOR").'",
    dataIndex: "access_for",
    renderer:  function (value) {
            var r = JGrid.combo_store[40].findRecord("access_for", value)
            if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
            }
            return r.data.Type;
    },
    tooltip: "'. JText::_("ACCESS_FOR_TOOLTIP").'"
},
{
    header: "'. JText::_("USER_ROLE_NAME").'",
    dataIndex: "access_for_id",
    renderer: function (value) {
            var r = JGrid.combo_store[41].findRecord("access_for_id", value)
            if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
            }
            return r.data.access_for_name;
    },
    tooltip: "'. JText::_("USER_NAME_TOOLTIP").'"
},
{
    header: "'. JText::_("ACCESS_TYPE").'",
    dataIndex: "access_type",
    renderer: function (value) {
            var r = JGrid.combo_store[42].findRecord("access_type", value)
            if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
            }
            return r.data.Type;
    },
    tooltip: "'. JText::_("ACCESS_TYPE_TOOLTIP").'"
},
{
    header: "'. JText::_("OBJECT_NAME").'",
    dataIndex: "access_type_id",
    renderer: function (value) {
            var r = JGrid.combo_store[43].findRecord("access_type_id", value)
            if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
            }
            return r.data.access_type_name;
    },
    tooltip: "'. JText::_("OBJECT_NAME_TOOLTIP").'",
    width: 200
},
{
    header: "'. JText::_("ACCESS_LEVEL").'",
    dataIndex: "access_level",
    renderer: function (value) {
            var r = JGrid.combo_store[44].findRecord("access_level", value)
            if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
            }
            return r.data.Type;
    },
    tooltip: "'. JText::_("ACCESS_LEVEL_TOOLTIP").'"
},
{
    header: "'. JText::_("USERID_ASSIGNING_ACCESS").'",
    dataIndex: "userid_assigning_access",
    tooltip: "'. JText::_("USERID_ASSIGNING_ACCESS_TOOLTIP").'",
    hidden: true
},
{
    header: "'. JText::_("LAST_UPDATED").'",
    dataIndex: "last_updated",
    tooltip: "'. JText::_("LAST_UPDATED_TOOLTIP").'",
    hidden: true
}];';
	        
echo 'JGrid.columns[7]=[
{
       header: "'. JText::_("ID").'", 
	   dataIndex: "id", 
	   hidden: false, 
	   allowBlank: true
},
{
	   header: "'. JText::_("USER_NAME").'", 
		dataIndex: "userid",
		renderer:  function (value) {
			var r = JGrid.combo_store[73].findRecord("userid", value)
	  		if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
	     	}
	    	return r.data.username;
    	},
	   	editor: combo73
},
{
	  header: "'. JText::_("ROLE_NAME").'",
		dataIndex: "role_id",
		renderer:  function (value) {
			var r = JGrid.combo_store[71].findRecord("role_id", value)
		  	if (Ext.isEmpty(r)) {
	        	return "'. JText::_("VALUE_NOT_FOUND").'";
		  	}
	    	return r.data.role_name;
    	},
	  editor: combo71
}				   
];';

echo 'JGrid.columns[8]=[
{
       header: "'. JText::_("ID").'", 
	   dataIndex: "id", 
	   hidden: false, 
	   allowBlank: true
},
{
	   header: "'. JText::_("ROLE_NAME").'",
       tooltip: "'. JText::_("ROLE_NAME_TOOLTIP").'", 
	   dataIndex: "role_name",
	   field: {
	   	xtype: "textfield"
       }
},
{
      header: "'. JText::_("ROLE_DESCRIPTION").'",
      tooltip: "'. JText::_("ROLE_DESCRIPTION_TOOLTIP").'",
	  dataIndex: "description",
	  width: 200,
	  field: {
		xtype: "textfield"
      }
}				   
];';


echo 'JGrid.columns[9] = [
{
    header: "'. JText::_("ID").'",
    tooltip: "'. JText::_("MODIFY_DEFAULT_GROUP_ID_TOOLTIP").'",	
    dataIndex: "id",
    hidden: false,
    allowBlank: true
},
{
    header: "'. JText::_("DEFAULT_GROUP").'",
    tooltip: "'. JText::_("DEFAULT_GROUP_TOOLTIP").'",
    dataIndex: "usertype_name"
},
{
    header: "'. JText::_("ACCESS_RIGHTS").'",
    tooltip: "'. JText::_("ACCESS_RIGHTS_TOOLTIP").'",
    dataIndex: "access_level",
    renderer: function (value) {
            var r = JGrid.combo_store[44].findRecord("access_level", value)
            if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
            }
            return r.data.Type;
    },
	editor: combo99
}];';



echo 'JGrid.columns[12] = [{
    header: "'. JText::_("ID").'",
    dataIndex: "id",
    hidden: true,
    allowBlank: true  
},
{
    header: "'. JText::_("LIST_BOX_VALUES").'",
    tooltip: "'. JText::_("LIST_BOX_VALUES_TOOLTIP").'",
    dataIndex: "listboxvalues",
    width: 248,
    field: {
		xtype: "textfield"
    }, 
    sortable: true
}];';

echo 'JGrid.columns[15] = [{
    header: "'. JText::_("ID").'",
    dataIndex: "id",
    hidden: true,
    allowBlank: true  
},
{
    header: "'. JText::_("CRITERIA_TYPE").'",
    tooltip: "'. JText::_("CRITERIA_TYPE_TOOLTIP").'",
    dataIndex: "criteria_type_id",
    hidden: true,
    width: 75, 
    sortable: true,
   	renderer: function (value) {
            var r = JGrid.combo_store[17].findRecord("criteria_type_id", value)
            if (Ext.isEmpty(r)) {
                return "'. JText::_("VALUE_NOT_FOUND").'";
            }
            return r.data.criteria_type;
    },
	editor: combo17
},
{
    header: "'. JText::_("MYSQL_DATABASE_NAME").'",
    tooltip: "'. JText::_("MYSQL_DATABASE_NAME_TOOLTIP").'",
    width: 150,
    hidden: true,
    dataIndex: "database_sql_name_id",
	editor: combo28
},
{
    header: "'. JText::_("MYSQL_TABLE_NAME").'",
    tooltip: "'. JText::_("MYSQL_TABLE_NAME_TOOLTIP").'",
    width: 150,
    dataIndex: "table_sql_name_id",
	editor: combo29 
},
{
    header: "'. JText::_("MYSQL_COLUMN_NAME").'",
    tooltip: "'. JText::_("MYSQL_COLUMN_NAME_TOOLTIP").'",
    width: 150,
    dataIndex: "column_sql_name_id",
	editor: combo30   
},
{
    header: "'. JText::_("CRITERIA_OPERATOR").'",
    tooltip: "'. JText::_("CRITERIA_OPERATOR_TOOLTIP").'",
    dataIndex: "criteria_operator_id",
    width: 150, 
    sortable: true,
	editor: combo15
},
{
    header: "'. JText::_("MYSQL_DATABASE_NAME").'",
    tooltip: "'. JText::_("MYSQL_DATABASE_NAME_TOOLTIP").'",
    width: 150,
    hidden: true,
    dataIndex: "jdatabase_sql_name_id",
	editor: combo31
},
{
    header: "'. JText::_("MYSQL_TABLE_NAME").'",
    tooltip: "'. JText::_("MYSQL_TABLE_NAME_TOOLTIP").'",
    width: 150,
    dataIndex: "jtable_sql_name_id",
	editor: combo32 
},
{
    header: "'. JText::_("MYSQL_COLUMN_NAME").'",
    tooltip: "'. JText::_("MYSQL_COLUMN_NAME_TOOLTIP").'",
    width: 150,
    dataIndex: "jcolumn_sql_name_id",
	editor: combo33   
},
{
    header: "'. JText::_("WILDCARD_CRITERIA").'",
    tooltip: "'. JText::_("WILDCARD_CRITERIA_TOOLTIP").'",
    dataIndex: "select_wildcard_id",
    width: 100,
	editor: combo16
},
{
    header: "'. JText::_("CRITERIA_VALUE").'",
    tooltip: "'. JText::_("CRITERIA_VALUE_TOOLTIP").'",
    dataIndex: "criteria_value",
    width: 100, 
    sortable: true,
    field: {
		xtype: "textfield"
      }
}

];';

?>    
    