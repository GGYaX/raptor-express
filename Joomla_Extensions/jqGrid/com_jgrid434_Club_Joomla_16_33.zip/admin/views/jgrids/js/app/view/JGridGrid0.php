<?php
 /*
 *  JGridGrid0.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');

echo 'Ext.define("JGrid.view.JGridGrid0", {
	extend : "Ext.grid.Panel",
	alias : "widget.JGridGrid0",
	requires : [ "JGrid.view.JGridToolbar0", "JGrid.store.JGridStore0"  ],
   	id: "grids_data",	
  	title: "'. JText::_("DATA_GRID_SETTINGS").'",
  	xtype: "editorgrid",
   	tabTip: "'. JText::_("DATA_GRID_SETTINGS_TABTIP").'",
  	height: 250,
  	width: 750,
  	enableDragDrop: true,
 	enableColumnMove: false,
	store: JGrid.store[0],
 	columns: JGrid.columns[0],
 	//selModel: Ext.create("Ext.selection.RowModel", { singleSelect: true, selectFirstRow: true }),
 	selModel: Ext.create("Ext.selection.RowModel", { mode: "MULTI"}),    	
	tbar: {xtype: "JGridToolbar0"},		    
	frame: true,
	stripeRows: true,
	enableColumnResize: true,
	columnLines: true,
	listeners: {
       activate: function ( panel, layout, opts)
       {
       		combo101 = Ext.getCmp("combo101");
       }
    },	
	beforeRender: function() {
      	JGrid.grids[0] = Ext.ComponentMgr.get("grids_data");
    },
    selType: "rowmodel",
   	plugins: [	Ext.create("Ext.grid.plugin.RowEditing", {
    				saveText: "Update",
	  				errorSummary: false,
	  				clicksToEdit: 2,
	  				listeners: {
						validateedit: function(e){
        					e.value = Ext.util.Format.stripTags(e.value);
        				}
      				}
	  			})
	],
	keys: [{
		key: 46,
		fn: function () {
			var pgrid = Ext.ComponentMgr.get("grids_data");
			var sm = pgrid.getSelectionModel();
			var sel = sm.getSelected();
			var gridname = sel.get("title");
			if (sm.hasSelection()) {
				Ext.Msg.show({
					title: "'. JText::_("GRID_SETTINGS").'",
                  	buttons: Ext.MessageBox.YESNOCANCEL,
                  	msg:" "+gridname+"?",
                   	fn: function (btn) {
                    	if (btn == "yes") {           
                        	//pgrid.stopEditing();
                           	var sels = sm.getSelection();
                           	// Multiple row delete
                           	for(var i = 0, r; r = sels[i]; i++){             
                            	pgrid.getStore().remove(r);
                          	}              
	                  	}
	            	}
       			})
           	} else Ext.Msg.alert("'. JText::_("PLEASE").'", "'. JText::_("SELECT_GRID_FIRST_TO_MODIFY_SETTINGS").'");
     	},
     	ctrl: false,
     	stopEvent: true
  	}],
  	viewConfig: {
		plugins: {
             		ddGroup: "gridDD0",
                	ptype: "gridviewdragdrop",
                  	enableDrag: true,
                  	enableDrop: true,
                  	allowCopy: false
   		},
      	listeners: {
						drop: function(objThis, dragData, dropData, position) {
            				if(dragData.records.length===0) return;
             				if (dropData.index==0)
              				{
               					// ordering at index 0 which is above index 1 shown on drop index
                   				var new_above_record_id=-1;
                   				var new_record_below_id = dropData.data.id;
            				}
               				else if(dropData.index==this.all.elements.length-1)
               				{
               					// At last record of view
               					var new_above_record_id = dropData.data.id;
               					var new_record_below_id=-1;
               				}
               				else
               				{ 
               					// Has records above and below
               					if(position == "before")
            					{
            						var new_above_record_id = -1;
               						var new_record_below_id = dropData.data.id;
            					}
            					else
            					{
            						var new_above_record_id = dropData.data.id;
               						var new_record_below_id = -1;
            					}

             				}    
               				Ext.Ajax.request({
               					waitMsg: "'.JText::_("MOVING_ROW").'",                                  
           						url: "index.php?option=com_jgrid&task=moveGrid&format=ajax",
             					params: { 
				                  	first_record_id: dragData.records[0].data.id,
				                   	last_record_id: dragData.records[dragData.records.length-1].data.id,
				                   	new_above_record_id: new_above_record_id,
				                   	new_record_below_id: new_record_below_id,                                                       
				                   	number_of_records: dragData.records.length,
				                   	oldIndex: dragData.item.viewIndex,
				                   	newIndex: dropData.index
				              	},
				               	method: "POST",
				              	failure: function (response, options) {
				               		Ext.Msg.alert("'.JText::_("COLUMN_WAS_NOT_MOVED_IN_DATABASE").'");    //RMS fix message                                                                                                        
				            	},
				            	success: function (response, options) {
				               	},
				              	scope: this
			           		});
				       	}
		}
	}                              	
});
// load initital store and grid
		JGrid.store[0].load();
';
?>


