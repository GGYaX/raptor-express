<?php
 /*
 *  JGridHelp.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>

// Grids help
Ext.define("JGrid.view.JGridHelp0", {
	extend : "Ext.window.Window",
	alias : "widget.JGridHelp0",
    renderTo: "editcell",
    tbar: [
  			{ 	xtype: 'button',
<?php  			 
  				echo 'text: "'. JText::_("HELP_INDEX").'",
  				icon: "'.JURI::base().'components/com_jgrid/os/jgrid/icons/lightbulb.png",
                tooltip: "'. JText::_("FULL_INDEXED_HELP_TOPICS_ON_USING_JGRID").'",';
?>                
               	handler: function () 
               	{
					window.open("http://www.datagrids.clubsareus.org/images/stories/HelpDocs/JGridHelp.htm");
  				}
  			}
	],
<?php     
    echo 'title: "'.JText::_("HELP_INSTRUCTIONS").'",
    tooltip: "'. JText::_("HELP_INSTRUCTIONS_TOOLTIP").'",';
  ?>   
    // x: 40,
     y: 100,
     closeAction: 'hide', 
     minimizable: true,  
     maximizable: true,
   	 items: {
      //  xtype: "iframepanel",
      xtype: "uxiframe",
<?php       
      echo 'src: "'.JURI::base().'components/com_jgrid/help/en-GB/jgrid_admin_grids_helpfile.html",';        
?>      
      width: 700,  
      height: 650,
      autoRender: true

	}     
});


// columns help
Ext.define("JGrid.view.JGridHelp1", {
	extend : "Ext.window.Window",
	alias : "widget.JGridHelp1",
    renderTo: "editcell",
    tbar: [
  			{ 	xtype: 'button',
<?php  			 
  				echo 'text: "'. JText::_("HELP_INDEX").'",
  				icon: "'.JURI::base().'components/com_jgrid/os/jgrid/icons/lightbulb.png",
                tooltip: "'. JText::_("FULL_INDEXED_HELP_TOPICS_ON_USING_JGRID").'",';
?>                
               	handler: function () 
               	{
					window.open("http://www.datagrids.clubsareus.org/images/stories/HelpDocs/JGridHelp.htm");
  				}
  			}
	],
<?php     
    echo 'title: "'.JText::_("HELP_INSTRUCTIONS").'",
    tooltip: "'. JText::_("HELP_INSTRUCTIONS_TOOLTIP").'",';
  ?>   
    // x: 40,
     y: 100,
     closeAction: 'hide', 
     minimizable: true,  
     maximizable: true,
   	 items: {
      //  xtype: "iframepanel",
      xtype: "uxiframe",
<?php       
      echo 'src: "'.JURI::base().'components/com_jgrid/help/en-GB/jgrid_admin_columns_helpfile.html",';        
?>      
      width: 695,  
      height: 400,
      autoRender: true

	}     
});

//help access rules and roles panels
Ext.define("JGrid.view.JGridHelp2", {
	extend : "Ext.window.Window",
	alias : "widget.JGridHelp2",
    renderTo: "editcell",
    tbar: [
  			{ 	xtype: 'button',
<?php  			 
  				echo 'text: "'. JText::_("HELP_INDEX").'",
  				icon: "'.JURI::base().'components/com_jgrid/os/jgrid/icons/lightbulb.png",
                tooltip: "'. JText::_("FULL_INDEXED_HELP_TOPICS_ON_USING_JGRID").'",';
?>                
               	handler: function () 
               	{
					window.open("http://www.datagrids.clubsareus.org/images/stories/HelpDocs/JGridHelp.htm");
  				}
  			}
	],
<?php     
    echo 'title: "'.JText::_("HELP_INSTRUCTIONS").'",
    tooltip: "'. JText::_("HELP_INSTRUCTIONS_TOOLTIP").'",';
  ?>   
     //x: 40,
     y: 100,
     closeAction: 'hide', 
     minimizable: true,  
     maximizable: true,
   	 items: {
      //  xtype: "iframepanel",
      xtype: "uxiframe",
<?php       
      echo 'src: "'.JURI::base().'components/com_jgrid/help/en-GB/jgrid_admin_access_helpfile.html",';        
?>      
      width: 695,  
      height: 400,
      autoRender: true

	}     
});


//help columngrid win
Ext.define("JGrid.view.JGridHelp3", {
	extend : "Ext.window.Window",
	alias : "widget.JGridHelp3",
    renderTo: "editcell",
    tbar: [
  			{ 	xtype: 'button',
<?php  			 
  				echo 'text: "'. JText::_("HELP_INDEX").'",
  				icon: "'.JURI::base().'components/com_jgrid/os/jgrid/icons/lightbulb.png",
                tooltip: "'. JText::_("FULL_INDEXED_HELP_TOPICS_ON_USING_JGRID").'",';
?>                
               	handler: function () 
               	{
					window.open("http://www.datagrids.clubsareus.org/images/stories/HelpDocs/JGridHelp.htm");
  				}
  			}
	],
<?php     
    echo 'title: "'.JText::_("HELP_INSTRUCTIONS").'",
    tooltip: "'. JText::_("HELP_INSTRUCTIONS_TOOLTIP").'",';
  ?>   
    // x: 40,
     y: 100,
	 closeAction: "hide", 
     minimizable: true,  
     maximizable: true,
   	 items: {
      //  xtype: "iframepanel",
      xtype: "uxiframe",
<?php       
      echo 'src: "'.JURI::base().'components/com_jgrid/help/en-GB/jgrid_admin_columngrid_helpfile.html",';        
?>      
      width: 695,  
      height: 400,
      autoRender: true

	}     
});

//help newrole
Ext.define("JGrid.view.JGridHelp4", {
	extend : "Ext.window.Window",
	alias : "widget.JGridHelp4",
    renderTo: "editcell",
    tbar: [
  			{ 	xtype: 'button',
<?php  			 
  				echo 'text: "'. JText::_("HELP_INDEX").'",
  				icon: "'.JURI::base().'components/com_jgrid/os/jgrid/icons/lightbulb.png",
                tooltip: "'. JText::_("FULL_INDEXED_HELP_TOPICS_ON_USING_JGRID").'",';
?>                
               	handler: function () 
               	{
					window.open("http://www.datagrids.clubsareus.org/images/stories/HelpDocs/JGridHelp.htm");
  				}
  			}
	],
<?php     
    echo 'title: "'.JText::_("HELP_INSTRUCTIONS").'",
    tooltip: "'. JText::_("HELP_INSTRUCTIONS_TOOLTIP").'",';
  ?>   
    // x: 40,
     y: 100,
     closeAction: 'hide', 
     minimizable: true,  
     maximizable: true,
   	 items: {
      //  xtype: "iframepanel",
      xtype: "uxiframe",
<?php       
      echo 'src: "'.JURI::base().'components/com_jgrid/help/en-GB/jgrid_admin_newroles_helpfile.html",';        
?>      
      width: 695,  
      height: 400,
      autoRender: true

	}     
});

//help newrole
Ext.define("JGrid.view.JGridHelp5", {
	extend : "Ext.window.Window",
	alias : "widget.JGridHelp5",
    renderTo: "editcell",
    tbar: [
  			{ 	xtype: 'button',
<?php  			 
  				echo 'text: "'. JText::_("HELP_INDEX").'",
  				icon: "'.JURI::base().'components/com_jgrid/os/jgrid/icons/lightbulb.png",
                tooltip: "'. JText::_("FULL_INDEXED_HELP_TOPICS_ON_USING_JGRID").'",';
?>                
               	handler: function () 
               	{
					window.open("http://www.datagrids.clubsareus.org/images/stories/HelpDocs/JGridHelp.htm");
  				}
  			}
	],
<?php     
    echo 'title: "'.JText::_("HELP_INSTRUCTIONS").'",
    tooltip: "'. JText::_("HELP_INSTRUCTIONS_TOOLTIP").'",';
  ?>   
     //x: 40,
     y: 100,
     closeAction: 'hide', 
     minimizable: true,  
     maximizable: true,
   	 items: {
      //  xtype: "iframepanel",
      xtype: "uxiframe",
<?php       
      echo 'src: "'.JURI::base().'components/com_jgrid/help/en-GB/jgrid_admin_newroles_helpfile.html",';        
?>      
      width: 695,  
      height: 400,
      autoRender: true

	}     
});

