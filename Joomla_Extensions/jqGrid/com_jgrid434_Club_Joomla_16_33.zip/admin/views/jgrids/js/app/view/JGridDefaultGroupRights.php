<?php
 /*
 *  JGridDefaultGroupRights.php  in joomla/Administrator/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
 
Ext.define("JGrid.view.JGridDefaultGroupRights", {
	extend : "Ext.window.Window",
	alias : "widget.JGridDefaultGroupRights",
	requires : ["JGrid.store.JGridStore9"  ],
	id: "JGridDefaultGroupRights",
 <?php
           echo 'title: "'.JText::_("MODIFY_DEFAULT_GROUP").'",
           tooltip: "'. JText::_("MODIFY_DEFAULT_GROUP_TOOLTIP").'",';
 ?>  
	renderTo: 'editcell',
	closeAction: 'hide',
	layout: 'fit',
    autoHeight: true,
  	width: 762,
   //	height: 450,
  // 	x: 35,
  	y: 100, 
  	plain: true,    
	items:  [
	{
	 	id: "default_groups",          
	    xtype: "editorgrid",
	    layout: 'fit',    
	    tbar: [{
	            	text: ''
	            }],
    	autoHeight: true, 
		//height: 440,
		width: 750,                 
		enableDragDrop: true,       
		enableColumnMove: false,
		store: JGrid.store[9],
		columns: JGrid.columns[9],
		listeners: {
           	activate: function ( panel, layout, opts)
            {
            		combo99 = Ext.ComponentMgr.get("combo99");
            },		
			afteredit: function (e) {
				JGrid.store[9].save();
			},
			failure: function (response, options) {
	 <?php               
				echo 'window.alert("'. JText::_("DATA_WAS_NOT_SAVED_TO_DATABASE").'")';
	 ?>                  
			},
	    	success: function (response, options) {
	       		var server_response = Ext.decode(response.responseText);
	      		// window.alert(response.responseText);
	        	JGrid.store[9].commitChanges();
	   		},
	  		scope: this
		},
		sm: new Ext.selection.RowModel({
			singleSelect: false
		})
	}]
});
     

     
