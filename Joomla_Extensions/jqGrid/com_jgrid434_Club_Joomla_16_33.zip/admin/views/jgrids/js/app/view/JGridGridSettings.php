<?php
 /*
 *  JGridGridSettings.php  in joomla/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
  
Ext.define("JGrid.view.JGridGridSettings", {
	extend : "Ext.window.Window",
	alias : "widget.JGridGridSettings",
	id: "JGridGridSettings",
//RMS add language
   	title: 'Grid Settings',
   	renderTo: 'editcell',
	closable: true,
	closeAction: 'hide',
	autoScroll: true,
	layout: 'fit',
    autoHeight: true,
	width: 910,
	//height:800,
	//x: 35,
    y: 100,
	plain: true,	     
	items:  [
	{
		xtype: 'form',
		id: "formpanel2",
		frame: true,
		layout: 'fit',
    	autoHeight: true,
		labelWidth: 85,
		//width:700,
      	//height: 1145,
      	items: [{
          	items: [{
          		xtype: 'fieldset',
              	autoHeight: true,
              	labelAlign: 'right',
               	waitMsgTarget: true,
               	layout: 'column',
              	defaultType: "container",
              	defaults: {
               		autoEl: {},
                	layout: 'form',
                 	// applied to each contained item
                 	//       width: 230,
                   	msgTarget: "side"
             	},
             	items: [{
               		title: 'Width = 50%',
                  	columnWidth: .5,
                   	items: [
                        new Ext.form.FieldSet({
                      		//  title: 'Contact Information',
                            defaultType: 'textfield',
                            defaults: {
                           		height: "30px"
                            },
                            autoHeight: true,
                            items: [{
<?php 
                          		echo 'fieldLabel: "'.JText::_("GRID_ID").'",                         		
                          		plugins: [ new Ext.ux.FieldHelp("'. JText::_("GRID_ID_TOOLTIP").'") ],
                          		';                
?>
                                name: 'id',
                                disabled: true,
                                width: "51px"
                            },
                            {
<?php 
                          		echo 'fieldLabel: "'.JText::_("GRID_LABEL").'",
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("GRID_LABEL_TOOLTIP").'", "bottom") ],
                                ';
?>                              
                                name: 'grid_reference_id',
                                disabled: true,
                                width: "190px"
                            },
                            {
<?php 
                                echo 'fieldLabel: "'.JText::_("APPLICATION").'",
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("APPLICATION_TOOLTIP").'") ],
                                ';
?>                              
                                name: 'grid_application_name',
                                disabled: true,
                                width: "190px"
                            },
                            {
<?php 
                                echo 'fieldLabel: "'.JText::_("RENDERTO").'",
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("RENDERTO_TOOLTIP").'") ],
                                ';
?>                              
                                name: 'renderto',
                                disabled: true,
                                width: "190px"
                            },
                            {
<?php 
                                echo 'fieldLabel: "'.JText::_("TITLE").'",
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("TITLE_TOOLTIP").'") ],
                                ';
?>                              
                                maskRe: /([a-zA-Z0-9\s]+)$/,
                                disabled: true,
                                name: 'title',
                                width: "190px"
                            },
                            {
<?php 
                                echo 'fieldLabel: "'.JText::_("GRID_TAB_ORDER").'",
                              	plugins: [ new Ext.ux.FieldHelp("'. JText::_("GRID_TAB_ORDER_TOOLTIP").'") ],
                              	';
?>                              
                                name: 'ordering',
                                disabled: true,
                                width: "190px"
                            },
                            {
<?php 
                                echo 'fieldLabel: "'.JText::_("HEIGHT").'",
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("HEIGHT_TOOLTIP").'") ],
                                ';
?>                              
                                name: 'height',
                                xtype: 'textfield',
                                disabled: true,
                                allowblank: false,
                                width: "190px"
                            },
                            {
<?php 
                                echo 'fieldLabel: "'.JText::_("WIDTH").'",
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("GRID_WIDTH_TOOLTIP").'") ],
                                ';
?>                              
                                name: 'width',
                                disabled: true,
                                width: '190px'
                            },
                            {
            					xtype: 'radiogroup',
            					name: 'enableGroupBy',
<?php   	
            					echo 'fieldLabel: "'.JText::_("GROUP_BY").'",
					            cls: "x-check-group-alt",
					            items: [
					                {boxLabel: "'.JText::_("JNO").'", name: "enableGroupBy", inputValue: 0},
					                {boxLabel: "'.JText::_("LOCAL").'", name: "enableGroupBy", inputValue: 1},
					                {boxLabel: "'.JText::_("REMOTE").'", name: "enableGroupBy", inputValue: 2}';
?>             					
					            ]
       		 				},{
               					xtype: 'radiogroup',
                 				name: 'enableGroupBySummary',
<?php   	
            					echo 'fieldLabel: "'.JText::_("GRID_SUMMARY").'",
					            cls: "x-check-group-alt",
					            items: [
					                {boxLabel: "'.JText::_("JNO").'", name: "enableGroupBySummary", inputValue: 0},
					                {boxLabel: "'.JText::_("GROUP_SUMMARY").'", name: "enableGroupBySummary", inputValue: 1},
					                {boxLabel: "'.JText::_("SUMMARY").'", name: "enableGroupBySummary", inputValue: 2}';
?>                  				
				                 ]
              				},                             
                              combo1,
                                new Ext.form.ComboBox({
                                typeAhead: true,
                                height: "32px",
                                name: 'groupDir',
<?php           
                                echo 'emptyText: "'.JText::_("SELECT_A_FIELD").'",
                                fieldLabel: "'.JText::_("GROUP_BY_DIRECTION").'",
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("GROUP_BY_DIRECTION_TOOLTIP").'") ],
                                valueNotFoundText: "'.JText::_("SELECT_A_FIELD").'",';
?>                                  
                                triggerAction: 'all',
                                lazyRender: true,
                                forceSelection: true,                                
                                mode: 'local',
                                store: new Ext.data.SimpleStore({
                             		id: 0,                                   
                                    fields: ['sortByDirection', 'Sort_Direction'],
                                    data: [
<?php           
                                echo '["ASC", "'. JText::_("ASC").'"],
                                      ["DESC", "'. JText::_("DESC").'"]]';
?>                                    
                                }),
                                valueField: 'sortByDirection',
                                displayField: 'Sort_Direction'
                             }),
                            {
                                xtype: 'checkbox',
                                name: 'showGroupName',
<?php 
                                echo '
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("SHOW_GROUP_NAME_TOOLTIP").'") ],
                                fieldLabel: "'.JText::_("SHOW_GROUP_NAME").'"'; 
?>                                                               
 
                            },
                            {
                                xtype: 'checkbox',
                                name: 'hideGroupedColumn',
<?php 
                                echo '
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("HIDE_GROUP_COLUMN_TOOLTIP").'") ],
                                fieldLabel: "'.JText::_("HIDE_GROUP_COLUMN").'"'; 
?>                                                               
 
                            }, 
                            {
                                xtype: 'checkbox',
                                name: 'startCollapsed',
<?php 
                                echo '
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("STARTCOLLAPSED_TOOLTIP").'") ],
                                fieldLabel: "'.JText::_("STARTCOLLAPSED_COLUMN").'"'; 
?>                                                               
 
                            },                                                                                   
                            {
<?php 
                                echo '
                                fieldLabel: "'.JText::_("FORMAT_CLS").'",
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("FORMAT_TOOLTIP").'") ],
                                ';
?>                              
                                name: 'cls',
                                width: "190px"
                            },
                            {
<?php 
                                echo '
                                fieldLabel: "'.JText::_("FORMAT_CTCLS").'",
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("FORMAT_TOOLTIP").'") ],
                                ';
?>                              
                                name: 'ctCls',
                                width: "190px"
                            }]
                        })]
  
                    },
                    {
                   		columnWidth: .5,
                        items: [new Ext.form.FieldSet({
                            //  title: 'Contact Information',
                            defaultType: 'textfield',
                            autoHeight: true,
                            defaults: {
                                 height: "30px"
                            },
                            items: [{
                                xtype: 'checkbox',
                                name: 'frame',
<?php 
                                echo '
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("FRAME_GRID_TOOLTIP").'") ],
                                fieldLabel: "'.JText::_("FRAME_GRID").'"';                          
?>                               
                            },
                            {
                                xtype: 'checkbox',
                                name: 'stripe_rows',
<?php 
                                echo '
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("STRIPE_ROWS_TOOLTIP").'") ],
                                fieldLabel: "'.JText::_("STRIPE_ROWS").'"'; 
?>                                                               
 
                            },
                            {
                                xtype: 'checkbox',
                                name: 'print',
<?php 
                                echo '
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("PRINT_ROWS_TOOLTIP").'") ],
                                fieldLabel: "'.JText::_("ALLOW_PRINTING").'"'; 
?>                                                               
 
                            },                                                       
                            {
                                xtype: 'checkbox',
                                name: 'enableRowEditor',
                               // value: true,
                                //disable: true,
<?php 
                                echo '
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("ENABLE_ROW_EDITOR_TOOLTIP").'") ],
                                fieldLabel: "'.JText::_("ENABLE_ROW_EDITOR").'"'; 
?>                                                               
 
                            },
                            {
                                xtype: 'checkbox',
                                name: 'enable_row_numbers',
<?php 
                                echo '
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("ENABLE_ROW_NUMBERS_TOOLTIP").'") ],
                                fieldLabel: "'.JText::_("ENABLE_ROW_NUMBERS").'"'; 
?>                                                               
                            },
                            {
<?php 
                                echo '
                                fieldLabel: "'.JText::_("NUMBER_COLUMN_HEADER").'",
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("NUMBER_COLUMN_HEADER_TOOLTIP").'") ],
                                ';
?>                              
                                name: 'number_header',
                                width: "190px"
                            },
                            {
<?php 
                                echo '
                                fieldLabel: "'.JText::_("NUMBER_COLUMN_WIDTH").'",
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("NUMBER_COLUMN_WIDTH_TOOLTIP").'") ],
                                ';
?>                              
                                maskRe: /[0-9]/,
                                height: "23px",
                                name: 'number_width',
                                width: "190px"
                            },                             
                            {
                                xtype: 'checkbox',
                                name: 'enableColumnMove',
<?php 
                                echo '
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("MOVE_COLUMNS_TOOLTIP").'") ],
                                fieldLabel: "'.JText::_("MOVE_COLUMNS").'"'; 
?>                                  
                            },
                                                        {
                                xtype: 'checkbox',
                                name: 'enableColumnResize',
<?php 
                                echo '
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("RESIZE_COLUMNS_TOOLTIP").'") ],
                                fieldLabel: "'.JText::_("RESIZE_COLUMNS").'"'; 
?>                                  
                            },
                                                        {
                                xtype: 'checkbox',
                                name: 'columnLines',
<?php 
                                echo '
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("COLUMNS_LINES_TOOLTIP").'") ],
                                fieldLabel: "'.JText::_("COLUMNS_LINES").'"'; 
?>                                  
                            },
                            {
            					xtype: 'radiogroup',
            					name: 'enableSortBy',
            					id: 'enableSortBy',
<?php            					
            					echo 'fieldLabel: "'.JText::_("SORTABLE").'",
					            cls: "x-check-group-alt",
					            items: [
					                {boxLabel: "'.JText::_("JNO").'", name: "enableSortBy", inputValue: 0},
					                {boxLabel: "'.JText::_("LOCAL").'", name: "enableSortBy", inputValue: 1},
					                {boxLabel: "'.JText::_("REMOTE").'", name: "enableSortBy", inputValue: 2}';
?>             					
					            ]
       		 				},                            
             				combo2,
                            new Ext.form.ComboBox({
                                typeAhead: true,
                                height: "32px",
                                name: 'sortByDirection',
<?php           
                                echo 'emptyText: "'.JText::_("SELECT_A_FIELD").'",
                                fieldLabel: "'.JText::_("SORT_BY_DIRECTION").'",
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("SORT_BY_DIRECTION_TOOLTIP").'") ],
                                valueNotFoundText: "'.JText::_("SELECT_A_FIELD").'",';
?>                                  
                                triggerAction: 'all',
                                lazyRender: true,
                                forceSelection: true,                                
                                mode: 'local',
                                store: new Ext.data.SimpleStore({
                                    id: 0,                                   
                                    fields: ['sortByDirection', 'Sort_Direction'],
                                    data: [
<?php           
                                echo '["ASC", "'. JText::_("ASC").'"],
                                      ["DESC", "'. JText::_("DESC").'"]]';
?>                                    
                                }),
                                valueField: 'sortByDirection',
                                displayField: 'Sort_Direction'
                             }), 
                             {
                                xtype: 'checkbox',
<?php 
                                echo 'fieldLabel: "'.JText::_("ENABLE_PAGING").'",
                                //plugins: [ new Ext.ux.FieldHelp("'. JText::_("ENABLE_PAGING_TOOLTIP").'") ],
                                ';
?>                                  
                                name: 'enable_paging'
                            },
                            {
<?php 
                                echo 'fieldLabel: "'.JText::_("NUMBER_OF_PAGING_RECORDS").'",
                                plugins: [ new Ext.ux.FieldHelp("'. JText::_("NUMBER_OF_PAGING_RECORDS_TOOLTIP").'") ],
                                ';
?>                              
                                maskRe: /[0-9]+$/,
                                 height: 23,
                                name: 'paging_records',
                                width: "190px"
                            }]
                        })]
                    }]
                }]
            }],
            buttons: [{

<?php 
            	echo 'text: "'.JText::_("SAVE_CHANGES").'",
            	tooltip: "'. JText::_("SAVE_CHANGES_TOOLTIP").'",';
?>            
            	disabled: false,
            	handler: function () {
        			Ext.ComponentMgr.get("formpanel2").getForm().submit({
                   		url: "index.php?option=com_jgrid&task=submitgridsettings&format=ajax&grid_id=" + JGrid.selectedgridid + "&sortByField=" + combo2.getValue() + "&groupByField=" + combo1.getValue() + "",
<?php                    
                    	echo 'waitMsg: "'. JText::_("SAVING_DATA").'",';
?>                    
						success: function (form, action) {
	         				var results = Ext.decode(action.response.responseText);
	            			Ext.ComponentMgr.get("formpanel2").getForm().setValues({
	              				groupByField: String(results.data.groupByField),
	                  			sortByField: String(results.data.sortByField)
               				});
            				JGrid.JGridGridSettings.hide();
              			},
						failure: function (form, action) {
<?php 
							echo 'Ext.MessageBox.alert("'. JText::_("MESSAGE").'", "'. JText::_("GRID_SETTINGS_NOT_SAVED,_PLEASE_RETRY").'");';
?>
						}
				});
			}    
      	}]
	}]      	
});
     

     
