<?php
 /*
 *  Config.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */

// no direct access
defined('_JEXEC') or die('Restricted access');
require_once(JPATH_BASE . '/components/com_jgrid/os/jgrid/functions.php' );
// check for joomla version
$version = new JVersion;
$joomla = $version->getShortVersion();
$app = JFactory::getApplication();
$database_schema= $app->getCfg('db');
$db = JFactory::getDBO();

?>
JGrid = {
 	 // Define global JGrid varibles
  	columns: new Array(),
  	grids: new Array(),
  	store: new Array(),
	dsModel: new Array(),
	dsCModel: new Array(),
	editor: new Array(),
	proxy: new Array(),
	help: new Array(),
	combo_store: new Array(), //name as If called from grid 5, combo[51] jgrid_combo_store[51], combo[52] jgrid_combo_store[52], etc
    currenteditgrid: -1,
    selectedgridid: -1,
    newcolumnrecord: null,
    double_move_call_fix: 0,
    color_menu_type: 0,
    gridname: '',
    modifyListsWin: '',
    JGridGridSettings: '',
    JGridAccessRules:'',
    JGridSelectionWin: '',
    JGridDefaultGroupRights: '',
    column_selection: '',
    criteria_selection: '',
    select_type: '1',
   	databases: new Array(),
	tables: new Array(),
	table_letter: ['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'],      
    first_where: true,
    multiple_databases: false,
<?php			
			echo 'joomla_database: "'.$database_schema.'",
			table_prefix: "'.$db->getPrefix().'",';
?>    
    demodata: false
}

// shorthand alias
var fm = Ext.form;

// setting up column as a variable   
fm.VTypes.nameVal = /^([A-Z]{1})[A-Za-z\-]+ ([A-Z]{1})[A-Za-z\-]+/;
fm.VTypes.nameMask = /[A-Za-z\- ]/;
fm.VTypes.nameText = 'In-valid Director Name.';
fm.VTypes.name = function (v) {
	return fm.VTypes.nameVal.test(v);
}

		

    
var data_type = new Ext.data.SimpleStore({
	fields: ['value', 'data_type'],
	data: [
			['T', 'Text'],
            ['I', 'Integer'],
            ['D', 'Date'],
            ['B', 'Boolean'],
            ['F', 'Float'],
            ['L', 'List'],
            ['R', 'Unique Row ID'],
            ['P', 'Picture'],
            ['U', 'URL'],
            ['E', 'EMail'],
            ['S', 'Grid Sheet']]
});  
  
function data_type_name(val) {
    return data_type.queryBy(function (rec) {
        return rec.data.id == val;
    }).itemAt(0).data.data_type;
}

// combo box renderer for all combo boxes 
Ext.util.Format.comboRenderer = function (combo) {
    return function (value) {
        var record = combo.findRecord(combo.valueField, value);
        return record ? record.get(combo.displayField) : combo.valueNotFoundText;
    }
};  

  
var colorMenu = Ext.create('Ext.menu.ColorPicker', {
	height : 500,
    colors: [
"000000", 	"000033", 	"000066", 	"000099", 	"0000CC", 	"0000FF",
"003300", 	"003333", 	"003366", 	"003399", 	"0033CC", 	"0033FF",
"006600", 	"006633", 	"006666", 	"006699", 	"0066CC", 	"0066FF",
"009900", 	"009933", 	"009966", 	"009999", 	"0099CC", 	"0099FF",
"00CC00", 	"00CC33", 	"00CC66", 	"00CC99", 	"00CCCC", 	"00CCFF",
"00FF00", 	"00FF33", 	"00FF66", 	"00FF99", 	"00FFCC", 	"00FFFF",
"330000", 	"330033", 	"330066", 	"330099", 	"3300CC", 	"3300FF",
"333300", 	"333333", 	"333366", 	"333399", 	"3333CC", 	"3333FF",
"336600", 	"336633", 	"336666", 	"336699", 	"3366CC", 	"3366FF",
"339900", 	"339933", 	"339966", 	"339999", 	"3399CC", 	"3399FF",
"33CC00", 	"33CC33", 	"33CC66", 	"33CC99", 	"33CCCC", 	"33CCFF",
"33FF00", 	"33FF33", 	"33FF66", 	"33FF99", 	"33FFCC", 	"33FFFF",
"660000", 	"660033", 	"660066", 	"660099", 	"6600CC", 	"6600FF",
"663300", 	"663333", 	"663366", 	"663399", 	"6633CC", 	"6633FF",
"666600", 	"666633", 	"666666", 	"666699", 	"6666CC", 	"6666FF",
"669900", 	"669933", 	"669966", 	"669999", 	"6699CC", 	"6699FF",
"66CC00", 	"66CC33", 	"66CC66", 	"66CC99", 	"66CCCC", 	"66CCFF",
"66FF00", 	"66FF33", 	"66FF66", 	"66FF99", 	"66FFCC", 	"66FFFF",
"990000", 	"990033", 	"990066", 	"990099", 	"9900CC", 	"9900FF",
"993300", 	"993333", 	"993366", 	"993399", 	"9933CC", 	"9933FF",
"996600", 	"996633", 	"996666", 	"996699", 	"9966CC", 	"9966FF",
"999900", 	"999933", 	"999966", 	"999999", 	"9999CC", 	"9999FF",
"99CC00", 	"99CC33", 	"99CC66", 	"99CC99", 	"99CCCC", 	"99CCFF",
"99FF00", 	"99FF33", 	"99FF66", 	"99FF99", 	"99FFCC", 	"99FFFF",
"CC0000", 	"CC0033", 	"CC0066", 	"CC0099", 	"CC00CC", 	"CC00FF",
"CC3300", 	"CC3333", 	"CC3366", 	"CC3399", 	"CC33CC", 	"CC33FF",
"CC6600", 	"CC6633", 	"CC6666", 	"CC6699", 	"CC66CC", 	"CC66FF",
"CC9900", 	"CC9933", 	"CC9966", 	"CC9999", 	"CC99CC", 	"CC99FF",
"CCCC00", 	"CCCC33", 	"CCCC66", 	"CCCC99", 	"CCCCCC", 	"CCCCFF",
"CCFF00", 	"CCFF33", 	"CCFF66", 	"CCFF99", 	"CCFFCC", 	"CCFFFF",
"FF0000", 	"FF0033", 	"FF0066", 	"FF0099", 	"FF00CC", 	"FF00FF",
"FF3300", 	"FF3333", 	"FF3366", 	"FF3399", 	"FF33CC", 	"FF33FF",
"FF6600", 	"FF6633", 	"FF6666", 	"FF6699", 	"FF66CC", 	"FF66FF",
"FF9900", 	"FF9933", 	"FF9966", 	"FF9999", 	"FF99CC", 	"FF99FF",
"FFCC00", 	"FFCC33", 	"FFCC66", 	"FFCC99", 	"FFCCCC", 	"FFCCFF",
"FFFF00", 	"FFFF33", 	"FFFF66", 	"FFFF99", 	"FFFFCC", 	"FFFFFF"
    ],
    handler: function(cm, color){
       sel=Ext.ComponentMgr.get("listboxvalues").getSelectionModel().getSelection(); 
       var current_value=sel[0].get("listboxvaluerowcolor");
       if(current_value=='')
       { 
         current_value='~~';
       }
       var current_color_array=current_value.split("~",3);
       cssname = 'css'+current_color_array[0];        
       if(JGrid.color_menu_type==1)
       {
         Ext.util.CSS.removeStyleSheet( cssname ); 
         current_color_array[0]=color;  
       }
       if(JGrid.color_menu_type==2)
       {
         Ext.util.CSS.removeStyleSheet( '.x-grid-row-selected.' + cssname );
         current_color_array[1]=color;  
       }
       if(JGrid.color_menu_type==3)
       {
         Ext.util.CSS.removeStyleSheet( '.x-grid-row-selected.' + cssname );
         current_color_array[2]=color;  
       }
       var new_color_value=current_color_array[0]+'~'+current_color_array[1]+'~'+current_color_array[2];
       sel[0].set("listboxvaluerowcolor",new_color_value);
       // Ext.MessageBox.alert("Message", color);
    },
    id: 'color_menu' 
});

function grid_columns_menu() {
    JGrid.currenteditgrid = Ext.ComponentMgr.get("grids_data");
    var sm = JGrid.currenteditgrid.getSelectionModel();
    if (sm.hasSelection()) {
        var sel = sm.getSelection();
        JGrid.selectedgridid = sel[0].get('id');
        JGrid.select_type = sel[0].get('select_type');
        JGrid.gridname = sel[0].get('title');
        JGrid.store[2].loadData([],false);
       	JGrid.store[13].loadData([],false); 
        JGrid.store[14].loadData([],false);
        JGrid.store[15].loadData([],false);
        JGrid.store[16].loadData([],false);
        JGrid.newcolumnrecord=0;
      //  if(JGrid.selectedgridid<9&&JGrid.demodata==false)
      //  {
<?php        
       //    echo 'Ext.Msg.alert("'. JText::_("WARNING_CREATE_YOUR_OWN_GRIDS").'", "'. JText::_("CHANGES_MADE_TO_DEMO_GRIDS_WILL_BE_LOST_WHEN_UPGRADEING").'");';
?>
       //    JGrid.demodata=true;
       // }
    } 
    else //if sel
    {
<?php 
		echo 'Ext.Msg.alert("'.JText::_("PLEASE").'", "'.JText::_("SELECT_GRID_FIRST_TO_ADD_COLUMNS").'");';
?> 
		return;       
    }
 	if(!JGrid.JGridSelectionWin)
  	{
  		JGrid.combo_store[21].load({
            params: {
                selected_grid_id: JGrid.selectedgridid
      	}
        });
        JGrid.combo_store[23].load({
            params: {
                selected_grid_id: JGrid.selectedgridid
      	}
        });
       	JGrid.combo_store[13].load({
            params: {
                selected_grid_id: JGrid.selectedgridid 
            }
        });
      	JGrid.combo_store[16].load({
            params: {
                selected_grid_id: JGrid.selectedgridid 
            }
        });
        JGrid.combo_store[17].load({
            params: {
                selected_grid_id: JGrid.selectedgridid 
            }
        });
   		JGrid.JGridSelectionWin = Ext.create("JGrid.view.JGridSelectionWin");    	
    }
	JGrid.store[13].load({
            params: {
                selected_grid_id: JGrid.selectedgridid 
            }
  	});
	JGrid.store[14].load({
            params: {
                selected_grid_id: JGrid.selectedgridid 
            }
	});
  	JGrid.store[16].load({
            params: {
                selected_grid_id: JGrid.selectedgridid 
            }
	});
 	JGrid.store[2].load({
            params: {
                grid_id: JGrid.selectedgridid 
            }
	});
	Ext.ComponentMgr.get("custom_where_clause").setValue("");   
	Ext.ComponentMgr.get("north_select_query").setValue("");
	combo26.setValue(JGrid.select_type);
	set_gridcolumn_view();
    JGrid.JGridSelectionWin.show();
    
}

function add_access_menu() {
	if(!JGrid.JGridAccessRules)
  	{
 		JGrid.JGridAccessRules = Ext.create("JGrid.view.JGridAccessRules");
   	}
  	JGrid.JGridAccessRules.show();
	Ext.ComponentMgr.get("formpanel3").getForm().setValues({
         'access_rule_id': '99999'
     });
     JGrid.selectedgridid=0;
     combo40.clearValue();
     combo411.clearValue();
     combo42.clearValue();
     combo431.clearValue();
     combo44.clearValue();
     combo45.clearValue(); 
}



function edit_access_menu() {
	JGrid.currenteditgrid = Ext.ComponentMgr.get("jgrid_security");
	var sm = JGrid.currenteditgrid.getSelectionModel();
	if (sm.hasSelection()) {
		var sel = sm.getSelection();
	    JGrid.selectedgridid = sel[0].get('id'); 
	    if(!JGrid.JGridAccessRules)
	  	{
	 		JGrid.JGridAccessRules = Ext.create("JGrid.view.JGridAccessRules");
	   	}
	  	JGrid.JGridAccessRules.show();	    
	   	if (JGrid.selectedgridid) {
			if(record = JGrid.store[4].findRecord("id", JGrid.selectedgridid))
		 	{
				Ext.ComponentMgr.get("formpanel3").getForm().setValues({
	         		'access_rule_id': JGrid.selectedgridid
	       		});
				combo40.setValue(String(record.get("access_for")));
	       		combo411.setValue(String(record.get("access_for_id")));
	       		combo42.setValue(String(record.get("access_type")));
			  	combo431.setValue(String(record.get("access_type_id")));
			 	combo44.setValue(String(record.get("access_level")));
			  	combo45.setValue(String(record.get("access_rule_application_id")));
	  		}
	     	//Ext.ComponentMgr.get("formpanel3").form.title = 'Edit Access Rule '+JGrid.selectedgridid;
		}
	}
	else 
	{
<?php 
		echo 'Ext.MessageBox.alert("'. JText::_("PLEASE").'", "'. JText::_("SELECT_RULE_FIRST_TO_MODIFY_SETTINGS").'");';
?>    
	}  
}

// build sql statement from grid selection window
function set_where_or_and(new_sql_statement,first_where) {
	if(first_where == true) 
	{
		new_sql_statement += ' WHERE ';
		JGrid.first_where = false;
	}
	else new_sql_statement += ' AND ';
	return(new_sql_statement);						
}

// check to see if multiple databases accessed, if yes include database name in table spec. database.table
function multiple_database_check() {
	JGrid.multiple_databases = false;
	if(JGrid.store[2].data.items.length != 0)
	{
		var column_data = JGrid.store[2].data.items;
	}
	else column_data = false;
	if(JGrid.store[15].data.items.length != 0)
	{
		var where_data = JGrid.store[15].data.items;
	}
	else where_data = false;
	if(column_data)
	{
	 var database_sql_name1 = column_data[0].data['database_sql_name_id'];	//RMS check for sql column type
		for(var i=1;i < column_data.length;i++)
	    { 
			database_sql_name = column_data[i].data['database_sql_name_id'];
	   		if(database_sql_name != database_sql_name1)
	    	{
	    		if(database_sql_name)
	    	    {
	    			JGrid.multiple_databases = true;
	    		}	
	    		break;
	    	}
	    }	
	}
	if(where_data)
	{
		for(i=0;i < where_data.length;i++)
	    { 
			database_sql_name = where_data[i].data['database_sql_name_id'];
			jdatabase_sql_name = where_data[i].data['jdatabase_sql_name_id'];
	   		if(database_sql_name != database_sql_name1 || jdatabase_sql_name != database_sql_name1 )
	    	{
	    	    if(database_sql_name && jdatabase_sql_name)
	    	    {
	    			JGrid.multiple_databases = true;
	    		}	
	    		break;
	    	}	
		}
	}
	var where_clause_dependencies = Ext.ComponentMgr.get("where_clause_dependencies");
	var gridcolumns_data = Ext.ComponentMgr.get("gridcolumns_data");
	if(where_clause_dependencies)
	{
		if(JGrid.multiple_databases == true) 
		{
			where_clause_dependencies.columns[6].show();
			where_clause_dependencies.columns[2].show();
			//gridcolumns_data.columns[5].show();
		}
		else
		{
			where_clause_dependencies.columns[6].hide();
			where_clause_dependencies.columns[2].hide();
			//gridcolumns_data.columns[5].hide();		
		}
	}	
}

// find the letter representing the database.table eg a.columnName in SQL statement
function get_tletter(database_sql_name,table_sql_name) {
	for(j=0;j < JGrid.tables.length;j++)
  	{
   		if(database_sql_name == JGrid.databases[j] && table_sql_name == JGrid.tables[j])
    	{
			return(JGrid.table_letter[j]);
    	}	
 	}
}

//check if a new table and if it is add to database.table array
function add_new_table(database_sql_name,table_sql_name) {	
	var save_table = true;
	for(j=0; j < JGrid.tables.length;j++)
   	{
   		save_table = true;
   		if(database_sql_name == JGrid.databases[j] && table_sql_name == JGrid.tables[j])
    	{
    		save_table = false;
    		//j = j-1;
    		break;
    	}	
  	}
  	if(save_table==true)
   	{
  		JGrid.databases[JGrid.tables.length] = database_sql_name;
    	JGrid.tables[JGrid.tables.length] = table_sql_name;
    	j = JGrid.tables.length - 1;
  	}
  	return 	j;
}


// set_gridcolumn_view
function set_gridcolumn_view() {
	var centerTabPanel = Ext.ComponentMgr.get("centerTabPanel");
	var north_select_query = Ext.ComponentMgr.get("north_select_query");
	var gridcolumns_data = Ext.ComponentMgr.get("gridcolumns_data");
	var custom_where_clause = Ext.ComponentMgr.get("custom_where_clause");
	save_database_query_button = Ext.ComponentMgr.get("save_database_query");
	test_database_query_button = Ext.ComponentMgr.get("test_database_query");
	JGrid.combo_store[27].loadData([],false);
	//JGrid.combo_store[27].removeAll();	
	if(JGrid.select_type == "1") 
	{
	 	JGrid.combo_store[27].add(	[
<?php 	 		
	 									echo '{"column_type":"1", "column_type_name":"'. JText::_("JGRID_DATA").'"},	
  										{"column_type":"4", "column_type_name":"'. JText::_("FORMULA").'"}';
?>   										         	
 									])
	}
	else
	{
	 	JGrid.combo_store[27].add(	[
<?php 	 		
	 									echo '	{"column_type":"1", "column_type_name":"'. JText::_("JGRID_DATA").'"},	
  												{"column_type":"4", "column_type_name":"'. JText::_("FORMULA").'"},
       											{"column_type":"2", "column_type_name":"'. JText::_("JOOMLA_TABLE_DATA").'"},
       											{"column_type":"3", "column_type_name":"'. JText::_("MYSQL_TABLE_DATA").'"}';
?>        									         	
 									])	
	}
	
	
	switch(JGrid.select_type) {
	            	case "1":	            	
	            		centerTabPanel.child('#gridcolumns_data').tab.show();
	            		centerTabPanel.child('#where_clause_dependencies').tab.hide();
	            		centerTabPanel.child('#custom_where_clause').tab.hide();
	            		centerTabPanel.show();
	            		north_select_query.hide();
	            		save_database_query_button.hide();
	            		test_database_query_button.hide();
	            		gridcolumns_data.columns[3].show();	            		
						gridcolumns_data.columns[4].show();
	            		gridcolumns_data.columns[5].hide();
	            		gridcolumns_data.columns[6].hide();
	            		gridcolumns_data.columns[7].hide();	            		
	            		gridcolumns_data.columns[8].hide();
	            		gridcolumns_data.columns[9].show();
	            		gridcolumns_data.columns[10].show();
	            		// default any table.column records back to JGrid data
	            		while(joomla_column_record = JGrid.store[2].findRecord('column_type',/[23]/))
	            		{
	            			joomla_column_record.set({	column_type: 1,
	            										database_sql_name_id: '',
	            										table_sql_name_id: '',
	            										column_sql_name_id: '',
	            										formula: '',
	            										primary_key_column: false
	            			});
	            		}
	            		break;
	            	case "2":	            	
	            		centerTabPanel.child('#gridcolumns_data').tab.show();
	            		centerTabPanel.child('#where_clause_dependencies').tab.show();
	            		centerTabPanel.child('#custom_where_clause').tab.hide();
	            		north_select_query.show();
	            		save_database_query_button.hide();
	            		test_database_query_button.show();
	            		gridcolumns_data.columns[3].show();
						gridcolumns_data.columns[4].show();	
	            		if(JGrid.multiple_databases==true) gridcolumns_data.columns[5].show();
	            		else gridcolumns_data.columns[5].hide();
	            		gridcolumns_data.columns[6].show();
	            		gridcolumns_data.columns[7].show();	            		
	            		gridcolumns_data.columns[8].show();
	            		gridcolumns_data.columns[9].hide();
	            		gridcolumns_data.columns[10].show();            	
	            		break;
	            	case "3":            	
	            		centerTabPanel.child('#gridcolumns_data').tab.show();        		
	            		centerTabPanel.child('#where_clause_dependencies').tab.show();
	            		centerTabPanel.child('#custom_where_clause').tab.show();
	            		north_select_query.show();
	            		save_database_query_button.hide();
	            		test_database_query_button.show();
	            		gridcolumns_data.columns[3].show();
						gridcolumns_data.columns[4].show();
	            		if(JGrid.multiple_databases==true) gridcolumns_data.columns[5].show();
	            		else gridcolumns_data.columns[5].hide();
	            		gridcolumns_data.columns[6].show();
	            		gridcolumns_data.columns[7].show();	            		
	            		gridcolumns_data.columns[8].show();
	            		gridcolumns_data.columns[9].hide();
	            		gridcolumns_data.columns[10].show(); 
	            		break;
	            	case "4":           	
	            		centerTabPanel.child('#gridcolumns_data').tab.show();
	            		centerTabPanel.child('#where_clause_dependencies').tab.hide();
	            		centerTabPanel.child('#custom_where_clause').tab.hide();
	            		north_select_query.show();
	            		save_database_query_button.show();
	            		test_database_query_button.show();
	            		gridcolumns_data.columns[3].show();
						gridcolumns_data.columns[4].show();
	          			if(JGrid.multiple_databases==true) gridcolumns_data.columns[5].show();
	            		else gridcolumns_data.columns[5].hide();
	            		gridcolumns_data.columns[6].show();
	            		gridcolumns_data.columns[7].show();	            		
	            		gridcolumns_data.columns[8].show();
	            		gridcolumns_data.columns[9].hide();            		
	            		gridcolumns_data.columns[10].show();
	            		var crecord = JGrid.store[13].findRecord('grid_id', JGrid.selectedgridid );
						var new_custom_sql = Ext.ComponentMgr.get("north_select_query").getValue();
						if(crecord) crecord.set('sql_query',new_custom_sql); 
						else JGrid.store[13].insert(0,	{grid_id: JGrid.selectedgridid,sql_query: new_custom_sql});				            		 
	            		break;	            		
	}
	centerTabPanel.setActiveTab(0);
}

// build sql statement from grid selection window
function build_sql() {
	var new_sql_statement = 'SELECT ';
	var at_least_one_sql_col = false;
	var column_data = JGrid.store[2].data.items;
	var where_data = JGrid.store[15].data.items;
	if(!Ext.isEmpty(JGrid.store[14].data.items[0]))
	{
		var custom_sql_query = JGrid.store[14].data.items[0].data['sql_query'];
	}
	else var custom_sql_query = '';
	if(!Ext.isEmpty(JGrid.store[16].data.items[0]))
	{
		var custom_where_query = JGrid.store[16].data.items[0].data['custom_where_query'];
	}
	else var custom_where_query = '';
	if(!Ext.isEmpty(JGrid.store[13].data.items[0]))
	{
		var sql_query = JGrid.store[13].data.items[0].data['sql_query'];
	}
	else var sql_query = '';
	var database_sql_name = '';
	var table_sql_name = '';
	var column_sql_name = '';
	JGrid.databases = new Array();
	JGrid.tables = new Array();
	JGrid.multiple_databases = false;
	// check to see if multiple databases accessed, if yes include database name in table spec. database.table
	multiple_database_check();
		
    for(i=0; i < column_data.length;i++)
    {       	
		switch(JGrid.select_type)
		{
			case "1":
			case "4":
		    	break;
			case "2":
			case "3":
				database_sql_name = column_data[i].data['database_sql_name_id'];
				table_sql_name = column_data[i].data['table_sql_name_id'];
				column_sql_name = column_data[i].data['column_sql_name_id'];
			 	if(database_sql_name&&table_sql_name&&column_sql_name)
			 	{
			 		at_least_one_sql_col = true;
			  		// check to see if database.table already saved
			  		table_index = this.add_new_table(database_sql_name,table_sql_name);
			    	new_sql_statement +=  JGrid.table_letter[table_index] + '.' + column_sql_name + ' AS ' + column_data[i].data['dataindex'] + ', ';	            	
				}
				else break;
				break;
		}
	}
	// check for custom where clause tables
	for(i=0;i < where_data.length;i++)
    {   
    	database_sql_name = where_data[i].data['database_sql_name_id'];
		table_sql_name = where_data[i].data['table_sql_name_id'];
		jdatabase_sql_name = where_data[i].data['jdatabase_sql_name_id'];
		jtable_sql_name = where_data[i].data['jtable_sql_name_id'];				
		// check to see if database.table already saved
		if(database_sql_name&&table_sql_name)
		{
			this.add_new_table(database_sql_name,table_sql_name);
		}
				if(database_sql_name&&table_sql_name)
		{
			this.add_new_table(jdatabase_sql_name,jtable_sql_name);
		}
	}
	// remove last comma
	new_sql_statement = new_sql_statement.substring(0, new_sql_statement.length-2);
	new_sql_statement += ' FROM ';
	for(i=0;i < JGrid.tables.length;i++)
    { 
    	if(JGrid.tables[i] != "") {   	
	    	if(JGrid.multiple_databases==true) new_sql_statement += JGrid.databases[i] + '.'; 
	    	new_sql_statement += JGrid.tables[i] + ' ' + JGrid.table_letter[i] + ', ';
    	}
	}
	new_sql_statement = new_sql_statement.substring(0, new_sql_statement.length-2);

	
	// add where clause
	JGrid.first_where = true;
	for(i=0;i < where_data.length;i++)
    {       	
		switch(JGrid.select_type) {
			case "1":
			case "4":
		    	break;
			case "2":
			case "3":	
				database_sql_name = where_data[i].data['database_sql_name_id'];
				table_sql_name = where_data[i].data['table_sql_name_id'];
				column_sql_name = where_data[i].data['column_sql_name_id'];
				jdatabase_sql_name = where_data[i].data['jdatabase_sql_name_id'];
				jtable_sql_name = where_data[i].data['jtable_sql_name_id'];				
				jcolumn_sql_name = where_data[i].data['jcolumn_sql_name_id'];
				criteria_operator = where_data[i].data['criteria_operator_id'];
				criteria_value = where_data[i].data['criteria_value'];
				select_wildcard = where_data[i].data['select_wildcard_id'];
				
				// check to see if database.table already saved
				if(database_sql_name&&table_sql_name)
				{
					this.add_new_table(database_sql_name,table_sql_name);
				}
				if(database_sql_name&&table_sql_name)
				{
					this.add_new_table(jdatabase_sql_name,jtable_sql_name);
				} 				
				//(1,'Database Join'),(2,'Column Value'),(3,'Wildcard Value');
				switch(where_data[i].data['criteria_type_id']) {
					case 1:
						if(column_sql_name&&jcolumn_sql_name&&criteria_operator)
						{
							new_sql_statement = this.set_where_or_and(new_sql_statement,JGrid.first_where);
							new_sql_statement +=  this.get_tletter(database_sql_name,table_sql_name) + '.' + column_sql_name + ' ' + criteria_operator + ' ' + this.get_tletter(jdatabase_sql_name,jtable_sql_name) + '.' + jcolumn_sql_name; 
						}
						break;
					case 2:						
						if(column_sql_name&&criteria_value&&criteria_operator)
						{
							new_sql_statement = this.set_where_or_and(new_sql_statement,JGrid.first_where);
							new_sql_statement += this.get_tletter(database_sql_name,table_sql_name) + '.' + column_sql_name + ' ' + criteria_operator + ' ' + criteria_value; 
						}
						break;
					case 3:						
						if(column_sql_name&&select_wildcard&&criteria_operator)
						{
							new_sql_statement = this.set_where_or_and(new_sql_statement,JGrid.first_where);
							new_sql_statement += this.get_tletter(database_sql_name,table_sql_name) + '.' + column_sql_name + ' '+  criteria_operator + ' ' + ' @' + select_wildcard; 
						}
						break;	
				}
				break;
			}		
	}
	if(JGrid.select_type == "3")
	{
		// add custom where
		if(custom_where_query)
		{
			new_sql_statement = this.set_where_or_and(new_sql_statement,JGrid.first_where);
			// Strip leading AND or WHERE
			custom_where_query_array = custom_where_query.split(new RegExp("\\s+"));
			if((custom_where_query_array[0].toLowerCase().indexOf('where')==-1) && (custom_where_query_array[0].toLowerCase().indexOf('and')==-1))
			{
				var n = 0;
			}
			else
			{
				var n = 1;	
			}
			var striped_custom_where_query = '';
			for(i=n; i < custom_where_query_array.length; i++)
			{
				striped_custom_where_query += ' ';
				striped_custom_where_query += custom_where_query_array[i];
			}                 
			new_sql_statement += striped_custom_where_query; 
		}
	}
	if(at_least_one_sql_col == false) new_sql_statement = '';  // if no columns selected send back null
	if(JGrid.select_type == "4") new_sql_statement = custom_sql_query;
	if(Ext.ComponentMgr.get("north_select_query"))
	{
		Ext.ComponentMgr.get("north_select_query").setValue(new_sql_statement);
	}
}

// change theme
function jgrid_change_theme(application_name, theme) {
    
              Ext.Ajax.request({
<?php           
                                echo 'waitMsg: "'.JText::_("CHANGING_THEME").'",';
            
                echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=change_theme&format=ajax",';
?>               
                params: {
                    theme: theme,
                    application_name: application_name
                },
                method: "POST",
                failure: function (response, options) {
<?php                    
                   echo 'Ext.Msg.alert("'. JText::_("THEME_NOT_CHANGED").'", "'. JText::_("CHECK_DATABASE_CONNECTION").'");';
?>               
                },
                success: function (response, options) {
                    var server_response = Ext.decode(response.responseText);
                    if (!server_response.success) {                                           
<?php 
                       echo 'Ext.MessageBox.alert("'. JText::_("THEME_NOT_CHANGED").'", "'. JText::_("CHECK_DATABASE_CONNECTION").'");';
?>                                         
                    }                  
                },
                scope: this
            }); 
}
