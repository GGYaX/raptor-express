<?php
/**
 * Jgrid_security Model in Joomla/Administrator/Components/models
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.model' );

/**
 * Jgrid_security model
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid administrator "Manager User Access" screens
 * to "Manage User Access" rights
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */

if(!class_exists('RMWorksAroundJoomlaToGetAModel')) {
	if(interface_exists('JModel')) {
		abstract class RMWorksAroundJoomlaToGetAModel extends JModelLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAModel extends JModel {}
	}
}

class JgridsModelJgrid_security extends RMWorksAroundJoomlaToGetAModel
{
	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * Retrieves the "User Access Rules" data
	 * @return array Array of objects containing the "User Access Rules" grid rows
	 */
	var $_query=null;


	/**
	 * Retrieves the "User Access Rules" data
	 * @return string json string containing the "User Access Rules" grid rows
	 */
	function getUserAccessRules()
	{
		$this->_result_count=0;
		$this->_result=0;

		$this->_query = 'SELECT a.id,
		                        a.access_rule_application_id,
		                        a.userid_assigning_access, 
		                        a.access_for,
                                a.access_for_id,					    
					            a.access_type,
                                a.access_type_id,					    
				                a.access_level, 
		                        a.last_updated
			        FROM #__jgrid_security a       	                      
			        ORDER BY a.access_for_name, 
			                 a.access_type_name';		          
		$this->_result_count = $this->_getListCount($this->_query );
		if($this->_result_count==0)
		{
			return false;
		}
		$this->_result = $this->_getList( $this->_query );

		for($i=0;$i<$this->_result_count;$i++)
		{

			switch ($this->_result[$i]->access_for)
			{
		 	// USER
		 	case '1':
		 		$this->_result[$i]->access_for_id="U".$this->_result[$i]->access_for_id;
		 		break;
		 		// ROLE
		 	case '2':
		 		$this->_result[$i]->access_for_id="R".$this->_result[$i]->access_for_id;
		 		break;
		 		// DEFAULT
		 	case '3':
		 		$this->_result[$i]->access_for_id="D".$this->_result[$i]->access_for_id;
		 		break;
		 		// CREATOR
		 	case '4':
		 		$this->_result[$i]->access_for_id="C".$this->_result[$i]->access_for_id;
		 		break;			 		
			}

			switch ($this->_result[$i]->access_type)
			{
		 	// Grid
		 	case '1':
		 		$this->_result[$i]->access_type_id="G".$this->_result[$i]->access_type_id;
		 		break;
		 		// Grid-Column
		 	case '2':
		 		$this->_result[$i]->access_type_id="C".$this->_result[$i]->access_type_id;
		 		break;
		 		// Sheet
		 	case '3':
		 		$this->_result[$i]->access_type_id="D".$this->_result[$i]->access_type_id;
		 		break;
		 		// Sheet-Column
		 	case '4':
		 		$this->_result[$i]->access_type_id="E".$this->_result[$i]->access_type_id;
		 		break;
			}
		}
		if($this->_result)return array($this->_result_count,$this->_result);
		else return false;
	}

	/**
	 * Retrieves a list of installed application ID and Name that access rules can be applied and adds in combo box drop down selector box
	 * @return array Array of objects containing the user ids and names or false if no applications were found
	 */
	function get_combo_access_rule_application()
	{
		$this->_query = 'SELECT id as access_rule_application_id,
                                 grid_application_name AS access_rule_application
			           	  FROM #__jgrid_applications';             
		$this->_result_count = $this->_getListCount($this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result)return array($this->_result_count,$this->_result);
		else return false;
	}
	
		/**
	 * Retrieves a joomla default groups
	 * @return array Array of objects containing the groups
	 */
	function read_default_group()
	{
		$this->_query = 'SELECT id,
                                usertype_name,
                                access_level
			           	  FROM #__jgrid_user_type_defaults';             
		$this->_result_count = $this->_getListCount($this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result)return array($this->_result_count,$this->_result);
		else return false;
	}
	
	/**
	 * Updates the   "joomla default groups" JGrid default access rules being edited in the  "Manager User Access" grid
	 * @var array $ default group access level
	 * @return array return the data that was just updated to the grid or false if rule not updated.
	 */
	function update_default_group()
	{
		$db =JFactory::getDBO();
		$user =JFactory::getUser();
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
				$query =  'SELECT id, access_level,usertype_name FROM  #__jgrid_user_type_defaults';
 		$db->setQuery($query);
		$_result = $db->loadObjectList();
//echo 'sql '.print_r($_result);
		$query =  'UPDATE  #__jgrid_user_type_defaults
			      SET access_level = '.$row_data[0]['access_level'].'
			      WHERE id = '.$row_data[0]['id']; 
//echo 'sql'.$query;		
		$db->setQuery( $query);
		if($db->query())return true;
		else return false;
	}	
	
	

	/**
	 * Retrieves the users ID and Name that access rules can be applied and adds in combo box drop down selector box
	 * @return array Array of objects containing the user ids and names or false if no users were found
	 */
	function get_combo_User_Id_List($access_for)
	{
		// check for joomla version
		$version = new JVersion;
		$creator_rule = array();

		$joomla = $version->getShortVersion();
		$creator_rule[0] = (object) array('access_for_name' => JText::_('CREATOR_EDIT_PRIVATE'), 'access_for_id' => 'C1');
		$creator_rule[1] = (object) array('access_for_name' => JText::_('CROLE_EDIT_PRIVATE'), 'access_for_id' => 'C2');
		$creator_rule[2] = (object) array('access_for_name' => JText::_('CREATOR_EDIT_CROLE_VIEW'), 'access_for_id' => 'C3');
		$creator_rule[3] = (object) array('access_for_name' => JText::_('CREATOR_EDIT_REG_VIEW'), 'access_for_id' => 'C4');		
		$creator_rule[4] = (object) array('access_for_name' => JText::_('CROLE_EDIT_REG_VIEW'), 'access_for_id' => 'C5');
		$creator_rule[5] = (object) array('access_for_name' => JText::_('CREATOR_EDIT_PUB_VIEW'), 'access_for_id' => 'C6');
		$creator_rule[6] = (object) array('access_for_name' => JText::_('CROLE_EDIT_PUB_VIEW'), 'access_for_id' => 'C7');	
		$creator_rule[7] = (object) array('access_for_name' => JText::_('ACCESS_MANAGER_EDIT_CREATOR_VIEW'), 'access_for_id' => 'C8');			
		$creator_rule[8] = (object) array('access_for_name' => JText::_('ACCESS_MANAGER_EDIT_CROLE_VIEW'), 'access_for_id' => 'C9');					
		switch ($access_for){
			case '0':  //all rule types to be used to validate "object type" values
				// find users
				$this->_query = 'SELECT a.username AS access_for_name,
				                         CONCAT("U",a.id) AS access_for_id
			           	          FROM #__users a';

				$user_result = $this->_getList( $this->_query );
				// find roles
				$this->_query = 'SELECT b.role_name AS access_for_name,
			           	                  CONCAT("R",b.id) AS access_for_id
			           	          FROM #__jgrid_roles b';

				$role_result = $this->_getList( $this->_query );
				// find defaults
				if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
				{
					$this->_query = 'SELECT c.usertype_name AS access_for_name,
			           	                  CONCAT("D",c.id) AS access_for_id
			           	          FROM #__jgrid_user_type_defaults c
                                  WHERE c.version16 = 1 ';
				}
				else
				{
					$this->_query = 'SELECT c.usertype_name AS access_for_name,
			           	                  CONCAT("D",c.id) AS access_for_id
			           	          FROM #__jgrid_user_type_defaults c
                                  WHERE c.version15 = 1';             
				}
					
				$default_result = $this->_getList( $this->_query );
				$this->_result = array_merge($user_result, $role_result, $default_result, $creator_rule);
				$this->_result_count = count($this->_result);
				break;
					
			case '1':  //USER type
				$this->_query = 'SELECT a.username AS access_for_name,
		                                CONCAT("U",a.id) AS access_for_id
			                     FROM #__users a
			                     order by a.username';
				$this->_result_count = $this->_getListCount($this->_query );
				$this->_result = $this->_getList( $this->_query );
				break;
					
			case '2':  //Role Type
				$this->_query = 'SELECT a.role_name AS access_for_name,
				                        CONCAT("R",a.id) AS access_for_id
			           	         FROM #__jgrid_roles a
			           	         order by a.role_name';
				$this->_result_count = $this->_getListCount($this->_query );
				$this->_result = $this->_getList( $this->_query );
				break;
			case '3':  //User Type Default
				if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
				{
					$this->_query = 'SELECT a.usertype_name AS access_for_name,
				                        CONCAT("D",a.id) AS access_for_id
			           	             FROM #__jgrid_user_type_defaults a
                               WHERE a.version16 = 1 
                               order by a.usertype_name';
				}
				else
				{
					$this->_query = 'SELECT a.usertype_name AS access_for_name,
				                        CONCAT("D",a.id) AS access_for_id
			           	              FROM #__jgrid_user_type_defaults a
                                WHERE a.version15 = 1
                                order by a.usertype_name';
				}
				$this->_result_count = $this->_getListCount($this->_query );
				$this->_result = $this->_getList( $this->_query );
				break;
			case '4':  //Creator Type Rules
				$this->_result_count = count($creator_rule);
				$this->_result = $creator_rule;
				break;				
		}
		if($this->_result)return array($this->_result_count,$this->_result);
		else return false;
	}

	/**
	 * Retrieves the "object type" id and name to add in combo box selector drop down
	 * @param string $access_type type of "User Access Rule" (All=0,Grid=1,Sheet=2,Column=3)
	 * @return array Array of objects containing the object id and name depending on the access type selection or false if no rules were found
	 */
	function get_combo_User_Access_Rule_Id_List($access_type)
	{
    if(!$access_type) $access_type = '0';
		$name_apply_to_all_grids[0] = array("access_type_name"=>"All Grids (Global Rule)","access_type_id"=>"G-1");
		$apply_to_all_grids[0] = array("access_type_name"=>"All Grids (Global Rule)","access_type_id"=>"-1");
		switch ($access_type){
			case '0':  //all rule types to be used to validate "object type" values
				$this->_query = 'SELECT b.title AS access_type_name,
				                  CONCAT("G",b.id) AS access_type_id
			           	     FROM #__jgrid_security a,
			           	          #__jgrid_grids b
			           	     WHERE a.access_subtype_grid_id = b.id
			           	      AND a.access_type="1"';
				$typeone_result = $this->_getList( $this->_query );

				$this->_query = ' SELECT CONCAT(b.title,"-",c.header) AS access_type_name,
			           	          CONCAT("C",b.id,"-",d.id) AS access_type_id
			           	     FROM #__jgrid_security a,
			           	          #__jgrid_grids b,
                                  #__jgrid_columns c,
                                  #__jgrid_columngrid d	
			           	     WHERE a.access_subtype_grid_id = b.id
			           	      AND a.access_subtype_column_id = d.id
			           	      AND c.id = d.column_id
			           	      AND a.access_type="2"';
				$typetwo_result = $this->_getList( $this->_query );

				$this->_query = ' SELECT d.document_title AS access_type_name,
			           	          CONCAT("D",d.id) AS access_type_id
			           	     FROM #__jgrid_security a,
			           	          #__jgrid_document d	
			           	     WHERE a.access_subtype_document_id = d.id
			           	      AND a.access_type="3"';
				 
				$typethree_result = $this->_getList( $this->_query );
				 
				$this->_query = ' SELECT CONCAT(e.document_title,"-",f.header) AS access_type_name,
			           	          CONCAT("E",e.id,"-",g.id) AS access_type_id
			           	     FROM #__jgrid_security a,
                                  #__jgrid_document e,
                                  #__jgrid_columns f,
                                  #__jgrid_columngrid g	
			           	     WHERE a.access_subtype_document_id = e.id
			           	      AND a.access_subtype_column_id = g.id
			           	      AND f.id = g.column_id
			           	      AND a.access_type="4"';
				$typefour_result = $this->_getList( $this->_query );
				$this->_result = array_merge($name_apply_to_all_grids, $typeone_result, $typetwo_result, $typethree_result,$typefour_result);
				$this->_result_count = count($this->_result);
				break;
					
			case '1':  //grid rule
				$this->_query = 'SELECT a.title AS access_type_name,
				                 CONCAT("G",a.id) AS access_type_id
			           	    FROM #__jgrid_grids a,
			           	         #__jgrid_applications b
			          	    WHERE  a.grid_application_name = b.grid_application_name
			          	    AND b.id = '.JRequest::getVar('application_id');
				$this->_result = $this->_getList( $this->_query );
				//$this->_result = $apply_to_all_grids + $this->_result;
				$this->_result = array_merge($apply_to_all_grids, $this->_result );
				$this->_result_count = count($this->_result);
				break;

			case '2':  //Grid-Column rule
				$this->_query = 'SELECT CONCAT(a.title,"-",b.header) AS access_type_name,
				                        CONCAT("C",a.id,"-",c.id) AS access_type_id
			           	         FROM #__jgrid_grids a,
                                #__jgrid_columns b,
                                #__jgrid_columngrid c,
			           	         #__jgrid_applications d
			          	    WHERE  a.grid_application_name = d.grid_application_name
			          	      AND d.id = '.JRequest::getVar('application_id').'
                              AND a.id = c.grid_id
                              AND b.id = c.column_id';
				$this->_result_count = $this->_getListCount( $this->_query );
				$this->_result = $this->_getList( $this->_query );
				break;
					
			case '3':  //sheet  rule
				$this->_query = 'SELECT a.document_title AS access_type_name,
				                        CONCAT("D",a.id) AS access_type_id
			           	         FROM #__jgrid_document a,                                   
			           	              #__jgrid_grids b,
			           	              #__jgrid_applications c
			          	    WHERE b.grid_application_name = c.grid_application_name
			          	      AND a.grid_id = b.id 
			          	      AND c.id = '.JRequest::getVar('application_id');
				$this->_result_count = $this->_getListCount( $this->_query );
				$this->_result = $this->_getList( $this->_query );
				break;


			case '4':  //Sheet-Column rule
				$this->_query = 'SELECT CONCAT(a.document_title,"-",b.header) AS access_type_name,
				                        CONCAT("E",a.id,"-",c.id) AS access_type_id
			           	         FROM #__jgrid_document a,
			           	              #__jgrid_columns b, 
                                      #__jgrid_columngrid c,
                                      #__jgrid_grids d,
			           	              #__jgrid_applications e
			          	    WHERE  d.grid_application_name = e.grid_application_name
			          	      AND e.id = '.JRequest::getVar('application_id').'
			          	      AND a.grid_id = d.id 
                              AND a.grid_id = c.grid_id
                              AND b.id = c.column_id';
				$this->_result_count = $this->_getListCount( $this->_query );
				$this->_result = $this->_getList( $this->_query );
				break;
		}

		if($this->_result)return array($this->_result_count,$this->_result);
		else return false;

	}

	/**
	 * Updates the   "Manager User Access" rule being edited in the  "Manager User Access" grid
	 * @var array $user array of objects defining the various Joomla user data, user->id used to define user assigning access rule
	 * @var array $row_data array of objects sent from the "Manager User Access" grid containing the values to be updated in the database
	 * @return array return the data that was just updated to the grid or false if rule not updated.
	 */
	function updateUserAccessRule()
	{
		$db =JFactory::getDBO();
		$user =JFactory::getUser();
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		$access_type = $row_data[0]['access_type'];
		$access_type_id = $row_data[0]['access_type_id'];	
		$access_subtype_grid_id = 0;
		$access_subtype_column_id = 0;
		$access_subtype_document_id = 0;	
		// if leading character added to access_type_id remove it		
		if($access_type_id[0] = 'G'
		    || $access_type_id[0] = 'C'
		    || $access_type_id[0] = 'D'
		    || $access_type_id[0] = 'E')
		{		
			$access_type_id = substr((string)$access_type_id,1);						
		}
		switch ($access_type)
		{
			//grid level
			case '1':
				$access_subtype_grid_id = $access_type_id;								
				break;
				//grid-column level
			case '2':
				$access_subtype_grid_id = substr($access_type_id,0,strpos($access_type_id,'-'));
				$access_subtype_column_id = substr($access_type_id,strpos($access_type_id,'-')+1);
				break;
				//document level
			case '3':
				$access_subtype_document_id = substr($access_type_id,0);
				break;
				//document-column
			case '4':
				$access_subtype_document_id = substr($access_type_id,0,strpos($access_type_id,'-'));
				$access_subtype_column_id = substr($access_type_id,strpos($access_type_id,'-')+1);
				break;
		}
		$query = 'UPDATE  #__jgrid_security
			                  SET userid_assigning_access = "'.$user->id.'",';  
		if(array_key_exists('access_rule_application_id',$row_data[0]))	$query .= ' access_rule_application_id ='.$row_data[0]['access_rule_application_id'].',';
		if(array_key_exists('access_for',$row_data[0]))  				$query .= ' access_for ='.$row_data[0]['access_for'].',';
		if(array_key_exists('access_for_name',$row_data[0]))  			$query .= ' access_for_name="'.$row_data[0]['access_for_name'].'",';
		if(array_key_exists('access_for_id',$row_data[0]))  			$query .= ' access_for_id = SUBSTR("'.$row_data[0]['access_for_id'].'",2),'; 
		if(array_key_exists('access_type',$row_data[0]))  				$query .= ' access_type='.$row_data[0]['access_type'].',';
		if(array_key_exists('access_type_name',$row_data[0])) 			$query .= ' access_type_name="'.$row_data[0]['access_type_name'].'",';
		if(array_key_exists('access_type_id',$row_data[0]))  			$query .= ' access_type_id = "'.$access_type_id.'",';
		if(array_key_exists('access_type_id',$row_data[0])) 			$query .= ' access_subtype_grid_id = "'.$access_subtype_grid_id.'",';
		if(array_key_exists('access_type_id',$row_data[0])) 			$query .= ' access_subtype_column_id = "'.$access_subtype_column_id.'",';
		if(array_key_exists('access_type_id',$row_data[0])) 			$query .= ' access_subtype_document_id = "'.$access_subtype_document_id.'",';
		if(array_key_exists('access_level',$row_data[0])) 				$query .= ' access_level='.$row_data[0]['access_level'].',';
		$query[strlen($query)-1] = ' '; 
	    $query .= ' WHERE id = '.$row_data[0]['id'];
	    
//echo 'sql '.$query;
//return;		    	
		$db->setQuery( $query);
		if($db->query())return true;
		else return false;
	}

	/**
	 * Creates new rule in the "Manager User Access" grid
	 * @var array $user array of objects defining the various Joomla user data, user->id used to default user new rule applies to
	 * @var array $row_data array of objects sent from the "Manager User Access" grid containing the values to be updated in the database
	 * @var integer $last_id the database row id of the new Access Rule to be returned to the grid
	 * @return array return the new rule data that was updated ($last_id, and $user->id) to the grid row false if new rule not created.
	 */
	function createUserAccessRule()
	{
		$db =JFactory::getDBO();
		$user =JFactory::getUser();
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		$access_type = $row_data[0]['access_type'];
		$access_type_id = $row_data[0]['access_type_id'];
		$access_subtype_grid_id = 0;
		$access_subtype_column_id = 0;
		$access_subtype_document_id = 0;
        
		
		// if leading character added to access_type_id remove it
		if($access_type_id[0] = 'G'
		    || $access_type_id[0] = 'C'
		    || $access_type_id[0] = 'D'
		    || $access_type_id[0] = 'E')
		{
			$access_type_id = substr($access_type_id,1);
		}

		switch ($access_type)
		{
			//grid level
			case '1':
				$access_subtype_grid_id = $access_type_id;
				break;
				//grid-column level
			case '2':
				$access_subtype_grid_id = substr($access_type_id,0,strpos($access_type_id,'-'));
				$access_subtype_column_id = substr($access_type_id,strpos($access_type_id,'-')+1);
				break;
				//document level
			case '3':
				$access_subtype_document_id = substr($access_type_id,0);
				break;
				//document-column
			case '4':
				$access_subtype_document_id = substr($access_type_id,0,strpos($access_type_id,'-'));
				$access_subtype_column_id = substr($access_type_id,strpos($access_type_id,'-')+1);
				break;
		}
		$db->setQuery('INSERT  INTO #__jgrid_security
		                         (userid_assigning_access,
		                          access_rule_application_id, 
		                          access_for, 
		                          access_for_name, 
		                          access_for_id, 
		                          access_type,
		                          access_type_name, 
		                          access_type_id,
		                          access_subtype_grid_id,
                                  access_subtype_column_id,
                                  access_subtype_document_id, 
		                          access_level)
			              VALUES ("'.$user->id.'",
			                      "'.$row_data[0]['access_rule_application_id'].'",
			                      "'.$row_data[0]['access_for'].'",
			                      "'.$row_data[0]['access_for_name'].'", 
			                      SUBSTR("'.$row_data[0]['access_for_id'].'",2),
			                      "'.$access_type.'", 
			                      "'.$row_data[0]['access_type_name'].'",
			                      "'.$access_type_id.'",
			                      "'.$access_subtype_grid_id.'",
			                      "'.$access_subtype_column_id.'",
			                      "'.$access_subtype_document_id.'",			                      			                      			                      
			                      "'.$row_data[0]['access_level'].'")');
		$this->_result = $db->query();
		$db->setQuery('SELECT last_insert_id() FROM #__jgrid_security');
		$last_id = $db->loadResult();
		$row_data[0]["id"]=$last_id;
		//$row_data[0]['access_for_id']=$user->id;
		if($last_id) return $row_data[0];
		else return false;
	}

	/**
	 * Deletes rule in the "Manager User Access" grid
	 * @return integer result true of rule deleted or false if delete failed
	 */
	function deleteUserAccessRule()
	{
		$db =JFactory::getDBO();
		$db->setQuery('DELETE FROM  #__jgrid_security
			                  WHERE id = '.JRequest::getVar('rows','','','INTEGER')); 
		if($db->query())return true;
		else return false;
	}

}