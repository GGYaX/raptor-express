<?php
/**
 * Jgrid_columns Model in Joomla/Administrator/Components/models
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.model' );

/**
 * Jgrid_columns model
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid administrator "Column Settings" screen
 * to "Grid Column Settings"
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */

if(!class_exists('RMWorksAroundJoomlaToGetAModel')) {
	if(interface_exists('JModel')) {
		abstract class RMWorksAroundJoomlaToGetAModel extends JModelLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAModel extends JModel {}
	}
}

class JgridsModeljgrid_columnslistboxvalues extends RMWorksAroundJoomlaToGetAModel
{
	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The string containing the SQL call (query) that will retrieve the desired results
	 * @var string
	 */
	var $_query=null;



	/**
	 * Updates List of Valid column values for "List Box type Column" in the "Columns Setting data_type popup" grid
	 * @var array $row_data array of objects sent from the "List Box Values" grid containing the values to be updated in the database
	 * @return integer return true if row updated or false if update failed.
	 */
	function update_listBoxValues()
	{
		$db =JFactory::getDBO();
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		// select existing values
		$this->_query = 'SELECT id,
		                        listboxvalues,
		                        listboxvaluerowcolor
	                      FROM  #__jgrid_column_list_field_values
	                      WHERE id = '.$row_data[0]['id'];
		$this->_result_count = $this->_getListCount( $this->_query );
		$old_listbox_values = $this->_getList( $this->_query );
		
		$query = 'UPDATE  #__jgrid_column_list_field_values
			                  SET ';
		if($row_data[0]['listboxvalues'])
		{
			$query .= 'listboxvalues = "'.$row_data[0]['listboxvalues'].'"';
		}
		if($row_data[0]['listboxvalues']&&$row_data[0]['listboxvaluerowcolor'])
		{
			$query .= ', ';
		}
		if($row_data[0]['listboxvaluerowcolor'])
		{
			$query .= 'listboxvaluerowcolor = "'.$row_data[0]['listboxvaluerowcolor'].'"';
		}
		$query .= ' WHERE id = '.$row_data[0]['id'];
//echo 'sql '.$query;		
		$this->_db->setQuery($query); 

		if($this->_db->query())
		{
		   //search database and update all previous values
		   	$query = 'UPDATE  #__jgrid_columndata
			                  SET ';
			if($row_data[0]['listboxvalues'])
			{
				$query .= 'string_data = "' . $row_data[0]['listboxvalues'] .'"';
			}
			if($row_data[0]['listboxvalues']&&$row_data[0]['listboxvaluerowcolor'])
			{
				$query .= ', ';
			}
			if($row_data[0]['listboxvaluerowcolor'])
			{
				$query .= 'listboxvaluerowcolor = "'.$row_data[0]['listboxvaluerowcolor'].'"';
			}
			$query .= '  WHERE id IN (SELECT id 
                                                 FROM (SELECT a.id
                                                       FROM #__jgrid_columndata a,
                                                            #__jgrid_columns b
                                                       WHERE  a.string_data = "'.$old_listbox_values[0]->listboxvalues.'"
                                                         AND  a.column_id = b.id
                                                         AND  b.data_type = "L") as temp_table)';
			$this->_db->setQuery($query);
			$this->_db->query();
			return true;
		}
		else
		{
			return false;
		}




	}

	/**
	 * Creates List of Valid column values for "List Box type Column" in the "Columns Setting data_type popup" grid
	 * @var array $row_data array of objects sent from the "List Box Values" combo box popup containing the values to be updated in the database
	 * @var integer $last_id the database row id of the new value to be returned to the grid
	 * @return array return the new value data that was updated ($last_id) to the grid row or false if value not created.
	 */
	function create_listBoxValues()
	{
		$db =JFactory::getDBO();
		//insert row
		$this->_db->setQuery('INSERT  INTO #__jgrid_column_list_field_values (column_id,
		                                                                      listboxvalues,
		                                                                      listboxvaluerowcolor)
		                      VALUES ('.JRequest::getVar('column_id','','','INTEGER').',
		                              "",
		                              "")');		              
		$this->_result = $this->_db->query();

		//find new row id and return
		$this->_db->setQuery('SELECT last_insert_id() FROM #__jgrid_column_list_field_values');
		$last_id = $this->_db->loadResult();
		$row_data["id"]=$last_id;
		if($last_id) return $row_data;
		else return false;

	}

	/**
	 * Retrieves the List of Valid column values for "List Box type Column" in the "Columns Setting data_type popup" grid
	 * @return array containing the "List values" grid rows or false if no values returned
	 *
	 */
	function read_listBoxValues()
	{
		$this->_query = 'SELECT id,
		                        listboxvalues,
		                        listboxvaluerowcolor
	                      FROM  #__jgrid_column_list_field_values
	                      WHERE column_id = '.JRequest::getVar('column_id','','','INTEGER').'
	                      ORDER BY listboxvalues';
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else
		{
			$this->create_listBoxValues();
			$this->_query = 'SELECT id,
		                        listboxvalues,
		                        listboxvaluerowcolor
	                      FROM  #__jgrid_column_list_field_values
	                      WHERE column_id = '.JRequest::getVar('column_id','','','INTEGER');
			$this->_result_count = $this->_getListCount( $this->_query );
			$this->_result = $this->_getList( $this->_query );
			if($this->_result) return array($this->_result_count,$this->_result);
			else return false;
		}
	}



	/**
	 * Deletes List of Valid column values for "List Box type Columns" in the "Columns Setting data_type popup" grid
	 * @var integer $row_id the database row id of the value to be deleted.
	 * @return integer result true if value deleted or false if delete failed
	 */
	function destroy_listBoxValues()
	{
		$db =JFactory::getDBO();
		//get row_id to delete from user interface
		$row_id=JRequest::getVar('rows','','','INTEGER');

		//delete column from "columns settings" grid
		$this->_db->setQuery('DELETE FROM  #__jgrid_column_list_field_values
			                  WHERE id = '.$row_id);
		if($this->_db->query())return true;
		else return false;
	}

}