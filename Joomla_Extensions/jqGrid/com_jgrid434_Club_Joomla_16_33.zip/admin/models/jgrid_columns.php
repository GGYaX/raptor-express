<?php
/**
 * Jgrid_columns Model in Joomla/Administrator/Components/models
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.model' );

/**
 * Jgrid_columns model
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid administrator "Column Settings" screen
 * to "Grid Column Settings"
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */

if(!class_exists('RMWorksAroundJoomlaToGetAModel')) {
	if(interface_exists('JModel')) {
		abstract class RMWorksAroundJoomlaToGetAModel extends JModelLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAModel extends JModel {}
	}
}

class JgridsModelJgrid_columns extends RMWorksAroundJoomlaToGetAModel
{
	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The string containing the SQL call (query) that will retrieve the desired results
	 * @var string
	 */
	var $_query=null;

	/**
	 * Retrieves the "Column Settings" data
	 * @return array containing the "Column Settings" grid rows or false if no rows returned
	 *
	 */
	function getColumnRows()
	{
		$this->_query = 'SELECT id,
		                    header, 
		                    editable, 
		                    width, 
		                    data_type,
		                    validation_type,
		                    dfilter,
		                    sortable, 
		                    ddefault,
		                    align, 
		                    css,		                    
		                    tooltip,
		                    freeze_column,
		                    email_subject,
		                    summarycolumn,
		                    summarytype,
		                    summaryprefix,
		                    summarypostfix
	                      FROM  #__jgrid_columns
	                      ORDER BY header';		
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;
	}

	/**
	 * Updates the   "Column Settings" data being edited in the  "Column Settings" grid
	 * @var array $row_data array of objects sent from the "Column Settings" grid containing the values to be updated in the database
	 * @return integer return true if row updated or false if update failed.
	 */
	function updateColumnRow()
	{
		$db =JFactory::getDBO();
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		$query = 'UPDATE  #__jgrid_columns
			                  SET ';  
		if(array_key_exists('header',$row_data[0]))   		$query .= ' header ="'.$row_data[0]['header'].'",';
		if(array_key_exists('editable',$row_data[0]))   		$query .=    ' editable="'.$row_data[0]['editable'].'",';
		if(array_key_exists('width',$row_data[0]))   		$query .=    ' width='.$row_data[0]['width'].',';
		if(array_key_exists('data_type',$row_data[0]))  		$query .=    ' data_type="'.$row_data[0]['data_type'].'",';
		if(array_key_exists('validation_type',$row_data[0]))	$query .=    ' validation_type="'.$row_data[0]['validation_type'].'",';
		if(array_key_exists('dfilter',$row_data[0]))   		$query .=    ' dfilter="'.$row_data[0]['dfilter'].'",';
		if(array_key_exists('sortable',$row_data[0]))   		$query .=    ' sortable="'.$row_data[0]['sortable'].'",';
		if(array_key_exists('ddefault',$row_data[0]))  		$query .=    ' ddefault="'.$row_data[0]['ddefault'].'",';
		if(array_key_exists('align',$row_data[0]))	$query .=    ' align="'.$row_data[0]['align'].'",';
		if(array_key_exists('css',$row_data[0]))   		$query .=    ' css="'.$row_data[0]['css'].'",';
		if(array_key_exists('tooltip',$row_data[0]))   		$query .=    ' tooltip="'.$row_data[0]['tooltip'].'",';
		if(array_key_exists('freeze_column',$row_data[0]))   		$query .=    ' freeze_column="'.$row_data[0]['freeze_column'].'",';		
		if(array_key_exists('email_subject',$row_data[0]))   		$query .=    ' email_subject="'.$row_data[0]['email_subject'].'",';
		if(array_key_exists('summarycolumn',$row_data[0]))   		$query .=    ' summarycolumn="'.$row_data[0]['summarycolumn'].'",';
		if(array_key_exists('summaryprefix',$row_data[0]))   		$query .=    ' summaryprefix="'.$row_data[0]['summaryprefix'].'",';
		if(array_key_exists('summarypostfix',$row_data[0]))   		$query .=    ' summarypostfix="'.$row_data[0]['summarypostfix'].'",';
		if(array_key_exists('summarytype',$row_data[0]))   		$query .=    ' summarytype="'.$row_data[0]['summarytype'].'",';
	
		
		$query[strlen($query)-1] = ' '; 
	    $query .=              ' WHERE id = '.$row_data[0]['id'];
		$this->_db->setQuery($query); 			
		if($this->_db->query()) return true;
		else return false;
	}


	/**
	 * Creates new column in the "Column Settings" grid
	 * @var array $row_data array of objects sent from the "Column Settings" grid containing the values to be updated in the database
	 * @var integer $last_id the database row id of the new column to be returned to the grid
	 * @return array return the new column data that was updated ($last_id) to the grid row or false if row not created.
	 */
	function createColumnRow()
	{
		$db =JFactory::getDBO();
		//insert row
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		if(!$row_data[0]['ddefault'])
		{
			switch ($row_data[0]['data_type'])
		 {
			//text
			case 'T':
			//List
			case 'L':
			//Picture
			case 'P':
			//URL
			case 'U':
			//EMail
			case 'E':						
			//Sheet Name
			case 'S':
		 		$ddefault = '';
		 		break;
		 		//date
		 	case 'D':
		 		$ddefault= '';
		 		break;
		 		// Integer
		 	case 'I':
		 		//Date
		 		// Boolean
		 	case 'B':
		 		// Row id
		 	case 'R':
		   // Float
		 	case 'F':
		 		$ddefault = 0;
		 		break;
		 }
		}
		else
		{
			$ddefault = $row_data[0]['ddefault'];
		}
		$this->_query='INSERT  INTO #__jgrid_columns (header, 
		                                                     editable, 
		                                                     width, 
		                                                     data_type,
		                                                     validation_type,
		                                                     dfilter,
		                                                     sortable, 
		                                                     ddefault,
		                                                     align, 
		                                                     css,
		                                                     tooltip,
		                                                     freeze_column,
		                                                     email_subject)
		                      VALUES ("'.$row_data[0]['header'].'",
		                              "'.$row_data[0]['editable'].'",
		                              "'.$row_data[0]['width'].'", 
			                          "'.$row_data[0]['data_type'].'",
			                          "'.$row_data[0]['validation_type'].'",
			                          "'.$row_data[0]['dfilter'].'",
			                          "'.$row_data[0]['sortable'].'",
			                          "'.$ddefault.'",
			                          "'.$row_data[0]['align'].'",
			                          "'.$row_data[0]['css'].'",
			                          "'.$row_data[0]['tooltip'].'",
			                          "'.$row_data[0]['freeze_column'].'",
			                          "'.$row_data[0]['email_subject'].'")';	
		$this->_db->setQuery($this->_query);
		$this->_result = $this->_db->query();

		//find new row id and return
		$this->_db->setQuery('SELECT last_insert_id() FROM #__jgrid_columns');
		$last_id = $this->_db->loadResult();
		$row_data[0]["id"]=$last_id;
		if($last_id) return $row_data[0];
		else return false;

	}

	/**
	 * Deletes column record (row) in the "Columns Setting" grid
	 * @var integer $row_id the database row id of the row to be deleted.
	 * @return integer result true if row deleted or false if delete failed
	 */
	function deleteColumnRow()
	{
		$db =JFactory::getDBO();
		//get row_id to delete from user interface
		$row_id=JRequest::getVar('rows','','','INTEGER');

		//delete any combo list values for this column
		$this->_db->setQuery('DELETE FROM  #__jgrid_column_list_field_values
		                      WHERE column_id = '.$row_id);
		$this->_db->query();

		//delete data rows stored in column to be removed from all sheets in all grids where the column is used
		$this->_db->setQuery('DELETE FROM  #__jgrid_columndata
		                      WHERE column_id = '.$row_id);
		$this->_db->query();

		//delete "User Access Rules" related to the column for all sheets in all grids where the column is used
		$this->_db->setQuery('DELETE FROM  #__jgrid_security
		                      WHERE access_type_id = '.$row_id.'
		                        AND access_type="3"');
		$this->_db->query();

		//delete column from all grids it is used in
		$this->_db->setQuery('DELETE FROM  #__jgrid_columngrid
			                  WHERE column_id = '.$row_id);
		$this->_db->query();

		//delete column from "columns settings" grid
		$this->_db->setQuery('DELETE FROM  #__jgrid_columns
			                  WHERE id = '.$row_id);
		if($this->_db->query())return true;
		else return false;
	}

	/**
	 * Retrieves the validation formats based on column type and adds in combo box drop down selector box
	 * @return array Array of objects containing the validation formats or false if no users were found
	 */
	function jgrid_valid_format_query()
	{
		switch (JRequest::getVar( 'data_type' )){
			case '0':  //all data format types
				$this->_query = 'SELECT valid_format,
				                        valid_format_name				                        
			                     FROM #__jgrid_valid_format';
				break;
					
			case 'T':  //Text
				$this->_query = 'SELECT valid_format,
				                        valid_format_name				                        
			                     FROM #__jgrid_valid_format 
			                     WHERE data_type="T"';
				break;
				
			case 'U':  //URL
				$this->_query = 'SELECT valid_format,
				                        valid_format_name				                        
			                     FROM #__jgrid_valid_format 
			                     WHERE data_type="U"';
				break;	

			case 'E':  //EMail
				$this->_query = 'SELECT valid_format,
				                        valid_format_name				                        
			                     FROM #__jgrid_valid_format 
			                     WHERE data_type="E"';
				break;				
					
			case 'D':  //Date
				$this->_query = 'SELECT valid_format,
				                        valid_format_name				                        
			                     FROM #__jgrid_valid_format 
			                     WHERE data_type="D"';
				break;
			case 'F':  //Float
				$this->_query = 'SELECT valid_format,
				                        valid_format_name				                        
			                     FROM #__jgrid_valid_format 
			                     WHERE data_type="F"';
				break;
			default:
				if($this->_result)
				{
					$this->_result[0]->valid_format='none';
					$this->_result[0]->valid_format_name='none';
				}
				return array(1,$this->_result);
		}
		$this->_result_count = $this->_getListCount($this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result)return array($this->_result_count,$this->_result);
		else return false;
	}

}