
<?php
/**
 * Jgrid_sqlselect Model in Joomla/Administrator/Components/models
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.model' );
require_once(JPATH_BASE . '/components/com_jgrid/os/jgrid/functions.php' );

/**
 * Jgrid_columngrid model
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid administrator "Column Settings" screen
 * to "Grid Column Settings"
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */

if(!class_exists('RMWorksAroundJoomlaToGetAModel')) {
	if(interface_exists('JModel')) {
		abstract class RMWorksAroundJoomlaToGetAModel extends JModelLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAModel extends JModel {}
	}
}

class JgridsModelJgrid_sqlselect extends RMWorksAroundJoomlaToGetAModel
{
	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The string containing the SQL call (query) that will retrieve the desired results
	 * @var string
	 */
	var $_query=null;

	/**
	 * Retrieves the select criteria 
	 * @return array containing the "Columns assigned to grid" rows or false if no rows returned
	 *
	 */
	function readJoinCriteria()
	{
		$this->_query = 'SELECT a.id,
		                        a.grid_id, 
		                        a.criteria_type_id,
								a.database_sql_name_id,
								a.table_sql_name_id,
								a.column_sql_name_id,
								a.criteria_operator_id,
								a.jdatabase_sql_name_id,
								a.jtable_sql_name_id,
								a.jcolumn_sql_name_id,
								a.select_wildcard_id,
								a.criteria_value
	                      FROM  #__jgrid_select_join_criteria a 	                           	                            
	                      WHERE a.grid_id = '. JRequest::getVar('selected_grid_id','','','STRING');			
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;
	}


	/**
	 * Updates the select criteria
	 * @return integer return true if row updated or false if update failed.
	 */
	function updateJoinCriteria()
	{
		$db =JFactory::getDBO();
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		$query = 'UPDATE  #__jgrid_select_join_criteria
			                  SET ';  
		if(array_key_exists('criteria_type_id',$row_data[0])) 		$query .= ' criteria_type_id ='.$row_data[0]['criteria_type_id'].',';
		if(array_key_exists('database_sql_name_id',$row_data[0]))  	$query .=    ' database_sql_name_id="'.$row_data[0]['database_sql_name_id'].'",';
		if(array_key_exists('table_sql_name_id',$row_data[0]))  	$query .=    ' table_sql_name_id="'.$row_data[0]['table_sql_name_id'].'",';
		if(array_key_exists('column_sql_name_id',$row_data[0]))  	$query .=    ' column_sql_name_id="'.$row_data[0]['column_sql_name_id'].'",';
		if(array_key_exists('criteria_operator_id',$row_data[0])) 	$query .=    ' criteria_operator_id="'.$row_data[0]['criteria_operator_id'].'",';
		if(array_key_exists('jdatabase_sql_name_id',$row_data[0])) 	$query .=    ' jdatabase_sql_name_id="'.$row_data[0]['jdatabase_sql_name_id'].'",';
		if(array_key_exists('jtable_sql_name_id',$row_data[0]))  	$query .=    ' jtable_sql_name_id="'.$row_data[0]['jtable_sql_name_id'].'",';
		if(array_key_exists('jcolumn_sql_name_id',$row_data[0]))  	$query .=    ' jcolumn_sql_name_id="'.$row_data[0]['jcolumn_sql_name_id'].'",';
		if(array_key_exists('select_wildcard_id',$row_data[0]))  	$query .=    ' select_wildcard_id="'.$row_data[0]['select_wildcard_id'].'",';
		if(array_key_exists('criteria_value',$row_data[0]))  	$query .=    ' criteria_value="'.$row_data[0]['criteria_value'].'",';
		$query[strlen($query)-1] = ' '; 
	    $query .=              ' WHERE id = '.$row_data[0]['id'];	
		$this->_db->setQuery($query);	
		if($this->_db->query()) return true;
		else return false;
	}

	/**
	 * Creates a new select criterial where clause rule
	 * @return array return the new column assigned to grid data that was updated ($last_id) to the grid row or false if row not created.
	 */
	function createJoinCriteria()
	{
		$user=JFactory::getUser();
		$db =JFactory::getDBO();
		$app = JFactory::getApplication();
    	$database_schema= $app->getCfg('db');
		//insert row
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		// add default database name
		if(!$row_data[0]['database_sql_name_id']) $row_data[0]['database_sql_name_id'] = $database_schema;
		if(!$row_data[0]['jdatabase_sql_name_id']) $row_data[0]['jdatabase_sql_name_id'] = $database_schema;
			  
		$this->_db->setQuery( 'INSERT  INTO #__jgrid_select_join_criteria (column_id,
		                                                         grid_id,  
		                                                         database_sql_name_id,
		                                                         Jdatabase_sql_name_id)
			                   VALUES ('.$row_data[0]['grid_id'].',
			                   			"'.$row_data[0]['database_sql_name_id'].'",
		                               	"'.$row_data[0]['Jdatabase_sql_name_id'].'")');		              
		$this->_result = $this->_db->query();

		//find new row id and return
		$this->_db->setQuery('SELECT last_insert_id() FROM #__jgrid_select_join_criteria');
		$last_id = $this->_db->loadResult();
		$row_data[0]["id"] = $last_id;

		if($last_id) return $row_data[0];
		else return false;
	}


	/**
	 * Deletes SELECT CRITERIA VALUE
	 * @return integer result true if row deleted or false if delete failed
	 */

	function destroyJoinCriteria()
	{
		$db =JFactory::getDBO();


		//delete data rows stored in column to be removed from all sheets used in where the column is used on this grid
		$rows = json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		for ($i=0;$i<count($rows);$i++)
		{
			$query = '	DELETE FROM  #__jgrid_columndata a
			 			WHERE a.id = '.$rows[$i]->id;
			$db->setQuery($query);
			$result=$db->query();			
		}

		if($this->result)return true;
		else return false;
	}
	
		
	/**
	 * selects jgrid_select_wildcards combo list valid entries
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function jgrid_select_wildcards()
	{
		$this->_query = 'SELECT	a.id,
								a.select_wildcard as select_wildcard_id,	
		                     	a.select_wildcard
	                      FROM  #__jgrid_select_wildcards a
	                     ORDER BY a.select_wildcard';			
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;

	}
	
	/**
	 * selects jgrid_select_criteria_type combo list valid entries
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function jgrid_select_criteria_type()
	{
		$this->_query = 'SELECT  a.id,
		                         a.criteria_type
	                      FROM  #__jgrid_select_criteria_type a
	                     ORDER BY a.criteria_type';			
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;

	}
		

}