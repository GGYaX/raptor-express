<?php
/**
 * Jgrid_users Controller in Joomla/Administrator/Components/controllers
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
jimport( 'joomla.application.component.model' );

/**
 * Jgrid_users model
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid administrator "Manager User Access" screens
 * to "Manage User Access" rights
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */

if(!class_exists('RMWorksAroundJoomlaToGetAModel')) {
	if(interface_exists('JModel')) {
		abstract class RMWorksAroundJoomlaToGetAModel extends JModelLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAModel extends JModel {}
	}
}

class JgridsModelJgrid_users extends RMWorksAroundJoomlaToGetAModel
{

	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The pointer to the joomla model to be accesses
	 * @var array
	 */
	var $_model=null;

	/**
	 * The pointer to the database query to be queried
	 * @var array
	 */
	var $_query = null;


	/*
	 * Retrieves the jgrid roles list
	 *  @return string json string containing the "Roles User List" grid rows
	 */
	function get_roles_data()
	{
		$db =JFactory::getDBO();
		$this->_query = 'SELECT a.id,
		                        a.userid,		                        				            
				                b.username,
				                a.role_id,
				                c.role_name
				            FROM #__jgrid_role_userlist a,
				                 #__users b,
				                 #__jgrid_roles c
				            WHERE (a.userid = b.id
				                     OR a.userid = 0)
				              AND (a.role_id = c.id
				                     OR a.role_id = 0)
				            ORDER BY b.username'; 
//echo 'sql '.$this->_query.' end';
		$this->_result_count = $this->_getListCount($this->_query);
		$this->_result = $this->_getList($this->_query);
		if($this->_result)return array($this->_result_count,$this->_result);
		else return false;
	}

	/**
	 * Retrieves the users ID and Name that access rules can be applied and adds in combo box drop down selector box
	 * @return array Array of objects containing the user id's and names or false if no users were found
	 */
	function get_jgrid_username_query()
	{

		$this->_query = 'SELECT username,
		                        id AS userid
			             FROM #__users
			             ORDER BY username'; 
		$this->_result_count = $this->_getListCount($this->_query);
		$this->_result = $this->_getList($this->_query);
		if($this->_result)return array($this->_result_count,$this->_result);
		else return false;
	}

	/**
	 * Retrieves the roles ID and Name that users can be applied and adds in combo box drop down selector box
	 * @return array Array of objects containing the user id's and names or false if no users were found
	 */
	function get_jgrid_roles_query()
	{

		$this->_query = 'SELECT role_name,
		                        id AS role_id
			           	        FROM #__jgrid_roles
			           	        ORDER BY role_name';
		$this->_result_count = $this->_getListCount($this->_query);
		$this->_result = $this->_getList( $this->_query );
		if($this->_result)return array($this->_result_count,$this->_result);
		else return false;
	}

	/**
	 * Updates the User Role User List edited in the  "Manager User Roles" grid
	 * @var array $user array of objects defining the various Joomla user data, user->id used to define user assigning access rule
	 * @var array $row_data array of objects sent from the "Manager User Access" grid containing the values to be updated in the database
	 * @return array return the data that was just updated to the grid or false if rule not updated.
	 */
	function updateUserRole()
	{
		$db =JFactory::getDBO();
		$user =JFactory::getUser();
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		$query = 'UPDATE  #__jgrid_role_userlist
			                  SET ';  
		if(array_key_exists('role_id',$row_data[0]))	$query .= ' role_id ='.$row_data[0]['role_id'].',';
		if(array_key_exists('userid',$row_data[0]))  	$query .= ' userid ='.$row_data[0]['userid'].',';
		$query[strlen($query)-1] = ' '; 
	    $query .= ' WHERE id = '.$row_data[0]['id'];
		$this->_db->setQuery($query);
		if($this->_db->query())return true;
		else return false;
	}

	/**
	 * Creates new role in the "Manager User Roles" grid
	 * @var array $user array of objects defining the various Joomla user data, user->id used to default user new rule applies to
	 * @var array $row_data array of objects sent from the "Manager User Roles" grid containing the values to be updated in the database
	 * @var integer $last_id the database row id of the new Role to be returned to the grid
	 * @return array return the new rule data that was updated the grid row false if new rule not created.
	 */
	function createUserRole()
	{

		$user =JFactory::getUser();
		$db =JFactory::getDBO();
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		$query = 'INSERT INTO #__jgrid_role_userlist
		                         (userid_assigning_role)
			                  VALUES ('.$user->id.')';
		//	echo 'sql'.$query;
		$this->_db->setQuery($query);
		$this->_result = $this->_db->query();
		$this->_db->setQuery('SELECT last_insert_id() FROM #__jgrid_role_userlist');
		$last_id = $this->_db->loadResult();
		$row_data[0]["id"]=$last_id;
		if($last_id) return $row_data[0];
		else return false;
	}

	/**
	 * Deletes role in the "Manager User Roles" grid
	 * @return integer result true of rule deleted or false if delete failed
	 */
	function deleteUserRole()
	{
		$db =JFactory::getDBO();
		// check to make sure this is not the last user role, one must be kept in table for select joins to work
		$this->_query = 'SELECT a.id
				            FROM #__jgrid_role_userlist a';            
		$this->_result_count = $this->_getListCount($this->_query);
		if($this->_result_count==0)
		{
			return false;
		}
		if(JRequest::getVar('rows','','','INTEGER')==1) return false;
		$this->_db->setQuery('DELETE FROM  #__jgrid_role_userlist
			                  WHERE id = '.JRequest::getVar('rows','','','INTEGER')); 
		if($this->_db->query())return true;
		else return false;
	}


	/**
	 * Updates the Role Name edited in the  "Manager User Roles" grid
	 * @var array $user array of objects defining the various Joomla user data, user->id used to define user assigning access rule
	 * @var array $row_data array of objects sent from the "Manager User Access" grid containing the values to be updated in the database
	 * @return array return the data that was just updated to the grid or false if rule not updated.
	 */
	function update_rolename()
	{
		$user =JFactory::getUser();
		$db =JFactory::getDBO();
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		$this->_db->setQuery(
		         'UPDATE  #__jgrid_roles
			      SET role_name = "'.$row_data[0]['role_name'].'"
			      WHERE id = '.$row_data[0]['id']);
		if($this->_db->query())return true;
		else return false;
	}

	/**
	 * Creates new role in the "Manager User Roles" grid

	 * @var array $row_data array of objects sent from the "Manager User Roles" grid containing the values to be updated in the database
	 * @var integer $last_id the database row id of the new Role to be returned to the grid
	 * @return array return the new rule data that was updated the grid row false if new rule not created.
	 */
	function create_rolename()
	{
		$db =JFactory::getDBO();
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		$this->_db->setQuery('INSERT  INTO #__jgrid_roles
		                         (role_name)
			                  VALUES ("'.$row_data[0]['role_name'].'"');
		$this->_result = $this->_db->query();
		$this->_db->setQuery('SELECT last_insert_id() FROM #__jgrid_roles');
		$last_id = $this->_db->loadResult();
		$row_data[0]["id"]=$last_id;
		if($last_id) return $row_data[0];
		else return false;
	}

	/**
	 * Deletes role name in the "Manager User Roles" grid
	 * @return integer result true of rule deleted or false if delete failed
	 */
	function destroy_rolename()
	{
		$db =JFactory::getDBO();
		// check to make sure this is not the last rolename, one must be kept in table for select joins to work
		$this->_query = 'SELECT a.id
				            FROM #__jgrid_roles a';            
		$this->_result_count = $this->_getListCount($this->_query);
		if($this->_result_count==0)
		{
			return false;
		}
		
		
		$this->_db->setQuery('DELETE FROM  #__jgrid_roles
			                  WHERE id = '.JRequest::getVar('rows','','','INTEGER')); 
		if($this->_db->query())return true;
		else return false;
	}
	
}