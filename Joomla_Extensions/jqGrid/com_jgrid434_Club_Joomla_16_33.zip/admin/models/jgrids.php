<?php
/**
 * Jgrid_Jgrids Model in Joomla/Administrator/Components/controllers
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

jimport( 'joomla.application.component.model' );
require_once(JPATH_BASE . '/components/com_jgrid/os/jgrid/functions.php' );

/**
 * Jgrid Model
 * Manage data grids
 */

if(!class_exists('RMWorksAroundJoomlaToGetAModel')) {
	if(interface_exists('JModel')) {
		abstract class RMWorksAroundJoomlaToGetAModel extends JModelLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAModel extends JModel {}
	}
}

class JgridsModelJgrids extends RMWorksAroundJoomlaToGetAModel
{
	/**
	 * Jgrids data arrays
	 *
	 * @var array
	 */
	var $_data=null;
	var $_count=null;
	var $result=null;

	/**
	 * Creates Query to return grid columns list ??? where called ??? why not in columngrid model
	 * @access public
	 * @return string query with dataindex set to groupById, sortById, or selectionID
	 *
	 */
	function getGridColumnsQuery($grid_id,$columnAlias)
	{
		$query = 'SELECT b.id,
		                 b.header,
		                 b.header as '.$columnAlias.'Display,
		                 CONCAT(b.data_type, a.id)	as '.$columnAlias.'	                 
	              FROM  #__jgrid_columngrid a, 
	                    #__jgrid_columns b
	              WHERE a.grid_id = '.$grid_id.'
		          AND  a.column_id = b.id';		
		return $query;
	}


	/**
	 * Retrieves the jgrids data
	 * @access public
	 * @return array of result count, Array of objects containing the data from the database or false if not grids found
	 *
	 */
	function getGrids()
	{
		// check for joomla version
		$version = new JVersion;
		$joomla = $version->getShortVersion();
		$db =JFactory::getDBO();

	
		//linked list select
		//		$query = 'SELECT a.id,
		//		                 a.grid_application_name,
		//		                 a.renderto,
		//		                 a.title,
		//		                 a.frame,
		//		                 a.height,
		//		                 a.width,
		//		                 a.ordering,
		//		                 a.stripe_rows,
		//		                 a.enable_row_numbers,
		//		                 a.enableColumnMove,
		//		                 a.enable_paging,
		//		                 a.paging_records,
		//		                 a.tabtip
		//		               FROM (SELECT
		//		                 @r AS _parent,
		//                           @r := (
		//                                  SELECT  id
		//                                  FROM    #__jgrid_grids
		//                                  WHERE   parent_id = _parent
		//                                 ) AS id
		//	                           FROM  (
		//                                      SELECT  @r := 0
		//                                     ) vars,
		//                                     #__jgrid_grids
		//		                WHERE @r IS NOT NULL
		//		                )q
		//		        JOIN #__jgrid_grids a
		//		        ON a.id = q.id';

		//ordering row select for speed
		$query = 'SELECT a.id,
						 a.select_type,
		                 a.grid_application_name, 
		                 a.renderto, 
		                 a.title, 
		                 a.frame, 
		                 a.height, 
		                 a.width,
		                 a.ordering, 
		                 a.stripe_rows,
		                 a.enable_row_numbers, 
		                 a.enableColumnMove,
		                 a.enable_paging,
		                 a.paging_records,
		                 a.tabtip,
		                 a.cls,
                         a.ctCls 		
		          FROM #__jgrid_grids a
		          ORDER BY ordering';		


		$this->_count = $this->_getListCount( $query );
		$this->_data = $this->_getList( $query );
		return array($this->_count,$this->_data);

	}


	/**
	 * Updates the   "Data Grid Settings" grid row being edited in the  "Data Grid Settings" grid
	 * @var array $row_data array of objects sent from the "Data Grid Settings" grid containing the values to be updated in the database
	 * @return array return the data that was just updated to the grid or false if grid row not updated.
	 */
	function updateGrid()
	{
		$db =JFactory::getDBO();
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		
		// if select type changes from type 1 add view if type 2 or above remove view
		if(array_key_exists('select_type',$row_data[0]))
		{
			if($row_data[0]['select_type'] > 1)
			{
				dropGridJView($row_data[0]['id']);
			}  		
		}

		
		// if title changes then update view name
		if(array_key_exists('title',$row_data[0]))
		{
			dropGridJView($row_data[0]['id']);
		}

		
		$query = 'UPDATE  #__jgrid_grids
			                  SET ';
		if(array_key_exists('select_type',$row_data[0]))   			$query .= ' select_type ="'.$row_data[0]['select_type'].'",';  
		if(array_key_exists('grid_application_name',$row_data[0]))  $query .= ' grid_application_name ="'.$row_data[0]['grid_application_name'].'",';
		if(array_key_exists('renderTo',$row_data[0]))  				$query .= ' renderTo="'.$row_data[0]['renderto'].'",'; 
		if(array_key_exists('title',$row_data[0]))   				$query .= ' title="'.$row_data[0]['title'].'",';
		if(array_key_exists('frame',$row_data[0]))  				$query .= ' frame='.($row_data[0]['frame']? '1' : '0').',';
		if(array_key_exists('height',$row_data[0]))   				$query .= ' height="'.$row_data[0]['height'].'",';
		if(array_key_exists('width',$row_data[0])) 					$query .= ' width="'.$row_data[0]['width'].'",';
		if(array_key_exists('stripe_rows',$row_data[0]))   			$query .= ' stripe_rows='.($row_data[0]['stripe_rows']? '1' : '0').',';
		if(array_key_exists('enableColumnMove',$row_data[0]))  		$query .= ' enableColumnMove='.($row_data[0]['enableColumnMove']? '1' : '0').',';
		if(array_key_exists('ordering',$row_data[0]))  				$query .= ' ordering='.$row_data[0]['ordering'].', ';
		$query[strlen($query)-1] = ' '; 
	    $query .=	' WHERE id = '.$row_data[0]['id'];
		$this->_db->setQuery($query);
		$result = $this->_db->query();
		
		if(array_key_exists('title',$row_data[0])||(array_key_exists('select_type',$row_data[0])&&($row_data[0]['select_type'] < 2)))
		{
			//create view
			addGridJView($row_data[0]['id']);
		}
					
		if($result)return true;
		else return false;
	}

	/**
	 * Creates new data grid in the "Data Grid Settings" grid
	 *
	 * Creates new grid, creates default public sheet, and sets current user sheet to this default public sheet
	 *
	 * updates
	 * @var array $row_data array of objects sent from the Data Grid Settings" grid containing the values to be updated in the database
	 * @return array containing the new grid default data (including new grid id) or false if grid not created.
	 */
	function createGrid()
	{
		$db =JFactory::getDBO();
		$user =JFactory::getUser();
		$row_data=json_decode(JRequest::getVar('rows','','','RAW'),TRUE);

		$query ='INSERT  INTO #__jgrid_grids (parent_id,
		                                      grid_reference_id,
		                                      grid_application_name,  
		                                      renderTo, 
		                                      title, 
		                                      frame, 
		                                      height, 
		                                      width, 
		                                      stripe_rows, 
		          		                      ordering,
		                                      enableColumnMove)
			                 VALUES ("'.JRequest::getVar('last_record_id','','','INTEGER').'",
			                         "'.$row_data[0]["grid_reference_id"].'",
			                         "'.$row_data[0]["grid_application_name"].'",
			                         "'.$row_data[0]["grid_application_name"].'-renderTo",
			                         "'.$row_data[0]["title"].'", 
			                          '.($row_data[0]["frame"] ? '1' : '0').',
			                         "'.$row_data[0]["height"].'",
			                         "'.$row_data[0]["width"].'",
			                         '.($row_data[0]["stripe_rows"] ? '1' : '0').',
			                          '.$row_data[0]["ordering"] .',
			                          '.($row_data[0]["enableColumnMove"] ? '1' : '0').')';
//echo 'sql'.print_r($row_data);
//echo 'sql2 '.$row_data[0]["grid_reference_id"];
//echo 'query'.$query;
		$this->_db->setQuery($query);
		$this->_result = $this->_db->query();

		// set id to new record id to return to
		$this->_db->setQuery('SELECT last_insert_id()
		                      FROM #__jgrid_grids');
		$new_grid_id = $this->_db->loadResult();
		$row_data[0]["id"]=$new_grid_id;

		// Put in liked list and ordering
		$this->_db->setQuery('UPDATE #__jgrid_grids
                              SET parent_id = '.JRequest::getVar('last_record_id','','','INTEGER').'
                              WHERE id = '.$new_grid_id);
		$this->_db->query();

		//default do current user ID
		$row_data[0]['access_for_id']=$user->id;

		// add default rule to set grid creator user as Access_Manager for the new grid
		$this->_db->setQuery('INSERT  INTO #__jgrid_security
		                         (userid_assigning_access, 
		                          access_for, 
		                          access_for_name, 
		                          access_for_id, 
		                          access_type,
		                          access_type_name, 
		                          access_type_id, 
		                          access_level)
			              VALUES ("'.$user->id.'",
			                      "1",
			                      "'.$user->name.'",
			                      "'.$user->id.'",
			                      "1",
			                      "'.$row_data[0]['title'].'",
			                      "'.$new_grid_id.'",
			                      "6")');
		$this->_result = $this->_db->query();




		// set grid reference id as unique index identifier for each grid in user interface
		$this->_db->setQuery('UPDATE #__jgrid_grids
		                      SET grid_reference_id = "Grid-'.$new_grid_id.'" 
		                      WHERE id='.$new_grid_id);
		$result = $this->_db->query();
		$row_data[0]["grid_reference_id"]='Grid-'.$new_grid_id;
		
		addGridJView($new_grid_id);

		// add default public sheet in "Data Grid Settings" and set default flag to true
		$this->_db->setQuery('INSERT  INTO #__jgrid_document (document_title,
		                                                      creator_userid,
		                                                      grid_id,
		                                                      grid_default_document_flag)
			                  VALUES ("'. JText::_("PUBLIC_SHEET_GRID").$new_grid_id.'",
			                          "'.$user->id.'",
			                          "'.$new_grid_id.'",
			                            1)'); 
		$this->_result = $this->_db->query();

		// set default document as current sheet for new grid
		$this->_db->setQuery('SELECT last_insert_id() FROM #__jgrid_document');
		$new_document_id = $this->_db->loadResult();

		//set user current sheet to default document
		$this->_db->setQuery('INSERT  INTO #__jgrid_current_user_grid_document
		                        (current_document_id, 
		                         userid,  
		                         grid_id)
			                 VALUES ('.$new_document_id.',
			                        "'.$user->id.'",
			                         '.$new_grid_id.')');
		$result = $this->_db->query();

		if($new_grid_id) return $row_data[0];
		else return false;
	}

	/**
	 * Deletes Grid the "Data Grid Settings" grid
	 * @return integer result true if grid deleted or false if delete failed
	 */
	function deleteGrid()
	{
		$db =JFactory::getDBO();
		$grid_id=JRequest::getVar("rows","","","INTEGER");

		// delete grid view		
		dropGridJView($grid_id);			

		// delete all data from grid documents.
		$db->setQuery('	DELETE a
								FROM #__jgrid_columndata AS a
								LEFT JOIN #__jgrid_document AS b ON a.document_id = b.id
								WHERE b.grid_id='.$grid_id);
		$db->query();
		


		//delete rows
		$db->setQuery('DELETE FROM  #__jgrid_rows
			                  WHERE grid_id='.$grid_id);
		$db->query();

		// delete all documents assigned to this grid
		$db->setQuery('DELETE FROM #__jgrid_document
			                  WHERE #__jgrid_document.grid_id='.$grid_id);		
		$db->query();

		// remove grid from linked list row order
		// Get id of row below deleted row
		$db->setQuery('SELECT id
                              FROM #__jgrid_grids 
                              WHERE parent_id ='.$grid_id);
		$below_deleted_row_id = $db->loadResult();

		if($below_deleted_row_id)
		{
			$db->setQuery('UPDATE #__jgrid_grids
	                             SET parent_id = (SELECT parent_id
	                                              FROM 
	                                                (SELECT parent_id 
	                                                     FROM #__jgrid_grids 
	                                                     WHERE id ='.$grid_id.')
	                                                 AS temp_table1)
	                             WHERE id = '.$below_deleted_row_id);                         
			$db->query();
			
			// Reorder column ordering below removed ID
			$db->setQuery('UPDATE #__jgrid_grids
	                              SET ordering = ordering - 1
	                              WHERE ordering >= (SELECT ordering 
	                                                FROM #__jgrid_columngrid
	                                                WHERE id = '.$below_deleted_row_id.') 
	                              AND id = '.$grid_id);
			$db->query();
		}

		// delete columns from Grid
		$db->setQuery('DELETE FROM  #__jgrid_columngrid
			                  WHERE grid_id = '.$grid_id);
		$db->query();

		// delete the images in grid
		delete_images('G',
		               $grid_id,
		              '',
                      '',
                      '');

		// delete references in jgrid_images
		$db->setQuery('DELETE FROM  #__jgrid_images
			                  WHERE grid_id = '.$grid_id);
		$db->query();


		// delete any references to document
		$query = 'SELECT a.id,
		                 CONCAT_WS("~",b.image_thumb_path,b.tooltip,b.hyper_url,"") AS string_data
		          FROM #__jgrid_columndata a,
		               #__jgrid_images b
		          WHERE SUBSTRING_INDEX(b.hyper_grid_sheet, "-", 1) = "'.$grid_id.'"
		            AND a.document_id = b.document_id
		            AND a.column_id = b.id
		            AND a.row_number = b.row_id';		

		$this->_count = $this->_getListCount( $query );
		
		if($this->_count)
		{
			$this->_result = $this->_getList( $query );
		}
		for($i=0;$i<$this->_count;$i++)
		{
			$query='UPDATE #__jgrid_columndata
		                        SET string_data = "'.$this->_result[$i]->string_data.'"
		                        WHERE id = '.$this->_result[$i]->id;
			$db->setQuery($query);
			$db->query();
		}

		// delete chart data
		$query = '	SELECT id 
					FROM #__jgrid_document_graph 
					WHERE grid_id = '.$grid_id;
		$this->_count = $this->_getListCount( $query );
		
		if($this->_count)
		{
			$chart_delete_id = $this->_getList( $query );
			for($i=0;$i < $this->_count; $i++ )
			{
			  If($chart_delete_id[$i]) {
				// delete Chart category axes config option
				$this->_query = 'DELETE FROM  #__jgrid_chart_category_axes
				    	    WHERE 	chart_id = '. $chart_delete_id[$i]->id;
				$this->_db->setQuery($this->_query);	
				
				// delete Chart Numeric axes config option
				$this->_query = 'DELETE FROM  #__jgrid_chart_numeric_axes
				    	    WHERE 	chart_id = '. $chart_delete_id[$i]->id;
				$this->_db->setQuery($this->_query);	
			
				// delete Chart Numeric axes config option
				$this->_query = 'DELETE FROM  #__jgrid_chart_numeric_axes_fields
				    	    WHERE 	chart_id = '. $chart_delete_id[$i]->id;
				$this->_db->setQuery($this->_query);			
				
				// delete Chart series config opton
				$this->_query = 'DELETE FROM  #__jgrid_chart_series
				    	    WHERE 	chart_id = '. $chart_delete_id[$i]->id;
				$this->_db->setQuery($this->_query);
				
				// delete Chart Legend  config opton
				$this->_query = 'DELETE FROM  #__jgrid_chart_legend
				    	    WHERE 	chart_id = '. $chart_delete_id[$i]->id;
				$this->_db->setQuery($this->_query);
				
				// delete Chart Legend  config opton
				$this->_query = 'DELETE FROM  #__jgrid_chart_legend
				    	    WHERE 	chart_id = '. $chart_delete_id[$i]->id;
				$this->_db->setQuery($this->_query);
							
				// Finally deleting from docuyment graph
				$this->_query = 'DELETE FROM  #__jgrid_document_graph   
				    	    WHERE 	grid_id  = '.$grid_id;
				$this->_db->setQuery($this->_query);
				
				//END of Deleting CHART setting	
			 }		
			}

			// delete sql data for grid
			$this->_query = 'DELETE FROM  #__jgrid_custom_select_query   
				    	    	WHERE 	grid_id  = '.$grid_id;
			$this->_db->setQuery($this->_query);
			
			$this->_query = 'DELETE FROM  #__jgrid_select_custom_criteria   
				    	    	WHERE 	grid_id  = '.$grid_id;
			$this->_db->setQuery($this->_query);
			
			$this->_query = 'DELETE FROM  #__jgrid_select_join_criteria  
				    	    	WHERE 	grid_id  = '.$grid_id;
			$this->_db->setQuery($this->_query);

			$this->_query = 'DELETE FROM  #___jgrid_select_query  
				    	    	WHERE 	grid_id  = '.$grid_id;
			$this->_db->setQuery($this->_query);

			$this->_query = 'DELETE FROM  #___jgrid_select_sheet_values  
				    	    	WHERE 	grid_id  = '.$grid_id;
			$this->_db->setQuery($this->_query);
						
			// delete document summary detail
			$this->_query = 'DELETE FROM  #__jgrid_document_summary_detail  
				    	    	WHERE 	grid_id  = '.$grid_id;
			$this->_db->setQuery($this->_query);
			
		}

		// delete sql data

		// delete the grid
		$db->setQuery('DELETE FROM  #__jgrid_grids
			                  WHERE id = '.$grid_id); 
		if($db->query())return true;
		else return false;
}

	/**
	 * Moves grid order in  "Data Grid Settings" grid
	 * @return integer result true if grid moved or false if move failed
	 */
	function moveGrid()
	{
		return moveGrid('#__jgrid_grids',
		JRequest::getVar('number_of_records','','','INTEGER'),
		JRequest::getVar('new_above_record_id','','','INTEGER'),
		JRequest::getVar('new_record_below_id','','','INTEGER'),
		JRequest::getVar('first_record_id','','','INTEGER'),
		JRequest::getVar('last_record_id','','','INTEGER'));
	}

	/**
	 * Retrieves the grid columns assisgned to the grid data for GroupByCombo
	 * @access public
	 * @return array of result count, Array of objects containing the data from the database or false if not grids found
	 */
	function jgrid_application_name_combo()
	{
		$query = 'SELECT id,
		                 grid_application_name                 
	              FROM  #__jgrid_applications';
		$this->_count = $this->_getListCount( $query );
		$this->_result = $this->_getList( $query );
		return array($this->_count,$this->_result);
	}

	/**
	 * Retrieves the detailed pipup form "Data Grid Detailed Settings" data popup window
	 * @return array associative array containing the "Data Grid Settings" grid rows or false if no grids found
	 */
	function loadGridSettings()
	{
		$db =JFactory::getDBO();
		$this->_db->setQuery('SELECT id,
			                             grid_reference_id, 
			                             grid_application_name, 
			                             ordering, 
			                             renderto, 
			                             title, 
			                             frame, 
			                             height, 
			                             width, 
			                             stripe_rows,
			                             print,
			                             number_width,
		                                 number_header,
			                             enableRowEditor,
			                             enable_row_numbers,
			                             enableColumnMove,
			                             enableColumnResize,
			                             columnLines, 
			                             enableGroupBy, 
			                             groupByField,
			                             groupDir,
			                             showGroupName,
			                             hideGroupedColumn,
			                             startCollapsed,
			                             enableSortBy, 
			                             sortByField, 
			                             sortByDirection, 
			                             enable_paging, 
			                             paging_records,
			                             tabtip,
			                             cls,
                                   		 ctCls,
                                   		 enableGroupBySummary 
	                              FROM  #__jgrid_grids
	                              WHERE id = '.JRequest::getVar('grid_id','','','INTEGER'));
		$this->_result = $this->_db->loadAssoc();
		if($this->_result) return $this->_result;
		else return false;
	}

	/**
	 * Updates the detailed popup form  "Data Grid Settings" grid row being edited in the  "Data Grid Settings" grid
	 * @return array return the data that was just updated to the grid or false if grid row not updated.
	 */
	function submitGridSettings()
	{
		$db =JFactory::getDBO();


		// If enableGroupBy make sure GroupByField and SortByField are set, if not then set them to first field returned from column list
		if(JRequest::getVar('enableGroupBy','','','INTEGER')!=0)
		{
			if(JRequest::getVar('groupByField','','','STRING')=='Select a Field...')
			{
				$this->_db->setQuery($this->getGridColumnsQuery(JRequest::getVar('grid_id','','','STRING'),'groupByField'));
				$groupField = $this->_db->loadAssoc();
				
			}
			if(JRequest::getVar('sortByField','','','STRING')=='Select a Field...')
			{
				$this->_db->setQuery($this->getGridColumnsQuery(JRequest::getVar('grid_id','','','STRING'),'sortByField'));
				$sortField = $this->_db->loadAssoc();
			}
			if(class_exists('Jinput')) {
				$input = new Jinput;
				if($groupField) $jinput->set('groupByField',$groupField['groupByField']);
				if($sortField) $jinput->set('sortByField',$sortField ['sortByField']);		
			}
			else
			{
				if($groupField) JRequest::setVar('groupByField', $groupField['groupByField']);
				if($sortField) JRequest::setVar('sortByField', $sortField['sortByField']);
			}
			
		}

		$this->_db->setQuery('UPDATE  #__jgrid_grids
			                  SET  frame='.(JRequest::getVar('frame','','','STRING')? '1' : '0').',			            
			                       stripe_rows='.(JRequest::getVar('stripe_rows','','','STRING')? '1' : '0').',
			                       print='.(JRequest::getVar('print','','','STRING')? '1' : '0').',
			                       number_width="'.JRequest::getVar('number_width','','','STRING').'",
			                       number_header="'.JRequest::getVar('number_header','','','STRING').'",
			                       enableRowEditor='.(JRequest::getVar('enableRowEditor','','','STRING')? '1' : '0').',
			                       enable_row_numbers='.(JRequest::getVar('enable_row_numbers','','','STRING')? '1' : '0').',
			                       enableColumnMove='.(JRequest::getVar('enableColumnMove','','','STRING')? '1' : '0').',
			                       enableColumnResize='.(JRequest::getVar('enableColumnResize','','','STRING')? '1' : '0').',
			                       columnLines='.(JRequest::getVar('columnLines','','','STRING')? '1' : '0').',
			                       enableGroupBy='.JRequest::getVar('enableGroupBy','','','INTEGER').',	                       
			                       enableGroupBySummary='.JRequest::getVar('enableGroupBySummary','','','INTEGER').',
			                       groupByField="'.JRequest::getVar('groupByField','','','STRING').'",
			                       groupDir="'.JRequest::getVar('groupDir','','','STRING').'",
			                       showGroupName='.(JRequest::getVar('showGroupName','','','STRING')? '1' : '0').',
			                       hideGroupedColumn='.(JRequest::getVar('hideGroupedColumn','','','STRING')? '1' : '0').',
			                       startCollapsed='.(JRequest::getVar('startCollapsed','','','STRING')? '1' : '0').',		                       
			                       enableSortBy='.JRequest::getVar('enableSortBy','','','INTEGER').',
			                       sortByField="'.JRequest::getVar('sortByField','','','STRING').'",
			                       sortByDirection="'.JRequest::getVar('sortByDirection','','','STRING').'",
			                       enable_paging='.(JRequest::getVar('enable_paging','','','STRING')? '1' : '0').',
			                       paging_records="'.JRequest::getVar('paging_records','','','STRING').'",
			                       tabtip="'.JRequest::getVar('tabtip','','','STRING').'",
			                       cls="'.JRequest::getVar('cls','','','STRING').'",
			                       ctCls="'.JRequest::getVar('ctCls','','','STRING').'"			                       
	                          WHERE id = '.JRequest::getVar('grid_id','','','STRING')); 
		if($this->_db->query())return JRequest::get('post');
		else return false;
	}

	/**
	 * Retrieves the grid columns assisgned to the grid data for GroupByCombo
	 * @access public
	 * @return array of result count, Array of objects containing the data from the database or false if not grids found
	 */
	function gridColumnsGroupByComboList()
	{
		$query = $this->getGridColumnsQuery(JRequest::getVar('selected_grid_id','','','STRING'),'groupByField');
		$this->_count = $this->_getListCount( $query );
		$this->_result = $this->_getList( $query );
		return array($this->_count,$this->_result);
	}

	/**
	 * Retrieves the grid columns assisgned to the grid data for sortByCombo
	 * @access public
	 * @return array of result count, Array of objects containing the data from the database or false if not grids found
	 */
	function gridColumnsSortByComboList()
	{
		$query = $this->getGridColumnsQuery(JRequest::getVar('selected_grid_id','','','STRING'),'sortByField');
		$this->_count = $this->_getListCount( $query );
		$this->_result = $this->_getList( $query );
		return array($this->_count,$this->_result);
	}
	
	/**
	 * Change JGRID THEME
	 * @return true if success false if fail
	 */
	function change_theme()
	{
		$db =JFactory::getDBO();
		$theme_id = JRequest::getVar('theme','','','STRING');
		$this->_query='UPDATE #__jgrid_applications		                      
		               SET theme = '.$theme_id.'
		               WHERE grid_application_name = "'.JRequest::getVar('application_name','','','STRING').'"';						               	
		$db->setQuery($this->_query);
		$result = $db->query();
		return ($result);
	}

}


