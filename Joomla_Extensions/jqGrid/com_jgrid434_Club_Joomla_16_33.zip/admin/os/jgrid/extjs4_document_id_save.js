// save extjs document_id prior to resetting mootools document_id then resetting extjs document_id after page load
Ext.documentID = document.id;
// reset to mootools document_id to lead page
document.id = MOOTOOLS_DOCUMENT_ID_VALUE;
