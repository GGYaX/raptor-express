<?php
/**
 * Jgrid_roles Controller in Joomla/Administrator/Components/controllers
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_roles controller
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid administrator "Manager User Access" screens
 * to "Manage User Access" rights
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class JgridsControllerJgrid_roles extends JgridsController
{

	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The pointer to the joomla model to be accesses
	 * @var array
	 */
	var $_model=null;

	function read()
	{
		// delay to allow the list boxes to populate first
		sleep(1);
		$this->_model = $this->getModel('jgrid_roles');
		list($this->_result_count,$this->_result) = $this->_model->get_roles_data();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}



	/**
	 * Updates the Role Name being edited in the  "Manager User Roles" grid
	 * @return integer true if update successful or false if update failed.
	 */
	function update()
	{
		$this->_model = $this->getModel('jgrid_roles');
		if($this->_model->update_rolename())Echo '{success:true}';
		else Echo '{success:false}';
	}

	/**
	 * Creates new Role Name in the "Manager User Roles" grid
	 * @var array $row_data array of objects sent from the "Manager User Access" grid containing the values to be updated in the database
	 * @return string json encoded string containing the new Role Name to the "Manage User Roles" grid row or false if rule not created.
	 */
	function create()
	{
		$this->_model = $this->getModel('jgrid_roles');
		$this->_result = $this->_model->create_rolename();
		if($this->_result==true)Echo '{success:true,results:"1",rows: '. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Deletes Role Name in the "Manager User Roles" grid
	 * @return integer result true if rule deleted or false delete failed
	 */
	function destroy()
	{
		$this->_model = $this->getModel('jgrid_roles');
		if($this->_model->destroy_rolename()) Echo '{success:true}';
		else Echo '{success:false}';
	}

}