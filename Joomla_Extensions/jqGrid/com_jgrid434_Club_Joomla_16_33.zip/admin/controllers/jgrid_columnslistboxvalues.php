<?php
/**
 * Jgrid_columns Controller in Joomla/Administrator/Components/controllers
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );


/**
 * Jgrid_columns controller
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid administrator "Column Settings" screen
 * to "Grid Column Settings"
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class JgridsControllerjgrid_ColumnsListBoxValues extends JgridsController
{

	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The pointer to the joomla model to be accesses
	 * @var array
	 */
	var $_model=null;

	/**
	 * Retrieves the "Column Settings" data
	 * @return string json string containing the "Column Settings" grid rows or false if no row returned
	 */
	function read_listBoxValues()
	{
		$this->_model = $this->getModel('jgrid_ColumnsListBoxValues');
		list($this->_result_count,$this->_result) = $this->_model->read_listBoxValues();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Updates the   "Column Settings" data being edited in the  "Column Settings" grid
	 * @return integer return true if row updated or false if update failed.
	 */
	function update_listBoxValues()
	{
		$this->model = $this->getModel('jgrid_ColumnsListBoxValues');
		if($this->model->update_listBoxValues()) Echo '{success:true}';
		else Echo '{success:false}';
	}

	/**
	 * Creates List of Valid column values for "List Box type Clumns" in the "Columns Setting" grid
	 * @return integer result true if value created or false if create failed
	 */
	function create_listBoxValues()
	{
		$this->model = $this->getModel('jgrid_ColumnsListBoxValues');
		$this->_result = $this->model->create_listBoxValues();
		if($this->_result) Echo '{success:true,results:"1",rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Deletes column record (row) in the "Columns Setting" grid
	 * @return integer result true if column removed or false if remove failed
	 */
	function destroy_listBoxValues()
	{
		$this->model = $this->getModel('jgrid_ColumnsListBoxValues');
		if($this->model->destroy_listBoxValues())Echo '{success:true}';
		else Echo '{success:false}';
	}
	
}