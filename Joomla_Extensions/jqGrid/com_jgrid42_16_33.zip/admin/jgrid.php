<?php
/**
 * Jgrid Controller in Joomla/Administrator/Components
 *
 * @version	    $id$ V2.4
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2011 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

// Require the base controller

require_once( JPATH_COMPONENT.'/controller.php' );


$controller = JRequest::getWord('controller');

if($controller == 'controller'  ||
$controller == 'jgrid_columngrid'  ||
$controller == 'jgrid_columns' ||
$controller == 'jgrid_columnslistboxvalues' ||
$controller == 'jgrid_roles'  ||
$controller == 'jgrid_security' ||
$controller == 'jgrid_sqlselect' ||
$controller == 'jgrid_users')
{
	$path = JPATH_COMPONENT.'/controllers/'.$controller.'.php';
	if (file_exists($path)) {
		require_once $path;
	} else {
		$controller = '';
	}
}


// Create the controller
$classname	= 'JgridsController'.$controller;
$controller	= new $classname( );

// Perform the Request task
$controller->execute( JRequest::getVar( 'task' ) );

// Redirect if set by the controller
$controller->redirect();
