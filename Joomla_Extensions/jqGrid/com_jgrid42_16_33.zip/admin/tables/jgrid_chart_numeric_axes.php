<?php
/**
 * Jgrid_chart_numeric_axes Table  in Joomla/Components/Tables
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_chart_numeric_axes Table Class
 *
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class TableJgrid_chart_numeric_axes extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $naxes_id = null;
	
	/**
	 * @var int
	 */
	var $chart_id = null;
	
	/**
	 * @var string
	 */
	var $title = null;	
		
	/**
	 * @var string
	 */
	var $grid = null;
	
		/**
	 * @var string
	 */
	var $position = null;
	
	/**
	 * @var string
	 */
	var $fields = null;
	
	/**
	 * @var int
	 */
	var $minimum = null;

	/**
	 * @var int
	 */
	var $minorTickSteps = null;

	/**
	 * @var int
	 */
	var $majorTickSteps = null;
	
	/**
	 * @var int
	 */
	var $width = null;


	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableJgrid_chart_numeric_axes(& $db) {
		parent::__construct('#__jgrid_chart_numeric_axes
		', 'id', $db);
	}
}