<?php
/**
 * Jgrid_select_join_criteria Table  in Joomla/Components/Tables
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_select_join_criteria Table Class
 *
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class TableJgrid_select_join_criteria extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var string
	 */
	var $id = null;
	
	/**
	 * @var int
	 */
	var $grid_id = null;
	
	/**
	 * @var int
	 */
	var $criteria_type_id = null;	
	
	/**
	 * @var string
	 */
	var $database_sql_name_id = null;	
	
	/**
	 * @var string
	 */
	var $table_sql_name_id = null;

	/**
	 * @var string
	 */
	var $column_sql_name_id = null;
	
		/**
	 * @var string
	 */
	var $column_sql_name_id = null;

	/**
	 * @var string
	 */
	var $jdatabase_sql_name_id = null;

	/**
	 * @var string
	 */
	var $jtable_sql_name_id = null;

	/**
	 * @var string
	 */
	var $jcolumn_sql_name_id = null;

	/**
	 * @var string
	 */
	var $select_wildcard_id = null;
	
	/**
	 * @var string
	 */
	var $criteria_value  = null;

	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableJgrid_select_join_criteria(& $db) {
		parent::__construct('#__jgrid_select_join_criteria
		', 'id', $db);
	}
}