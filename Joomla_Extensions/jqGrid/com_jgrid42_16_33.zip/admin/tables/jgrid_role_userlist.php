<?php
/**
 * Jgrid_roles Table  in Joomla/Components/Tables
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_roles Table Class
 *
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class TableJgrid_role_userlist extends JTable
{
	/**
	 * Primary Key
	 *
	 * @var int
	 */
	var $id = null;

	/**
	 * @var int
	 */
	var $userid = null;

	/**
	 * @var int
	 */
	var $role_id = null;

	/**
	 * @var int
	 */
	var $userid_assigning_role = null;

	/**
	 * @var timestamp
	 */
	var $last_updated = null;


	/**
	 * Constructor
	 *
	 * @param object Database connector object
	 */
	function TableJgrid_role_userlist(& $db) {
		parent::__construct('#__jgrid_role_userlist
		', 'id', $db);
	}
}