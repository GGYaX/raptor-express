<?php
 /*
 *  JGridToolbar0.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');




echo 'Ext.define("JGrid.view.JGridToolbar0.php", {
	extend : "Ext.toolbar.Toolbar",
	requires : [ "JGrid.view.JGridHelp0"],	
	alias : "widget.JGridToolbar0",
	id : "JGridToolbar0",
	items : [{
		text: "'. JText::_("ADD_NEW_GRID").'",
		icon: "components/com_jgrid/os/jgrid/icons/table_add.png",
		cls: "x-btn-text-icon",
		tooltip: "'. JText::_("ADD_NEW_GRID_TOOLTIP").'",
      	handler: function () {
			var newrowlocation = JGrid.store[0].getCount();
           	var jgrid_newrowcolumns0 = {
            	id: "",
              	grid_application_name: "com_jgrid",
               	grid_reference_id: "grid-999",
              	renderto: "com_jgrid-renderTo",
               	title: "name_your_title",
               	frame: "1000",
              	height: 250,
               	width: 520,
              	ordering: newrowlocation+1,
               	enableColumnMove: "false",
               	stripe_rows: "false",
               	enableColumnMove: "false",
              	enable_paging: "false",
              	paging_records: 30
         	};
         	if(newrowlocation==0) var last_record_id=0;
          	else var last_record_id=JGrid.store[0].data.items[newrowlocation-1].data.id;
         	JGrid.proxy[0].api.create = "index.php?option=com_jgrid&task=create&format=ajax&last_record_id="+last_record_id;
         	JGrid.store[0].insert(newrowlocation, jgrid_newrowcolumns0);
         	JGrid.currenteditgrid = Ext.ComponentMgr.get("grids_data");
          	JGrid.currenteditgrid.getView().refresh();
   		}
	},
	{
		text: "'. JText::_("ADD_GRID_COLUMNS").'",
		icon: "components/com_jgrid/os/jgrid/icons/table_add.png",
		cls: "x-btn-text-icon",
     	tooltip: "'. JText::_("ADD_GRID_COLUMNS_TOOLTIP").'",
        handler: grid_columns_menu
	},
	{
		text: "'. JText::_("GRID_SETTINGS").'",
       	icon: "components/com_jgrid/os/jgrid/icons/table_add.png",
      	cls: "x-btn-text-icon",
       	tooltip: "'. JText::_("GRID_SETTINGS_TOOLTIP").'",
       	handler: function () {
			JGrid.currenteditgrid = Ext.ComponentMgr.get("grids_data");
    		var sm = JGrid.currenteditgrid.getSelectionModel();
    		if (sm.hasSelection()) {
        		var sel = sm.getSelection();
        		JGrid.selectedgridid = sel[0].get("id");
        		JGrid.combo_store[1].removeAll();
        		JGrid.combo_store[1].load({
            		params: {
                		selected_grid_id: JGrid.selectedgridid
            		}
        		});
	        	JGrid.combo_store[2].removeAll();
	        	JGrid.combo_store[2].load({
	            	params: {
	                	selected_grid_id: JGrid.selectedgridid
	            	}
	        	});
        		JGrid.gridname = sel[0].get("title");
        		if(!JGrid.JGridGridSettings)
    			{
    				JGrid.JGridGridSettings = Ext.create("JGrid.view.JGridGridSettings");
    			}
    			JGrid.JGridGridSettings.show();
     		} 
     		else //if sel
    		{
				Ext.MessageBox.alert("'. JText::_("PLEASE").'", "'. JText::_("SELECT_GRID_FIRST_TO_MODIFY_SETTINGS").'");           
  				return;
    		}
    		Ext.ComponentMgr.get("formpanel2").getForm().load({
        		url: "index.php?option=com_jgrid&task=loadgridsettings&format=ajax&grid_id=" + JGrid.selectedgridid + "",
        		method: "GET",
      			success: function (form, action) { // Optional function
      				combo1.setValue(action.result.data.groupByField);
      				combo2.setValue(action.result.data.sortByField);
            		Ext.getCmp("formpanel2").getForm().setValues({
                		enableSortBy : {  // it is a field ConfigID
                   			enableSortBy : action.result.data.enableSortBy  // here is a GroupName
                		}
            		});
            		Ext.getCmp("formpanel2").getForm().setValues({
                		enableGroupBy : {  // it is a field ConfigID
                   			enableGroupBy : action.result.data.enableGroupBy  // here is a GroupName
                		}
            		});
                    // submit.enable();
       		},
        		failure: function (form, action) {
            		Ext.MessageBox.alert("'. JText::_("MESSAGE").'", "'. JText::_("GRID_SETTINGS_DATA_NOT_LOADED._PLEASE_RETRY").'");         
				}

			});	
		}
  	},
 	{
    	text: "'. JText::_("REMOVE_GRID").'",
      	icon: "components/com_jgrid/os/jgrid/icons/table_delete.png",
       	cls: "x-btn-text-icon",
       	tooltip: "'. JText::_("REMOVE_GRID_TOOLTIP").'",
       	handler: function () {
        	var pgrid = Ext.ComponentMgr.get("grids_data");
           	var sm = pgrid.getSelectionModel();
           	var sel = sm.getSelection();
           	if (sm.hasSelection()) {
                var gridname = sel[0].get("title");
            	Ext.Msg.show({
                	title: "'. JText::_("REMOVE_GRID").'",
                   	buttons: Ext.MessageBox.YESNOCANCEL,
                 	msg: " "+gridname+"?",
                  	fn: function (btn) {
                    	if (btn == "yes") {           
                        	//pgrid.stopEditing();
                          	var sels = sm.getSelection();
                          	// Multiple row delete
                          	for(var i = 0, r; r = sels[i]; i++){             
                           		pgrid.getStore().remove(r);
                          	}              
                      	}
             		}
          		})
       		} else Ext.Msg.alert("'. JText::_("PLEASE").'", "'. JText::_("SELECT_GRID_FIRST_TO_MODIFY_SETTINGS").'");
   		}
 	},
  	{    
		id: "user_help_grids",                   
      	text: "<b>'. JText::_("HELP").'</b>",
     	icon: "components/com_jgrid/os/jgrid/icons/help.png",
       	tooltip: "'. JText::_("INSTRUCTIONS_DESCRIBING_GRID_OPERATION").'",
    	handler: function () {
    		if(!JGrid.help[0])
    		{
    			JGrid.help[0] = Ext.create("JGrid.view.JGridHelp0");
    		}
    		//JGrid.help.items.items[0].src = "'.JURI::base().'components/com_jgrid/help/en-GB/jgrid_admin_columns_helpfile.html";                            
			// RMS Can not figure out how to show change above...
    		JGrid.help[0].show();  
      	}          
  	},
  	combo102]
});';
?>

