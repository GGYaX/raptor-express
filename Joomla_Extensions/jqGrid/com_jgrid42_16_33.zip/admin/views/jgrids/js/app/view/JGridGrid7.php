<?php
 /*
 *  JGridGrid7.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');

echo 'Ext.define("JGrid.view.JGridGrid7", {
	extend : "Ext.grid.Panel",
	alias : "widget.JGridGrid7",
	requires : [ "JGrid.view.JGridToolbar7", "JGrid.store.JGridStore7"  ],
 	id: "jgrid_roles",
   	title: "'. JText::_("MANAGE_GRID_ROLES").'",
  	xtype: "editorgrid",
   	tabTip: "'. JText::_("MANAGE_GRID_ROLES_TABTIP").'",
   	height: 250,
   	width: 750,
 	enableColumnMove: false,
	store: JGrid.store[7],
 	columns: JGrid.columns[7],
 	//selModel: Ext.create("Ext.selection.RowModel", { singleSelect: true, selectFirstRow: true }),
 	selModel: Ext.create("Ext.selection.RowModel", { mode: "MULTI"}),    	
	tbar: {xtype: "JGridToolbar7"},		    
	frame: true,
	stripeRows: true,
	enableColumnResize: true,
	columnLines: true,
	beforeRender: function() {
      	JGrid.grids[7] = Ext.ComponentMgr.get("jgrid_roles");
    },
	plugins: [	Ext.create("Ext.grid.plugin.RowEditing", {
    				saveText: "Update",
	  				errorSummary: false,
	  				listeners: {
						validateedit: function(e){
        					e.value = Ext.util.Format.stripTags(e.value);
        				}
      				}
	  			})
	],
	listeners: {

        activate: function ( panel, layout, opts)
        {	
        	combo71 = Ext.ComponentMgr.get("combo71");
        	combo73 = Ext.ComponentMgr.get("combo73");
        },
   		beforerender: function () {';
//                    JGrid.combo_store[71].load();
//                    JGrid.combo_store[73].load();
      		echo 'JGrid.store[8].load();
     	}
 	},
 	keys: [{
		key: 46,
		fn: function () {
			var pgrid = Ext.ComponentMgr.get("jgrid_roles");
			var sm = pgrid.getSelectionModel();
			var sel = sm.getSelected();
			if (sm.hasSelection()) {
				Ext.Msg.show({
              		title: "'. JText::_("REMOVE_USER_FROM_ROLE").'",
                	buttons: Ext.MessageBox.YESNOCANCEL,
                	msg: "'. JText::_("REMOVE_USER_FROM_ROLE_QUESTION").'",
                   	fn: function (btn) {
                    	if (btn == "yes") {           
                        	//pgrid.stopEditing();
                           	var sels = sm.getSelection();
                           	// Multiple row delete
                           	for(var i = 0, r; r = sels[i]; i++){             
                            	pgrid.getStore().remove(r);
                          	}              
	                  	}
	            	}
       			})
           	} else Ext.Msg.alert("'. JText::_("PLEASE").'", "'. JText::_("SELECT_GRID_FIRST_TO_MODIFY_SETTINGS").'");
     	},
     	ctrl: false,
     	stopEvent: true
  	}] 	
});
// load initital store and grid
		//JGrid.store[7].load();
';
?>


