<?php
 /*
 *  JGridModifyListsWin.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>  
Ext.define("JGrid.view.JGridmodifyListsWin", {
	extend : "Ext.window.Window",
	requires: "Ext.picker.Color",
	alias : "widget.JGridmodifyListsWin",
	id: "JGridmodifyListsWin",
  	title: '',
   	renderTo: 'editcell',
   	layout: 'fit',
    autoHeight: true,
  	width: 280,
   	//height: 440,
   	closeAction: 'hide',
   //	x: 35,
	y: 100,       
	items:  [
	{
		id: "listboxvalues",
<?php 
  		echo 'title: "'. JText::_("LIST_BOX_VALUES").'",  
      	tooltip: "'. JText::_("LIST_BOX_VALUES_TOOLTIP").'",';
?>            
       	xtype: "editorgrid",
       	layout: 'fit',
    	autoHeight: true,
       	width: 270,
       //	height: 410,
      	enableTabScroll:true,
      	store: JGrid.store[12],
   		columns: JGrid.columns[12],
  		viewConfig: {
       		getRowClass: function ( row, index, rowParams, store) { 
           		color_code = row.get('listboxvaluerowcolor');
              	if(color_code=="")
             	{
              		return "";
             	}
               	else
              	{
               		var current_color_array=color_code.split("~",3);
                    cssname = 'css'+current_color_array[0];
                    if(!Ext.util.CSS.getRule(cssname))
                    {
                   		var cssDef = '.' + cssname + ' .x-grid-cell{ background-color: #' + current_color_array[0] + '; }';
                  		Ext.util.CSS.createStyleSheet(cssDef);
                    	if(current_color_array[1]!=''||current_color_array[2]!='')
                      	{
                        	var selCssDef= '.x-grid-row-selected.' + cssname + ' { background-color: #' + current_color_array[2] + ' !important; color: #' + current_color_array[1] +'; }';                  
                        	Ext.util.CSS.createStyleSheet(selCssDef);
                      	}
                    }
                   // return "green-row";   
                    return cssname;
               	}
			},
          	markDirty: false
		},
       	enableColumnMove: false,
       	listeners: {
			afteredit: function (e) {
          		JGrid.store[12].save();
          	},
                failure: function (response, options) {
<?php 
                    echo'window.alert("'. JText::_("DATA_WAS_NOT_SAVED_TO_DATABASE").'");';
?>                   
                },
                success: function (response, options) {
                    var server_response = Ext.decode(response.responseText);
                 // window.alert(response.responseText);
                 JGrid.store[12].commitChanges();
                 e.grid.getView().refresh();
                },
                
                scope: this

            },
          	sm: new Ext.selection.RowModel({
                    singleSelect: false
            }),
            tbar: {
              xtype: 'container',
              layout: 'anchor',
              defaults: {anchor: '0'},
              defaultType: 'toolbar',
              items: [{
                items: [{
<?php
                echo 'text: "'. JText::_("ADD").'",
                tooltip: "'. JText::_("ADD_NEW_LIST_BOX_VALUE_TOOLTIP").'",';
?>               
                icon: "components/com_jgrid/os/jgrid/icons/table_add.png",
                cls: "x-btn-text-icon",
                handler: function () { 
                        var selectedColumn=Ext.ComponentMgr.get("columns_data").getSelectionModel().getSelection();
                        //var newrowlocation = JGrid.store[12].getCount();
                        var newrowlocation = 0;
                        var jgrid_newrowcolumns12 = {
                            id: "",
                            listboxvalues: "",
                            listboxvaluerowcolor: ""
                        };
                        JGrid.proxy[12].api.create = "index.php?option=com_jgrid&controller=jgrid_columnslistboxvalues&task=create_listboxvalues&format=ajax&column_id="+selectedColumn[0].get('id');   
                        JGrid.store[12].insert(newrowlocation, jgrid_newrowcolumns12);
                        //formpanel12.getView().refresh();                       
                }
            },
            {
<?php            
                echo 'text: "'. JText::_("REMOVE").'",
                tooltip: "'. JText::_("REMOVE_VALUE_TOOLTIP").'",';            
?>  
                icon: "components/com_jgrid/os/jgrid/icons/table_delete.png",
                cls: "x-btn-text-icon",
                handler: function () {
                    var sm = Ext.getCmp('listboxvalues').getSelectionModel();
                    if (sm.hasSelection()) {
                        Ext.Msg.show({
                            title: "Remove Row",
                            buttons: Ext.MessageBox.YESNOCANCEL,
<?php 
               //             echo 'msg: "Remove Selected Column:"+JGrid.gridname+"?",';
                           echo 'msg: "'. JText::_("REMOVE_VALUE").'",';
 ?>                          
                            fn: function (btn) {
                                if (btn == "yes") {
                                  var sels=Ext.getCmp("listboxvalues").getSelectionModel().getSelection();
                                  // Multiple row delete
                                  for(var i = 0; i < sels.length; i++){ 
                                    r = sels[i];            
                                    Ext.getCmp("listboxvalues").getStore().remove(r);
                                  }
                                }
                            }
                        })
                    }
                }
            },
            {
<?php            
                echo 'text: "'. JText::_("COLOR").'",
                tooltip: "'. JText::_("CHANGE_COLOR_TOOLTIP").'",';            
?>  
                icon: "components/com_jgrid/os/jgrid/icons/color_swatch.png",
                cls: "x-btn-text-icon",
                renderTo: 'editcell',
                menu: colorMenu,
                handler: function(cm, color){
                  if (!Ext.ComponentMgr.get("listboxvalues").getSelectionModel().hasSelection()) {
<?php                
                    echo 'Ext.ComponentMgr.get("color_menu").hide();
                    Ext.Msg.alert("'. JText::_("PLEASE").'", "'. JText::_("SELECT_A_LIST_VALUE_BEFORE_COLOR_SELECTION").'");';
?>                    
                    return;
                  }
                  JGrid.color_menu_type=1;
                }  
            }]
              },
              {
                items: [
            {
<?php            
                echo 'text: "'. JText::_("SELECTION_COLOR").'",
                tooltip: "'. JText::_("CHANGE_SELECTION_COLOR_TOOLTIP").'",';            
?>  
                icon: "components/com_jgrid/os/jgrid/icons/color_swatch.png",
                cls: "x-btn-text-icon",
                renderTo: 'editcell',
                menu: colorMenu,
                handler: function(cm, color){
                  if (!Ext.ComponentMgr.get("listboxvalues").getSelectionModel().hasSelection()) {
<?php                
                    echo 'Ext.ComponentMgr.get("color_menu").hide();
                    Ext.Msg.alert("'. JText::_("PLEASE").'", "'. JText::_("SELECT_A_LIST_VALUE_BEFORE_COLOR_SELECTION").'");';
?>                    
                    return;
                  }
                  JGrid.color_menu_type=2;
               		} 
            	},
            	{
<?php            
	                echo 'text: "'. JText::_("SELECTION_BKGND_COLOR").'",
	                tooltip: "'. JText::_("CHANGE_SELECTION_BACKGROUND_COLOR_TOOLTIP").'",';            
?>  
	                icon: "components/com_jgrid/os/jgrid/icons/color_swatch.png",
	                cls: "x-btn-text-icon",
	                renderTo: 'editcell',
	                menu: colorMenu,
	                handler: function(cm, color){
	                  if (!Ext.ComponentMgr.get("listboxvalues").getSelectionModel().hasSelection()) {
<?php                
	                    echo 'Ext.ComponentMgr.get("color_menu").hide();
	                    Ext.Msg.alert("'. JText::_("PLEASE").'", "'. JText::_("SELECT_A_LIST_VALUE_BEFORE_COLOR_SELECTION").'");';
?>                    
	                    return;
	                  }
	                  JGrid.color_menu_type=3;
	                }  
            	}]
    		}]
		}
	}]
});
     

     
