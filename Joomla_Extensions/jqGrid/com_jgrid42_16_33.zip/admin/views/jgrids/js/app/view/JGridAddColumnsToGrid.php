<?php
 /*
 *  JGridAddColumnsToGrid.php  in joomla/Administrator/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
 
Ext.define("JGrid.view.JGridAddColumnsToGrid", {
	extend : "Ext.panel.Panel",
	alias : "widget.JGridAddColumnsToGrid",
	requires : [ "JGrid.view.AddColumnToolbar", "JGrid.store.JGridStore2"  ],
	id: "JGridAddColumnsToGrid",
 <?php
           echo 'title: "'.JText::_("ADD_COLUMNS_TO_SELECTED_GRID").'",
           tooltip: "'. JText::_("ADD_COLUMNS_TO_SELECTED_GRID_TOOLTIP").'",';
  ?>  
	renderTo: 'editcell',
	closeAction: 'hide',
  	width: 762,
   	height: 450,
  // 	x: 35,
  	y: 100, 
  	plain: true,    
	items:  [
	{
 id: "gridcolumns_data",
<?php 
            echo 'title: "'. JText::_("ADD_COLUMNS_TO_SELECTED_GRID").'"+JGrid.gridname,
            tooltip: "'. JText::_("ADD_COLUMNS_TO_SELECTED_GRID_TOOLTIP").'",           
            xtype: "editorgrid", 
            height: 440,
            width: 750,                 
            enableDragDrop: true,
            tbar: {xtype: "AddColumnToolbar"},        
			viewConfig: {
                  	plugins: {
                  		ddGroup: "grid_columns_data-dd",
                  		ptype: "gridviewdragdrop",
                  		enableDrag: true,
                  		enableDrop: true,
                  		allowCopy: false,
                  		copy: false,                 		
                  	},
                  	listeners: {
                  		drop: function(objThis, dragData, dropData, position) {
                  			dragData.copy = false;              		                      
            				if(dragData.records.length===0) return;
             				if (dropData.index==0)
              				{
               					// ordering at index 0 which is above index 1 shown on drop index
                   				var new_above_record_id=-1;
                   				var new_record_below_id = dropData.data.id;
            				}
               				else if(dropData.index==this.all.elements.length-1)
               				{
               					// At last record of view
               					var new_above_record_id = dropData.data.id;
               					var new_record_below_id=0;
               				}
               				else
               				{ 
               					// Has records above and below
               					if(position == "before")
            					{
            						var new_above_record_id = 0;
               						var new_record_below_id = dropData.data.id;
            					}
            					else
            					{
            						var new_above_record_id = dropData.data.id;
               						var new_record_below_id = 0;
            					}

             				}    
               				Ext.Ajax.request({
               					waitMsg: "'.JText::_("MOVING_COLUMN").'",                                  
           						url: "index.php?option=com_jgrid&task=moveColumn&format=ajax",
             					params: {
				                	grid_id: JGrid.selectedgridid, 
				                  	first_record_id: dragData.records[0].data.id,
				                   	last_record_id: dragData.records[dragData.records.length-1].data.id,
				                   	new_above_record_id: new_above_record_id,
				                   	new_record_below_id: new_record_below_id,                                                       
				                   	number_of_records: dragData.records.length,
				                   	oldIndex: dragData.item.viewIndex,
				                   	newIndex: dropData.index  	
				              	},
				               	method: "POST",
				              	failure: function (response, options) {
				               		Ext.Msg.alert("'.JText::_("COLUMN_WAS_NOT_MOVED_IN_DATABASE").'");                                                                                                            
				            	},
				            	success: function (response, options) {
				               	},
				              	scope: this
			           		});
				       	}
				    }
          	},
            enableColumnMove: false,
            store: JGrid.store[2],
            columns: JGrid.columns[2],
            listeners: {
                afteredit: function (e) {
                    //editor2.stopEditing();
                    JGrid.store[2].save();
                },
                failure: function (response, options) {

                    window.alert("'. JText::_("COLUMN_WAS_NOT_MOVED_IN_DATABASE").'");
                  
                },
                success: function (response, options) {
                    var server_response = Ext.decode(response.responseText);
                 // window.alert(response.responseText);
                    JGrid.store[2].commitChanges();
                    e.grid.getView().refresh();
                },
                scope: this

            },
          	sm: new Ext.selection.RowModel({
                    singleSelect: false
            }),
            keys: [{
                key: 46,
                fn: function () {
                    JGrid.currenteditgrid = Ext.ComponentMgr.get("gridcolumns_data");
                    var sm = JGrid.currenteditgrid.getSelectionModel();
                    if (sm.hasSelection()) {
                        Ext.Msg.show({
                            title: "Remove Row",
                            buttons: Ext.MessageBox.YESNOCANCEL,
                            msg: "' .JText::_("REMOVE_SELECTED_COLUMN_QUESTION"). '",';
?>             
                            fn: function (btn) {
                                if (btn == "yes") {
                                  //JGrid.currenteditgrid.stopEditing();
                                  var sels = sm.getSelection();
                                  // Multiple row delete
                                  for(var i = 0, r; r = sels[i]; i++){             
                                    JGrid.currenteditgrid.getStore().remove(r);
                                  }
                                }
                            }
                        })
                    }
                },
                ctrl: false,
                stopEvent: true
            }]
	}]
});
     

     
