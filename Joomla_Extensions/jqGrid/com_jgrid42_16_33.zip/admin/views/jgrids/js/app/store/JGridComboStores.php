<?php
/*
 *  JGridComboStores.php in joomla/Components/com_jgrid/views/jgrid/js/app/store
 *
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
$db =JFactory::getDBO();
$fversion = $params->get ('fversion');
?>
	


// combo box for groupbyfield in Grid Settings Form
	Ext.define("JGrid.store.JGridCStore1", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel1",   
	model: "JGrid.model.JGridCModel1",
	alias : "widget.JGridCStore1",
	storeId:"JGridCStore1",
	id:"JGridCStore1",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=gridColumnsGroupByComboList&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[1]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    },
    listeners: {
    	beforeload: function(store, operation, eOpts ) {
    		store.proxy.url = "index.php?option=com_jgrid&task=gridColumnsGroupByComboList&selected_grid_id="+JGrid.selectedgridid+"&format=ajax";
    	}
    }
});
JGrid.combo_store[1] = Ext.create("JGrid.store.JGridCStore1");
		 

// combo box for sortbybyfield in Grid Settings Form
	Ext.define("JGrid.store.JGridCStore2", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel2",   
	model: "JGrid.model.JGridCModel2",
	alias : "widget.JGridCStore2",
	storeId:"JGridCStore2",
	id:"JGridCStore2",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=gridColumnsSortByComboList&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[2]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    },
    listeners: {
    	beforeload: function(store, operation, eOpts ) {
    		store.proxy.url = "index.php?option=com_jgrid&task=gridColumnsSortByComboList&selected_grid_id="+JGrid.selectedgridid+"&format=ajax";
    	}
    }
});
JGrid.combo_store[2] = Ext.create("JGrid.store.JGridCStore2");

// create new columns JGrid.columns	data_type
	Ext.define("JGrid.store.JGridCStore11", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel11",   
	model: "JGrid.model.JGridCModel11",
	alias : "widget.JGridCStore11",
	storeId:"JGridCStore11",
	id:"JGridCStore11",
	autoLoad: false,
<?php 	
  	echo' data: [	{"data_type":"T", "Type":"'. JText::_("TEXT").'"},
       				{"data_type":"I", "Type":"'. JText::_("INTEGER").'"},
    				{"data_type":"B", "Type":"'. JText::_("BOOLEAN").'"},
        			{"data_type":"D", "Type":"'. JText::_("DATE").'"},
  					{"data_type":"L", "Type":"'. JText::_("LIST_BOX").'"},
       				{"data_type":"R", "Type":"'. JText::_("UNIQUE_ROW_ID").'"},
    				{"data_type":"P", "Type":"'. JText::_("PICTURE").'"},
    				{"data_type":"U", "Type":"'. JText::_("URL").'"},
    				{"data_type":"E", "Type":"'. JText::_("EMAIL").'"},
    				{"data_type":"F", "Type":"'. JText::_("NUMBER").'"}';
?>
	]//comboData
});
JGrid.combo_store[11] = Ext.create("JGrid.store.JGridCStore11");


// combo boxs for data format validation
	Ext.define("JGrid.store.JGridCStore13", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel13",   
	model: "JGrid.model.JGridCModel13",
	alias : "widget.JGridCStore13",
	storeId:"JGridCStore13",
	id:"JGridCStore13",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=jgrid_valid_format_query&controller=jgrid_columns&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[13]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[13] = Ext.create("JGrid.store.JGridCStore13");
JGrid.combo_store[13].load({
      params: {
          access_type: "0"
      }
});


// combo boxs for criteria operator
	Ext.define("JGrid.store.JGridCStore15", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel15",   
	model: "JGrid.model.JGridCModel15",
	alias : "widget.JGridCStore15",
	storeId:"JGridCStore15",
	id:"JGridCStore15",
	autoLoad: false,
<?php 	
  	echo' data: [	{"criteria_operator_id":"=", "criteria_operator":"="},					
       				{"criteria_operator_id":"!=", "criteria_operator":"!="},
       				{"criteria_operator_id":"<", "criteria_operator":"<"},
       				{"criteria_operator_id":">", "criteria_operator":">"},
       				{"criteria_operator_id":"<=", "criteria_operator":"<="},
    				{"criteria_operator_id":">=", "criteria_operator":">="}';
?>         	
 	]//comboData
});
JGrid.combo_store[15] = Ext.create("JGrid.store.JGridCStore15");


// combo boxs for jgrid_select_wildcards
	Ext.define("JGrid.store.JGridCStore16", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel16",   
	model: "JGrid.model.JGridCModel16",
	alias : "widget.JGridCStore16",
	storeId:"JGridCStore16",
	id:"JGridCStore16",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=jgrid_select_wildcards&controller=jgrid_columngrid&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[16]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[16] = Ext.create("JGrid.store.JGridCStore16");
JGrid.combo_store[16].load(); 

// combo boxs for jgrid_select_criteria_type
	Ext.define("JGrid.store.JGridCStore17", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel17",   
	model: "JGrid.model.JGridCModel17",
	alias : "widget.JGridCStore17",
	storeId:"JGridCStore17",
	id:"JGridCStore17",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=jgrid_select_criteria_type&controller=jgrid_columngrid&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[17]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[17] = Ext.create("JGrid.store.JGridCStore17");
JGrid.combo_store[17].load();


// select from columns to add from combo box not already selected newcolumnlist
	Ext.define("JGrid.store.JGridCStore21", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel21",   
	model: "JGrid.model.JGridCModel21",
	alias : "widget.JGridCStore21",
	storeId:"JGridCStore21",
	id:"JGridCStore21",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=newcolumnlist&controller=jgrid_columngrid&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[21]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[21] = Ext.create("JGrid.store.JGridCStore21");

// combo boxs for SELECT_A_COLOR_PRIORITY
	Ext.define("JGrid.store.JGridCStore22", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel22",   
	model: "JGrid.model.JGridCModel22",
	alias : "widget.JGridCStore22",
	storeId:"JGridCStore22",
	id:"JGridCStore22",
	autoLoad: false,
<?php 	
  	echo' data: [	{"row_color_pressidence":"1", "Color_Priority":"'. JText::_("1").'"},
       				{"row_color_pressidence":"3", "Color_Priority":"'. JText::_("2").'"},
    				{"row_color_pressidence":"3", "Color_Priority":"'. JText::_("3").'"},
        			{"row_color_pressidence":"4", "Color_Priority":"'. JText::_("4").'"},
  					{"row_color_pressidence":"5", "Color_Priority":"'. JText::_("5").'"},
       				{"row_color_pressidence":"6", "Color_Priority":"'. JText::_("6").'"},
    				{"row_color_pressidence":"7", "Color_Priority":"'. JText::_("7").'"},
    				{"row_color_pressidence":"8", "Color_Priority":"'. JText::_("8").'"},
        			{"row_color_pressidence":"9", "Color_Priority":"'. JText::_("9").'"}';
?>
	]//comboData
});
JGrid.combo_store[22] = Ext.create("JGrid.store.JGridCStore22");

// columns combo box database_sql_name for database 
	Ext.define("JGrid.store.JGridCStore23", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel23",   
	model: "JGrid.model.JGridCModel23",
	alias : "widget.JGridCStore23",
	storeId:"JGridCStore23",
	id:"JGridCStore23",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=database_sql_name&controller=jgrid_columngrid&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[23]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    },
    listeners: {
    	beforeload: function(store, operation, eOpts ) {
    	    store.proxy.url = "index.php?option=com_jgrid&task=database_sql_name&controller=jgrid_columngrid&grid_id="+JGrid.selectedgridid+"&format=ajax";
   		}
    }
});
JGrid.combo_store[23] = Ext.create("JGrid.store.JGridCStore23");

// columns combo box table_sql_name for table
	Ext.define("JGrid.store.JGridCStore24", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel24",   
	model: "JGrid.model.JGridCModel24",
	alias : "widget.JGridCStore24",
	storeId:"JGridCStore24",
	id:"JGridCStore24",
	autoLoad: false,
	proxy: {
   		type: "ajax",
<?php   		
   	 	echo 'url: "index.php?option=com_jgrid&task=table_sql_name&controller=jgrid_columngrid&format=ajax",';
    	
?>   	 	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[24]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    },
    listeners: {
    	beforeload: function(store, operation, eOpts ) {
    	    var database_sql_name = JGrid.ceditor.items.items[5].value;
    	    if(!database_sql_name && JGrid.column_selection) database_sql_name = JGrid.column_selection[0].get('database_sql_name_id'); 			
			if(!database_sql_name) database_sql_name = JGrid.joomla_database;	    		
    		if(database_sql_name) store.proxy.url = "index.php?option=com_jgrid&task=table_sql_name&controller=jgrid_columngrid&database_sql_name="+database_sql_name+"&grid_id="+JGrid.selectedgridid+"&format=ajax";
   		}
    }
});
JGrid.combo_store[24] = Ext.create("JGrid.store.JGridCStore24");

// columns  combo box column_sql_name for columns
	Ext.define("JGrid.store.JGridCStore25", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel25",   
	model: "JGrid.model.JGridCModel25",
	alias : "widget.JGridCStore25",
	storeId:"JGridCStore25",
	id:"JGridCStore25",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=column_sql_name&controller=jgrid_columngrid&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[25]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    },
    listeners: {
    	beforeload: function(store, operation, eOpts ) {
    	    var database_sql_name = JGrid.ceditor.items.items[5].value;
    	    var table_sql_name = JGrid.ceditor.items.items[6].value;
    	    if(!database_sql_name && JGrid.column_selection) database_sql_name = JGrid.column_selection[0].get('database_sql_name_id'); 		
			if(!database_sql_name) database_sql_name = JGird.joomla_database;			
			if(!table_sql_name && JGrid.column_selection) table_sql_name = JGrid.column_selection[0].get('table_sql_name_id'); 
    		store.proxy.url = "index.php?option=com_jgrid&task=column_sql_name&controller=jgrid_columngrid&database_sql_name="+database_sql_name+"&table_sql_name="+table_sql_name+"&grid_id="+JGrid.selectedgridid+"&format=ajax";    	
    	}
    }
});

JGrid.combo_store[25] = Ext.create("JGrid.store.JGridCStore25");

// combo boxs for table sql query type
	Ext.define("JGrid.store.JGridCStore26", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel26",   
	model: "JGrid.model.JGridCModel26",
	alias : "widget.JGridCStore26",
	storeId:"JGridCStore26",
	id:"JGridCStore26",
	autoLoad: false,
<?php 	
  	echo' data: [	{"query_type":"1", "Type":"'. JText::_("JGRID").'"}';
  			if($fversion==0)
			{			
       				echo ',{"query_type":"2", "Type":"'. JText::_("TABLE").'"},
       				{"query_type":"3", "Type":"'. JText::_("CUSTOM_WHERE_CLAUSE").'"},
    				{"query_type":"4", "Type":"'. JText::_("CUSTOM_SQL").'"}';
			}
?>         	
 	]//comboData
});
JGrid.combo_store[26] = Ext.create("JGrid.store.JGridCStore26");

// combo boxs for column type
	Ext.define("JGrid.store.JGridCStore27", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel27",   
	model: "JGrid.model.JGridCModel27",
	alias : "widget.JGridCStore27",
	storeId:"JGridCStore27",
	id:"JGridCStore27",
	autoLoad: false,
<?php 	
  	echo' data: [	{"column_type":"1", "column_type_name":"'. JText::_("JGRID_DATA").'"},	
  					{"column_type":"4", "column_type_name":"'. JText::_("FORMULA").'"},
       				{"column_type":"2", "column_type_name":"'. JText::_("JOOMLA_TABLE_DATA").'"},
       				{"column_type":"3", "column_type_name":"'. JText::_("MYSQL_TABLE_DATA").'"}';
?>         	
 	]//comboData

});
JGrid.combo_store[27] = Ext.create("JGrid.store.JGridCStore27");


// select for combo box jdatabase_sql_name criteria grid database
	Ext.define("JGrid.store.JGridCStore28", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel23",   
	model: "JGrid.model.JGridCModel23",
	alias : "widget.JGridCStore28",
	storeId:"JGridCStore28",
	id:"JGridCStore28",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=database_sql_name&controller=jgrid_columngrid&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[23]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[28] = Ext.create("JGrid.store.JGridCStore28");

// select for combo box jtable_sql_name  select criteria grid table
	Ext.define("JGrid.store.JGridCStore29", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel24",   
	model: "JGrid.model.JGridCModel24",
	alias : "widget.JGridCStore29",
	storeId:"JGridCStore29",
	id:"JGridCStore29",
	autoLoad: false,
	proxy: {
   		type: "ajax",
<?php   		
   	 	echo 'url: "index.php?option=com_jgrid&task=table_sql_name&controller=jgrid_columngrid&format=ajax",';
    	
?>   	 	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[24]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    },
    listeners: {
    	beforeload: function(store, operation, eOpts ) {
    	  	var database_sql_name = JGrid.ceditor.items.items[2].value;
    	    if(!database_sql_name && JGrid.criteria_selection) database_sql_name = JGrid.criteria_selection[0].get('database_sql_name_id'); 			
			if(!database_sql_name) database_sql_name = JGrid.joomla_database;	    		
    		if(database_sql_name) store.proxy.url = "index.php?option=com_jgrid&task=table_sql_name&controller=jgrid_columngrid&database_sql_name="+database_sql_name+"&format=ajax";
   		}
    }
});
JGrid.combo_store[29] = Ext.create("JGrid.store.JGridCStore29");

// combo box jcolumn_sql_name join criteria grid column
	Ext.define("JGrid.store.JGridCStore30", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel25",   
	model: "JGrid.model.JGridCModel25",
	alias : "widget.JGridCStore30",
	storeId:"JGridCStore30",
	id:"JGridCStore30",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=column_sql_name&controller=jgrid_columngrid&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[25]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    },
    listeners: {
    	beforeload: function(store, operation, eOpts ) {
    	    var database_sql_name = JGrid.ceditor.items.items[2].value;
    	    var table_sql_name = JGrid.ceditor.items.items[3].value;
    	    if(!database_sql_name && JGrid.criteria_selection) database_sql_name = JGrid.criteria_selection[0].get('database_sql_name_id'); 			
			if(!database_sql_name) database_sql_name = JGrid.joomla_database;			
			if(!table_sql_name && JGrid.criteria_selection) table_sql_name = JGrid.criteria_selection[0].get('table_sql_name_id'); 
    		store.proxy.url = "index.php?option=com_jgrid&task=column_sql_name&controller=jgrid_columngrid&database_sql_name="+database_sql_name+"&table_sql_name="+table_sql_name+"&format=ajax";    	
    	}
    }
});

JGrid.combo_store[30] = Ext.create("JGrid.store.JGridCStore30");

// select for combo box database_sql_name for join criteria grid database 
	Ext.define("JGrid.store.JGridCStore31", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel23",   
	model: "JGrid.model.JGridCModel23",
	alias : "widget.JGridCStore31",
	storeId:"JGridCStore31",
	id:"JGridCStore31",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=database_sql_name&controller=jgrid_columngrid&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[23]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[31] = Ext.create("JGrid.store.JGridCStore31");

// select for combo box table_sql_name join criteria grid table
	Ext.define("JGrid.store.JGridCStore32", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel24",   
	model: "JGrid.model.JGridCModel24",
	alias : "widget.JGridCStore32",
	storeId:"JGridCStore32",
	id:"JGridCStore32",
	autoLoad: false,
	proxy: {
   		type: "ajax",
<?php   		
   	 	echo 'url: "index.php?option=com_jgrid&task=table_sql_name&controller=jgrid_columngrid&format=ajax",';
    	
?>   	 	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[24]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    },
    listeners: {
    	beforeload: function(store, operation, eOpts ) {
    		var database_sql_name = JGrid.ceditor.items.items[6].value;
    	    if(!database_sql_name && JGrid.criteria_selection) database_sql_name = JGrid.criteria_selection[0].get('jdatabase_sql_name_id'); 			
			if(!database_sql_name) database_sql_name = JGrid.joomla_database;	    		
    		if(database_sql_name) store.proxy.url = "index.php?option=com_jgrid&task=table_sql_name&controller=jgrid_columngrid&database_sql_name="+database_sql_name+"&format=ajax";
   		}
    }
});
JGrid.combo_store[32] = Ext.create("JGrid.store.JGridCStore32");

// combo box jcolumn_sql_name join criteria grid column
	Ext.define("JGrid.store.JGridCStore33", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel25",   
	model: "JGrid.model.JGridCModel25",
	alias : "widget.JGridCStore33",
	storeId:"JGridCStore33",
	id:"JGridCStore33",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=column_sql_name&controller=jgrid_columngrid&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[25]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    },
    listeners: {
    	beforeload: function(store, operation, eOpts ) {
    	    var database_sql_name = JGrid.ceditor.items.items[6].value;
    	    var table_sql_name = JGrid.ceditor.items.items[7].value;
    	    if(!database_sql_name && JGrid.criteria_selection) database_sql_name = JGrid.criteria_selection[0].get('jdatabase_sql_name_id'); 		
			if(!database_sql_name) database_sql_name = JGrid.joomla_database;			
			if(!table_sql_name && JGrid.criteria_selection) table_sql_name = JGrid.criteria_selection[0].get('jtable_sql_name_id'); 
    		store.proxy.url = "index.php?option=com_jgrid&task=column_sql_name&controller=jgrid_columngrid&database_sql_name="+database_sql_name+"&table_sql_name="+table_sql_name+"&format=ajax";    	
    	}
    }
});

JGrid.combo_store[33] = Ext.create("JGrid.store.JGridCStore33");



// combo boxs for security access for type role or user	
	Ext.define("JGrid.store.JGridCStore40", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel40",   
	model: "JGrid.model.JGridCModel40",
	alias : "widget.JGridCStore40",
	storeId:"JGridCStore40",
	id:"JGridCStore40",
	autoLoad: false,
<?php 	
  	echo' data: [	{"access_for":"1", "Type":"'. JText::_("USER").'"},
	       			{"access_for":"2", "Type":"'. JText::_("ROLE").'"},
	    			{"access_for":"3", "Type":"'. JText::_("DEFAULT").'"},
	        		{"access_for":"4", "Type":"'. JText::_("CREATOR").'"}';
?>         	
 	]//comboData
});
JGrid.combo_store[40] = Ext.create("JGrid.store.JGridCStore40");



// combo boxs for security role or user	
	Ext.define("JGrid.store.JGridCStore41", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel41",   
	model: "JGrid.model.JGridCModel41",
	alias : "widget.JGridCStore41",
	storeId:"JGridCStore41",
	id:"JGridCStore41",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=access_for_name_id&controller=jgrid_security&format=ajax&access_for=0",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[41]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[41] = Ext.create("JGrid.store.JGridCStore41");
JGrid.combo_store[41].load({
      params: {
          access_for: "0"
      }
});

// combo boxs for user access type grid, sheet, or column type
	Ext.define("JGrid.store.JGridCStore42", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel42",   
	model: "JGrid.model.JGridCModel42",
	alias : "widget.JGridCStore42",
	storeId:"JGridCStore42",
	id:"JGridCStore42",
	autoLoad: false,
<?php 	
  	echo' data: [	{"access_type":"1", "Type":"'. JText::_("GRID").'"},
       		{"access_type":"2", "Type":"'. JText::_("GRID_COLUMN").'"},
    		{"access_type":"3", "Type":"'. JText::_("SHEET").'"},
        	{"access_type":"4", "Type":"'. JText::_("SHEET_COLUMN").'"}';
?>         	
 	]//comboData
});
JGrid.combo_store[42] = Ext.create("JGrid.store.JGridCStore42"); 
	

// combo boxs for access type name
	Ext.define("JGrid.store.JGridCStore43", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel43",   
	model: "JGrid.model.JGridCModel43",
	alias : "widget.JGridCStore43",
	storeId:"JGridCStore43",
	id:"JGridCStore43",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=access_type_name_id&controller=jgrid_security&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[43]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[43] = Ext.create("JGrid.store.JGridCStore43");
JGrid.combo_store[43].load({
      params: {
          access_type: "0"
      }
}); 


// combo boxs for acess level
	Ext.define("JGrid.store.JGridCStore44", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel44",   
	model: "JGrid.model.JGridCModel44",
	alias : "widget.JGridCStore44",
	storeId:"JGridCStore44",
	id:"JGridCStore44",
	autoLoad: false,
<?php 	
  	echo' data: [	{"access_level":"0", "Type":"'. JText::_("JNO_ACCESS").'"},
       				{"access_level":"1", "Type":"'. JText::_("VIEWER").'"},
    				{"access_level":"-1", "Type":"'. JText::_("VIEW_DOWNLOAD").'"},
        			{"access_level":"2", "Type":"'. JText::_("CELL_EDIT").'"},
  					{"access_level":"3", "Type":"'. JText::_("ROW_EDITOR").'"},
       				{"access_level":"4", "Type":"'. JText::_("ADD_DELETE_ROWS").'"},
    				{"access_level":"5", "Type":"'. JText::_("SHEET_MANAGER").'"},
        			{"access_level":"6", "Type":"'. JText::_("ACCESS_MANAGER").'"}';
?>         	
 	]//comboData
});
JGrid.combo_store[44] = Ext.create("JGrid.store.JGridCStore44"); 

// combo boxs for security role or user
	Ext.define("JGrid.store.JGridCStore45", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel45",   
	model: "JGrid.model.JGridCModel45",
	alias : "widget.JGridCStore45",
	storeId:"JGridCStore45",
	id:"JGridCStore45",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=access_rule_application&controller=jgrid_security&format=ajax&access_for=0",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[45]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[45] = Ext.create("JGrid.store.JGridCStore45");
JGrid.combo_store[45].load({
      params: {
          access_type: "0"
      }
});  

// combo boxs for security role or user	
	Ext.define("JGrid.store.JGridCStore71", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel71",   
	model: "JGrid.model.JGridCModel71",
	alias : "widget.JGridCStore71",
	storeId:"JGridCStore71",
	id:"JGridCStore71",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=jgrid_roles_query&controller=jgrid_users&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[71]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    },
   	listeners: {
 		load: function(store, operation, eOpts ) {
    		if(JGrid.grids[7])
    		{
    			JGrid.grids[7].getView().refresh();
    		}
    	}
  	}
});
JGrid.combo_store[71] = Ext.create("JGrid.store.JGridCStore71");

// combo boxs for users assigned to role
	Ext.define("JGrid.store.JGridCStore73", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel73",   
	model: "JGrid.model.JGridCModel73",
	alias : "widget.JGridCStore73",
	storeId:"JGridCStore73",
	id:"JGridCStore73",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=jgrid_username_query&controller=jgrid_users&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[73]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    },
   	listeners: {
 		load: function(store, operation, eOpts ) {
    		if(JGrid.grids[7])
    		{
    			JGrid.grids[7].getView().refresh();
    		}
    	}
  	}
});
JGrid.combo_store[73] = Ext.create("JGrid.store.JGridCStore73");

// list box for jgrid_application_name values
	Ext.define("JGrid.store.JGridCStore101", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel101",   
	model: "JGrid.model.JGridCModel101",
	alias : "widget.JGridCStore101",
	storeId:"JGridCStore101",
	id:"JGridCStore101",
	autoLoad: false,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=jgrid_application_name&format=ajax",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[101]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    },
 	listeners: {
    		load: function(store, operation, eOpts ) {
    			if(JGrid.grids[0])
    			{
    				JGrid.grids[0].getView().refresh();
    			}
    		}
    	}
});

JGrid.combo_store[101] = Ext.create("JGrid.store.JGridCStore101");
JGrid.combo_store[101].load(); 

// list box for jgrid_theme_name values
	Ext.define("JGrid.store.JGridCStore102", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel102",   
	model: "JGrid.model.JGridCModel102",
	alias : "widget.JGridCStore102",
	storeId:"JGridCStore102",
	id:"JGridCStore102",
	autoLoad: false,
  	data: [	{"id":"1", "grid_theme_name":"Classic Theme"},
	       	{"id":"2", "grid_theme_name":"Gray Theme"},
	    	{"id":"3", "grid_theme_name":"Access Theme"},
	     	{"id":"4", "grid_theme_name":"Neptune Theme"}
	    // 	,{"id":"5", "grid_theme_name":"Sandbox Theme"}
	      ]//comboData
});
JGrid.combo_store[102] = Ext.create("JGrid.store.JGridCStore102");





  	 
// combo boxs for security role or user	 
	Ext.define("JGrid.store.JGridCStore411", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel41",   
	model: "JGrid.model.JGridCModel41",
	alias : "widget.JGridCStore411",
	storeId:"JGridCStore411",
	id:"JGridCStore411",
	autoLoad: true,
	proxy: {
   		type: "ajax",
   	 	url: "index.php?option=com_jgrid&task=access_for_name_id&controller=jgrid_security&format=ajax&access_for=0",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[41]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[411] = Ext.create("JGrid.store.JGridCStore411");
JGrid.combo_store[411].load({
      params: {
          access_for: "0"
      }
});

// combo boxs for user access grid, sheet, or column 
	Ext.define("JGrid.store.JGridCStore431", {
	extend: "Ext.data.Store",
	requires: "JGrid.model.JGridCModel43",   
	model: "JGrid.model.JGridCModel43",
	alias : "widget.JGridCStore431",
	storeId:"JGridCStore431",
	id:"JGridCStore431",
	autoLoad: true,
	proxy: {
   		type: "ajax",
     	url: "index.php?option=com_jgrid&task=access_type_name_id&controller=jgrid_security&format=ajax&access_type=0",
    	reader: new Ext.data.JsonReader({
	        root: "rows",
	        totalProperty: "results",
	        id: "id"
    	},JGrid.dsCModel[43]),
   		 writer: {
			type: "json",
			writeAllFields : false,  //just send changed fields
			allowSingle :false      //always wrap in an array
		}
    }
});
JGrid.combo_store[431] = Ext.create("JGrid.store.JGridCStore431");
JGrid.combo_store[431].load({
      params: {
          access_type: "0"
      }
}); 



	











	      
