<?php
 /*
 *  JGridGrid15.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');

echo 'Ext.define("JGrid.view.JGridGrid15", {
	extend : "Ext.grid.Panel",
	alias : "widget.JGridGrid15",
	requires : [ "JGrid.view.JGridToolbar15", "JGrid.store.JGridStore15"  ],
 	id: "where_clause_dependencies",
 	hidden: true,
   	title: "'. JText::_("WHERE_CLAUSE_DEPENDENCIES").'",
  	xtype: "editorgrid",
   	tooltip: "'. JText::_("WHERE_CLAUSE_DEPENDENCIES_TABTIP").'",
   	height: 250,
   	//width: 1100,
 	enableColumnMove: false,
	store: JGrid.store[15],
 	columns: JGrid.columns[15],
 	listeners: {';
?>
        viewready: function ( panel, layout, opts)
        {
        	// RMS This does not seem to work but required to clear combo setup structure. fixed below in before edit
        	combo15 = Ext.getCmp("combo15");
        	combo16 = Ext.getCmp("combo16");
        	combo17 = Ext.getCmp("combo17");
        	combo28 = Ext.getCmp("combo28");       	
        	combo29 = Ext.getCmp("combo29");		
			combo30 = Ext.getCmp("combo30");						
		   	combo31 = Ext.getCmp("combo31");	   	
			combo32 = Ext.getCmp("combo32");			
		   	combo33 = Ext.getCmp("combo33");
		 },
<?php         	
	echo '	beforeedit: function (thisEditor,e)
		{	
					 if(!combo15) combo15 = Ext.getCmp("combo15");
        			 if(!combo16) combo16 = Ext.getCmp("combo16");
        	         if(!combo17) combo17 = Ext.getCmp("combo17");
        	         if(!combo28) combo28 = Ext.getCmp("combo28");
        	         if(!combo29) combo29 = Ext.getCmp("combo29");
        	         if(!combo30) combo30 = Ext.getCmp("combo30");
        	         if(!combo31) combo31 = Ext.getCmp("combo31");
        	         if(!combo32) combo32 = Ext.getCmp("combo32");
        	         if(!combo33) combo33 = Ext.getCmp("combo33");
					
            		var reditor = Ext.ComponentMgr.get("gridcolumns_data");
            		if(reditor) reditor.editingPlugin.cancelEdit();
                    var cgrid = Ext.ComponentMgr.get("where_clause_dependencies");
                    JGrid.ceditor = cgrid.editingPlugin.editor;
    				sm = cgrid.getSelectionModel();
    				if (sm.hasSelection()) {
			            JGrid.cselection = sm.getSelection();
			            JGrid.criteria_selection = sm.getSelection();
			            var where_clause_dependencies = Ext.ComponentMgr.get("where_clause_dependencies");			            
			          	var criteria_type_id = JGrid.criteria_selection[0].get("criteria_type_id");
						combo17.setValue(cvalue);
						multiple_database_check();
						where_clause_dependencies.columns[1].show();
			            switch(criteria_type_id) {
			            	case 1:
			            		if(JGrid.multiple_databases == true) 
			            		{
			            			where_clause_dependencies.columns[6].show();
			            			where_clause_dependencies.columns[2].show();
			            		}
			            		else
			            		{
			            			where_clause_dependencies.columns[6].hide();
			            			where_clause_dependencies.columns[2].hide();
			            		}	            	
			            		where_clause_dependencies.columns[5].show();
			            		where_clause_dependencies.columns[7].show();
			            		where_clause_dependencies.columns[8].show();
			            		where_clause_dependencies.columns[9].hide();
			            		where_clause_dependencies.columns[10].hide();
			            		break;
			            	case 2:
			            		where_clause_dependencies.columns[5].hide();	            	
			            		where_clause_dependencies.columns[6].hide();
			            		where_clause_dependencies.columns[7].hide();
			            		where_clause_dependencies.columns[8].hide();
			            		where_clause_dependencies.columns[9].hide();
			            		where_clause_dependencies.columns[10].show();            	
			            		break;
			            	case 3:
			            		where_clause_dependencies.columns[5].hide();            	
			            		where_clause_dependencies.columns[6].hide();
			            		where_clause_dependencies.columns[7].hide();
			            		where_clause_dependencies.columns[8].hide();
			            		where_clause_dependencies.columns[9].show();
			            		where_clause_dependencies.columns[10].hide();
			            		break;		
		            	} 

			          	var cvalue = JGrid.criteria_selection[0].get("database_sql_name_id");
			            combo28.store.add({database_sql_name_id:cvalue, database_sql_name:cvalue});
						combo28.setValue(cvalue);
						
						var cvalue = JGrid.criteria_selection[0].get("table_sql_name_id");
			            combo29.store.add({table_sql_name_id:cvalue, table_sql_name:cvalue});
						combo29.setValue(cvalue);
						
						var cvalue = JGrid.criteria_selection[0].get("column_sql_name_id");
			            combo30.store.add({column_sql_name_id:cvalue, column_sql_name:cvalue});
						combo30.setValue(cvalue);
						
						var cvalue = JGrid.criteria_selection[0].get("jdatabase_sql_name_id");
			            combo31.store.add({jdatabase_sql_name_id:cvalue, jdatabase_sql_name:cvalue});
						combo31.setValue(cvalue);
						
						var cvalue = JGrid.criteria_selection[0].get("jtable_sql_name_id");
			            combo32.store.add({jtable_sql_name_id:cvalue, table_sql_name:cvalue});
						combo32.setValue(cvalue);
			            
			            var cvalue = JGrid.criteria_selection[0].get("jcolumn_sql_name_id");
			            combo33.store.add({jcolumn_sql_name_id:cvalue, column_sql_name:cvalue});
						combo33.setValue(cvalue);
						
						var cvalue = JGrid.criteria_selection[0].get("select_wildcard_id");
			            combo16.store.add({select_wildcard_id:cvalue, select_wildcard:cvalue});
						combo16.setValue(cvalue);

     
			        }
			        else JGrid.cselection = "";
			        // RMS exit and ask for selection
                },
                validateedit: function (e) {
                    JGrid.store[15].save();
                    multiple_database_check();
                    var where_clause_dependencies = Ext.ComponentMgr.get("where_clause_dependencies");
                    where_clause_dependencies.columns[1].hide();
                	where_clause_dependencies.columns[5].show();
                	where_clause_dependencies.columns[6].show();
			    	where_clause_dependencies.columns[7].show();
			     	where_clause_dependencies.columns[8].show();
			     	where_clause_dependencies.columns[9].show();
			       	where_clause_dependencies.columns[10].show();
                },
                failure: function (response, options) {

                    window.alert("'. JText::_("CRITERIA_WAS_NOT_SAVED_IN_DATABASE").'");
                  
                },
                success: function (response, options) {
                    var server_response = Ext.decode(response.responseText);
                 // window.alert(response.responseText);
                    JGrid.store[15].commitChanges();
		    	e.grid.getView().refresh();
		},
		scope: this

    },
 	//selModel: Ext.create("Ext.selection.RowModel", { singleSelect: true, selectFirstRow: true }),
 	selModel: Ext.create("Ext.selection.RowModel", { mode: "MULTI"}),    	
	tbar: {xtype: "JGridToolbar15"},		    
	frame: true,
	stripeRows: true,
	enableColumnResize: true,
	columnLines: true,
	beforeRender: function() {
      	JGrid.grids[15] = Ext.ComponentMgr.get("where_clause_dependencies");
    },
	plugins: [	Ext.create("Ext.grid.plugin.RowEditing", {
    				saveText: "Update",
	  				errorSummary: false,
	  				listeners: {
						validateedit: function(e){
        					e.value = Ext.util.Format.stripTags(e.value);
        				}
      				}
	  			})
	],
 	keys: [{
		key: 46,
		fn: function () {
			var pgrid = Ext.ComponentMgr.get("where_clause_dependencies");
			var sm = pgrid.getSelectionModel();
			var sel = sm.getSelected();
			if (sm.hasSelection()) {
				Ext.Msg.show({
              		title: "'. JText::_("REMOVE_WHERE_CLAUSE").'",
                	buttons: Ext.MessageBox.YESNOCANCEL,
                	msg: "'. JText::_("REMOVE_WHERE_CLAUSE").'",
                   	fn: function (btn) {
                    	if (btn == "yes") {           
                        	//pgrid.stopEditing();
                           	var sels = sm.getSelection();
                           	// Multiple row delete
                           	for(var i = 0, r; r = sels[i]; i++){             
                            	pgrid.getStore().remove(r);
                          	}              
	                  	}
	            	}
       			})
           	} else Ext.Msg.alert("'. JText::_("PLEASE").'", "'. JText::_("SELECT_GRID_FIRST_TO_MODIFY_SETTINGS").'");
     	},
     	ctrl: false,
     	stopEvent: true
  	}] 	
});

';
?>
