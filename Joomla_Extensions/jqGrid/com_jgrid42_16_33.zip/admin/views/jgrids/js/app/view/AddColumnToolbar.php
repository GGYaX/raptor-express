<?php
 /*
 *  AddColumnToolbar.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');




echo 'Ext.define("JGrid.view.AddColumnToolbar", {
	extend : "Ext.toolbar.Toolbar",
	requires : [ "JGrid.view.JGridHelp3"],	
	alias : "widget.AddColumnToolbar",
	id : "AddColumnToolbar",
	items : [{';
?>
		xtype: 'combo',
		id: 'columnid',
		fieldLabel: 'Add Column',
		growToLongestValue: false,
		width: 300,
		hiddenName: 'columngridid',
<?php           
		echo 'emptyText: "'. JText::_("SELECT_A_COLUMN_TO_ADD").'",';
?>   
		store: JGrid.combo_store[21],
		displayField: 'header',
		valueField: 'id',
		selectOnFocus: true,
		mode: 'remote',
		typeAhead: true,
		hideTrigger : false,
		lastquery : "",
 		editable: false,
 		triggerAction: 'all',
		listeners: {
			select: {
				fn: function (combo, records, eOpts) {
					JGrid.newcolumnrecord = records[0];
				}
			}
		}
	},	
	{
<?php
                echo 'text: "'. JText::_("ADD_NEW_GRID_COLUMN").'",
                tooltip: "'. JText::_("ADD_NEW_GRID_COLUMN_TOOLTIP").'",';
?>               
                icon: "components/com_jgrid/os/jgrid/icons/table_add.png",
                cls: "x-btn-text-icon",
                handler: function () {
                    if(!JGrid.newcolumnrecord)
                    {
<?php 
                       echo 'window.alert("'. JText::_("FIRST_SELECT_A_COLUMN_FROM_THE_PULLDOWN_LIST").'");';
?>
                    } else { 
                      //  editor2.stopEditing();
                        //  JGrid.store[2].commitChanges();
                        var newrowlocation = JGrid.store[2].getCount();
                        var jgrid_newrowcolumns = {
                            id: "",
                            title: JGrid.gridname,
                            header: JGrid.newcolumnrecord.data.header,
                            ordering: newrowlocation + 1,
                            grid_id: JGrid.selectedgridid,
                            column_id: JGrid.newcolumnrecord.data.id
                        };
                        if(newrowlocation==0) var last_record_id=0;
                        else var last_record_id=JGrid.store[2].data.items[newrowlocation-1].data.id;
                        JGrid.proxy[2].api.create="index.php?option=com_jgrid&task=create&controller=jgrid_columngrid&format=ajax&last_record_id="+last_record_id;   
                        JGrid.store[2].insert(newrowlocation, jgrid_newrowcolumns);
                        JGrid.currenteditgrid = Ext.ComponentMgr.get("gridcolumns_data");
                        JGrid.currenteditgrid.getView().refresh();
                        Ext.ComponentMgr.get("columnid").clearValue();
                        JGrid.combo_store[21].remove(JGrid.newcolumnrecord);
                        JGrid.newcolumnrecord=null;
                        // JGrid.store[2].commitChanges();
                        // var sm = JGrid.currenteditgrid.getSelectionModel();
                        // sm.selectRow(newrowlocation);
                        // var sel = sm.getSelected();
                   }    //editor2.startEditing(newrowlocation);  // allows the new id number to render
                }
            },
            {
<?php         
                echo 'text: "'. JText::_("REMOVE_COLUMN").'",
                tooltip: "'. JText::_("REMOVE_COLUMN_TOOLTIP").'",';            
?>  
                icon: "components/com_jgrid/os/jgrid/icons/table_delete.png",
                cls: "x-btn-text-icon",
                handler: function () {
                //    editor2.stopEditing();
                    JGrid.currenteditgrid = Ext.ComponentMgr.get("gridcolumns_data");
                    var sm = JGrid.currenteditgrid.getSelectionModel();
                    if (sm.hasSelection()) {
                        Ext.Msg.show({
<?php         
                echo 'title: "'. JText::_("REMOVE_COLUMN").'",';            
?>                        
                            buttons: Ext.MessageBox.YESNOCANCEL,
<?php 
                           echo 'msg: "'. JText::_("REMOVE_SELECTED_COLUMN_QUESTION").'",';
 ?>                          
                            fn: function (btn) {
                                if (btn == "yes") {
                                  //JGrid.currenteditgrid.stopEditing();
                                  var sels = sm.getSelection();
                                  // Multiple row delete
                                  for(var i = 0, r; r = sels[i]; i++){             
                                    JGrid.currenteditgrid.getStore().remove(r);
                                  }
                                }
                            }
                        })
                    }
	                }
		},
		{  
<?php                
                        echo 'id: "user_help_columngrid",               
                        text: "<b>'. JText::_("HELP").'</b>",                       
                        icon: "components/com_jgrid/os/jgrid/icons/help.png",
                        tooltip: "'. JText::_("INSTRUCTIONS_DESCRIBING_GRID_OPERATION_TOOLTIP").'",';
?>                       
                        handler: function () {                              
                    		if(!JGrid.help[3])
    						{
    							JGrid.help[3] = Ext.create("JGrid.view.JGridHelp3");
    						}
    						JGrid.help[3].show(); 
                        }          
		}]
});


