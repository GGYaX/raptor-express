<?php
 /*
 *  JGridModifyListsWin.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>  
Ext.define("JGrid.view.JGridSelectionWin", {
	extend : "Ext.window.Window",
	requires : [ "JGrid.view.JGridHelp3"],
	alias : "widget.JGridSelectionWin",
	id: "JGridSelectionWin",
  	title: '',
   	renderTo: 'editcell',
   	layout: 'fit',
    //autoHeight: true,
  	width: 1300,
   	height: 500,
   	closeAction: 'hide', 
     minimizable: true,  
     maximizable: true,
   //	x: 35,
	y: 100,
	layout: "border",
	tbar:[	combo26,
	{
		id: "save_database_query",
		hidden: true,
		
<?php		                   
     	echo 'text: "<b>'. JText::_("SAVE_CUSTOM_QUERY").'</b>",
   		icon: "components/com_jgrid/os/jgrid/icons/script_save.png",
       	tooltip: "'. JText::_("SAVE_CUSTOM_QUERY_TOOLTIP").'",';
?>      	
    	handler: function () {
			var crecord = JGrid.store[14].findRecord('grid_id', JGrid.selectedgridid );
			var new_custom_sql = Ext.ComponentMgr.get("north_select_query").getValue();
			if(crecord) crecord.set('sql_query',new_custom_sql); 
			else JGrid.store[14].insert(0,	{grid_id: JGrid.selectedgridid,
												sql_query: new_custom_sql});
			var crecord = JGrid.store[13].findRecord('grid_id', JGrid.selectedgridid );
			var new_custom_sql = Ext.ComponentMgr.get("north_select_query").getValue();
			if(crecord) crecord.set('sql_query',new_custom_sql); 
			else JGrid.store[13].insert(0,	{grid_id: JGrid.selectedgridid,
												sql_query: new_custom_sql});
		}
  	},	
  	{
		id: "test_database_query",
		hidden: true,
		
<?php		                   
     	echo 'text: "<b>'. JText::_("TEST_QUERY").'</b>",
   		icon: "components/com_jgrid/os/jgrid/icons/medal_gold_add.png",
       	tooltip: "'. JText::_("TEST_QUERY_TOOLTIP").'",';
?>      	
    	handler: function () {
    		var crecord = JGrid.store[13].findRecord('grid_id', JGrid.selectedgridid );
			var new_select_query = Ext.ComponentMgr.get("north_select_query").getValue();
    	
			Ext.Ajax.request({
<?php           
                                echo 'waitMsg: "'.JText::_("TESTING_SQL_SELECT").'",';
            
                     echo 'url: "'.JURI::base().'index.php?option=com_jgrid&task=jgrid_test_grid_select&controller=jgrid_columngrid&format=ajax",';
?>                     
                     params: {
                         task: "jgrid_test_grid_select",
                         option: "com_jgrid",
                         grid_id: JGrid.selectedgridid,
                         sql_query: new_select_query,
                         select_type: JGrid.select_type
                     },
                     method: "POST",
                     failure: function (response, options) {
<?php 
                            echo 'Ext.MessageBox.alert("'. JText::_("ERROR_IN_YOUR_SELECT").'", "'. JText::_("USE_PHPMYADMIN_TO_DEBUG_THIS_SQL_SELECT_STATEMENT").'");';
?> 
                     },
                     success: function (response, options) {
                         var server_response = Ext.decode(response.responseText);
                         if (!server_response.success) {                                                      
<?php 
                            echo 'Ext.MessageBox.alert("'. JText::_("DATABASE_ERROR").'", "'. JText::_("SELECT_TEST_FAILED").'");';
?>
                                        
                         } else {
                            // var new_document_id = parseInt(server_response.rows.new_document_id);
<?php 
                            echo 'Ext.MessageBox.alert("'. JText::_("SQL_SELECT_VALIDATED").'", "'. JText::_("GOTO_JGRID_FRONT_END_TO_SEE_DATA").'");';
?>                            						
                         }
                },
                scope: this
              });    	
		}
  	},
  	{    
		id: "user_help_columngrid",
<?php		                   
      	echo 'text: "<b>'. JText::_("HELP").'</b>",
     	icon: "components/com_jgrid/os/jgrid/icons/help.png",
       	tooltip: "'. JText::_("INSTRUCTIONS_DESCRIBING_GRID_OPERATION_TOOLTIP").'",';
?>      	
    	handler: function () {
    		if(!JGrid.help[3])
    		{
    			JGrid.help[3] = Ext.create("JGrid.view.JGridHelp3");
    		}
    		JGrid.help[3].show();  
      	}          
  	}],     
    items: [
    {
        region: 'center',     // center region is required, no width/height specified
    	id: 'centerTabPanel',
		xtype : "tabpanel",
		enableTabScroll:true,
		margins: "5 5 0 0",
        activeTab: 0,
        listeners: {
            tabchange: function (tabpanel, tab) {
				var custom_where_clause_button = Ext.ComponentMgr.get("save_custom_where");
                if(tab.id == 'custom_where_clause') {
                	custom_where_clause_button.show();
                }
                else custom_where_clause_button.hide();
            } 
        },     
        tbar:[
		{
			id: "save_custom_where",
			hidden: true,
<?php		                   
	     	echo 'text: "<b>'. JText::_("SAVE_CUSTOM_WHERE").'</b>",
	   		icon: "components/com_jgrid/os/jgrid/icons/script_save.png",
	       	tooltip: "'. JText::_("SAVE_CUSTOM_WHERE_TOOLTIP").'",';
?>      	
	    	handler: function () {
				var crecord = JGrid.store[16].findRecord('grid_id', JGrid.selectedgridid );
				var new_custom_where = Ext.ComponentMgr.get("custom_where_clause").getValue();
				if(crecord) crecord.set('custom_where_query',new_custom_where); 
				else JGrid.store[16].insert(0,	{grid_id: JGrid.selectedgridid,
												custom_where_query: new_custom_where});
				build_sql(); 
			}									
  		}],
        items : [	{	xtype : "JGridGrid2"},
       				{	xtype : "JGridGrid15"},
       				{	xtype: 'textarea',
       					hidden: true,
       					id: 'custom_where_clause',
       					enableTabScroll:true,
       					margins: '0 5 5 5',
<?php
           				echo 'title: "'.JText::_("CUSTOM_WHERE_CLAUSE").'",
          				 tooltip: "'. JText::_("CUSTOM_WHERE_CLAUSE_TOOLTIP").'"';
 ?>  
       				}
       			]
    },{
<?php
	echo 'title: "'.JText::_("DATABASE_SELECT_QUERY").'",
	tooltip: "'. JText::_("DATABASE_SELECT_QUERY_TOOLTIP").'",';
 ?>  
          
        region: 'north',     // position for region
      	id: 'north_select_query',
      	hidden: true,
        xtype: 'textarea',
        editable: false,
        height: 75,
        margins: '0 5 5 5'
    }]

});
     

     
