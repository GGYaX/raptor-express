<?php
 /*
 *  JGridToolbar7.php  in joomla/administrator/components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');




echo 'Ext.define("JGrid.view.JGridToolbar7.php", {
	extend : "Ext.toolbar.Toolbar",
	requires : [ "JGrid.view.JGridHelp4"],	
	alias : "widget.JGridToolbar7",
	id : "JGridToolbar7",
	items : [{
                text: "'. JText::_("ADD_USER_TO_ROLE").'",
                icon: "components/com_jgrid/os/jgrid/icons/table_add.png",
                cls: "x-btn-text-icon",
                tooltip: "'. JText::_("ADD_USER_TO_ROLE_TOOLTIP").'",
                handler: function () {
                 //   editor7.stopEditing();
                    var newrowlocation = JGrid.store[7].getCount();
                    var jgrid_newrowcolumns7 = {
                        id: "",
                        role_name: "",
                        role_id: "",
                        username: "",
                        userid: ""
                    };
                    if (newrowlocation == null) newrowlocation = 0;                  
                    JGrid.store[7].insert(newrowlocation, jgrid_newrowcolumns7);
                    JGrid.currenteditgrid = Ext.ComponentMgr.get("jgrid_roles");
          			JGrid.currenteditgrid.getView().refresh();
             
               }
            },
            {
                text: "'. JText::_("REMOVE_USER_FROM_ROLE").'",
                icon: "components/com_jgrid/os/jgrid/icons/table_delete.png",
                cls: "x-btn-text-icon",
                tooltip: "'. JText::_("REMOVE_USER_FROM_ROLE_TOOLTIP").'",
                handler: function () {
                 //   editor7.stopEditing();
                    JGrid.currenteditgrid = Ext.ComponentMgr.get("jgrid_roles");
                    var sm = JGrid.currenteditgrid.getSelectionModel();
                    var sel = sm.getSelection();
                    if (sm.hasSelection()) {
                        Ext.Msg.show({
                            title: "'. JText::_("REMOVE_USER_FROM_ROLE").'",
                            buttons: Ext.MessageBox.YESNOCANCEL,
                            msg: "'. JText::_("REMOVE_USER_FROM_ROLE").'",
                            fn: function (btn) {
                                if (btn == "yes") {
                                    JGrid.store[7].remove(sel[0]);
                                }
                            }
                        })
                    }
                }
            },
             {    
                        id: "manage_roles",                   
                        text: "<b>'. JText::_("MANAGE_ROLES").'</b>",
                        icon: "components/com_jgrid/os/jgrid/icons/folder_user.png",
                        tooltip: "'. JText::_("MANAGE_ROLES_TOOLTIP").'",
                       	handler:  function() {
                       		if(!JGrid.grids[8])
                      		{
                      			JGrid.grids[8] = Ext.create("JGrid.view.JGridGrid8");
                      		}
                      		JGrid.grids[8].show(); 
                       	} 
                                 
             },
             {    
                        id: "user_help_role",                   
                        text: "<b>'. JText::_("HELP").'</b>",
                        icon: "components/com_jgrid/os/jgrid/icons/help.png",
                        tooltip: "'. JText::_("INSTRUCTIONS_DESCRIBING_GRID_OPERATION").'",
                        handler: function () {                              
                          	if(!JGrid.help[4])
    						{
    							JGrid.help[4] = Ext.create("JGrid.view.JGridHelp4");
    						}
    						JGrid.help[4].show();  
                        }          
               }]
});';
?>

