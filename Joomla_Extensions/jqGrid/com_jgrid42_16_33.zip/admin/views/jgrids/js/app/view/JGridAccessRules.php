<?php
 /*
 *  JGridAccessRules.php  in joomla/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>
  
Ext.define("JGrid.view.JGridAccessRules", {
	extend : "Ext.window.Window",
	alias : "widget.JGridAccessRules",
	id: "JGridAccessRules",
//RMS add language
   	title: 'Create or Edit Access Rules',
   	renderTo: 'editcell',
	closable: true,
	closeAction: 'hide',
	layout: 'fit',
    autoHeight: true,
  	width: 800,
  	// height:500,
 	//x: 35,
  	//y: 100,
	plain: true,	     
	items:  [
	{
		xtype: 'form',
		id: "formpanel3",
		frame: true,
		labelWidth: 85,
		//width:700,
        height: 400,
        layout: 'fit',
    	autoHeight: true,
      	//layout: 'fit',
       	items: [
       	{
			xtype: 'fieldset',
          	autoHeight: true,
          	labelAlign: 'right',
           	waitMsgTarget: true,
          	layout: 'column',
           	defaultType: "container",
          	listeners: {
      			afterlayout: function(form, layout, eOpts) {
      				// hide selections when creator type					
  					if(combo40.getValue() == "4")
				  	{
				    	combo44.setValue("1");
				    	combo44.hide();
				 	}
				  	else
				  	{
				    	combo44.show();
				  	}
      			}
      		},
           	defaults: {
          		autoEl: {},
              	layout: 'form',
              	// applied to each contained item
               	//       width: 230,
              	msgTarget: "side"
          	},
          	items: [
          	{
            			//title: 'Width = 50%',
            			columnWidth: .5,
            			items: [
              				new Ext.form.FieldSet({
                				//  title: 'Contact Information',
                				defaultType: 'textfield',
               					defaults: {
                  					height: 30
                				},
                				autoHeight: true,
                				items: [
                				{
<?php 
									echo 'fieldLabel: "'.JText::_("RULE_ID").'",
									plugins: [ new Ext.ux.FieldHelp("'. JText::_("RULE_ID_TOOLTIP").'") ],';                
?>
									name: 'id',
									id: 'access_rule_id',
									disabled: true,
									width: "50px"
                				},
                				combo45,
				                combo40,
				                combo411,
				                combo42,
				                combo431
				        		]
                        	})
                        ]
                    },
                    {
                        columnWidth: .5,
                        items: [
                        	new Ext.form.FieldSet({
	                    		//  title: 'Contact Information',
	                            defaultType: 'textfield',
	                            autoHeight: true,
	                            defaults: {
	                                 height: 30
	                            },
                            	items: [combo44]
                        	})
                     	]
                }
            ]
		}],
        buttons: [{

<?php 
            	echo 'text: "'.JText::_("SAVE_CHANGES").'",
            	tooltip: "'. JText::_("SAVE_CHANGES_TOOLTIP").'",';
?>            
            	disabled: false,
            	formBind: true,
            	handler: function () {
	            	if(combo40.getValue()=="")
	                {
	<?php 
	                    echo'window.alert("'. JText::_("PLEASE_SELECT_ACCESS_FOR_VALUE").'");';
	                    
	?>  
	                   return;
	                }
	                if(combo411.getValue()==""||Ext.isEmpty(combo411.getValue()))
	                {
	<?php 
	                    echo'window.alert("'. JText::_("PLEASE_SELECT_USER_ROLE_NAME_VALUE").'");';
	                    
	?>  
	                   return;
	                }
	                if(combo42.getValue()==""||Ext.isEmpty(combo42.getValue()))
	                {
	<?php 
	                    echo'window.alert("'. JText::_("PLEASE_SELECT_ACCESS_TYPE_VALUE").'");';
	                    
	?>  
	                   return;
	                }
	                if(combo431.getValue()==""||Ext.isEmpty(combo431.getValue()))
	                {
	<?php 
	                    echo'window.alert("'. JText::_("PLEASE_SELECT_OBJECT_NAME_VALUE").'");';
	                    
	?>  
	                   return;
	                }
	                if(combo44.getValue()==""||Ext.isEmpty(combo44.getValue()))
	                {
	<?php 
	                    echo'window.alert("'. JText::_("PLEASE_SELECT_ACCESS_LEVEL_VALUE").'");';
	                    
	?>  
	                   return;
	                }
	                if(combo45.getValue()==""||Ext.isEmpty(combo45.getValue()))
	                {
	<?php 
	                    echo'window.alert("'. JText::_("PLEASE_SELECT_APPLICATION_VALUE").'");';
	                    
	?>  
	                   return;
	                }
	                // update combo boxs
	                record_index = JGrid.combo_store[431].find('access_type_id', combo431.getValue(),0,true,false)
	                    record = JGrid.combo_store[431].getAt(record_index);
	                    // set new value and display of combo
	                    var col431 = {
	                        			access_type_name: record.get("access_type_name"),
	                        			access_type_id: combo431.getValue()
	                    };                  
	                    JGrid.combo_store[43].insert(1,col431);
	                
	                record_index = JGrid.combo_store[411].find('access_for_id', combo411.getValue(),0,true,false)
	                    record = JGrid.combo_store[411].getAt(record_index);
	                    // set new value and display of combo
	                    var col411 = {
	                        	access_for_name: record.get("access_for_name"),
	                        	access_for_id: combo411.getValue()
	                    };                  
	                    JGrid.combo_store[41].insert(1,col411);
	                                 
	              if (JGrid.selectedgridid) { // update record
	                // update record
	                if (record = JGrid.store[4].findRecord("id", JGrid.selectedgridid)) {
	                    JGrid.store[4].suspendEvents(true);            
	                    record.set("access_for", combo40.getValue());
	                    record.set("access_for_id", combo411.getValue());
	                    record.set("access_type", combo42.getValue());      
	                    record.set("access_type_id", combo431.getValue());       
	                    record.set("access_level", combo44.getValue());
	                    record.set("access_rule_application_id", combo45.getValue());
	                    JGrid.store[4].resumeEvents();                   
	                }
	             
	              } // add record
	              else
	              {                
	                 var jgrid_newrowcolumns4 = {
	                        userid_assigning_access: "",
	                        access_for: combo40.getValue(),
	                        access_for_name: combo40.lastSelection[0].data.Type,
	                        access_for_id: combo411.getValue(),
	                        access_type: combo42.getValue(),
	                        access_type_id: combo431.getValue(),
	                        access_type_name: col431.access_type_name,
	                        access_level: combo44.getValue(),
	                        access_rule_application_id: combo45.getValue(),
	                        last_updated: ""
	                  };                  
	                  JGrid.store[4].add(jgrid_newrowcolumns4);
	                  JGrid.currenteditgrid = Ext.ComponentMgr.get("jgrid_security");
	              }      
            }

      	},
      	{
<?php 
          echo 'text: "'.JText::_("CLEAR_FORM").'",
          tooltip: "'. JText::_("CLEAR_FORM_DATA").'",';
?>            
          disabled: false,
          formBind: true,
          handler: function(){
            Ext.ComponentMgr.get("formpanel3").getForm().setValues({
              'access_rule_id': '99999'
            });
	            combo40.clearValue();
	            combo411.clearValue();
	            combo42.clearValue();
	            combo431.clearValue();
	            combo44.clearValue();
	            combo45.clearValue();
	            JGrid.selectedgridid=0;
          	}
     	}]
	}]      	
});
     

     
