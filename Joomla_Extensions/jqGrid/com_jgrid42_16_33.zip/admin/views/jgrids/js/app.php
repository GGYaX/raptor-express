<?php
/**
 * app.php in joomla/administrator/omponents/views/jgrid/js
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

//Ext.require([ "Ext.grid.*", "Ext.data.*", "Ext.util.*", "Ext.form.*", "Ext.menu.*", "Ext.grid.PagingScroller", "Ext.tip.*", "Ext.Button", "Ext.window.*" ]);
Ext.require([ "Ext.grid.*", "Ext.data.*", "Ext.util.*", "Ext.state.*","Ext.form.*", "Ext.menu.*", "Ext.tip.*", "Ext.Button", "Ext.window.*" ]);


Ext.application({

	// name of the application
	name : "JGrid",

	// define app folder //RMS add read from joomla for directory
	//appFolder : "../../../../../joomla301/administrator/components/com_jgrid/views/jgrids/js/app",
	
	// Requires do not work with Joomla PHP so loaded instead in default.php to use Joomla namespace and then works in extjs mvc. 
	requires : [ "JGrid.view.Viewport" ],

	controllers: ["JGridController0"],

	launch : function() {

		// launch main tab view
		Ext.create("JGrid.view.Viewport").show();
		
		// reset to extjs document_id from mootools document_id
		//document.id = Ext.documentID;

        
        // Initialize tool tips
		Ext.QuickTips.init();

	}
});


