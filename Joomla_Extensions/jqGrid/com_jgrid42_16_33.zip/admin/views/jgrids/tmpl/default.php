<?php
/**
 * default.php in Joomla/Administrator/Components/views/jgrids/tmpl
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// no direct access
defined('_JEXEC') or die('Restricted access');
require_once(JPATH_BASE . '/components/com_jgrid/os/jgrid/functions.php' );
$document = JFactory::getDocument();
$db =JFactory::getDBO();
jimport('joomla.application.component.helper');
$params = JComponentHelper::getParams('com_jgrid');
$fversion = $params->get ('fversion');

JLoader::import( 'joomla.version' );
$jversion = new JVersion();
if (version_compare( $jversion->RELEASE, '2.5', '<=')) {
    if(JFactory::getApplication()->get('jquery') !== true) {
        // load jQuery here
        JFactory::getApplication()->set('jquery', true);
    }
} else {
    JHtml::_('jquery.framework');
}

//Make extjs 3.1.0 compatable with ie 8
header('X-UA-Compatible: IE=EmulateIE7');

// check and see if database needs upgraded from new install
jgrid_database_upgrade_check("Admin");

$jgrid_theme=1;
if($fversion==0)
{
	$query = 'SELECT theme
              FROM #__jgrid_applications
              WHERE grid_application_name = "com_jgrid"'; 					
	$db->setQuery($query);
	$jgrid_theme=$db->loadResult();
}


if($fversion==0&&$jgrid_theme)
{
	switch($jgrid_theme)
	{
		case 1:
			$document->addCustomTag('<link rel="stylesheet" type="text/css" href="components/com_jgrid/os/ext/resources/css/ext-all.css" />' );	
			Break;
		case 2:
			$document->addCustomTag('<link rel="stylesheet" type="text/css" href="components/com_jgrid/os/ext/resources/css/ext-all-gray.css" />' );	
			Break;
		case 3:
			$document->addCustomTag('<link rel="stylesheet" type="text/css" href="components/com_jgrid/os/ext/resources/css/ext-all-access.css" />' );	
			Break;
		case 4:
			$document->addCustomTag('<link rel="stylesheet" type="text/css" href="components/com_jgrid/os/ext/resources/css/ext-all-neptune.css" />' );	
			Break;
		case 5:
			$document->addCustomTag('<link rel="stylesheet" type="text/css" href="components/com_jgrid/os/ext/resources/css/sandbox.css" />' );	
			Break;      	
	}
}
else 
{
	$document->addCustomTag('<link rel="stylesheet" type="text/css" href="components/com_jgrid/os/ext/resources/css/ext-all.css" />' );
}

$document->addCustomTag('<link rel="stylesheet" type="text/css" href="components/com_jgrid/os/ext/ux/css/FieldHelp.css" />
                         <link rel="stylesheet" type="text/css" href="components/com_jgrid/os/ext/ux/css/jgrid_custom.css" />' );
// keeps the Joomla page from timing out when the extjs grid is displayed
echo JHTML::_('behavior.keepalive');

// script change to keep mootools working with extjs 4.0
echo JHTML::script('administrator/components/com_jgrid/os/jgrid/mooltools_document_id_save.js',false);

//echo JHTML::script('administrator/components/com_jgrid/os/ext/bootstrap.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ext-all.js',false);
//echo JHTML::script('administrator/components/com_jgrid/os/ext/ext-all-debug-w-comments.js',false);


if($fversion==0&&$jgrid_theme)
{
	switch($jgrid_theme)
	{
	  // other cases 1 to 3 and 5 are 0 value
		case 4:
			echo JHTML::script('administrator/components/com_jgrid/os/ext/ext-theme-neptune.js',false);
			Break;	
	}
}

// script change to keep mootools working with extjs 4.0
echo JHTML::script('administrator/components/com_jgrid/os/jgrid/extjs4_document_id_save.js',false);

echo JHTML::script('administrator/components/com_jgrid/views/jgrids/js/MessageBus.js',false);
//echo JHTML::script('components/com_jgrid/views/jgrids/js/Config.js',false);

//load custom modification to Extjs 4 loader to allow .php files to echo javascript
echo JHTML::script('administrator/components/com_jgrid/os/jgrid/Extjs_Loader_getPath_php.js',false);

//echo JHTML::script('Ext.Loader.setConfig({enabled: true});
                  //  Ext.onReady(function(){ 
                   //  });',false);

//echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/RowEditing.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/GridOrdering.js',false);
//echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/HelpQtip.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/FieldHelp.js',false);

echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/filter/Filter.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/filter/StringFilter.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/filter/DateFilter.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/filter/ListFilter.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/filter/NumericFilter.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/gridfilters/filter/BooleanFilter.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/ext/ux/IFrame.js',false);
echo JHTML::script('administrator/components/com_jgrid/os/jgrid/Custom_JSON.js',false);

//echo JHTML::script('administrator/components/com_jgrid/os/ext/jgrid.js',false);
ob_start();
//load the jgrid component to the users screen
//require(JPATH_BASE . '/components/com_jgrid/views/jgrids/config-grid.php' );



//JToolBarHelper::preferences( 'com_jgrid' )
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/Config.php' );
require(JPATH_BASE . '/components/com_jgrid/os/jgrid/CustomVtypes.php' );
//require(JPATH_BASE . '/components/com_jgrid/os/ext/ux/Printer.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/model/JGridModels.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/store/JGridStores.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/store/JGridComboStores.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridHelp.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/renderers/JGridCombos.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/renderers/JGridColumns.php' );
//require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/AddColumnToolbar.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridToolbar2.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridToolbar15.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridGrid2.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridGrid15.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridSelectionWin.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridGridSettings.php' );
//require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridAddColumnsToGrid.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridModifyListsWin.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridToolbar0.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridToolbar1.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/controller/JGridController0.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridGrid0.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridGrid1.php' );
if($fversion==0)
{
	
	require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridDefaultGroupRights.php' );
	require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridAccessRules.php' );	
	require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridToolbar4.php' );
	require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridToolbar7.php' );
	require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridToolbar8.php' );
	require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridGrid8.php' );	
	require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridGrid4.php' );
	require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/JGridGrid7.php' );
}
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app/view/Viewport.php' );
require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/Initalize.php' );

require(JPATH_BASE . '/components/com_jgrid/views/jgrids/js/app.php' );

$script = ob_get_clean();
$document->addScriptDeclaration($script);
ob_start();
?>
<style>
.grid-row-insert-below {
	border-bottom: 1px solid #3366cc;
}

.grid-row-insert-above {
	border-top: 1px solid #3366cc;
}
</style>
<div id="editcell"></div>
<!--<form action="<?php echo JRoute::_('index.php?option=com_jgrid');?>" method="post" name="adminForm" id="adminForm">
   <div>
		<input type="hidden" name="task" value="" />
		<?php echo JHtml::_('form.token'); ?>
	</div>
</form>-->
