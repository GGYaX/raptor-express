<?php

/**
 * functions in Joomla/Administrator/Components/os/jgrid
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

# Don't allow direct linking
defined( '_JEXEC' ) or die( 'Restricted access' );
//define a maxim size for the uploaded images
define ("MAX_USER_DIR_SIZE",500000000);
//require(JPATH_BASE . '/components/com_jgrid/os/jgrid/functions.php' );
define("FIRSTROW", 1);
define("ADD_ROW_ABOVE", 2);
define("ADD_ROW_BELOW", 3);
define("MAX_DATA_COLUMNS", 290);



//$params = JComponentHelper::getParams('com_jgrid');
// define free version
if((JRequest::getVar('application_type','','','STRING')=='MODULE'))
{
	jimport( 'joomla.application.module.helper' );
	$app = JFactory::getApplication();
	$module = JModuleHelper::getModule(JRequest::getVar('jgrid_application_name'));
	$params = new JRegistry();
	if(class_exists('JParameter'))
	{
		$params = new JParameter( $module->params ); 
	}
	else 
	{
	   $params->loadString($module->params);
	}	
}
else 
{
	$params = JComponentHelper::getParams('com_jgrid');
}
//JError::raiseError(1010,$params->get ('jgrid_width'));
//return;

$params->set('fversion',1);
$fversion = 1;


//
// remove_comments will strip the sql comment lines out of an uploaded sql file
// specifically for mssql and postgres type files in the install....
//
function remove_comments(&$output)
{
   $lines = explode("\n", $output);
   $output = "";

   // try to keep mem. use down
   $linecount = count($lines);

   $in_comment = false;
   for($i = 0; $i < $linecount; $i++)
   {
      if( preg_match("/^\/\*/", preg_quote($lines[$i])) )
      {
         $in_comment = true;
      }

      if( !$in_comment )
      {
         $output .= $lines[$i] . "\n";
      }

      if( preg_match("/\*\/$/", preg_quote($lines[$i])) )
      {
         $in_comment = false;
      }
   }

   unset($lines);
   return $output;
}

//
// remove_remarks will strip the sql comment lines out of an uploaded sql file
//
function remove_remarks($sql)
{
   $lines = explode("\n", $sql);

   // try to keep mem. use down
   $sql = "";

   $linecount = count($lines);
   $output = "";

   for ($i = 0; $i < $linecount; $i++)
   {
      if (($i != ($linecount - 1)) || (strlen($lines[$i]) > 0))
      {
         if (isset($lines[$i][0]) && $lines[$i][0] != "#")
         {
            $output .= $lines[$i] . "\n";
         }
         else
         {
            $output .= "\n";
         }
         // Trading a bit of speed for lower mem. use here.
         $lines[$i] = "";
      }
   }

   return $output;

}

//
// split_sql_file will split an uploaded sql file into single sql statements.
// Note: expects trim() to have already been run on $sql.
//
function split_sql_file($sql, $delimiter)
{
   // Split up our string into "possible" SQL statements.
   $tokens = explode($delimiter, $sql);

   // try to save mem.
   $sql = "";
   $output = array();

   // we don't actually care about the matches preg gives us.
   $matches = array();

   // this is faster than calling count($oktens) every time thru the loop.
   $token_count = count($tokens);
   for ($i = 0; $i < $token_count; $i++)
   {
      // Don't wanna add an empty string as the last thing in the array.
      if (($i != ($token_count - 1)) || (strlen($tokens[$i] > 0)))
      {
         // This is the total number of single quotes in the token.
         $total_quotes = preg_match_all("/'/", $tokens[$i], $matches);
         // Counts single quotes that are preceded by an odd number of backslashes,
         // which means they're escaped quotes.
         $escaped_quotes = preg_match_all("/(?<!\\\\)(\\\\\\\\)*\\\\'/", $tokens[$i], $matches);

         $unescaped_quotes = $total_quotes - $escaped_quotes;

         // If the number of unescaped quotes is even, then the delimiter did NOT occur inside a string literal.
         if (($unescaped_quotes % 2) == 0)
         {
            // It's a complete sql statement.
            $output[] = $tokens[$i];
            // save memory.
            $tokens[$i] = "";
         }
         else
         {
            // incomplete sql statement. keep adding tokens until we have a complete one.
            // $temp will hold what we have so far.
            $temp = $tokens[$i] . $delimiter;
            // save memory..
            $tokens[$i] = "";

            // Do we have a complete statement yet?
            $complete_stmt = false;

            for ($j = $i + 1; (!$complete_stmt && ($j < $token_count)); $j++)
            {
               // This is the total number of single quotes in the token.
               $total_quotes = preg_match_all("/'/", $tokens[$j], $matches);
               // Counts single quotes that are preceded by an odd number of backslashes,
               // which means they're escaped quotes.
               $escaped_quotes = preg_match_all("/(?<!\\\\)(\\\\\\\\)*\\\\'/", $tokens[$j], $matches);

               $unescaped_quotes = $total_quotes - $escaped_quotes;

               if (($unescaped_quotes % 2) == 1)
               {
                  // odd number of unescaped quotes. In combination with the previous incomplete
                  // statement(s), we now have a complete statement. (2 odds always make an even)
                  $output[] = $temp . $tokens[$j];

                  // save memory.
                  $tokens[$j] = "";
                  $temp = "";

                  // exit the loop.
                  $complete_stmt = true;
                  // make sure the outer loop continues at the right point.
                  $i = $j;
               }
               else
               {
                  // even number of unescaped quotes. We still don't have a complete statement.
                  // (1 odd and 1 even always make an odd)
                  $temp .= $tokens[$j] . $delimiter;
                  // save memory.
                  $tokens[$j] = "";
               }

            } // for..
         } // else
      }
   }

   return $output;
}






// Finds depth of an array
function array_depth($array) {
    $max_indentation = 1;

    $array_str = print_r($array, true);
    $lines = explode("\n", $array_str);

    foreach ($lines as $line) {
        $indentation = (strlen($line) - strlen(ltrim($line))) / 4;

        if ($indentation > $max_indentation) {
                $max_indentation = $indentation;
        }
    }

    return ceil(($max_indentation - 1) / 2) + 1;
}

// Copy directorys and any files inside
function full_copy( $source, $target ) {
	if ( is_dir( $source ) ) {
		@mkdir( $target );
		$d = dir( $source );
		while ( FALSE !== ( $entry = $d->read() ) ) {
			if ( $entry == '.' || $entry == '..' ) {
				continue;
			}
			$Entry = $source . '/' . $entry;
			if ( is_dir( $Entry ) ) {
				full_copy( $Entry, $target . '/' . $entry );
				continue;
			}
			copy( $Entry, $target . '/' . $entry );
		}

		$d->close();
	}else {
		copy( $source, $target );
	}
}



// This function reads the extension of the file.
// It is used to determine if the file is an image by checking the extension.
function getExtension($str) {
	$i = strrpos($str,".");
	if (!$i) { return ""; }
	$l = strlen($str) - $i;
	$ext = substr($str,$i+1,$l);
	return $ext;
}

// check directory size
function dir_size($dir) {
	$totalsize=0;
	if ($dirstream = @opendir($dir)) {
		while (false !== ($filename = readdir($dirstream))) {
			if ($filename!="." && $filename!="..")
			{
				if (is_file($dir."/".$filename))
				$totalsize+=filesize($dir."/".$filename);

				if (is_dir($dir."/".$filename))
				$totalsize+=JgridModelJgrid_images::dir_size($dir."/".$filename);
			}
		}
		closedir($dirstream);
	}
	return $totalsize;
}

// this is the function that will create the thumbnail image from the uploaded image
// the resize will be done considering the width and height defined, but without deforming the image
function make_directory($dir)
{

	// check on grid directory
	if(!(file_exists($dir) && is_dir($dir)))
	{
		if(!mkdir ($dir))
		{
			return array(false,JText::_("UNABLE_TO_MAKE_DIRECTORY").'" "'. $dir);
		}
		else // write index.html
		{
			$fptr= fopen($dir.'/index.html','x');
			if($fptr)
			{
				fwrite($fptr,'<html><body bgcolor="#FFFFFF"></body></html>');
				fclose($fptr);
			}
		}
	}
}

// removes all files from a directory and removes the directory
function fdestroy($dir) {
	if(file_exists($dir))
	{
		$mydir = opendir($dir);
		while(false !== ($file = readdir($mydir))) {
			if($file != "." && $file != "..")
			{

				$file_path= $dir.'/'.$file;
				chmod( $file_path, 0777);
				if(is_dir( $file_path)) {
					chdir('.');
					fdestroy( $file_path);
					rmdir( $file_path) or DIE("couldn't delete $dir$file<br />");
				}
				else
				{
					unlink( $file_path) or DIE("couldn't delete  $file_path<br />");
				}
			}
		}
		closedir($mydir);
		rmdir($dir);
	}
}

/**
 * Checks size of directory storage and then Sets Images on image File Paths
 * @return paths and image file name
 */
function check_image_path($grid_id,$current_document_id,$column_id,$row_id,$max_image_size,$image_extension)
{
	// check to see if user directory exists for this grid/document, if not create one.
	make_directory(JPATH_BASE.'/media/com_jgrid');
	make_directory(JPATH_BASE.'/media/com_jgrid/grid_'. $grid_id);
	$grid_doc_dir= '/grid_'. $grid_id.'/document_'. $current_document_id;
	$dir = JPATH_BASE.'/media/com_jgrid'.$grid_doc_dir;

	make_directory($dir);
	
	if((JRequest::getVar('application_type','','','STRING')=='MODULE'))
	{
		$module = JModuleHelper::getModule(JRequest::getVar('jgrid_application_name'));
		$params = new JRegistry();
		if(class_exists('JParameter'))
		{
			$params = new JParameter( $module->params ); 
		}
		else 
		{
		   $params->loadString($module->params);
		}	
	}
	else 
	{
		$params = JComponentHelper::getParams('com_jgrid');
	}
		
	
	

	// check directory size to make sure there is room to save file
	if($params->get ('max_user_directory_size'))
	{
		$max_user_directory_size = $params->get ('max_user_directory_size');
	}
	else $max_user_directory_size =  MAX_USER_DIR_SIZE;

	if(dir_size($dir)>$max_user_directory_size)
	{
		return array(false,JText::_("MAX_IMAGE_DIRECTORY_SIZE_OF").'" "'.$max_image_size.'" "'.JText::_("EXCEEDED_YOUR_MAX_IMAGE_DIRECTORY_SIZE_IS").'" "'.$max_image_size .'" "'.JText::_("PLEASE_UPGRADE_YOUR_CLUB_USER_STORAGE_LIMIT"));
	}

	$imgpath =  $grid_id. '_'. $current_document_id. '_'.$column_id. '_'.$row_id;
	$imgname = $dir    . '/'. $imgpath  . '_orig.'. $image_extension;
	return array($grid_doc_dir,$imgpath,$imgname,$dir);
}

/**
 * Delete Images on image delete or row delete or sheet delete or grid delete
 * @return integer return true if image deleted or false if delete failed.
 */
function delete_images($delete_type,$grid_id, $document_id, $column_id, $row_id)
{
	$db =JFactory::getDBO();
	switch ($delete_type)
	{
		//Grid
		case 'G':
			// delete any images associated with the document from hard drive
			$dir = JPATH_BASE.'\media\com_jgrid\grid_'. $grid_id;
			fdestroy($dir);

			// delete references in jgrid_images
			$db->setQuery('DELETE FROM  #__jgrid_images
		    	                 WHERE grid_id = '.$grid_id);
			$db->query();
			break;
		 // Sheet
		case 'S':
			// delete any images associated with the document from hard drive
			$dir = JPATH_BASE.'\media\com_jgrid\grid_'. $grid_id.'\document_'. $document_id;
			fdestroy($dir);

			// delete references in jgrid_images
			$db->setQuery('DELETE FROM  #__jgrid_images
			                  WHERE document_id = '.$document_id);
			$db->query();
			break;
			//row
		case 'R':
			$file_path = JPATH_BASE.'\media\com_jgrid\grid_'. $grid_id.'\document_'. $document_id .'\\'. $grid_id. '_'. $document_id. '_*_'. $row_id.'*.*' ;
			foreach (glob($file_path) as $filename)
			{
				chmod( $filename, 0777);
				unlink( $filename) or DIE("couldn't delete  $file_path<br />");
			}
			// delete references in jgrid_images
			$db->setQuery('DELETE FROM  #__jgrid_images
			                  WHERE row_id = '.$row_id);
			$db->query();
			break;
			//Cell
		case 'C':
			$file_path = JPATH_BASE.'\media\com_jgrid\grid_'. $grid_id.'\document_'. $document_id .'\\'. $grid_id. '_'. $document_id. '_'.$column_id. '_'. $row_id.'*.*' ;
			foreach (glob($file_path) as $filename)
			{
				chmod( $filename, 0777);
				unlink( $filename) or DIE("couldn't delete  $file_path<br />");
			}
			// delete references in jgrid_images
			$db->setQuery('DELETE FROM  #__jgrid_images
			                      WHERE row_id = '.$row_id.'
			                        AND columngrid_id='.$column_id);
			$db->query();
			break;

	}
	return true;

}

/**
 * Copy Images on row or document copy copy and rename any images in row or document
 * @return integer return true if image copied or false if image copy failed.
 */
function copy_images($copy_type, $grid_id, $from_document_id, $to_document_id, $column_id, $from_row_id, $to_row_id)
{
	$db =JFactory::getDBO();
	$user=JFactory::getUser();


	// save image cell data
	$query = 'SELECT grid_id,
		             document_id,
		             columngrid_id,
                     column_id,
                     row_id,  
                     filename,
                     file_type,
                     file_size,
                     image_thumb_path,
                     tooltip,
                     hyper_url,
                     image_email,
                     hyper_grid_sheet,
                     extension,
                     userid
              FROM #__jgrid_images
              WHERE grid_id = '.$grid_id.'
                AND document_id = '.$from_document_id.'
                AND columngrid_id = '.$column_id.'
                AND row_id = '.$from_row_id;
	//echo 'sql'.$query;
	$db->setQuery($query);
	$old_row_data = $db->loadObject();
	//echo 'sql1'.print_r($old_row_data).'sql'.$query;

	list($grid_doc_dir,$imgpath,$imgname, $dir) = check_image_path($grid_id,$to_document_id,$column_id,$to_row_id,$old_row_data->file_size,$old_row_data->extension);


	$query = 'INSERT INTO #__jgrid_images (grid_id,
		                                   document_id,
		                                   columngrid_id,
                                           column_id,
                                           row_id,  
                                           filename,
                                           file_type,
                                           file_size,
                                           image_thumb_path,
                                           tooltip,
                                           hyper_url,
                                           image_email,
                                           hyper_grid_sheet,
                                           extension,
                                           userid) 
              VALUES ('. $grid_id.',
		              '. $to_document_id.',
		              '. $columngrid_id.',
                      '. $column_id.',
                      '. $to_row_id.',  
                      "'.$old_row_data->filename.'",
                      "'.$old_row_data->file_type.'",
                      "'.$old_row_data->file_size.'",
                      "'.$grid_doc_dir . '/'. $imgpath .'_thumb.png",
                      "'.$old_row_data->tooltip.'",
                      "'.$old_row_data->hyper_url.'",
                      "'.$old_row_data->image_email.'",
                      "'.$old_row_data->hyper_grid_sheet.'",
                      "'.$old_row_data->extension.'",                                            
                      '.$user->id.')';
	
	$db->setQuery($query);
	$result = $db->query();

	// copy thumbnail
	$from=JPATH_BASE.'/media/com_jgrid'.$old_row_data->image_thumb_path;
	$to=JPATH_BASE.'/media/com_jgrid'.$grid_doc_dir . '/'. $imgpath .'_thumb.png';
	if (!copy($from,$to )) {
		echo "failed to copy thumbnail images...\n";
	}

	// copy original
	if (!copy(JPATH_BASE.'\media\com_jgrid\grid_'. $grid_id.'\document_'. $from_document_id .'\\'. $grid_id. '_'. $from_document_id. '_' .$column_id. '_'. $from_row_id.'_orig.jpg', $imgname)) {
		echo "failed to copy main images...\n";
	}
	return true;

}


// Corrects timezone warning on xampp
//date_default_timezone_set("America/New_York");

function createGridRow($table,$grid_id,$row_insert_position,$selected_row_number)
{

	//echo 'calldata row_inset_position = '.$row_insert_position.' selected_row_number = '.$selected_row_number;

	// add a row to the jgrid
	$db =JFactory::getDBO();
	$user =JFactory::getUser();
	$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
	// Find Insert Postion $row_insert_position == 1 is first new row, $row_insert_position == 3 is above current selected row , $row_insert_position == 4 is add below
	// Find Current Document ID
	$db->setQuery('SELECT current_document_id
	                          FROM #__jgrid_current_user_grid_document where userid = ' . $user->id .'
	                          AND grid_id = '.$grid_id);
	$current_document_id = $db->loadResult();
	
		//find document security types for creator lowest is most restrictive eg creator editable and viewable only to highest creator role editable public viewable
					$query = 'SELECT min(e.access_for_id)
		                   FROM #__jgrid_security e, 
		                        #__jgrid_role_userlist f
		                   WHERE e.access_for=4  
		                     AND ((e.access_type = 1                     
		                          AND e.access_subtype_grid_id = '.$grid_id.')
		                        OR (e.access_type = 3                     
		                          AND e.access_subtype_document_id = '.$current_document_id.') 		                        
		                        )';

					$db->setQuery($query);
					$creator_document_security_level = $db->loadResult();
	
	
	
	// set row access is
	if($creator_document_security_level>0)
	{
	   $row_access_id = "U".$user->id;
  }
  else
  {
    $row_access_id = "D";
  }
 

	//Insert new row_number in jgrid_rows
	$query = 'INSERT INTO '.$table.' (document_id,
                                      grid_id,
                                      ordering,
                                      creator_userid,
                                      row_access_id)
              VALUES ('.$current_document_id.',
                      '.$grid_id.',
                      999999,
                      ' . $user->id .',
                      "'.$row_access_id.'")';	
//echo 'sql'.$query;
	$db->setQuery($query);
	$_result = $db->query();
	// set id to new record id to return to
	$db->setQuery('SELECT last_insert_id()
		           FROM '.$table);
	$new_row_number = $db->loadResult();

	// check to see if new row needed for an empty query
	if($row_insert_position==FIRSTROW&&($selected_row_number==1||$selected_row_number==0))
	{
		// find last row number and its ordering
		$query = 'SELECT id, max(ordering)
	              FROM '.$table.'
	              WHERE grid_id = '.$grid_id.'
	                AND document_id = '.$current_document_id.'
	                AND ordering != 999999
	                GROUP BY ordering DESC
	                LIMIT 1';
		$db->setQuery($query);
		if($selected_row_number = $_result = $db->loadResult())
		{
			$row_insert_position = ADD_ROW_BELOW;
		}
		else
		{
			$row_insert_position = FIRSTROW;
			$selected_row_number = 0;
		}

	}

	// key == 1 is first new row, key == 3 is above current selected row , key == 4 is add below, key==5 is below but new last row
	if($row_insert_position==FIRSTROW)
	{
		//RMS Check to make sure there are no rows that were not paged. if there are add at row 1 and move all down  // removed userid check
		$query = 'SELECT id
	              FROM '.$table.'
	              WHERE grid_id = '.$grid_id.'
	                AND document_id = '.$current_document_id.'
	              ORDER BY ordering
	              LIMIT 1';
		$db->setQuery($query);
		$_result = $db->loadResult();
		//If not first row then insert above first row
		If($_result!=$new_row_number)
		{
			$row_insert_position==ADD_ROW_ABOVE;
			$selected_row_number=$_result;
		}
		else
		{
			//				JError::raiseError(1003, JText::_('sql'.$selected_row_number.'sql'.$query.'sql'));
			//return;
			//Start Row Numbering and linked list
			$db->setQuery('UPDATE '.$table.'
                                      SET parent_id = 0,
                                          ordering = 1
                                      WHERE id ='. $new_row_number);
			$db->query();
		}
	}
	// get next row number to insert above
	if($row_insert_position==ADD_ROW_ABOVE)
	{
		// Insert new row into linked list above selected
		// Find the parent_id and ordering of the selected row
		$db->setQuery('SELECT parent_id, ordering
		                     FROM '.$table.' 
                             WHERE id ='. $selected_row_number);	
		$_result = $db->loadObjectList();
		$selected_record_ordering=$_result[0]->ordering;
		$selected_record_parent_id=$_result[0]->parent_id;
		// point new row to row above selected
		$db->setQuery('UPDATE '.$table.'
                                  SET parent_id = '.$selected_record_parent_id.'
                                  WHERE id ='. $new_row_number);
		$db->query();
		//Point selected row to new row
		$db->setQuery('UPDATE '.$table.'
                                  SET parent_id = '.$new_row_number.'
                                  WHERE id ='. $selected_row_number);
		$db->query();
		// re-order ordering for select order by
		// Move all rows under new row down by 1
		$db->setQuery('UPDATE '.$table.'
                                  SET ordering = ordering + 1
                                  WHERE ordering >= '.$selected_record_ordering.'
                                      AND document_id = '.$current_document_id.'
                                      AND grid_id = '.$grid_id.'
                                  ORDER BY ordering');
		$db->query();
		// Update new row order
		$db->setQuery('UPDATE '.$table.'
                                      SET ordering = '.$selected_record_ordering.'
                                      WHERE id ='. $new_row_number);
		$db->query();
	}
	// assign row number below current
	if($row_insert_position==ADD_ROW_BELOW)
	{
		// Insert new row into linked list below selected
		// Find row below selected row

		$query = 'SELECT id, parent_id, ordering
		                         FROM '.$table.' 
                                 WHERE id = (SELECT id 
                                             FROM 
                                                (SELECT id 
                                                     FROM '.$table.' 
                                                     WHERE parent_id = '.$selected_row_number.')
                                                 AS temp_table1)';	
		$db->setQuery($query);
		$_result = $db->loadObjectList();
		//echo 'result'.$query;
		if($_result)
		{

			// get row data for row below selected row
			$below_selected_row_number=$_result[0]->id;
			$below_selected_record_ordering=$_result[0]->ordering;
			$below_selected_record_parent_id=$_result[0]->parent_id;
			//echo 'below row number '.$below_selected_row_number.'below ordering'.$below_selected_record_ordering.'below parent'.$below_selected_record_parent_id;
			// point new row to selected row
			$db->setQuery('UPDATE '.$table.'
                                          SET parent_id = '.$selected_row_number.'
                                           WHERE id ='. $new_row_number);
			$db->query();
			//Point row below selected row to new row
			$db->setQuery('UPDATE '.$table.'
                                          SET parent_id = '.$new_row_number.'
                                          WHERE id ='. $below_selected_row_number);
			$db->query();
			// re-order ordering for select order by
			// Move all rows under new row down by 1

			$query = 'UPDATE '.$table.' SET ordering = ordering + 1
                                       WHERE ordering >= '.$below_selected_record_ordering.'
                                          AND document_id = '.$current_document_id.'
                                          AND grid_id = '.$grid_id.'
                                       ORDER BY ordering';
			$db->setQuery($query);
			//echo 'ordering'.$query;
			$db->query();
			// Update new row order
			$db->setQuery('UPDATE '.$table.'
                                          SET ordering = '.$below_selected_record_ordering.',
                                              parent_id = '.$selected_row_number.'
                                          WHERE id ='. $new_row_number);
			$db->query();

		}
		else
		{
			// no row below selected row
			$db->setQuery('SELECT ordering
		                     FROM '.$table.' 
                             WHERE id ='. $selected_row_number);
			$selected_record_ordering = $db->loadResult();

			// point new row to row above selected
			$db->setQuery('UPDATE '.$table.'
                                  SET parent_id = '.$selected_row_number.',
                                      ordering = '.$selected_record_ordering.' + 1
                                  WHERE id ='. $new_row_number);
			$db->query();
			//			$db->setQuery('INSERT
			//					          INTO '.$table.'
			//		                                     (parent_id,
			//		                                      ordering)
			//		                      SELECT parent_id
			//                              FROM
			//                                (SELECT id AS parent_id, ordering+1
			//                                 FROM '.$table.'
			//                                 WHERE id = '.$selected_row_number.')
			//                                 AS temp_table1)');
			//			$db->query();
		}
	}
	// Insert cell records into the columndata row
	$query = 'INSERT into #__jgrid_columndata (document_id,
		                                       column_id,
		                                       columngrid_id,
		                                       column_header, 
		                                       userid, 
		                                       row_number,
		                                       string_data,
                                               int_data,
                                               float_data,
                                               boolean_data,
                                               date_data)
       	                 SELECT  '.$current_document_id.',
       	                          a.id,
       	                          b.id, 
       	                          a.header,
       	                          "' . $user->id . '",
       	                          "' . $new_row_number .'",
       	                          IF((a.data_type="T" OR a.data_type="L") ,a.ddefault,NULL),
       	                          CASE a.data_type WHEN "I" THEN a.ddefault WHEN "R" THEN "' . $new_row_number .'" ELSE NULL END,
       	                          IF(a.data_type="F",a.ddefault,NULL),
       	                          IF(a.data_type="B",a.ddefault,NULL),
       	                          IF(a.data_type="D",a.ddefault,NULL)
                        FROM  #__jgrid_columns a, 
                              #__jgrid_columngrid b
	                    WHERE b.grid_id = '.$grid_id.'
	                       AND a.id = b.column_id';
	
	$db->setQuery($query);
//echo 'sql'.$query;
	$_result = $db->query();
	$row_data[0]["id"]=$new_row_number;
	$row_data[0]["editable_line"]=1;
	if($_result) return $row_data[0];
	else return false;
}


/**
 * Moves grid order in  "Data Grid Settings" grid
 * @return integer result true if grid moved or false if move failed
 */
function moveGridRow($table,$grid_id,$number_of_records_to_copy,$new_above_record_id,$new_record_below_id,$first_record_id,$last_record_id )
{
	$db =JFactory::getDBO();
	$user =JFactory::getUser();
	$now_row_below=false;
	$new_above_record_id=JRequest::getVar('new_above_record_id','','','INTEGER');
	
	// find if after drag type
	if($new_record_below_id==-1) 
	{
		//Get record id below new insert record location in case paging active and records above visible page
		$query = 'SELECT id
			       		FROM '.$table.'
       	                WHERE parent_id ='.$new_above_record_id;
		$db->setQuery($query);
		$new_record_below_id = $db->loadResult();		
	}
	
	// Get first record ordering
	$db->setQuery('SELECT ordering
                              FROM '.$table.' 
                              WHERE id ='.$last_record_id);
	$last_record_ordering=$db->loadResult();
	// Get last record ordering
	$db->setQuery('SELECT ordering
                              FROM '.$table.' 
                              WHERE id ='.$first_record_id);
	$first_record_ordering=$db->loadResult();
	$original_first_record_ordering = $first_record_ordering;
//echo 'First Record Original Ordering = '.$original_first_record_ordering;
//echo 'Last Record Ordering'.$last_record_ordering;	
	// if records were selected largest to smallest by user then switch to re-align order from first to last
	if($first_record_ordering > $last_record_ordering)
	{
		$temprow_id = $first_record_id;
		$temprow_ordering = $first_record_ordering;
		$first_record_id = $last_record_id;
		$first_record_ordering = $last_record_ordering;
		$last_record_id = $temprow_id;
		$last_record_ordering = $temprow_ordering;
	}
	// GEt current document id
	$db->setQuery('SELECT current_document_id
	                          FROM #__jgrid_current_user_grid_document where userid = ' . $user->id .'
	                          AND grid_id = '.$grid_id);
	$current_document_id = $db->loadResult();

	if($new_above_record_id==-1) // top row shown on screen
	{
		//Get record id above new insert record location in case paging active and records above visible page
		$db->setQuery('SELECT parent_id
		               FROM '.$table.'
                       WHERE id ='.$new_record_below_id);
		$new_above_record_id = $db->loadResult();
		if($new_above_record_id) // record found above visible screen
		{
			//Get new_above_record_ordering
			$db->setQuery('SELECT ordering
		                   FROM '.$table.'
                           WHERE id ='.$new_above_record_id);
			$new_above_record_ordering=$db->loadResult();
		}
		else //top row in stack
		{
// echo 'first row ordering, new above record ID  = '.$new_above_record_id;			
			$new_above_record_id=0; // set to top row, top of stack
			$new_above_record_ordering =0;
		   // $first_record_ordering = 1; // RMS works for down needs to not be used for up
		}	
	}
	else
	{		
		if($new_record_below_id==-1) // record below screen
		{
			//Get record id below new insert record location in case paging active and records above visible page
			$db->setQuery('SELECT id
			               FROM '.$table.'
       	                WHERE parent_id ='.$new_above_record_id);
			$new_record_below_id = $db->loadResult();
			if(!$new_record_below_id) // record found above visible screen
			{
				$new_record_below_id=-1; // set to bottom row,bottom of stack
				$no_row_below==true;
			
			}
		}
		else
		{
			//Get record id below new insert record location
			$db->setQuery('SELECT id
		               FROM '.$table.'
                       WHERE parent_id ='.$new_above_record_id);
			$new_record_below_id = $db->loadResult();
			if(!$new_record_below_id) $no_row_below=true;
		}
		//Get new_above_record_ordering
		$db->setQuery('SELECT ordering
		               FROM '.$table.'
                       WHERE id ='.$new_above_record_id);
		$new_above_record_ordering=$db->loadResult();	
	}

	$db->setQuery('SELECT parent_id
		           FROM '.$table.' 
                   WHERE id ='.$first_record_id);
	$old_record_above_id=$db->loadResult();
	$db->setQuery('UPDATE '.$table.'
                             SET parent_id = '.$old_record_above_id.'
                             WHERE id = (SELECT id FROM
                                                  (SELECT id 
                                                   FROM '.$table.' 
                                                   WHERE parent_id ='.$last_record_id.') AS temp_table1)');
	$db->query();
	// insert rows back into linked list
	// insert bottom row
	if($no_row_below==false)
	{
		$db->setQuery('UPDATE '.$table.'
                                  SET parent_id = '.$last_record_id.'
                                  WHERE id ='. $new_record_below_id);
		$db->query();
	}

	// Insert top row
	$db->setQuery('UPDATE '.$table.'
                             SET parent_id = '.$new_above_record_id.'
                             WHERE id = '.$first_record_id); 
	$db->query();

	// now move the ordering to match
	// if(JRequest::getVar('newIndex','','','INTEGER') <= JRequest::getVar('oldIndex','','','INTEGER'))
	if($new_above_record_ordering <= $original_first_record_ordering)
	{
//echo 'first record ordering = '.$first_record_ordering;
//echo 'new_above_record_ordering = '.$new_above_record_ordering;
//echo 'last_record_ordering = '.$last_record_ordering;		
		// Select column rows to be moved out of ordering by adding 999999999 to order
		$db->setQuery('UPDATE '.$table.'
                            SET ordering = ordering
                                           + 999999999
                                           - '.$first_record_ordering.'
                                           + '.$new_above_record_ordering.'
                                           +1
                            WHERE ordering >=  '.$first_record_ordering.'
                              AND   ordering <= '.$last_record_ordering.'
                              AND document_id = '.$current_document_id.'
                              AND grid_id = '.$grid_id.'
                            ORDER BY ordering');
		$db->query();
		// Make row for moved columns
		$db->setQuery('UPDATE '.$table.'
                                  SET ordering = ordering
                                                 + '.$number_of_records_to_copy.'
                                  WHERE ordering > '.$new_above_record_ordering.'
                                    AND   ordering <= '.$last_record_ordering.'
                                    AND document_id = '.$current_document_id.'
                                    AND grid_id = '.$grid_id.'
                                  ORDER BY ordering');
		$db->query();
	}
//	else if (JRequest::getVar('newIndex','','','INTEGER') > JRequest::getVar('oldIndex','','','INTEGER'))
	else if($new_above_record_ordering > $original_first_record_ordering)
	{
		
//echo 'first record ordering = '.$first_record_ordering;
//echo 'new_above_record_ordering = '.$new_above_record_ordering;
//echo 'last_record_ordering = '.$last_record_ordering;		
		// Select column rows to be moved out of ordering by adding 999999999 to order
		$db->setQuery('UPDATE '.$table.'
                            SET ordering = ordering
                                           + 999999999
                                           - '.$first_record_ordering.'
                                           + '.$new_above_record_ordering.'
                                           - '.$number_of_records_to_copy.'
                                           +1
                            WHERE ordering >=  '.$first_record_ordering.'
                              AND   ordering <= '.$last_record_ordering.'
                              AND document_id = '.$current_document_id.'
                              AND grid_id = '.$grid_id.'
                            ORDER BY ordering');
		$db->query();
		// Make roow for moved columns
		$db->setQuery('UPDATE '.$table.'
                                  SET ordering = ordering
                                                 - '.$number_of_records_to_copy.'
                                  WHERE ordering <= '.$new_above_record_ordering.'
                                    AND   ordering > '.$first_record_ordering.'
                                    AND document_id = '.$current_document_id.'
                                    AND grid_id = '.$grid_id.'
                                  ORDER BY ordering');
		$db->query();
	}
	else return true;

	// Insert new columns into order
	$db->setQuery('UPDATE '.$table.'
                            SET ordering = ordering - 999999999 
                            WHERE ordering >= 999999999
                              AND document_id = '.$current_document_id.' 
                              AND grid_id = '.$grid_id.'     
                            ORDER BY ordering'); 
	if($db->query())return true;
	else return false;
}



/**
 * copy grid order in  "Data Grid Settings" grid
 * @return integer result true if grid moved or false if move failed
 */
function copyGridRow($table,$grid_id,$number_of_records_to_copy,$new_above_record_id,$new_record_below_id,$first_record_id,$last_record_id )
{
	$db =JFactory::getDBO();
	$user=JFactory::getUser();
	$now_row_below=false;
	$new_above_record_id=JRequest::getVar('new_above_record_id','','','INTEGER');
	// Get first record ordering
	$db->setQuery('SELECT ordering
                              FROM '.$table.' 
                              WHERE id ='.$last_record_id);
	$last_record_ordering=$db->loadResult();
	// Get last record ordering
	$db->setQuery('SELECT ordering
                              FROM '.$table.' 
                              WHERE id ='.$first_record_id);
	$first_record_ordering=$db->loadResult();

	// if records were selected largest to smallest by user then switch to re-align order from first to last
	if($first_record_ordering > $last_record_ordering)
	{
		$temprow_id = $first_record_id;
		$temprow_ordering = $first_record_ordering;
		$first_record_id = $last_record_id;
		$first_record_ordering = $last_record_ordering;
		$last_record_id = $temprow_id;
		$last_record_ordering = $temprow_ordering;
	}
	// Get first record parent_id
	$db->setQuery('SELECT parent_id
                              FROM '.$table.' 
                              WHERE id ='.$first_record_id);
	$first_record_parent_id=$db->loadResult();


	// GEt current document id
	$db->setQuery('SELECT current_document_id
	                          FROM #__jgrid_current_user_grid_document where userid = ' . $user->id .'
	                          AND grid_id = '.$grid_id);
	$current_document_id = $db->loadResult();
	if($new_above_record_id==-1) // top row shown on screen
	{
		//Get record id above new insert record location in case paging active and records above visible page
		$db->setQuery('SELECT parent_id
		               FROM '.$table.'
                       WHERE id ='.$new_record_below_id);
		$new_above_record_id = $db->loadResult();
		if($new_above_record_id) // record found above visible screen
		{
			//Get new_above_record_ordering
			$db->setQuery('SELECT ordering
		                   FROM '.$table.'
                           WHERE id ='.$new_above_record_id);
			$new_above_record_ordering=$db->loadResult();
		}
		else //top row in stack
		{
			$new_above_record_id=0; // set to top row, top of stack
			$new_above_record_ordering =0;
		}
	}
	else
	{
		//Get new_above_record_ordering
		$db->setQuery('SELECT ordering
		               FROM '.$table.'
                       WHERE id ='.$new_above_record_id);
		$new_above_record_ordering=$db->loadResult();
		//Get record id below new insert record location
		$db->setQuery('SELECT id
		               FROM '.$table.'
                       WHERE parent_id ='.$new_above_record_id);
		$new_record_below_id = $db->loadResult();
		if(!$new_record_below_id) $no_row_below=true;
	}


	//Get record id above first record_id to be moved and first record ordering
	//		$_query = 'SELECT parent_id, ordering
	//		                      FROM '.$table.'
	//                              WHERE id ='.JRequest::getVar('first_record_id','','','INTEGER');
	//		$_result = $_getList( $_query );
	//	$db->setQuery('SELECT parent_id, ordering
	//		           FROM '.$table.'
	//                   WHERE id ='.$first_record_id);
	//	$_result = $db->loadObjectList();
	//	$first_record_ordering=$_result[0]->ordering;
	//	$old_record_above_id=$_result[0]->parent_id;
	//		//Get record id below last record to be moved
	//		$db->setQuery('SELECT id
	//                              FROM '.$table.'
	//                              WHERE parent_id ='.JRequest::getVar('last_record_id','','','INTEGER'));
	//		$old_record_below_id=$db->loadResult();



	// Make room for moved columns
	$db->setQuery('UPDATE '.$table.'
                                  SET ordering = ordering
                                                 + '.$number_of_records_to_copy.'
                                  WHERE ordering > '.$new_above_record_ordering.'
                                  ORDER BY ordering');
	$db->query();

	// select row numbers to be copied data transversing the linked list paretn_id.
	$query = 'SELECT   DISTINCT       a.id,
				                          a.parent_id
				                   FROM (
				                          SELECT @r AS _parent,
		                                            @r :=
		                                            (
		                                             SELECT  id
		                                             FROM    '.$table.'
		                                             WHERE   parent_id = _parent
		                                             AND document_id = '.$current_document_id.'
		                                            ) AS id
			                              FROM  (
		                                     SELECT  @r := '.$first_record_parent_id.'
		                                     ) vars,
		                                     '.$table.'
		                                     WHERE @r IS NOT NULL
		                                     AND document_id = '.$current_document_id.'
		                                     )q
				          JOIN '.$table.' a
		                  ON a.id = q.id
		                  AND a.document_id = '.$current_document_id.'
		                  LIMIT '.$number_of_records_to_copy;
	//echo 'sql'.$query;
	$db->setQuery($query);
	$_list_of_records_to_be_copied = $db->loadObjectList();
	//echo 'sql'.print_r($_list_of_records_to_be_copied).'sql'.$query;
	//return;


	// Insert cell records into the columndata row  // select into from copied rows and add ordering
	//select from first record id to last record id by walking linked list into new columns update ordering from order above + 1
	$new_row_number_ordering=$new_above_record_ordering+1;
	$previous_new_record_id=$new_above_record_id;
	for ($i=0;$i<count($_list_of_records_to_be_copied);$i++)
	{

		//Insert new row_number in jgrid_rows
		$query = 'INSERT INTO '.$table.' (document_id,
	                                             ordering,
	                                             parent_id,
                                                 grid_id)
                                VALUES ('.$current_document_id.',
                                        '.$new_row_number_ordering.',
                                        '.$previous_new_record_id.',                                   
                                        '.$grid_id.')';

		$db->setQuery($query);
		$_result = $db->query();
		$new_row_number_ordering=$new_row_number_ordering+1;

		// set id to new record id to return to
		$db->setQuery('SELECT last_insert_id()
		                      FROM '.$table);
		$new_row_number = $db->loadResult();
		$previous_new_record_id=$new_row_number;
		$query = 'INSERT into #__jgrid_columndata (document_id,
														  columngrid_id,
		                                                  column_id,
		                                                  column_header, 
		                                                  userid, 
		                                                  row_number,
		                                                  string_data,
                                                          int_data,
                                                          float_data,
                                                          boolean_data,
                                                          date_data)
       	                 SELECT  '.$current_document_id.',
       	                 		 columngrid_id,
		                         column_id,
		                         column_header, 
		                         '.$user->id.', 
		                         '.$new_row_number.',
		                         string_data,
                                 int_data,
                                 float_data,
                                 boolean_data,
                                 date_data     	                            
                        FROM  #__jgrid_columndata a
	                    WHERE row_number = '.$_list_of_records_to_be_copied[$i]->id;
		//echo 'sql'.$query.'  ivalue'.$i.'  list of records'.$_list_of_records_to_be_copied[$i]->id;
		$db->setQuery($query);
		$db->query();
		// copy and rename images
		$query = 'SELECT column_id
              FROM #__jgrid_images
              WHERE grid_id = '.$grid_id.'
                AND document_id = '.$current_document_id.'
                AND row_id = '.$_list_of_records_to_be_copied[$i]->id; 
		$db->setQuery($query);
		$image_ids_to_copy = $db->loadObjectList();
		for($j=0;$j<count($image_ids_to_copy);$j++)
		{
			copy_images('R',$grid_id, $current_document_id, $current_document_id, $image_ids_to_copy[$j]->column_id, $_list_of_records_to_be_copied[$i]->id, $new_row_number);
		}


		$_list_of_new_row_numbers[$i]=$new_row_number;
	}
	$new_last_record_id=$new_row_number;
	// insert rows back into linked list
	// insert bottom row
	if($no_row_below==false)
	{
		$db->setQuery('UPDATE '.$table.'
                                  SET parent_id = '.$new_last_record_id.'
                                  WHERE id ='. $new_record_below_id);
		$db->query();
	}

	//echo 'list'.$_list_of_new_row_numbers[0].'  '.$_list_of_new_row_numbers[1];
	if($_list_of_records_to_be_copied)return $_list_of_new_row_numbers;
	else return false;
}

/**
 * Removes row from the data grid row and all associated data from grid
 * @return integer result true if sheet removed or false if remove failed
 */
function deleteRow($grid_id,$current_document_id,$row_id )
{
	$db =JFactory::getDBO();
	$user=JFactory::getUser();
	$removed_row_numbers = '';
	
	// remove grid from linked list row order
	// Get id of row below deleted row
	for($i=0;$i<count($row_id);$i++)
	{
		$db->setQuery('SELECT id
	                              FROM #__jgrid_rows 
	                              WHERE parent_id ='.$row_id[$i]['id']);
		$below_deleted_row_id = $db->loadResult();
		if($below_deleted_row_id)
		{
			$db->setQuery('UPDATE #__jgrid_rows
	                                  SET parent_id = (SELECT parent_id
	                                                   FROM 
	                                                     (SELECT parent_id 
	                                                      FROM #__jgrid_rows
	                                                      WHERE id ='.$row_id[$i]['id'].')
	                                                      AS temp_table1)
	                                 WHERE id = '.$below_deleted_row_id);
			$db->query();
	
			// Reorder column ordering below removed ID
			$db->setQuery('UPDATE #__jgrid_rows
	                                  SET ordering = ordering - 1
	                                  WHERE ordering >= (SELECT ordering 
	                                                     FROM
	                                                        (SELECT ordering 
	                                                         FROM #__jgrid_rows
	                                                         WHERE id = '.$below_deleted_row_id.')
	                                                         AS temp_table1)
	                                  AND document_id = '.$current_document_id.'                   
	                                  AND grid_id = '.$grid_id.'
		    	                      ORDER BY ordering');
		}
	
		// delete any images in the row
		delete_images('R',$grid_id,$current_document_id,'',$row_id[$i]['id']);
	
	
		$db->setQuery('DELETE FROM #__jgrid_columndata
			                      WHERE row_number = ' . $row_id[$i]['id']); 
		$db->query();
		$db->setQuery('DELETE FROM  #__jgrid_rows
				                  WHERE id = '.$row_id[$i]['id']);
		$result = $db->query();
		if($result) 
		{	
			if($removed_row_numbers) $removed_row_numbers .= ', ';	
			$removed_row_numbers .= $row_id[$i]['id'];
		} 
	}
	if($result) return $removed_row_numbers;
	else return false;
}



/**
 * Moves grid order in  "Data Grid Settings" grid
 * @return integer result true if grid moved or false if move failed
 */
function moveGrid($table,$number_of_records_to_copy,$new_above_record_id,$new_record_below_id,$first_record_id,$last_record_id )
{
	$db =JFactory::getDBO();
	$no_row_below=false;
	$new_above_record_id=JRequest::getVar('new_above_record_id','','','INTEGER');
	// Get first record ordering
	$db->setQuery('SELECT ordering
                              FROM '.$table.' 
                              WHERE id ='.$last_record_id);
	$last_record_ordering=$db->loadResult();
	// Get last record ordering
	$db->setQuery('SELECT ordering
                              FROM '.$table.' 
                              WHERE id ='.$first_record_id);
	$first_record_ordering=$db->loadResult();
	
	// find if after drag type
	if($new_record_below_id==-1) 
	{
		//Get record id below new insert record location in case paging active and records above visible page
		$query = 'SELECT id
			       		FROM '.$table.'
       	                WHERE parent_id ='.$new_above_record_id;
		$db->setQuery($query);
		$new_record_below_id = $db->loadResult();
//echo 'sql3 '.$query;		
	}
	
	// if records were selected largest to smallest by user then switch to re-align order from first to last
	if($first_record_ordering > $last_record_ordering)
	{
		$temprow_id = $first_record_id;
		$temprow_ordering = $first_record_ordering;
		$first_record_id = $last_record_id;
		$first_record_ordering = $last_record_ordering;
		$last_record_id = $temprow_id;
		$last_record_ordering = $temprow_ordering;
	}
	if($new_above_record_id==-1) // top row shown on screen or row above not known above drop
	{
		//Get record id above new insert record location in case paging active and records above visible page
		$db->setQuery('SELECT parent_id
		               FROM '.$table.'
                       WHERE id ='.$new_record_below_id);
		$new_above_record_id = $db->loadResult();
		if($new_above_record_id) // record found above visible screen
		{
			//Get new_above_record_ordering
			$db->setQuery('SELECT ordering
		                   FROM '.$table.'
                           WHERE id ='.$new_above_record_id);
			$new_above_record_ordering=$db->loadResult();
			//echo 'sql'.$new_above_record_ordering.'sql'.$new_above_record_id.'sql'.$new_record_below_id;
		}
		else //top row in stack
		{
			$new_above_record_id=0; // set to top row, top of stack
			$new_above_record_ordering =0;
			$first_record_ordering = 1;
		}
	}
	else 
	{
		
		if($new_record_below_id==-1) // record below screen
		{
			//Get record id below new insert record location in case paging active and records above visible page
			$db->setQuery('SELECT id
			               FROM '.$table.'
       	                WHERE parent_id ='.$new_above_record_id);
			$new_record_below_id = $db->loadResult();
			if(!$new_record_below_id) // record found above visible screen
			{
				$new_record_below_id=-1; // set to bottom row,bottom of stack
				$no_row_below==true;
			
			}
		}
		else
		{
			//Get record id below new insert record location
			$db->setQuery('SELECT id
		               FROM '.$table.'
                       WHERE parent_id ='.$new_above_record_id);
			$new_record_below_id = $db->loadResult();
			if(!$new_record_below_id) $no_row_below=true;
		}
		//Get new_above_record_ordering
		$db->setQuery('SELECT ordering
		               FROM '.$table.'
                       WHERE id ='.$new_above_record_id);
		$new_above_record_ordering=$db->loadResult();
	}
	//Get record id above first record_id to be moved and first record ordering
	$db->setQuery('SELECT parent_id
		           FROM '.$table.' 
                   WHERE id ='.$first_record_id);
	$old_record_above_id=$db->loadResult();
	
//echo 'sql1 last_record_id='.$last_record_id.', new_record_below_id='. $new_record_below_id.' new_above_record_id='.$new_above_record_id.' first_record_id='.$first_record_id;	
//echo 'sqls old_record_above_id='.$old_record_above_id.', last_record_ordering='. $last_record_ordering.' new_above_record_ordering='.$new_above_record_ordering.' first_record_ordering='.$first_record_ordering;		
//return;		
	
	
	//remove rows from list
	$db->setQuery('UPDATE '.$table.'
                             SET parent_id = '.$old_record_above_id.'
                             WHERE id = (SELECT id FROM
                                                  (SELECT id 
                                                   FROM '.$table.' 
                                                   WHERE parent_id ='.$last_record_id.') AS temp_table1)');
	$db->query();
	// insert rows back into linked list
	// insert bottom row
	if($no_row_below==false)
	{
		$db->setQuery('UPDATE '.$table.'
                                  SET parent_id = '.$last_record_id.'
                                  WHERE id ='. $new_record_below_id);
		$db->query();
	}

	// Insert top row
	$db->setQuery('UPDATE '.$table.'
                             SET parent_id = '.$new_above_record_id.'
                             WHERE id = '.$first_record_id); 
	$db->query();

	// now move the ordering to match
	if(JRequest::getVar('newIndex','','','INTEGER') <= JRequest::getVar('oldIndex','','','INTEGER'))
	{
		// Select column rows to be moved out of ordering by adding 999999999 to order
		$db->setQuery('UPDATE '.$table.'
                            SET ordering = ordering
                                           + 999999999
                                           - '.$first_record_ordering.'
                                           + '.$new_above_record_ordering.'
                                           +1
                            WHERE ordering >=  '.$first_record_ordering.'
                            AND   ordering <= '.$last_record_ordering.'
                            ORDER BY ordering');
		$db->query();
		// Make row for moved columns
		$db->setQuery('UPDATE '.$table.'
                                  SET ordering = ordering
                                                 + '.$number_of_records_to_copy.'
                                  WHERE ordering > '.$new_above_record_ordering.'
                                  AND   ordering <= '.$last_record_ordering.'
                                  ORDER BY ordering');
		$db->query();
	}
	else if (JRequest::getVar('newIndex','','','INTEGER') > JRequest::getVar('oldIndex','','','INTEGER'))
	{
		// Select column rows to be moved out of ordering by adding 999999999 to order
		$db->setQuery('UPDATE '.$table.'
                            SET ordering = ordering
                                           + 999999999
                                           - '.$first_record_ordering.'
                                           + '.$new_above_record_ordering.'
                                           - '.$number_of_records_to_copy.'
                                           +1
                            WHERE ordering >=  '.$first_record_ordering.'
                            AND   ordering <= '.$last_record_ordering.'
                            ORDER BY ordering');
		$db->query();
		// Make room for moved columns
		$db->setQuery('UPDATE '.$table.'
                                  SET ordering = ordering
                                                 - '.$number_of_records_to_copy.'
                                  WHERE ordering <= '.$new_above_record_ordering.'
                                  AND   ordering > '.$first_record_ordering.'
                                  ORDER BY ordering');
		$db->query();
	}
	else return true;

	// Insert new columns into order
	$db->setQuery('UPDATE '.$table.'
                            SET ordering = ordering - 999999999 
                            WHERE ordering >= 999999999      
                            ORDER BY ordering'); 
	if($db->query())return true;
	else return false;
}

/**
 * Moves grid order in  "Data Grid Settings" grid
 * @return integer result true if grid moved or false if move failed
 */
function moveGridColumn($table,$grid_id,$number_of_records_to_copy,$new_above_record_id,$new_record_below_id,$first_record_id,$last_record_id )
{
	$db =JFactory::getDBO();
	$now_row_below=false;
	$new_above_record_id=JRequest::getVar('new_above_record_id','','','INTEGER');
	$new_record_below_id=JRequest::getVar('new_record_below_id','','','INTEGER');
	// Get first record ordering
	$db->setQuery('SELECT ordering
                              FROM '.$table.' 
                              WHERE id ='.$last_record_id);
	$last_record_ordering=$db->loadResult();
	// Get last record ordering
	$db->setQuery('SELECT ordering
                              FROM '.$table.' 
                              WHERE id ='.$first_record_id);
	$first_record_ordering=$db->loadResult();
	// if records were selected largest to smallest by user then switch to re-align order from first to last
	if($first_record_ordering > $last_record_ordering)
	{
		$temprow_id = $first_record_id;
		$temprow_ordering = $first_record_ordering;
		$first_record_id = $last_record_id;
		$first_record_ordering = $last_record_ordering;
		$last_record_id = $temprow_id;
		$last_record_ordering = $temprow_ordering;
	}
	if($new_above_record_id==-1) // top row shown on screen
	{
		//Get record id above new insert record location in case paging active and records above visible page
		$db->setQuery('SELECT parent_id
		               FROM '.$table.'
                       WHERE id ='.$new_record_below_id);
		$new_above_record_id = $db->loadResult();
		if($new_above_record_id) // record found above visible screen
		{
			//Get new_above_record_ordering
			$db->setQuery('SELECT ordering
		                   FROM '.$table.'
                           WHERE id ='.$new_above_record_id);
			$new_above_record_ordering=$db->loadResult();
		}
		else //top row in stack
		{
			$new_above_record_id=0; // set to top row, top of stack
			$new_above_record_ordering =0;
		}
	}
	else if($new_above_record_id==-2) // middle row moving up shown on screen
	{
		//Get record id above new insert record location in case paging active and records above visible page
		$db->setQuery('SELECT parent_id
		               FROM '.$table.'
                       WHERE id ='.$new_record_below_id);
		$new_above_record_id = $db->loadResult();

		//Get new_above_record_ordering
		$db->setQuery('SELECT ordering
		                   FROM '.$table.'
                           WHERE id ='.$new_above_record_id);
		$new_above_record_ordering=$db->loadResult();
	}
	else if($new_above_record_id==-3) // middle row shown on screen moving down
	{		
		//Get record id above new insert record location in case paging active and records above visible page
		$db->setQuery('SELECT id
		               FROM '.$table.'
                       WHERE parent_id ='.$new_record_above_id);
		$new_below_record_id = $db->loadResult();

		//Get new_below_record_ordering
		$db->setQuery('SELECT ordering
		                   FROM '.$table.'
                           WHERE id ='.$new_below_record_id);
		$new_below_record_ordering=$db->loadResult();
	}
	else
	{
		//Get new_above_record_ordering
		$db->setQuery('SELECT ordering
		               FROM '.$table.'
                       WHERE id ='.$new_above_record_id);
		$new_above_record_ordering=$db->loadResult();
		//Get record id below new insert record location
		$db->setQuery('SELECT id
		               FROM '.$table.'
                       WHERE parent_id ='.$new_above_record_id);
		$new_record_below_id = $db->loadResult();
		if(!$new_record_below_id) $no_row_below=true;
	}
	//Get record id above first record_id to be moved and first record ordering

	$db->setQuery('SELECT parent_id
		           FROM '.$table.' 
                   WHERE id ='.$first_record_id);
	$old_record_above_id=$db->loadResult();
	//		//Get record id below last record to be moved
	//		$db->setQuery('SELECT id
	//                              FROM '.$table.'
	//                              WHERE parent_id ='.JRequest::getVar('last_record_id','','','INTEGER'));
	//		$old_record_below_id=$db->loadResult();
	//remove rows from list
	$db->setQuery('UPDATE '.$table.'
                             SET parent_id = '.$old_record_above_id.'
                             WHERE id = (SELECT id FROM
                                                  (SELECT id 
                                                   FROM '.$table.' 
                                                   WHERE parent_id ='.$last_record_id.') AS temp_table1)');
	$db->query();
	// insert rows back into linked list
	// insert bottom row
	if($no_row_below==false)
	{
		$db->setQuery('UPDATE '.$table.'
                                  SET parent_id = '.$last_record_id.'
                                  WHERE id ='. $new_record_below_id);
		$db->query();
	}

	// Insert top row
	$db->setQuery('UPDATE '.$table.'
                             SET parent_id = '.$new_above_record_id.'
                             WHERE id = '.$first_record_id); 
	$db->query();

	// now move the ordering to match
	if(JRequest::getVar('newIndex','','','INTEGER') <= JRequest::getVar('oldIndex','','','INTEGER'))
	{
		// Select column rows to be moved out of ordering by adding 999999999 to order
		$db->setQuery('UPDATE '.$table.'
                            SET ordering = ordering
                                           + 999999999
                                           - '.$first_record_ordering.'
                                           + '.$new_above_record_ordering.'
                                           +1
                            WHERE ordering >=  '.$first_record_ordering.'
                            AND   ordering <= '.$last_record_ordering.'
                            AND grid_id = '.$grid_id.'
                            ORDER BY ordering');
		$db->query();
		// Make row for moved columns
		$db->setQuery('UPDATE '.$table.'
                                  SET ordering = ordering
                                                 + '.$number_of_records_to_copy.'
                                  WHERE ordering > '.$new_above_record_ordering.'
                                  AND   ordering <= '.$last_record_ordering.'
                                  AND grid_id = '.$grid_id.'
                                  ORDER BY ordering');
		$db->query();
	}
	else if (JRequest::getVar('newIndex','','','INTEGER') > JRequest::getVar('oldIndex','','','INTEGER'))
	{
		// Select column rows to be moved out of ordering by adding 999999999 to order
		$db->setQuery('UPDATE '.$table.'
                            SET ordering = ordering
                                           + 999999999
                                           - '.$first_record_ordering.'
                                           + '.$new_above_record_ordering.'
                                           - '.$number_of_records_to_copy.'
                                           +1
                            WHERE ordering >=  '.$first_record_ordering.'
                            AND   ordering <= '.$last_record_ordering.'
                            AND grid_id = '.$grid_id.'
                            ORDER BY ordering');
		$db->query();
		// Make roow for moved columns
		$db->setQuery('UPDATE '.$table.'
                                  SET ordering = ordering
                                                 - '.$number_of_records_to_copy.'
                                  WHERE ordering <= '.$new_above_record_ordering.'
                                  AND   ordering > '.$first_record_ordering.'
                                  AND grid_id = '.$grid_id.'
                                  ORDER BY ordering');
		$db->query();
	}
	else return true;

	// Insert new columns into order
	$db->setQuery('UPDATE '.$table.'
                            SET ordering = ordering - 999999999 
                            WHERE ordering >= 999999999
                            AND grid_id = '.$grid_id.'      
                            ORDER BY ordering'); 
	
	$result = $db->query();
	
	// delete old grid view
	dropGridJView($grid_id);
		
	//create view
	addGridJView($grid_id);
	
	if($result)return true;
	else return false;
}




/**
 * Checks to see if default access rights apply
 * @return true if defaults do not apply  or false if defaults apply
 *
 */
function check_defaut_values_apply($grid_id, $current_document_id)
{
	$db =JFactory::getDBO();
	$user=JFactory::getUser();
	$not_default=0;


	// check if default access control applies
	$query='SELECT count(1)
		    FROM #__jgrid_security e, 
		         #__jgrid_role_userlist f
		    WHERE ((e.access_for = 1 
		             AND e.access_for_id = '.$user->id.')
		          OR(e.access_for=2
		            AND e.access_for_id = f.role_id
		            AND f.userid ='.$user->id.'))
		      AND ((e.access_type = 1 
		              AND e.access_subtype_grid_id = '.$grid_id.')
		           OR(e.access_type =  3
		               AND e.access_subtype_document_id = '.$current_document_id.'))';


	$db->setQuery($query);
	$not_default = $db->loadResult();

	return $not_default;
}

/**
 * Checks to see if user has backend admin access rights apply
 * @return true if defaults do not apply  or false if defaults apply
 *
 */
function check_for_backend_admin_access_rights()
{
	$db =JFactory::getDBO();
	$user=JFactory::getUser();

	// check for joomla version
	$version = new JVersion;
	$joomla = $version->getShortVersion();
	$access_control_user=false;
	// Joomla version test	
	if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
	{
		$query = 'SELECT count(1)
		            FROM #__jgrid_user_type_defaults a,
		                 #__usergroups b,
		                 #__user_usergroup_map  c	                        
		            WHERE a.usertype_name = b.title
		              AND c.user_id='.$user->id.'
		              AND b.id=c.group_id
		              AND a.access_level=6';
		$db->setQuery($query);
		$access_control_user = $db->loadResult();
		// Joomla controls not working below
		//	if (JFactory::getUser()->authorise('core.manage', 'com_jgrid'))
		//	{
		//		JError::raiseError(1001,'sql'.JFactory::getUser()->authorise('core.manage', 'com_jgrid').'sql'.$access_control_user.'sql'.$query);
		//		return;
		//		$access_control_user=true;
		//	}
		//jimport('joomla.access.rules');
		// $rules    = new JRules($data['rules']);
		//echo ' rules = '.print_r($rules);
		//	$myGroups = JAccess::getGroupsByUser($user->id);
		//echo ' groups = '.print_r($myGroups);
		//  $myRules = $rules->getData();
		//  $access_control_user=true;
		//echo ' myrules = '.print_r($myRules);
		//    	if($hasSuperAdmin = $myRules['core.admin']->allow($myGroups))
		//    	{
		//    		$access_control_user=true;
		//   	     }
	}
	else //Joomla 1.5 or below
	{
		if($user->usertype=="Super Administrator" ||
		$user->usertype=="Manager" ||
		$user->usertype=="Administrator")
		{
			$access_control_user=true;
		}
	}
	//JError::raiseError(1001,'sql'.$access_control_user);
	//return;
	return $access_control_user;
}

/**
 * Performs access level checking
 * @return array containing the "acess level checks"  or false if no values returned
 *
 */
function check_access_control($grid_id, $current_document_id, $access_level_check_value)
{
	$db =JFactory::getDBO();
	$user=JFactory::getUser();
	$access_control=0;
	$remove_access_control=0;
	$admin_user=0;
	$document_security_level='1';
	// check for joomla version
	$version = new JVersion;
	$joomla = $version->getShortVersion();

    // Find applicatin id for this grid_id
    $query = 'SELECT b.id
		      FROM #__jgrid_grids a,
		      	   #__jgrid_applications b		                        
		      WHERE a.id = '.$grid_id.'
		        AND a.grid_application_name = b.grid_application_name';
	$db->setQuery($query);
	$access_rule_application_id = $db->loadResult();
	
	// check if default access control applies
	$not_default=check_defaut_values_apply($grid_id, $current_document_id);

	//JError::raiseError(1001,'sql'.check_for_backend_admin_access_rights());
	//return;

	if(check_for_backend_admin_access_rights())
	{ // administrator
		$admin_user=1;
		$access_control=1;
		$remove_access_control=0;
		$document_security_level='6';
	}
	else
	{
		// normal user
		//Set default user security level based on usertype
		if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
		{
			$query = 'SELECT max(a.access_level)
		                   FROM #__jgrid_user_type_defaults a,
		                        #__usergroups b,
		                        #__user_usergroup_map  c	                        
		                   WHERE a.usertype_name = b.title
		                     AND c.user_id='.$user->id.'
		                     AND b.id=c.group_id';
		}
		else
		{
			$query = 'SELECT access_level
		                   FROM #__jgrid_user_type_defaults a		                        
		                   WHERE a.usertype_name = "'.$user->usertype.'"';
		}
		$db->setQuery($query);
		$default_security_level = $db->loadResult();
		$document_security_level=$default_security_level;

		//Find admin defined default user security level based on usertype
		if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
		{
			$query = 'SELECT max(d.access_level)
		                   FROM #__jgrid_user_type_defaults a,
		                        #__usergroups b,
		                        #__user_usergroup_map c,
		                        #__jgrid_security d
		                   WHERE d.access_for=3
                          AND ((a.usertype_name = b.title
		                         		AND c.user_id='.$user->id.'
		                         		AND b.id= c.group_id)
		                         	OR ('.$user->id.' = 0
		                         		 AND a.usertype_name = "Public"
		                         	     AND a.id = d.access_for_id)
		                         )
		                   AND d.access_rule_application_id = '. $access_rule_application_id. '
		                   AND ((d.access_type = 3                     
		                          AND d.access_subtype_document_id = '.$current_document_id.')
		                        OR (d.access_type = 1                     
								  AND (d.access_subtype_grid_id = '.$grid_id.'
		                       			OR
		                       		d.access_subtype_grid_id = -1))
		      					)';
//echo 'sql '.$query;
		}
		else
		{

			$query = 'SELECT max(e.access_level)
		                   FROM #__jgrid_security e,
		                        #__jgrid_user_type_defaults g
		                   WHERE e.access_for=3
		                         AND e.access_for_id = g.id
		                         AND ((g.usertype_name ="'.$user->usertype.'")
		                         		OR ('.$user->id.' = 0
		                         			 AND g.usertype_name = "Guest"
		                         	         AND g.id = e.access_for_id)))
		                   AND e.access_rule_application_id = '. $access_rule_application_id. '
		                   AND ((e.access_type = 3                     
		                          AND e.access_subtype_document_id = '.$current_document_id.')
		                        OR (e.access_type = 1                     
									  AND (d.access_subtype_grid_id = '.$grid_id.'
		                       			OR
		                       		d.access_subtype_grid_id = -1))
		               			)';
		}
		$db->setQuery($query);
		$default_security_level = $db->loadResult();

		if($default_security_level!=0)
		{
			$document_security_level=$default_security_level;
		}
			
		if($document_security_level > $access_level_check_value)
		{
			$access_control=1;
		}else if($document_security_level ==0)
		{
			$remove_access_control=1;
		}
		
		// check for user access rights meet minimum access check for grids or documents
		if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
		{
			$query = 'SELECT count(1) AS q
		                 FROM #__jgrid_user_type_defaults a,
		                      #__usergroups c,
		                      #__user_usergroup_map d,
		                      #__jgrid_security e, 
		                      #__jgrid_role_userlist f
		                 WHERE ((e.access_for = 1 
		                          AND 
		                         e.access_for_id = '.$user->id.')
		                          OR
		                         (e.access_for=2
		                              AND e.access_for_id = f.role_id
		                              AND f.userid ='.$user->id.')
		                           OR
		                         (e.access_for=3
		                             AND e.access_for_id = a.id
		                             AND 0 = '.$not_default.'
		                             AND a.usertype_name =c.title
		                             AND d.user_id='.$user->id.'
		                             AND c.id=d.group_id))
		                 AND e.access_level > '.$access_level_check_value.'
		                 AND e.access_rule_application_id = '. $access_rule_application_id. '
		                 AND ((e.access_type = 1 
		                       AND (e.access_subtype_grid_id = '.$grid_id.'
		                       		OR
		                       		e.access_subtype_grid_id = -1))
		                      OR
		                      (e.access_type =  3
		                       AND e.access_subtype_document_id = '.$current_document_id.'))';
		}
		else
		{
			$query = 'SELECT count(1) AS q
		                 FROM #__jgrid_security e, 
		                      #__jgrid_role_userlist f,
		                      #__jgrid_user_type_defaults g
		                 WHERE ((e.access_for = 1 
		                          AND 
		                         e.access_for_id = '.$user->id.')
		                          OR
		                         (e.access_for=2
		                              AND e.access_for_id = f.role_id
		                              AND f.userid ='.$user->id.')
		                           OR
		                         (e.access_for=3
		                             AND e.access_for_id = g.id
		                             AND 0 = '.$not_default.'
		                             AND g.usertype_name ="'.$user->usertype.'"))
		                 AND e.access_level > '.$access_level_check_value.'
		                 AND e.access_rule_application_id = '. $access_rule_application_id. '
		                 AND ((e.access_type = 1 
		                       AND (e.access_subtype_grid_id = '.$grid_id.'
		                       			OR
		                       		e.access_subtype_grid_id = -1))
		                      OR
		                      (e.access_type =  3
		                       AND e.access_subtype_document_id = '.$current_document_id.'))';
		}		
		$db->setQuery($query);
		$result=$db->loadResult();		
		if($result!=0)
		{
			$access_control=$result;
		}

		
		
		// set user access level for normal user  eg not admin 
	
		$query = 'SELECT max(a.access_level)
		                 FROM #__jgrid_security a, 
		                      #__jgrid_role_userlist b
		                 WHERE ((a.access_for = 1 
		                          AND 
		                         a.access_for_id = '.$user->id.')
		                          OR
		                         (a.access_for=2
		                              AND a.access_for_id = b.role_id
		                              AND b.userid = '.$user->id.'))
		                 AND a.access_rule_application_id = '. $access_rule_application_id. '             
		                 AND ((a.access_type = 1 
		                       AND (a.access_subtype_grid_id = '.$grid_id.'
		                       			OR
		                       		a.access_subtype_grid_id = -1))
		                      OR
		                      (a.access_type =  3
		                       AND a.access_subtype_document_id = '.$current_document_id.'))';
		
		$db->setQuery($query);
		$result=$db->loadResult();		
		if($result)
		{
			$document_security_level=$result;
		}

		
		
		
		
		// check for user access overide to take away rights for grids or documents
		if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
		{
			$query = 'SELECT count(1) 
		                 FROM #__jgrid_user_type_defaults a,
		                      #__usergroups c,
		                      #__user_usergroup_map d,
		                      #__jgrid_security e, 
		                      #__jgrid_role_userlist f
		                 WHERE ((e.access_for = 1 
		                          AND 
		                         e.access_for_id = '.$user->id.')
		                          OR
		                         (e.access_for=2
		                              AND e.access_for_id = f.role_id
		                              AND f.userid ='.$user->id.')
		                          OR
		                         (e.access_for=3
		                             AND e.access_for_id = a.id
		                             AND 0 = '.$not_default.'
		                             AND
		                             ((a.usertype_name =c.title
		                             AND d.user_id='.$user->id.'
		                             AND c.id=d.group_id)
		                             OR
		                             (a.usertype_name ="Public" AND '.$user->id.' = 0
		                             ))))
		                 AND e.access_level = 0
		                 AND e.access_rule_application_id = '. $access_rule_application_id. ' 
		                 AND ((e.access_type = 1 
		                       AND (e.access_subtype_grid_id = '.$grid_id.'	                       								
		                       			OR
		                       		e.access_subtype_grid_id = -1))
		                      OR
		                      (e.access_type =  3
		                       AND e.access_subtype_document_id = '.$current_document_id.'))';
		}
		else
		{
			$query = 'SELECT count(1) 
		                 FROM #__jgrid_security e, 
		                      #__jgrid_role_userlist f,
		                      #__jgrid_user_type_defaults g
		                 WHERE ((e.access_for = 1 
		                          AND 
		                         e.access_for_id = '.$user->id.')
		                          OR
		                         (e.access_for=2
		                              AND e.access_for_id = f.role_id
		                              AND f.userid ='.$user->id.')
		                          OR
		                         (e.access_for=3
		                             AND e.access_for_id = g.id
		                             AND 0 = '.$not_default.'
		                             AND (g.usertype_name ="'.$user->usertype.'"	
		                               OR (g.usertype_name = "Guest"
		                                    AND '.$user->id.' = 0))))
		                 AND e.access_level = 0
						 AND e.access_rule_application_id = '. $access_rule_application_id. '		                 
		                 AND ((e.access_type = 1 
		                       AND (e.access_subtype_grid_id = '.$grid_id.'	                       								
		                       			OR
		                       		e.aaccess_subtype_grid_id = -1))
		                      OR
		                      (e.access_type =  3
		                       AND e.access_subtype_document_id = '.$current_document_id.'))';

		}
		$db->setQuery($query);
		$remove_access_control=$db->loadResult();
	}

	$creator_access_control=0;
	// check for user access rights for each row updated if creator type
	//find document security types for creator lowest is most restrictive eg creator editable and viewable only to highest creator role editable public viewable
	$query = 'SELECT count(1)
		                   FROM #__jgrid_security e, 
		                        #__jgrid_role_userlist f
		                   WHERE e.access_for=4
		                   	 AND e.access_rule_application_id = '. $access_rule_application_id. '  
		                     AND ((e.access_type = 1                     
		                       AND (e.access_subtype_grid_id = '.$grid_id.'	                       								
		                       			OR
		                       		e.access_subtype_grid_id = -1))
		                        OR (e.access_type = 3                     
		                          AND e.access_subtype_document_id = '.$current_document_id.') 		                        
		                        )';

	$db->setQuery($query);
	$creator_access_control = $db->loadResult();
//echo 'sql'.$query.'sql';
	if($creator_access_control>0)
	{

     	$access_control=1;    
		if(!$user->guest)
    	{   
    		if($document_security_level<4)
    		{   
				$document_security_level = 4;
    		}
    	}	    	
	}
	// fix pressidence on remove access control but user based document security level higher
	if($document_security_level>0&&$remove_access_control>0)
	{
		// check for overrides for no access commands for specific roles or users
		if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
		{
			$query =   'SELECT count(1)
		                           FROM #__jgrid_security g, 
		                                #__jgrid_role_userlist h,
		                                #__jgrid_user_type_defaults i,
		                                #__usergroups j,
		                                #__user_usergroup_map k
		                           WHERE ((g.access_for = 1 
		                                     AND 
		                                     g.access_for_id = '.$user->id.')
		                                  OR
		                                   (g.access_for=2
		                                      AND g.access_for_id = h.role_id
		                                      AND h.userid ='.$user->id.')
		                                   OR
		                                       (g.access_for=3
		                                          AND g.access_for_id = i.id
		                                          AND ((i.usertype_name = j.title
		                                                 AND k.user_id = '.$user->id.'
		                                                 AND j.id=k.group_id))
		                                                 OR ('.$user->id.' = 0) 
		                                        )
		                                    OR 
		                                    	(g.access_for=4)    
		                                  )
		                           AND g.access_level != 0';
		}
		else
		{
			$query =   'SELECT count(1)
		                           FROM #__jgrid_security g, 
		                                #__jgrid_role_userlist h,
		                                #__jgrid_user_type_defaults i
		                           WHERE ((g.access_for = 1 
		                                     AND 
		                                     g.access_for_id = '.$user->id.')
		                                  OR
		                                   (g.access_for=2
		                                      AND g.access_for_id = h.role_id
		                                      AND h.userid ='.$user->id.')
		                                   OR
		                                       (g.access_for=3
		                                          AND g.access_for_id = i.id
		                                          AND ('.$user->id.' = 0))
		                                  OR (g.access_for=4)        
		                                          )
		                           AND g.access_level != 0';
		}
//echo 'sql'.$query;		
		$db->setQuery($query);
		$admin_defined_access_given = $db->loadResult();

		if($admin_defined_access_given) 
		{
			$remove_access_control = 0;
		}
	}
		
	return array($admin_user,$access_control,$remove_access_control,$document_security_level);

}

/**
 * Retrieves acccess control rights for Managing grid Sheets
 * @return array containing the "access right values" grid rows or false if no values returned
 *
 */
function check_grid_sheet_access_control($grid_id,$current_document_id,$access_level_check_value)
{
	$db =JFactory::getDBO();
	$user=JFactory::getUser();
	$access_control=0;
	$remove_access_control=0;
	$admin_user=0;
	// check for joomla version
	$version = new JVersion;
	$joomla = $version->getShortVersion();

	$grid_id=JRequest::getVar('grid_id','','','INTEGER');
	$not_default=0;
	// check if default access control applies
	$not_default=check_defaut_values_apply($grid_id, $current_document_id);

	if(check_for_backend_admin_access_rights())
	{ // administrator
		$admin_user=1;
		$access_control=1;
		$remove_access_control=0;
	}
	else
	{ // normal user
		// check for user access rights
		if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
		{
			$query = 'SELECT count(1) AS q
		                 FROM #__jgrid_user_type_defaults a,
		                      #__usergroups c,
		                      #__user_usergroup_map d,
		                      #__jgrid_security e, 
		                      #__jgrid_role_userlist f
		                 WHERE ((e.access_for = 1 
		                          AND 
		                         e.access_for_id = '.$user->id.')
		                          OR
		                         (e.access_for=2
		                              AND e.access_for_id = f.role_id
		                              AND f.userid ='.$user->id.')
		                          OR
		                         (e.access_for=3
		                             AND e.access_for_id = a.id
		                             AND 0 = '.$not_default.'
		                             AND a.usertype_name =c.title
		                             AND d.user_id='.$user->id.'
		                             AND c.id=d.group_id))
		                 AND e.access_level > '.$access_level_check_value.'
		                 AND (e.access_type = 1 
		                       AND e.access_subtype_grid_id = '.$grid_id.')';
		}
		else
		{
			$query = 'SELECT count(1) AS q
		                 FROM #__jgrid_security e, 
		                      #__jgrid_role_userlist f,
		                      #__jgrid_user_type_defaults g
		                 WHERE ((e.access_for = 1 
		                          AND 
		                         e.access_for_id = '.$user->id.')
		                          OR
		                         (e.access_for=2
		                              AND e.access_for_id = f.role_id
		                              AND f.userid ='.$user->id.')
		                          OR
		                         (e.access_for=3
		                             AND e.access_for_id = g.id
		                             AND 0 = '.$not_default.'
		                             AND g.usertype_name ="'.$user->usertype.'"))
		                 AND e.access_level > '.$access_level_check_value.'
		                 AND (e.access_type = 1 
		                       AND e.access_subtype_grid_id = '.$grid_id.')';

			//echo 'sql'.$query;
		}
		$db->setQuery($query);
		$access_control=$db->loadResult();
			
		// check for user access overide to take away rights rights
		if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
		{
			$query = 'SELECT count(1) AS q
		                 FROM #__jgrid_user_type_defaults a,
		                      #__usergroups c,
		                      #__user_usergroup_map d,
		                      #__jgrid_security e, 
		                      #__jgrid_role_userlist f
		                 WHERE ((e.access_for = 1 
		                          AND 
		                         e.access_for_id = '.$user->id.')
		                          OR
		                         (e.access_for=2
		                              AND e.access_for_id = f.role_id
		                              AND f.userid ='.$user->id.')
		                         OR
		                         (e.access_for=3
		                             AND e.access_for_id = a.id
		                             AND 0 = '.$not_default.'
		                             AND a.usertype_name =c.title
		                             AND d.user_id='.$user->id.'
		                             AND c.id=d.group_id))
		                 AND e.access_level = 0
		                 AND (e.access_type = 1 
		                       AND e.access_subtype_grid_id = '.$grid_id.')';
		}
		else
		{
			$query = 'SELECT count(1) AS q
		                 FROM #__jgrid_security e, 
		                      #__jgrid_role_userlist f,
		                      #__jgrid_user_type_defaults g
		                 WHERE ((e.access_for = 1 
		                          AND 
		                         e.access_for_id = '.$user->id.')
		                          OR
		                         (e.access_for=2
		                              AND e.access_for_id = f.role_id
		                              AND f.userid ='.$user->id.')
		                         OR
		                         (e.access_for=3
		                             AND e.access_for_id = g.id
		                             AND 0 = '.$not_default.'
		                             AND g.usertype_name ="'.$user->usertype.'"))
		                 AND e.access_level = 0
		                 AND (e.access_type = 1 
		                       AND e.access_subtype_grid_id = '.$grid_id.')';
		}
		$db->setQuery($query);
		$remove_access_control=$db->loadResult();
	}

	return array($admin_user,$access_control,$remove_access_control);

}

/**
 * finds next column available in jgrid_data
 * @return next column false if no values returned
 *
 */
function getNextDataColumn($grid_id,$data_type)
{
	$db =JFactory::getDBO();
	$user=JFactory::getUser();
	// find jgrid_data columns in use
	$query = 'SELECT jgrid_data_column
	                       FROM #__jgrid_columngrid 
	                       WHERE grid_id = '.$grid_id;
	$db->setQuery($query);
	$jgrid_data_column_array = $db->loadObjectList();
		
	// find next data column and assign to this column
	$next_column = false;
	for($j=1; $j < MAX_DATA_COLUMNS; $j++)
	{
		$found = false;
		for($i=0;$i<count($jgrid_data_column_array);$i++)
		{
			if($jgrid_data_column_array[$i]->jgrid_data_column[0] == $data_type)
			{
				if((int)substr($jgrid_data_column_array[$i]->jgrid_data_column, 1) == $j)
				{
					$found = true;
					continue;
				}
			}				
		}
		if ($found == false) break;
	}
	if($j == MAX_DATA_COLUMNS)
	{
		JError::raiseError(1091, "MAXIMUM_COLUMNS_OF " . MAX_DATA_COLUMNS . " FOR_THIS_TYPE_EXCEEDED");
		return;
	} 
	return ($data_type . (string)$j);
}

/**
 * finds editable line string
 * @return string  false if no values returned
 *
 */
function getEditlineSqlString($creator_document_security_level,$admin_user,$document_security_level,$myroles, $max_column_security_level)
{

	$db =JFactory::getDBO();
	$user=JFactory::getUser();	
	// find rows that are creator editable
	//echo 'sql'.$creator_document_security_level.'sql'.$admin_user.'sql'.$document_security_level;
	if(	$creator_document_security_level==1 ||
		$creator_document_security_level==3 ||
		$creator_document_security_level==4 ||
		$creator_document_security_level==6 &&
		($admin_user==0&&$document_security_level<5))
		{
			$query = ' CASE WHEN ROW.creator_userid = "'.$user->id.'"
				                      THEN  true
				                    ELSE false
				               END';	
		}
		// find rows that are creator role editable
	else if($creator_document_security_level==2 ||
		$creator_document_security_level==5 ||
		$creator_document_security_level==7  &&
		($admin_user==0&&$document_security_level<5))
		{
			// find myroleusers
			// find users roles for rowediting test
			$role_user_query = 'SELECT userid
		                        FROM #__jgrid_role_userlist
		                        WHERE FIND_IN_SET(role_id,"'.$myroles.'") = true';
			$result = $db->loadObjectList( $role_user_query );
			
			if(count($result)>0)
			{
				$myroleusers  = '0';
				for($i=0; $i<count($result);$i++)
				{
					$myroleusers  .= ','.$result[$i]->userid;
				}
			}
			$query = ' CASE WHEN  FIND_IN_SET(ROW.creator_userid,"'.$myroleusers.'")
				                      THEN  true
				                    ELSE false
				               END';				
		} // creator or Crole view only
		else if($creator_document_security_level==8 ||
				$creator_document_security_level==9)
		{
			$query = " false ";
		}
		else if($admin_user!=0)
		{
			$query = " true ";
		}
		else if($max_column_security_level > 2)
		{
			$query = " true ";
		}
		else
		{
			$query = ' CASE WHEN SUBSTR(ROW.row_access_id,1,1)= "U"
				                      THEN (CASE WHEN SUBSTR(ROW.row_access_id,2) = "'.$user->id.'"
				                                   THEN  true
				                                 ELSE false
				                            END)
				                   WHEN SUBSTR(ROW.row_access_id,1,1)= "R"
				                     THEN (CASE WHEN FIND_IN_SET(SUBSTR(ROW.row_access_id,2),"'.$myroles.'")
				                                  THEN  true
				                                ELSE false
				                           END)
				                   WHEN SUBSTR(ROW.row_access_id,1,1)= "D"
				                     THEN (CASE WHEN '.$document_security_level.' > 2
				                                  THEN  true
				                                ELSE false
				                           END)				                           
				                   ELSE  false
                               END';
		}
		//$query .= '  AS editable_line';
		return($query);
}


/**
 * finds slvl string
 * @return string  false if no values returned
 *
 */
function getSlvlSqlString($admin_user,$document_security_level,$creator_document_security_level,$column_security_level,$document_level_creator_rule)
{
	$db =JFactory::getDBO();
	$user=JFactory::getUser();	
	
	if($creator_document_security_level==0)
	{
		$query = ' 0';
	}
	else
	{
		$query = ' '.$creator_document_security_level;
	}
	$query .=  ' as creator_document_security_level,
	                            ROW.creator_userid, ';

		// add creator id rules
		if($creator_document_security_level!=0&&($admin_user==0&&$document_security_level<5))
		{
			switch ($creator_document_security_level)
			{
				// CREATOR_PRIVATE(editable)
				case '1':
					// CREATOR_ROLE_PRIVATE(editable)
				case '2':
					if(!$user->guest)
					{
						$query .= '"4"';
					}
					else
					{
						$query .= '"1"';
					}
					break;
					// CREATOR_ROLE_VIEWABLE creator editable
				case '3':
					// REGISTERED_VIEWABLE Creator Editable
				case '4':
					// PUblic_VIEWABLE Creator Editable
				case '6':
					// check for column level security
					// 0 if column type rule
					if($document_level_creator_rule==0)
					{
						$query .= ' CASE WHEN  ROW.creator_userid = '.$user->id.'
					                              THEN "2"'.$column_security_level.'
					                            ELSE "'.$document_security_level.'"				                           
					                       END ';
							
					}
					else
					{
						$query .= ' CASE WHEN  ROW.creator_userid = '.$user->id.'
					                              THEN "4"
					                            ELSE "'.$document_security_level.'"				                           
					                       END ';
					}
					break;
					// REGISTERED_VIEWABLE Role Editable
				case '5':
					// PUBLIC_VIEWABLE Role Editable
				case '7':
					// 0 if column type rule
					if($document_level_creator_rule==0)
					{
						$query .= ' CASE WHEN (ROW.creator_userid = RUL.userid AND RUL.role_id = "'.$user_role_id.'")
					                              THEN "2"'.$column_security_level.'
					                             ELSE "1"				                           
					                       END ';
					}
					else
					{
						$query .= ' CASE WHEN (ROW.creator_userid = RUL.userid AND RUL.role_id = "'.$user_role_id.'")
					                              THEN "4"
					                            ELSE "'.$document_security_level.'"					                           
					                       END ';
					}
					break;
				// creator viewable not Editable
				case '8':
				case '9':
					$query .= ' CASE WHEN (ROW.creator_userid = RUL.userid OR RUL.role_id = "'.$user_role_id.'")
					                              THEN "2"
					                            ELSE "'.$document_security_level.'"					                           
					                       END ';		
					break;	
			}

		}
		else
		{
			// check for cell row edidable column security settings
			if($column_security_level!='' && $document_security_level < 3)
			{
				if($document_security_level==1)
				// update security to 2 if set at 1 to get edit button to show
				{
					$document_security_level = 2;
				}
				$query .= '"'.$document_security_level.$column_security_level.'"';

			}
			else
			{
				$query .= '"'.$document_security_level.'"';
			}

		}
		//$query .= ' AS slvl,';
		return ($query);
}


/**
 * finds creator roles join criteria sql string
 * @return string  false if no values returned
 *
 */
function getCreatorJoinSqlString($admin_user,$document_security_level,$creator_document_security_level,$user_role_id)
{
	$db =JFactory::getDBO();
	$user=JFactory::getUser();
  $query = '';		


// add creator rules

		if($creator_document_security_level!=0&&($admin_user==0&&$document_security_level<5))
		{
			switch ($creator_document_security_level)
			{
				// CREATOR_PRIVATE
				case '1':
				case '8':
				case '9':		
					$query = ' AND ROW.creator_userid = '.$user->id;
					break;
					// CREATOR_ROLE_PRIVATE
				case '2':
					// CREATOR_ROLE_VIEWABLE
				case '3':
					$query = ' AND (ROW.creator_userid = RUL.userid AND RUL.role_id = "'.$user_role_id.'")';
					break;
					// REGISTERED_VIEWABLE Creator Editable
				case '4':
					// REGISTERED_VIEWABLE Role Editable
				case '5':
					if($user->guest)
					{
						// No grids to show
						//	JError::raiseError(1005, JText::_("NO_DATA_AVAILABLE_TO_PUBLIC_USER_PLEASE_LOGIN_AS_A_REGISTERED_USER"));
						return ('999');
					}
					break;
					// PUblic_VIEWABLE Creator Editable
				case '6':
					// PUBLIC_VIEWABLE Role Editable
				case '7 ':
					break;


			}
		}
		return ($query);
}


/**
 * Drop msql view of JGrid grid data
 * @return string  false if view not dropped
 *
 */
function dropGridJView($grid_id)
{
	$db =JFactory::getDBO();
	$table_prefix=$db->getPrefix();
	$app = JFactory::getApplication();
    $database_schema= $app->getCfg('db');
	
	// Find View Name based on Grid_id
	$query = '	SELECT 	a.title, 
						a.select_type 
				FROM #__jgrid_grids a
				WHERE id = '.$grid_id;
	$db->setQuery($query);
	$result = $db->loadObjectList();
	
	if($result[0]->select_type > 1) return false;
	$grid_title = $result[0]->title;	
	$grid_title = str_replace(' ','_',$grid_title);
	//check and see if view exists and delete grid view if it does
	$query = '	SELECT * from INFORMATION_SCHEMA.VIEWS
				WHERE table_name = "'.$table_prefix.'jview_g'.$grid_id.'_'.$grid_title.'"
				AND TABLE_SCHEMA = "'.$database_schema.'"
				LIMIT 1';
	$db->setQuery($query);
	$result = 0;
	$result=$db->loadResult();
//echo 'sql '.$result.$query;			
//return false;
	if($result)
	{
//echo 'sql2 '.'DROP VIEW  #__jview_g'.$row_data[0]['id'].'_'.$grid_title;				
		$db->setQuery('DROP VIEW  #__jview_g'.$grid_id.'_'.$grid_title);
		$db->query();
		return true;
	}
	return false;
}



/**
 * Add msql view of JGrid grid data
 * @return string  false if view not added
 *
 */
function addGridJView($grid_idd)
{
	$db =JFactory::getDBO();
	$user=JFactory::getUser();
	$table_letter = array('a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z');      
   	$grid_id = (int)$grid_idd;

	// Find View Name based on Grid_id
	$query = '	SELECT 	a.title, 
						a.select_type 
				FROM #__jgrid_grids a
				WHERE id = '.$grid_id;
	$db->setQuery($query);
	$result = $db->loadObjectList();
	// check and see if sql type and if is return, views only for jGrid type grids
	if($result[0]->select_type > 1) return false;
	$grid_title = $result[0]->title;	
	$grid_title = str_replace(' ','_',$grid_title);
	//Find column names
	
	// find jgrid_data columns in use
	$query = '	SELECT 	a.id,
						CONCAT(b.data_type,a.id) AS "dataindex",
						b.header,
						b.data_type 
	          	FROM 	#__jgrid_columngrid a, 
	          			#__jgrid_columns b
		       		WHERE a.grid_id = '.$grid_id.'
		                         AND a.column_id = b.id
		                         ORDER BY a.ordering';	
	$db->setQuery($query);
	$jgrid_data_column_array = $db->loadObjectList();
	
	$view_name = '#__jview_g'.$grid_id.'_'.$grid_title;
		
	// Create New View
	$query = 'CREATE OR REPLACE VIEW '.$view_name.' (id, grid_id, document_id, creator_userid';
	for($i=0;$i<count($jgrid_data_column_array);$i++)
	{
		$jgrid_data_column_array[$i]->header = str_replace(' ','_',$jgrid_data_column_array[$i]->header);
		$query .= ', '.$jgrid_data_column_array[$i]->dataindex.'_'.$jgrid_data_column_array[$i]->header;
	}
	$query .= ' ) AS SELECT DISTINCT a.id, a.grid_id, a.document_id, a.creator_userid';
	for($i=0,$x=0,$y=0;$i<count($jgrid_data_column_array);$i++)
	{
		$query .= ', '.$table_letter[$x].$table_letter[$y];
		switch ($jgrid_data_column_array[$i]->data_type)
		{
			//text
			case 'T':
			//List
			case 'L':
			//Picture
			case 'P':
			//URL
			case 'U':
			//EMail
			case 'E':						
			//Sheet Name
			case 'S':				
				$query .= '.string_data AS ';
				break;
			// Integer
			case 'I':
			// Integer
			case 'R':		 		
				$query .= '.int_data AS ';
				break;
			//Date
			case 'D':
				$query .= '.date_data AS ';			
				break;
			// Boolean
			case 'B':
				$query .= '.boolean_data AS ';
				break;
			// Float
			case 'F':
				$query .= '.float_data AS ';
				break;
	 		
		}
		$query .= $jgrid_data_column_array[$i]->dataindex.'_'.$jgrid_data_column_array[$i]->header;	
		if($y<26)
		{
			$y++;
		}
		else
		{
			$y = 0;
			$x++;
			if($x==26) // if > [z][z] break
			{
				break;
			}		
		}
	}
	$query .= ' FROM #__jgrid_rows a ';
	for($i=0,$x=0,$y=0;$i<count($jgrid_data_column_array);$i++)
	{
		$query .= ' LEFT JOIN #__jgrid_columndata '.$table_letter[$x].$table_letter[$y].' ON '.$table_letter[$x].$table_letter[$y].'.row_number = a.id AND '.$table_letter[$x].$table_letter[$y].'.columngrid_id = '.$jgrid_data_column_array[$i]->id;
		if($y<26)
		{
			$y++;
		}
		else
		{
			$y = 0;
			$x++;
			if($x==26) // if > [z][z] break
			{
				break;
			}		
		}
	}
	$query .= ' WHERE a.grid_id = '.$grid_id;
//echo 'sql'.$query;
	$db->setQuery($query);
	$result = $db->query();
	
//    $query = 'CREATE VIEW jos_jview_G1_membership (id, 
//	                        grid_id,
//	                        document_id, 
//	                        creator_userid,  
//	                        T2_Name, 
//	                        T3_Address_1, 
//	                        T4_Address_2, 
//	                        T5_City, 
//	                        T6_State, 
//	                        T7_Zip, 
//	                        T8_Home_Phone, 
//	                        T9_Work_Phone, 
//	                        T10_Cell_Phone )
//			AS
//			SELECT  DISTINCT  a.id, 
//			                  a.grid_id, 
//			                  a.document_id, 
//			                  a.creator_userid,  
//			                  b.string_data AS T2_Name, 
//			                  c.string_data AS T3_Address_1, 
//			                  d.string_data AS T4_Address_2, 
//			                  e.string_data AS T5_City, 
//			                  f.string_data AS T6_State, 
//			                  g.string_data AS T7_Zip, 
//			                  h.string_data AS T8_Home_Phone, 
//			                  i.string_data AS T9_Work_Phone, 
//			                  j.string_data AS T10_Cell_Phone
//			FROM jos_jgrid_rows a
//			LEFT JOIN jos_jgrid_columndata b ON b.row_number = a.id AND b.columngrid_id = 2  
//			LEFT JOIN jos_jgrid_columndata c ON c.row_number = a.id AND c.columngrid_id = 3  
//			LEFT JOIN jos_jgrid_columndata d ON d.row_number = a.id AND d.columngrid_id = 4  
//			LEFT JOIN jos_jgrid_columndata e ON e.row_number = a.id AND e.columngrid_id = 5  
//			LEFT JOIN jos_jgrid_columndata f ON f.row_number = a.id AND f.columngrid_id = 6  
//			LEFT JOIN jos_jgrid_columndata g ON g.row_number = a.id AND g.columngrid_id = 7  
//			LEFT JOIN jos_jgrid_columndata h ON h.row_number = a.id AND h.columngrid_id = 8  
//			LEFT JOIN jos_jgrid_columndata i ON i.row_number = a.id AND i.columngrid_id = 9  
//			LEFT JOIN jos_jgrid_columndata j ON j.row_number = a.id AND j.columngrid_id = 10
//			WHERE a.grid_id = '.$grid_id;
//			$db->setQuery($query);
//			$result = $db->query();


		return ($result);
}



/**
 * updates image column data
 * @return update string or false 
 *
 */
function update_image_cell($grid_id,$current_document_id, $columngrid_id, $row_id, $select_type, $img_cell_value, $primary_key_value)
{
	$db =JFactory::getDBO();
	$user=JFactory::getUser();
	
	if($select_type<2)
	{
		$query = '	UPDATE  #__jgrid_columndata  SET string_data = "' . $img_cell_value.'"
	       			WHERE columngrid_id = "' . $columngrid_id .'"
		           		AND row_number = ' . $row_id .' 
		           		AND document_id = '.$current_document_id;
		$db->setQuery($query);
		$result = $db->query();
	}
	else // select_type is table
	{
		$query = '	SELECT a.jgrid_data_column
							FROM #__jgrid_columngrid a
							WHERE a.id = ' . $columngrid_id;
		$db->setQuery($query);
		$jgrid_data_column = $db->loadResult();
		// if no column exists assign one to cover upgrades from previous verion
		if(!$jgrid_data_column)
		{
			// find the next data column available
			$jgrid_data_column = getNextDataColumn($grid_id,"P");
			$query = '	UPDATE #__jgrid_columngrid  SET jgrid_data_column = "'.$jgrid_data_column.'"
								WHERE id = ' . $columngrid_id;
			$db->setQuery($query);
			$result = $db->query();
		}						
		// check to see if row exists
		$query = '	SELECT id
							FROM #__jgrid_data a
							WHERE primary_key_value = "'.$primary_key_value.'"
			             		AND document_id = '.$current_document_id.'
			                 	AND grid_id = '.$grid_id;
		$db->setQuery($query);
		$jgrid_data_id = $db->loadResult();
		if($jgrid_data_id)
		{
			$query = 'UPDATE #__jgrid_data SET 	'.$jgrid_data_column.' = "' . $img_cell_value .'",
														creator_userid = ' . $user->id.'
							 WHERE id = '. $jgrid_data_id;
		}
		else 
		{
			$query = 'INSERT INTO  #__jgrid_data (	'.$jgrid_data_column.',
															creator_userid,
															primary_key_value,
															document_id,
															grid_id
																			)
			           		VALUES (	"' . $img_cell_value .'",
			                      		' . $user->id.',
			                        	"'.$primary_key_value.'",
			                         	'.$current_document_id.',
			                           	'.$grid_id.'
			                                                   		  )';
		}
		$db->setQuery($query);
		$result = $db->query();
		if(!$jgrid_data_id)
		{
			$db->setQuery('SELECT last_insert_id() FROM #__jgrid_data');
			$jgrid_data_id = $db->loadResult();
		}												
	}
	if($result) return( $img_cell_value);
	else return false;			
}

/**
 * select image cell data
 * @return update string or false 
 *
 */
function select_image_cell($grid_id,$current_document_id, $columngrid_id, $row_id, $select_type, $primary_key_value)
{
		$db =JFactory::getDBO();
	$user=JFactory::getUser();
	
	if($select_type<2)
	{
		// get stored info on original
		$query = '	SELECT string_data
			    	FROM #__jgrid_columndata
			  	 	WHERE columngrid_id = "' . $columngrid_id .'"
		          		AND row_number = ' . $row_id .' 
		             	AND document_id = '.$current_document_id;
		$db->setQuery($query);
		$result = $db->loadResult();
	}
	else // select_type is table
	{
		$query = '	SELECT a.jgrid_data_column
							FROM #__jgrid_columngrid a
							WHERE a.id = ' . $columngrid_id;
		$db->setQuery($query);
		$jgrid_data_column = $db->loadResult();
		if(!$jgrid_data_column) return false;
		
		$query = '	SELECT '.$jgrid_data_column.'
					FROM #__jgrid_data
					WHERE primary_key_value = "'.$primary_key_value.'"
						AND document_id = '.$current_document_id.'
						AND grid_id = '.$grid_id;
		$db->setQuery($query);
		$result = $db->loadResult();		
	}

	if($result) return(explode("~",$result));
	else return false;			

	
}

	/**
	 * Upgrade the JGrid database structures to the current release of JGrid
	 * @return true if successful  or false if no values returned
	 */
function jgrid_database_upgrade($jgrid_tables_version,$site_admin,$new_install)
{

		$db = JFactory::getDBO();
		$user = JFactory::getUser();
		$app = JFactory::getApplication();
		$table_prefix=$db->getPrefix();
    	$database_schema= $app->getCfg('db');
		//temp code
		if($site_admin=="Site") $dirsql = JPATH_BASE.'/administrator/components/com_jgrid/sql/';
		else $dirsql = JPATH_BASE.'/components/com_jgrid/sql/';
		$filename=$dirsql.'install.sql';
		$create_string='CREATE TABLE IF NOT EXISTS';
		$end_string='utf8;';
		$alt_end_string='last_updated';
		
		
		// get joomla admin user id				
		$query ='SELECT id
				FROM #__users 
					WHERE username = "admin"';
		$db->setQuery($query);
		$adminUserID=$db->loadResult();
		
		if(!$adminUserID) $adminUserID = 929;
		 
		// update from column_id to columngrid_id in jgrid_columndata (legacy fix)				
		$query ='SELECT count(1)
					 FROM information_schema.columns 
					 WHERE table_schema = "'.$database_schema.'"
						AND table_name = "'.$table_prefix.'jgrid_columndata"
						AND column_name = "columngrid_id"';
		$db->setQuery($query);
	    //JError::raiseError(1017, $query);
		//return;			
		if(($result=$db->loadResult())== 0)
		{
				$query = 'ALTER IGNORE TABLE '.$table_prefix.'jgrid_columndata
					 ADD COLUMN `columngrid_id` int(11);';

				$db->setQuery($query);
				$db->query();
				
				$query = 'UPDATE '.$table_prefix.'jgrid_columndata a
				SET a.columngrid_id = 
				( 
				SELECT b.id FROM '.$table_prefix.'jgrid_columngrid b, '.$table_prefix.'jgrid_document c 
				WHERE a.column_id = b.column_id
				  AND a.document_id = c.id
				  AND b.grid_id = c.grid_id LIMIT 1
				)';
	 //JError::raiseError(10077, $query );
		//return;				
				$db->setQuery($query);
				$db->query();				
		}

		// JError::raiseError(1003, JText::_('sql'.$column_name.'sql'.$table_prefix.'sql'));
		//return;
		$table_set=false;
		// open the file for reading
		$j=0;
		if($fp=fopen($filename,'r')){
			while (($line = fgets($fp, 4096)) !== false) {
				$j++;
				$line_fragement=$line;
				// find end of table create
				if (($result=stristr($line_fragement,$end_string))!== false) {
					$table_set=false;
							//    JError::raiseError(1005, JText::_('sql'.$query.'sql'.$line_fragement.'sql'.$column_name));
						//return;
				}
				// search for table create start
				if (($offset = strpos($line_fragement,$create_string))!== false) {
					// find table name
					$ptr=strpos($line_fragement,'`',$offset+strlen($create_string)+4);
					$table_name= substr($line_fragement,($offset+strlen($create_string)+5),($ptr-$offset-strlen($create_string)-5));
          // make sure table exists if not create it.
            $query ='SELECT count(1)
						        FROM information_schema.tables 
						        WHERE table_schema = "'.$database_schema.'"
						          AND table_name = "'.$table_prefix.$table_name.'"';                   					  
				    $db->setQuery($query);
		if(($result=$db->loadResult())== 0) 
            {
              $create_string = $line_fragement;          
              while (($line = fgets($fp, 4096)) !== false) {
                $create_string .= ' '.$line;
                if (($result=stristr($line,$end_string))!== false) {
                  $db->setQuery($create_string);
				  $result=$db->loadResult();
                  break;
				        }
              }
            
                	//	JError::raiseError(1005, JText::_('sql'.$table_name.'sql'.$line_fragement.'sql'.$ptr));
						//return;
            
            }
        
        
					$table_set=true;
				  continue;
				}
				// find column name
				if($table_set==true)
				{
					if (($offset = strpos($line_fragement,'`'))!== false) {
						$ptr=strpos($line_fragement,'`',$offset+1);
						$column_name=substr($line_fragement,($offset+1),($ptr-$offset-1));
//JError::raiseError(1007, JText::_('sql'.$query.'sql'.$line_fragement));
										//return;						
						if($column_name=='last_updated')
						{
							continue;
						}
						// find variable type
						if (($result=stristr($line_fragement,'int'))!== false) { //int
							$column_type='int';
						}
						else if (($result=stristr($line_fragement,'varchar'))!== false)
						{
							$column_type='varchar';
						}
						else if (($result=stristr($line_fragement,'boolean'))!== false)
						{
							$column_type_size='boolean';
						}						
						else if (($result=stristr($line_fragement,'enum'))!== false)
						{
							$column_type='enum';						
						}
					    else if (($result=stristr($line_fragement,'tinyint'))!== false)
						{
							$column_type='tinyint';						
						}
						else continue;
						// find size
						if (($offset = strpos($line_fragement,'('))!== false) {
							$ptr=strpos($line_fragement,')');
							$column_size =substr($line_fragement,($offset+1),($ptr-$offset-1));
							$column_type_size = $column_type.'('.$column_size.')';							
						}
						// find default
						$column_default='';
						if (($sub_string = stristr($line_fragement,' default'))!== false) {
							$sub_string_array=explode(' ',$sub_string);
						
							$removals = array("'", ",", " ", "\n", "\t");

							if(count($sub_string_array)==3)
							{
							  $column_default = str_replace($removals,"",$sub_string_array[2]);						  							  
							}
						}
						else
						{
							$column_default = 0;
						}
						// find NOT NULL
						if (($sub_string = stristr($line_fragement,'not null'))!== false) {
							$not_null = true;
						}
						else
						{
							$not_null = false;
						}
						//check information.scheme to see in JGrid tables are up to date
						$query ='SELECT count(1)
						         FROM information_schema.columns 
						         WHERE table_schema = "'.$database_schema.'"
						           AND table_name = "'.$table_prefix.$table_name.'"
						           AND column_name = "'.$column_name.'"
						           AND column_type = "'.$column_type_size.'"';					
						if($not_null)
						{
							$query .= ' AND IS_NULLABLE = "NO"';
						}
						else
						{
							$query .= ' AND IS_NULLABLE = "YES"';
						}
						if($column_default)
						{
							if($column_default=="true"||$column_default=="false")
							{
								$query .= ' AND column_default = '.$column_default.'';
							}
							else
							{
								$query .= ' AND column_default = "'.$column_default.'"';
							}

						}
						$db->setQuery($query);
						if($db->loadResult()== 0)
						{
							$query ='SELECT count(1)
						           FROM information_schema.columns 
						         WHERE table_schema = "'.$database_schema.'"
						             AND table_name = "'.$table_prefix.$table_name.'"
						             AND column_name = "'.$column_name.'"';					  
							$db->setQuery($query);
							if(($result=$db->loadResult())== 0)
							{
   		//	JError::raiseError(1007, JText::_('sql'.$query.'sql'.$line_fragement));
			//							return;
								//add column
								$query = 'ALTER TABLE '.$table_prefix.$table_name.'
						  	         ADD '.$column_name.' '.$column_type_size;
								if($not_null)
								{
									$query .= ' NOT NULL';
								}
								$query .= ' default  ';
								if($column_default!='true' && $column_default!='false')
								{
									$query .= '"';
								}
								$query .= $column_default;
								if($column_default!='true' && $column_default!='false')
								{
									$query .= '"';
								}
								if($column_name=='showGroupName')
								{
									// JError::raiseError(1007, JText::_('sql'.$column_default.'sql'.$query.'sql'.$line_fragement));
									//	return;
								}
					//JError::raiseError(1007, JText::_('sql'.$query));
										//return;					
								
								$db->setQuery($query);
								$db->query();
							}
							else
							{
								//modify column format
								$query = 'ALTER TABLE '.$table_prefix.$table_name.'
						  	         MODIFY '.$column_name.' '.$column_type_size;
								if($not_null)
								{
									$query .= ' NOT NULL';
								}
								if($column_default)
								{
									$query .= ' default  ';
									if($column_default!='true' && $column_default!='false')
									{
										$query .= '"';
									}
									$query .= $column_default;
									if($column_default!='true' && $column_default!='false')
									{
										$query .= '"';
									}

									//JError::raiseError(1003, JText::_('sql'.$query.'sql'.$line_fragement.'sql'));
									//return;
								}
								$db->setQuery($query);
								$db->query();
							}
						}
					}
				}
				// find end of table create
				if (($result=stristr($line_fragement,$end_string))!== false) {
					$table_set=false;
				}
			}
			if (!feof($fp)) {
				echo "Error: unexpected fgets() fail\n";
			}
			fclose($fp);
			//	continue;
			//JError::raiseError(1003, JText::_('sql'.$table_name.'sql'));
			//return;
			// update old group_by, sort_by fields from name to T1
			//select groupByField from grids
			$query = ' SELECT id, groupByField
                       FROM #__jgrid_grids a
                       WHERE SUBSTRING(a.groupByField,1,1) != BINARY "T"
                         AND SUBSTRING(a.groupByField,1,1) != BINARY "L"
                         AND SUBSTRING(a.groupByField,1,1) != BINARY "P"
                         AND SUBSTRING(a.groupByField,1,1) != BINARY "U"
                         AND SUBSTRING(a.groupByField,1,1) != BINARY "S"  
                         AND SUBSTRING(a.groupByField,1,1) != BINARY "I"  
                         AND SUBSTRING(a.groupByField,1,1) != BINARY "F"  
                         AND SUBSTRING(a.groupByField,1,1) != BINARY "B"';

			$data = 0;
			$db->setQuery($query);
			$result = $db->loadObjectList();
			if($result)
			{
				$result_count = count($result);
				for($i=0;$i<$result_count;$i++)
				{
					if($result[$i]->groupByField!=null)
					{
						$query = 'SELECT CONCAT(b.data_type,c.id)AS groupByField
                                    FROM #__jgrid_columns b,
                                         #__jgrid_columngrid c
                                    WHERE c.grid_id = '.$result[$i]->id.'
                                      AND b.id = c.column_id
                                      AND LOWER(b.header) = "'.$result[$i]->groupByField.'" LIMIT 1';					
						$db->setQuery($query);
						$data=$db->loadResult();
					}
					if($data == 0 && $result[$i]->groupByField==null)
					{
						$query = 'SELECT CONCAT(b.data_type,c.id)AS groupByField
                                    FROM #__jgrid_columns b,
                                         #__jgrid_columngrid c
                                    WHERE c.grid_id = '.$result[$i]->id.'
                                      AND b.id = c.column_id
                                      AND c.ordering = 1 LIMIT 1';
						$db->setQuery($query);
						$data=$db->loadResult();
					}
					$query = 'UPDATE #__jgrid_grids a
                              SET groupByField = "'.$data.'"
                              WHERE a.id = '.$result[$i]->id;
					$db->setQuery($query);
					$db->query();
				}
			}
			//select grids where fields need updated
			$query = ' SELECT id, sortByField
                       FROM #__jgrid_grids a
                       WHERE SUBSTRING(a.sortByField,1,1) != BINARY "T"
                         AND SUBSTRING(a.sortByField,1,1) != BINARY "L"
                         AND SUBSTRING(a.sortByField,1,1) != BINARY "P"
                         AND SUBSTRING(a.sortByField,1,1) != BINARY "U"
                         AND SUBSTRING(a.sortByField,1,1) != BINARY "S"  
                         AND SUBSTRING(a.sortByField,1,1) != BINARY "I"  
                         AND SUBSTRING(a.sortByField,1,1) != BINARY "F"  
                         AND SUBSTRING(a.sortByField,1,1) != BINARY "B"';

			$data = 0;
			$db->setQuery($query);
			$result = $db->loadObjectList();
			if($result)
			{
				$result_count=count($result);
				for($i=0;$i<$result_count;$i++)
				{
					if($result[$i]->sortByField!=null)
					{
						$query = 'SELECT CONCAT(b.data_type,c.id)AS sortByField
                                    FROM #__jgrid_columns b,
                                         #__jgrid_columngrid c
                                    WHERE c.grid_id = '.$result[$i]->id.'
                                      AND b.id = c.column_id
                                      AND LOWER(b.header) = "'.$result[$i]->sortByField.'" LIMIT 1';					
						$db->setQuery($query);
						$data=$db->loadResult();
					}
					if($data == 0 && $result[$i]->sortByField==null)
					{
						$query = 'SELECT CONCAT(b.data_type,c.id)AS sortByField
                                    FROM #__jgrid_columns b,
                                         #__jgrid_columngrid c
                                    WHERE c.grid_id = '.$result[$i]->id.'
                                      AND b.id = c.column_id
                                      AND c.ordering = 1 LIMIT 1';
						$db->setQuery($query);
						$data=$db->loadResult();
					}
					$query = 'UPDATE #__jgrid_grids a
                              SET sortByField = "'.$data.'"
                              WHERE a.id = '.$result[$i]->id;
					$db->setQuery($query);
					$db->query();
				}
			}
			// move demo pictures. needed since joomla1.5 removes foler on uninstall and would wipe out user image files
			$demo_images_dir = JPATH_SITE.'/media/com_jgrid/demo_images';
			$jgrid_images_dir = JPATH_SITE.'/media/com_jgrid/';
			full_copy($demo_images_dir,$jgrid_images_dir);
			
			//create grid views
			$query = 'SELECT id FROM #__jgrid_grids';
			$db->setQuery($query);
			$grids_array = $db->loadObjectList();
			for($i=0;$i<count($grids_array);$i++)
			{
				$grid_id = (int)$grids_array[$i]->id;
				addGridJView($grid_id);
			}
			

//return true;
			// update image filenames from columns to gridcolumn numbers if table version less than 4.0
			if($jgrid_tables_version[0] < '4')
			{
					$query = '	SELECT 	a.id AS image_id,
										a.grid_id,
		                             	a.document_id,
                                    	a.column_id,
                                    	a.row_id,  
                                      	a.filename,
                                      	a.file_type,
                                      	a.file_size,
                                       	a.image_thumb_path,
                                       	a.tooltip,
                                       	a.hyper_url,
                                     	a.hyper_grid_sheet,
                                   		a.extension,
                                     	a.userid,
                                     	b.id AS columngrid_id
                           		FROM #__jgrid_images a,
                           			 #__jgrid_columngrid b
                           		WHERE a.grid_id = b.grid_id
                           		  AND a.column_id = b.column_id';	
				$db->setQuery($query);
				$jgrid_images_array = $db->loadObjectList();
				$dir = JPATH_SITE.'/media/com_jgrid';
				
		//	JError::raiseError(1003, JText::_('sql'.print_r($jgrid_images_array).'sql'));
			//return true;			
				// rename images to columnGrid name
				for($i=0;$i<count($jgrid_images_array);$i++)
				{							
					// find columngrid id
					
					$grid_doc_dir= '/grid_'. $jgrid_images_array[$i]->grid_id.'/document_'. $jgrid_images_array[$i]->document_id;

					$imgpath_column =  $jgrid_images_array[$i]->grid_id. '_'. $jgrid_images_array[$i]->document_id. '_'. $jgrid_images_array[$i]->column_id. '_'. $jgrid_images_array[$i]->row_id;				
					$imgpath_columngrid =  $jgrid_images_array[$i]->grid_id. '_'. $jgrid_images_array[$i]->document_id. '_'. $jgrid_images_array[$i]->columngrid_id. '_'. $jgrid_images_array[$i]->row_id;
					
					$query = '	UPDATE #__jgrid_images
								SET image_thumb_path = "'.$grid_doc_dir . '/'. $imgpath_columngrid .'_thumb.png",
									columngrid_id = '.$jgrid_images_array[$i]->columngrid_id.'
								WHERE id = '.$jgrid_images_array[$i]->image_id;
					$db->setQuery($query);
					$db->query();

					// UPDATE Data Cell
					$query = '	UPDATE  #__jgrid_columndata
								SET string_data = "'.$grid_doc_dir . '/'. $imgpath_columngrid .'_thumb.png~'.$jgrid_images_array[$i]->tooltip.'~'.$jgrid_images_array[$i]->hyper_url.'~'.$jgrid_images_array[$i]->hyper_grid_sheet.'~'.$jgrid_images_array[$i]->extension.'"
								WHERE document_id = '.$jgrid_images_array[$i]->document_id.'
									AND column_id = '.$jgrid_images_array[$i]->column_id.'
									AND row_number = '.$jgrid_images_array[$i]->row_id;
					$db->setQuery($query);
					$db->query();
						
					// rename orignial image
					if(file_exists($dir.$grid_doc_dir.'/'. $imgpath_column  . '_orig.'.$jgrid_images_array[$i]->extension))
					{
						rename($dir.$grid_doc_dir.'/'. $imgpath_column  . '_orig.'.$jgrid_images_array[$i]->extension,$dir.$grid_doc_dir.'/'. $imgpath_columngrid  . '_orig.'.$jgrid_images_array[$i]->extension);
					}
						// rename thumbnail
					if(file_exists($dir.$grid_doc_dir.'/'. $imgpath_column  . '_thumb.png'))
					{
						rename($dir.$grid_doc_dir.'/'. $imgpath_column  . '_thumb.png',$dir.$grid_doc_dir.'/'. $imgpath_columngrid  . '_thumb.png');						
					}
				}
							
			}
			// if initial install then load sample data
			if($new_install)
			{
				$filename=$dirsql.'jgrid_sample_data.sql';
				if($fp=fopen($filename,'r'))
				{
					$sql_query = fread($fp, filesize($filename));
					
					// remove comment markups
					$sql_query = remove_remarks($sql_query);
					// replace joomla database name in queries
					$sql_query = str_replace ( '@JOOMLA_DATABASE' , $database_schema , $sql_query );
					// replace joomla table prefix  in queries
					$sql_query = str_replace ( '@__' , $table_prefix , $sql_query );
					// replace joomla admin user ID in queries
					$sql_query = str_replace ( '@ADMINUSERID' , $adminUserID , $sql_query );
					//split individual sql calls into an array
					$sql_query = split_sql_file($sql_query, ';');
					
					foreach($sql_query as $sql){
						$db->setQuery($sql);
						$db->query();
					}
					fclose($fp);
				}
				// find grids and add views
				$query = ' 	SELECT id
                       		FROM #__jgrid_grids';
				$db->setQuery($query);
				$grid_ids = $db->loadObjectList();
				if($grid_ids)
				{
					$result_count=count($grid_ids);
					for($i=0;$i<$result_count;$i++)
					{
						addGridJView($grid_ids[$i]);
					}
				}
			}
			// file opened and upgrade and sample data installed if new install
			return true;
		}
		// file would not open
		return false;
	}
	
		/**
	 * Check if database needs upgraded
	 * @return true if successful  or false if no values returned
	 */
function jgrid_database_upgrade_check($site_admin)
{	
	$db =JFactory::getDBO();
	$new_install = false;
	
			  		// check database matches new software. Check if #__jgrid_code_vcontrol.jgrid_installed == 0 
		// and it is not a new database install which would mean tables up to data eg
		$query = 'SELECT a.jgrid_installed 
		          FROM #__jgrid_code_vcontrol a
		          	LIMIT 1';		

		$db->setQuery($query);
		// if  0upgrade database based on install.sql file
		if($result=$db->loadResult()==0)
		{
		  // check to see if new install which means tables are good then update all to 1
		  $query = 'SELECT a.jgrid_installed 
		            FROM #__jgrid_tables_vcontrol a
		          	LIMIT 1';		

	  	  $db->setQuery($query);
		  // if  found then new install and update both to 1
		  if($result=$db->loadResult()==0)
		  {				
				$new_install = true;
				
				$result = jgrid_database_upgrade($result,$site_admin,$new_install);
				if($result==0) return array(0,'Database upgrade failed');
				
				$query = '	UPDATE #__jgrid_tables_vcontrol a
              				SET a.jgrid_installed = 1
                    		WHERE id = 1';		
				$db->setQuery($query);
				$db->query();
				
				$query = '	UPDATE #__jgrid_code_vcontrol a
              				SET a.jgrid_installed = 1
                    		WHERE id = 1';		
				$db->setQuery($query);
				$db->query();
		  }
		  else
		  {
			// get database table version 
			$query = 'SELECT a.grid_version 
		            FROM #__jgrid_tables_vcontrol a
		          	LIMIT 1';		

		  	$db->setQuery($query);
			// if  found then new install and update both to 1
			$result=$db->loadResult();
	
			$result = jgrid_database_upgrade($result,$site_admin,$new_install);
			if($result==0) return array(0,'Database upgrade failed');
			// set database version as upgraded
			$query = 'UPDATE #__jgrid_tables_vcontrol a
                    SET a.grid_version = (SELECT b.grid_version
                                          FROM #__jgrid_code_vcontrol b
                                          WHERE id = 1)
                    WHERE id = 1';		
			$db->setQuery($query);
			$db->query();
			
			// set code to one as well
			$query = '	UPDATE #__jgrid_code_vcontrol a
              			SET a.jgrid_installed = 1
                    	WHERE id = 1';		
			$db->setQuery($query);
			$db->query();
		  }

		  
		  // update any new user defined groups if version 1.6 and above		
		  if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
		  {			
			$query = 'SELECT a.title
                  FROM #__usergroups a
                  LEFT JOIN #__jgrid_user_type_defaults b ON a.title = b.usertype_name 
                  WHERE b.usertype_name IS NULL';					
			$this->_count = $this->_getListCount( $query );
			if($this->_count!=0)
			{
				// insert values into jos/jgrid_user_type_defaults default to 1 viewer
				$this->_data = $this->_getList( $query );
				for ($i=0;$i<$this->_count;$i++)
				{
				
					$query = 'INSERT INTO #__jgrid_user_type_defaults (
						usertype_name,	
						access_level,	
						version16,
						version15) 
					VALUES(
						"'.$this->_data[$i]->title.'",
						1,
						1,
						0)';
				}
				$db->setQuery($query);
				$result=$db->query();			
			}
			// remove any user groups deleted from jos_usergroups from jos_jgrid_user_type_defaults and from security rules
			$query = '	SELECT a.id, a.usertype_name
                  		FROM #__jgrid_user_type_defaults a
                  		LEFT JOIN #__usergroups b ON a.usertype_name = b.title
                  		WHERE b.title IS NULL';		

			$this->_count = $this->_getListCount( $query );
			if($this->_count!=0)
			{
				$this->_data = $this->_getList( $query );
				for ($i=0;$i<$this->_count;$i++)
				{
		
					$query = '	DELETE 
								FROM	#__jgrid_user_type_defaults
								WHERE id = '.$this->_data[$i]->id;
					$db->setQuery($query);
					$result=$db->query();
					//also delete any access rules using these deleted default names
					$query = '	DELETE 
								FROM	#__jgrid_security
								WHERE access_for = 3
								  AND access_for_id = '.$this->_data[$i]->id;
					$db->setQuery($query);
					$result=$db->query();
				}
							
			}
		  } 
 
		}	
}
