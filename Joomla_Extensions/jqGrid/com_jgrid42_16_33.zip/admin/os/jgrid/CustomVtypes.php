<?php
/**
 * CustomVtypes   in Joomla/Administrator/Components/os/jgrid
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

echo 'Ext.apply(Ext.form.VTypes,{

    timeText: "'.JText::_("NOT_A_VALID_TIME").'",  
    timeMask: /[\d\s:amp]/i,
    timeRe: /^([1-9]|1[0-9]):([0-5][0-9])(\s[a|p]m)$/i,
    time : function (v) {
        return this.timeRe.test(v);
    },
    dollarText: "'.JText::_("NOT_A_VALID_DOLLAR_AMOUNT").'",
    dollarMask: /[\d-]/,
    dollarRe: /^[\$]?[\d]*(.[\d]{2})?$/,
    dollar : function (v) {
        return this.dollarRe.test(v);
    },          
    phoneText: "'.JText::_("NOT_A_VALID_PHONE_NUMBER").'",
    phoneMask: /[\d-]/,
    phoneRe: /^(\d{3}[-]?){1,2}(\d{4})$/,
    phone : function (v) {
        return this.phoneRe.test(v);
    },          
    numericText: "'.JText::_("ONLY_NUMBERS_ARE_ALLOWED").'",
    numericMask: /[0-9]/,
    numericRe: /(^-?\d\d*.\d*$)|(^-?\d\d*$)|(^-?.\d\d*$)/,
    numeric :function (v) {
        return this.numericRe.test(v);
    },           
    decimalText: "'.JText::_("ONLY_DECIMAL_NUMBERS_ARE_ALLOWED").'",
    decimalMask: /(\d|.)/,
    decimalRe: /\d+.\d+|\d+/,
    decimal : function (v) {
        return this.decimalRe.test(v);
    }
});'; 
