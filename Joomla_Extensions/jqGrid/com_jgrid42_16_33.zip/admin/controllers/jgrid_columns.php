<?php
/**
 * Jgrid_columns Controller in Joomla/Administrator/Components/controllers
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );


/**
 * Jgrid_columns controller
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid administrator "Column Settings" screen
 * to "Grid Column Settings"
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class JgridsControllerJgrid_columns extends JgridsController
{

	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The pointer to the joomla model to be accesses
	 * @var array
	 */
	var $_model=null;

	/**
	 * Retrieves the "Column Settings" data
	 * @return string json string containing the "Column Settings" grid rows or false if no row returned
	 */
	function read()
	{
		$this->_model = $this->getModel('jgrid_columns');
		list($this->_result_count,$this->_result) = $this->_model->getColumnRows();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Updates the   "Column Settings" data being edited in the  "Column Settings" grid
	 * @return integer return true if row updated or false if update failed.
	 */
	function update()
	{
		$this->model = $this->getModel('jgrid_columns');
		if($this->model->updateColumnRow()) Echo '{success:true}';
		else Echo '{success:false}';
	}

	/**
	 * Creates new column in the "Column Settings" grid
	 * @return string json encoded string containing new column default data to the "Columns settings" grid row or false if column not created.
	 */
	function create()
	{
		$this->model = $this->getModel('jgrid_columns');
		$this->_result = $this->model->createColumnRow();
		if($this->_result) Echo '{success:true,results:"1",rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Deletes column record (row) in the "Columns Setting" grid
	 * @return integer result true if column removed or false if remove failed
	 */
	function destroy()
	{
		$this->model = $this->getModel('jgrid_columns');
		if($this->model->deleteColumnRow())Echo '{success:true}';
		else Echo '{success:false}';
	}
	
	/**
	 * Retrieves the "validation format" data
	 * @return string json string containing the "validation formats based onl column type" grid rows or false if no row returned
	 */
	function jgrid_valid_format_query()
	{
		$this->_model = $this->getModel('jgrid_columns');
		list($this->_result_count,$this->_result) = $this->_model->jgrid_valid_format_query();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

}