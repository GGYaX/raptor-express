<?php
/**
 * Jgrid_columngrid Controller in Joomla/Administrator/Components/controllers
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_columngrid controller
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid administrator "assignment of columns to grids" screen
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class JgridsControllerJgrid_columngrid extends JgridsController
{
	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The pointer to the joomla model to be accesses
	 * @var array
	 */
	var $_model=null;


	var $columngriditems=null;
	var $model=null;
	var $result_count=null;
	var $parms=null;


	/**
	 * Retrieves the "Columns assigned to grid" data
	 * @return string json string containing the "Columns assigned to the grid" or false if no row returned
	 */
	function read()
	{
		$this->_model = $this->getModel('jgrid_columngrid');
		list($this->_result_count,$this->_result) = $this->_model->getColumnGridRows();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Retrieves the jgrid columns that have not been added yet to grid and are available to add in combo box
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function newcolumnlist()
	{
		$this->_model = $this->getModel('jgrid_columngrid');
		list($this->_result_count,$this->_result) = $this->_model->getColumnList();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Updates the   "Columns assigned to the grid" data being edited in the  "Add Columns to selected grid" grid
	 * @return integer return true if row updated or false if update failed.
	 */
	function update()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		if($this->model->updateColumnGridRows()) Echo '{success:true}';
		else Echo '{success:false}';
	}

	/**
	 * Creates new columns assigned to grid in the "Add Columns to selected grid" grid
	 * @return string json encoded string containing new column default data to the "Add Columns to selected grid" row or false if column not created.
	 */
	function create()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		$this->_result = $this->model->createColumnGridRow();
		if($this->_result) Echo '{success:true,results:"1",rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * Moves selected data grid order "Data Grids" grid
	 * @return integer result true if grid deleted or false if delete failed
	 */
	function moveColumn()
	{
		$this->_model = $this->getModel('jgrid_columngrid');
		if($this->_model->moveGridRow('#__jgrid_columngrid')) Echo '{success:true}';
		else Echo '{success:false}';
	}

	/**
	 * Deletes column assigned to grid record (row) in the "Add Columns to selected grid" grid
	 * @return integer result true if column removed or false if remove failed
	 */
	function destroy()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		if($this->model->deleteColumnGridRow())Echo '{success:true}';
		else Echo '{success:false}';
	}
	
	/**
	 * selects jgrid_columngrid_column_type combo list valid entries
	 * @return array of values false if failed
	 */
	function jgrid_columngrid_column_type()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		list($this->_result_count,$this->_result) = $this->model->jgrid_columngrid_column_type();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}
	
	
	/**
	 * selects database_sql_name combo list valid entries
	 * @return array of values false if failed
	 */
	function database_sql_name()
	{
		$this->model = $this->getModel('jgrid_columngrid');		
		list($this->_result_count,$this->_result) = $this->model->database_sql_name();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}
	
	/**
	 * selects table_sql_name combo list valid entries
	 * @return array of values false if failed
	 */
	function table_sql_name()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		list($this->_result_count,$this->_result) = $this->model->table_sql_name();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}
	
	/**
	 * selects column_sql_name combo list valid entries
	 * @return array of values false if failed
	 */
	function column_sql_name()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		list($this->_result_count,$this->_result) = $this->model->column_sql_name();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}
	
	/**
	 * Retrieves the SelectCriteriaRows assigned to grid" data
	 * @return string json string containing the "Columns assigned to the grid" or false if no row returned
	 */
	function readJoinCriteria()
	{
		$this->_model = $this->getModel('jgrid_columngrid');
		list($this->_result_count,$this->_result) = $this->_model->readJoinCriteria();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}


	/**
	 * Updates the   SelectCriteriaRows 
	 * @return integer return true if row updated or false if update failed.
	 */
	function updateJoinCriteria()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		if($this->model->updateJoinCriteria()) Echo '{success:true}';
		else Echo '{success:false}';
	}

	/**
	 * Creates new SelectCriteriaRows 
	 * @return string json encoded string containing new column default data to the "Add Columns to selected grid" row or false if column not created.
	 */
	function createJoinCriteria()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		$this->_result = $this->model->createJoinCriteria();
		if($this->_result) Echo '{success:true,results:"1",rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}


	/**
	 * Deletes SelectCriteriaRows 
	 * @return integer result true if column removed or false if remove failed
	 */
	function destroyJoinCriteria()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		if($this->model->destroyJoinCriteria()) Echo '{success:true}';
		else Echo '{success:false}';
	}
	
	
	/**
	 * selects jgrid_select_wildcards combo list valid entries
	 * @return array of values false if failed
	 */
	function jgrid_select_wildcards()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		list($this->_result_count,$this->_result) = $this->model->jgrid_select_wildcards();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}
	
	/**
	 * selects jgrid_select_criteria_type combo list valid entries
	 * @return array of values false if failed
	 */
	function jgrid_select_criteria_type()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		list($this->_result_count,$this->_result) = $this->model->jgrid_select_criteria_type();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}
	
	/**
	 * selects  Database Select Query
	 * @return array of values false if failed
	 */
	function read_jgrid_select_query()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		list($this->_result_count,$this->_result) = $this->model->read_jgrid_select_query();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}
	
	/**
	 * selects Custom SQL QUERY Saved in DATABASE
	 * @return array of values false if failed
	 */
	function read_jgrid_custom_sql_query()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		list($this->_result_count,$this->_result) = $this->model->read_jgrid_custom_sql_query();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}

	/**
	 * selects Custom Where Clause Depedencies 
	 * @return array of values false if failed
	 */
	function read_jgrid_select_custom_criteria()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		list($this->_result_count,$this->_result) = $this->model->read_jgrid_select_custom_criteria();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}	
	
	/**
	 * udate select query 
	 * @return array of values false if failed
	 */
	function update_jgrid_select_query()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		$this->_result = $this->model->update_jgrid_select_query();
		if($this->_result)Echo '{success:true}';
		else Echo '{success:false}';
	}	
	
	/**
	 * update Custom sql select query  
	 * @return array of values false if failed
	 */
	function update_jgrid_custom_sql_query()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		$this->_result = $this->model->update_jgrid_custom_sql_query();
		if($this->_result)Echo '{success:true}';
		else Echo '{success:false}';
	}	
	
	/**
	 * update Custom Where Clause Depedencies   
	 * @return array of values false if failed
	 */
	function update_jgrid_select_custom_criteria()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		$this->_result = $this->model->update_jgrid_select_custom_criteria();
		if($this->_result)Echo '{success:true}';
		else Echo '{success:false}';
	}
	
	/**
	 * test grid sql query
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function jgrid_test_grid_select()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		list($this->_result_count,$this->_result) = $this->model->jgrid_test_grid_select();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
	}
	
	/**
	 * error message from last sql select test does not work for descriptive error messages
	 * @return array Array of objects containing the data from the database and integer number of results
	 */
	function jgrid_test_error_message()
	{
		$this->model = $this->getModel('jgrid_columngrid');
		list($this->_result_count,$this->_result) = $this->model->jgrid_test_error_message();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}
	
}