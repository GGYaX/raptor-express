<?php
/**
 * Jgrid_sqlselect Controller in Joomla/Administrator/Components/controllers
 *
 * @version	    $id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

/**
 * Jgrid_sql_select controller
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid administrator "assignment of columns to grids" screen
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */
class JgridsControllerJgrid_sqlselect extends JgridsController
{
	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The pointer to the joomla model to be accesses
	 * @var array
	 */
	var $_model=null;


	var $sql_selectitems=null;
	var $model=null;
	var $result_count=null;
	var $parms=null;


	/**
	 * Retrieves the SelectCriteriaRows assigned to grid" data
	 * @return string json string containing the "Columns assigned to the grid" or false if no row returned
	 */
	function readJoinCriteria()
	{
		$this->_model = $this->getModel('jgrid_sqlselect');
		list($this->_result_count,$this->_result) = $this->_model->readJoinCriteria();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}


	/**
	 * Updates the   SelectCriteriaRows 
	 * @return integer return true if row updated or false if update failed.
	 */
	function updateJoinCriteria()
	{
		$this->model = $this->getModel('jgrid_sqlselect');
		if($this->model->updateJoinCriteria()) Echo '{success:true}';
		else Echo '{success:false}';
	}

	/**
	 * Creates new SelectCriteriaRows 
	 * @return string json encoded string containing new column default data to the "Add Columns to selected grid" row or false if column not created.
	 */
	function createJoinCriteria()
	{
		$this->model = $this->getModel('jgrid_sqlselect');
		echo 'sql1 ';
		return true;
		$this->_result = $this->model->createJoinCriteria();
		if($this->_result) Echo '{success:true,results:"1",rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}


	/**
	 * Deletes SelectCriteriaRows 
	 * @return integer result true if column removed or false if remove failed
	 */
	function destroyJoinCriteria()
	{
		$this->model = $this->getModel('jgrid_sqlselect');
		if($this->model->destroyJoinCriteria()) Echo '{success:true}';
		else Echo '{success:false}';
	}
	
	
	/**
	 * selects jgrid_select_wildcards combo list valid entries
	 * @return array of values false if failed
	 */
	function jgrid_select_wildcards()
	{
		$this->model = $this->getModel('jgrid_sqlselect');
		list($this->_result_count,$this->_result) = $this->model->jgrid_select_wildcards();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}
	
	/**
	 * selects jgrid_select_criteria_type combo list valid entries
	 * @return array of values false if failed
	 */
	function jgrid_select_criteria_type()
	{
		$this->model = $this->getModel('jgrid_sqlselect');
		list($this->_result_count,$this->_result) = $this->model->jgrid_select_criteria_type();
		if($this->_result)Echo '{success:true,results:'.$this->_result_count.',rows:'. json_encode($this->_result) .'}';
		else Echo '{success:false}';
	}
	
	

	
}