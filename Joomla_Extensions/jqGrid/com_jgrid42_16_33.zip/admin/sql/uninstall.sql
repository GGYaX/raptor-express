DROP TABLE IF EXISTS `#__jgrid_code_vcontrol`;
DROP TABLE IF EXISTS `#__jgrid_user_type_defaults`;
DROP TABLE IF EXISTS `#__jgrid_current_user_grid_document`;
DROP TABLE IF EXISTS `#__jgrid_temp_table`;
DROP TABLE IF EXISTS `#__jgrid_temp_table2`; 