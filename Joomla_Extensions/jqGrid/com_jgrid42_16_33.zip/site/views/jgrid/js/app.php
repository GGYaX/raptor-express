<?php
/**
 * app.php in joomla/Components/views/jgrid/js
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

//Ext.require([ "Ext.grid.*", "Ext.data.*", "Ext.util.*", "Ext.form.*", 'Ext.form.field.File', "Ext.grid.PagingScroller", "Ext.tip.*", "Ext.Button", "Ext.window.*" ]);
Ext.require([ "Ext.grid.*", "Ext.data.*", "Ext.util.*", "Ext.form.*", 'Ext.form.field.File', "Ext.tip.*", "Ext.Button", "Ext.window.*" ]);

Ext.Loader.setConfig({
	enabled : true
});

Ext.application({

	// name of the application
	name : "JGrid",

	// define app folder
	//appFolder : "../../../../../joomla256/components/com_jgrid/views/jgrid/js/app",
	
	// Requires do not work with Joomla PHP so loaded instead in default.php to use Joomla namespace and then works in extjs mvc. 
	//requires : [ "JGrid.view.Viewport" ],

	controllers: ["JGridController0"],

	launch : function() {
	

		// launch main tab view      
		 var task = Ext.create('Ext.util.DelayedTask', function () {
            Ext.create("JGrid.view.Viewport").show();
        });
		task.delay(	<?php	if($params->get('jgrid_delay'))
    	{
     	 echo $params->get ('jgrid_delay');
    	} 
  		else 
   		{
    		echo '500';
 		}?>
 		);
		
		// reset to extjs document_id from mootools document_id
		//document.id = Ext.documentID;
		
		// shorthand alias
        var fm = Ext.form;
        
        // Initialize tool tips
		Ext.QuickTips.init();

	}
});


