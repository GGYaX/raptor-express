<?php
/**
 * viewport.php in joomla/Components/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

require_once(JPATH_BASE . '/administrator/components/com_jgrid/os/jgrid/functions.php' );
if((JRequest::getVar('application_type','','','STRING')=='MODULE'))
{
	jimport( 'joomla.application.module.helper' );
	$module = JModuleHelper::getModule(JRequest::getVar('jgrid_application_name'));
	$params = new JRegistry();
	if(class_exists('JParameter'))
	{
		$params = new JParameter( $module->params ); 
	}
	else 
	{
	   $params->loadString($module->params);
	}		
}
else 
{
	$params = JComponentHelper::getParams('com_jgrid');
}

//JError::raiseError(1003,$params->get ('jgrid_application_name'));
//return;

$fversion = $params->get ('fversion');
?>
Ext.require([
    'Ext.window.Window',
    'Ext.tab.*',
    'Ext.*',
    'Ext.toolbar.Spacer',
    'Ext.layout.container.Card',
	'Ext.ProgressBar',
    'Ext.layout.container.Border'
]);
	
Ext.define("JGrid.view.Viewport", {
	// As full page view port
	//extend : "Ext.container.Viewport",	
	// as panel in joomla structure
	extend : "Ext.panel.Panel",
	layout: "border",
	statics: {
		static_grid_id: 0,
		static_new_document_id:0,
		static_last_document_id:0,
		static_itemIndex:0
	},
<?php
echo 'requires : [ "JGrid.view.JGridGrid0" ';	
for($j=1;$j<$gridCount;$j++) {
	echo ' ,"JGrid.view.JGridGrid'.$j.'"';
}
    echo '],';
	echo 'layout : "fit",';	
	
    if($params->get('jgrid_renderTo'))
    {
      echo 'renderTo: "'.$params->get ('jgrid_renderTo').'",';
    } 
    else 
    {
      if(JRequest::getVar('application_type')=='MODULE')
      {
        echo 'renderTo: "jgrid_module1",';
      }
      else echo 'renderTo: "jgrid_component",';
    } 
    if($params->get ('jgrid_width'))
    {
      echo 'width: '.$params->get ('jgrid_width').',';
    } 
    else echo 'width: 900,'; 
    if($params->get ('jgrid_height'))
    {
      echo 'height: '.$params->get ('jgrid_height').',';
    } 
    else echo 'height: 751,';     
    if($params->get ('jgrid_tab_panel_title'))
    {
      echo 'title: "'.$params->get ('jgrid_tab_panel_title').'",';
    } 
    else echo 'title: "Jgrid Tab Panel",';	
?>
	items : [ {
		id : "jgrid_tabpanel",
		region: "center",
		xtype : "tabpanel",
		layout: "fit",
		enableTabScroll:true,
		margins: "5 5 0 0",
        activeTab: 0,
        listeners: {
            tabchange: function (tabpanel, tab) {
              if(tab.getId()!="chartTab"){
              	tab.items.items[0].store.load();
               	//tab.items.items[0].view.refresh();               
              }
            }
        },
<?php
        if($params->get ('jgrid_resize_tab_width')==1)
        {
         	echo 'resizeTabs: true,
               	  tabWidth: '.$params->get ('jgrid_tab_width').',';         
        }
?>
		items : [ {
<?php		
for($j=0;$j<$gridCount;$j++) {
		if( $j!=0) echo ' ,{';	 		
			echo 'layout : "border",
			title: "' .$griditems[$j]->title    . '",
			tabTip: "'. $griditems[$j]->tabtip . '",
			height: ' . $griditems[$j]->height . ',
   			//width: '. $griditems[$j]->width . ',
   			layout: "fit",
			id:"dataTab'.$j.'",
			region : "center", 	
			items : [ {
				xtype : "JGridGrid'.$j.'"
			}
			//			,
//			{
//				region : "south",
//				xtype : "JGridGridDetail'.$j.'"
//			} 
			]
		// end Selector items
		}';
}
?>				
	,{
		title:'',
		hidden:true,
		hideMode:'offsets',  
		id:'chartTab',
		items:[{
			xtype:'JGridChartWin'
		}]	
	}]
	// items of tab panel
	}]
// items of Viewport

});


