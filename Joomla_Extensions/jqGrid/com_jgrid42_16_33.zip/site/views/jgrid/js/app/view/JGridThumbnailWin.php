<?php
 /*
 *  JGridThumbnailWin.php  in joomla/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>

Ext.define("JGrid.view.JGridThumbnailWin", {
	extend : "Ext.window.Window",
	alias : "widget.JGridThumbnailWin",
	id: "JGridThumbnailWin",
    title: "",
    border: false,
    closeAction: "hide",
    layout: 'fit',
    autoHeight: true,
<?php      
    if($params->get ('jgrid_renderTo'))
	{
		echo 'renderTo: "'.$params->get ('jgrid_renderTo').'", ';
	} 
	else echo 'renderTo: "jgrid_component",';   
    if($params->get ('jgrid_upload_image_win_width') > 0)
    {
    	echo 'width: '.$params->get ('jgrid_upload_image_win_width').',';
    } 
    else echo 'width: 500,';
    if($params->get ('jgrid_upload_image_win_height') > 0)
    {
    	echo 'height: '.$params->get ('jgrid_upload_image_win_height').',';
    } 
    else echo 'height: 325,';         
    if($params->get ('jgrid_upload_image_win_x') > 0)
    {
    	echo 'x: '.$params->get ('jgrid_upload_image_win_x').',';
    }
    if($params->get ('jgrid_upload_image_win_y') > 0)
    {
   		echo 'y: '.$params->get ('jgrid_upload_image_win_y').',';
    }
?>        
   items:  [{ 
    	id: 'thumbtabs',
		xtype : "tabpanel",
		enableTabScroll:true,
		margins: "5 5 0 0",
        activeTab: 0,    
    	items : [{
			xtype: 'form',
			extend : "Ext.form.Panel",
			alias : "widget.JGridThumbnailFm",
			id: "JGridThumbnailFm",
		    fileUpload: true,
			isUpload: true,
		    buttonAlign: 'center',
		   // width: 400,
		    frame: true,
		    style: 'margin: 0 auto;',
		<?php                   
		      echo 'title: "'.JText::_("FILE_UPLOAD_FORM").'",';
		?> 		    
		    autoHeight: true,

            defaultType: "container",		    
		    bodyStyle: "padding: 10px 10px 0 10px;",
		    labelWidth: 50,
		    defaults: {
		    	autoEl: {},
		        anchor: '100%',
		        allowBlank: true,
		        msgTarget: "side",
		        layout: 'form'
		    },
          	items: [{
          		xtype: 'fieldset',
              	autoHeight: true,
              	labelAlign: 'right',
               	waitMsgTarget: true,
              	defaultType: "container",		    
		    items: [{
		    	xtype: "filefield",
		    	buttonConfig: {
		            iconCls: 'upload-icon'
		        },
				buttonText: 'browse',
				disabled: false,
		    	id: "photo",
		<?php                   
		      echo 'emptyText: "'.JText::_("SELECT_AN_IMAGE").'",
		        fieldLabel: "'.JText::_("PHOTO").'",
		      plugins: [ new Ext.ux.FieldHelp("'. JText::_("SELECT_AN_IMAGE_TO_UPLOAD").'") ],';
		?>                  
		        name: "photo"
			}, 
		    { 	xtype: 'textfield',
		        id: "imagetooltip",
		<?php                   
		    echo 'emptyText: "'.JText::_("ENTER_A_TOOLTIP").'",
		       fieldLabel: "'.JText::_("TOOLTIP").'",
		       plugins: [ new Ext.ux.FieldHelp("'. JText::_("ENTER_A_TOOLTIP_TO_HOVER_OVER_THE_IMAGE_THUMBNAIL").'") ],';
		?>                                                                       
		        name: 'imagetooltip',
		        width: 300
		    },       
		    {  	xtype: 'textfield',
		        id: "image_url",
		<?php                   
		      echo 'emptyText: "'.JText::_("ENTER_A_URL").'",
		       fieldLabel: "'.JText::_("URL_REF").'",
		        plugins: [ new Ext.ux.FieldHelp("'. JText::_("ENTER_A_URL_TO_ASSOCIATE_WITH_IMAGE_POPUP_BUTTON").'") ],';
		?>                                                     
		        name: 'image_url',
		        vtype: 'url',
		        width: 300
			},			
			combo3,
			{  	xtype: 'textfield',
		        id: "image_email",
		<?php                   
		      echo 'emptyText: "'.JText::_("ENTER_AN_EMAIL").'",
		       fieldLabel: "'.JText::_("EMAIL_REF").'",
		        plugins: [ new Ext.ux.FieldHelp("'. JText::_("ENTER_AN_EMAIL_TO_ASSOCIATE_WITH_IMAGE_POPUP_BUTTON").'") ],';
		?>                                                     
		        name: 'image_email',
		        vtype: 'email',
		        width: 300
			},
			{  	xtype: 'textfield',
		        id: "image_email_subject",
		<?php                   
		      echo 'emptyText: "'.JText::_("ENTER_EMAIL_SUBJECT").'",
		       fieldLabel: "'.JText::_("EMAIL_SUBJECT_REF").'",
		        plugins: [ new Ext.ux.FieldHelp("'. JText::_("ENTER_THE_DEFAULT_SUBJECT_OF_EMAIL").'") ],';
		?>                                                     
		        name: 'image_email_subject',
		        width: 300
		        }]
			}
		   ],
		   buttons: [{
		<?php       
		     echo 'text: "'. JText::_("SAVE").'",';
		?>
		   		handler: function(){  
		          if(Ext.getCmp("JGridThumbnailFm").getForm().isValid()){
			    	Ext.getCmp("JGridThumbnailFm").getForm().submit({
		<?php
		            	echo'url: "'.JURI::base().'index.php?option=com_jgrid&task=save_images&controller=jgrid_images&format=ajax&loadtype=image&grid_sheet="+combo3.getValue()+"&filename="+Ext.getCmp("photo").getValue()+"&tooltip="+Ext.getCmp("imagetooltip").getValue()+"&grid_id="+JGrid.thumbnailImage["grid_id"]+"&document_id="+JGrid.thumbnailImage["document_id"]+"&column_id="+JGrid.thumbnailImage["column_id"]+"&row_id="+JGrid.thumbnailImage["row_id"]+"&primary_key_value="+JGrid.thumbnailImage["primary_key_value"]+"",	     
			            waitMsg: "'.JText::_("UPLOADING_YOUR_PHOTO").'",
			            failure: function (response, o) {  
		                	Ext.MessageBox.alert("'. JText::_("IMAGE_SAVE_FAILED").'",Ext.decode(o.response.responseText).data);        
		       			},';
		?>
			            success: function(jgrid_thumbnail_loader, o){
			            	var revisedData = Ext.decode(o.response.responseText).data;
			            	JGrid.cacheState[JGrid.thumbnailImage["grid_index"]][JGrid.thumbnailImage["column_index"]]++;
			            	JGrid.thumbnailImage["record"].set(JGrid.thumbnailImage["fieldName"],revisedData);
			            	// Ext.ComponentMgr.get("photo").setValue("");
		                	JGrid.thumbnail_win.hide(); 
			  			}
					});
				  }
				}                        
			},
		    {
		<?php     
				echo 'text: "'. JText::_("DELETE").'",
				handler: function(){
		      		Ext.Ajax.request({
		        		waitMsg: "'.JText::_("DELETING_IMAGE").'",            
		            	url: "'.JURI::base().'index.php?option=com_jgrid&task=update&delete_image=1&grid_id="+JGrid.thumbnailImage["grid_id"]+"&document_id="+JGrid.thumbnailImage["document_id"]+"&column_id="+JGrid.thumbnailImage["column_id"]+"&row_id="+JGrid.thumbnailImage["row_id"]+"&format=ajax",';
		?>                
		            	params: {
		            		rows: '{"'+JGrid.thumbnailImage["fieldName"]+'":"","id":'+JGrid.thumbnailImage["record"].id+'}'               
		            	},
		            	method: "POST",
		            	failure: function (response, options) {  
		<?php  
		            		echo 'Ext.MessageBox.alert("'. JText::_("IMAGE_DELETE_FAILED").'", "");';
		?>            	                                 
		         		},
		           		success: function (response, options) {
		            		var server_response = Ext.decode(response.responseText);
		            		if (!server_response.success) {
		<?php            	
		                		echo 'Ext.MessageBox.alert("'. JText::_("IMAGE_DELETE_FAILED").'", "");';
		?>                                         
		                	} else {
		                    	// delete from screen
		                        JGrid.thumbnailImage["record"].set(JGrid.thumbnailImage["fieldName"],"");
		                        Ext.getCmp("JGridThumbnailFm").getForm().reset();
		                        JGrid.thumbnail_win.hide();
		                	}
		          		},
		            	scope: this
		     		});               
				}
			},
		    {
		<?php    	
				echo 'text: "'. JText::_("RESET").'",';
		?>            
				handler: function(){
		       		Ext.getCmp("JGridThumbnailFm").getForm().reset();
				}
			}]
  		},
  		{
			xtype: 'form',
			extend : "Ext.form.Panel",
			alias : "widget.JGridOptThumbFm",
			id: "JGridOptThumbFm",
		    fileUpload: true,
			isUpload: true,
			hidden: true,
		    buttonAlign: 'center',
		    width: 400,
		    frame: true,
		    style: 'margin: 0 auto;',
		<?php                   
		      echo 'title: "'.JText::_("OPTIONAL_CUSTOM_THUMBNAIL_IMAGE").'",';
		?> 	
		    autoHeight: true,
		    bodyStyle: "padding: 10px 10px 0 10px;",
		    labelWidth: 50,
		    defaults: {
		        anchor: "95%",
		        allowBlank: true,
		        msgTarget: "side"
		    },
		    items: [{
		    	xtype: "filefield",
		    	buttonConfig: {
		            iconCls: 'upload-icon'
		        },
				buttonText: 'browse',
				disabled: false,
		    	id: "thumbnail_image",
		<?php                   
		      echo 'emptyText: "'.JText::_("SELECT_AN_THUMBNAIL_IMAGE").'",
		        fieldLabel: "'.JText::_("THUMBNAIL_IMAGE").'",
		      plugins: [ new Ext.ux.FieldHelp("'. JText::_("SELECT_A_THUMBNAIL_IMAGE_TO_UPLOAD").'") ],';
		?>                  
		        name: "thumbnail_image"
			}
		   ],
		   buttons: [{
		<?php       
		     echo 'text: "'. JText::_("SAVE").'",';
		?>
		   		handler: function(){  
		          if(Ext.getCmp("JGridOptThumbFm").getForm().isValid()){
			    	Ext.getCmp("JGridOptThumbFm").getForm().submit({
		<?php
		            	echo'url: "'.JURI::base().'index.php?option=com_jgrid&task=save_images&controller=jgrid_images&format=ajax&loadtype=thumb&grid_sheet="+JGrid.thumbnail_loader.items.items[3].getValue()+"&filename="+JGrid.thumbnail_loader.items.items[0].getValue()+"&tooltip="+JGrid.thumbnail_loader.items.items[1].getValue()+"&grid_id="+JGrid.thumbnailImage["grid_id"]+"&document_id="+JGrid.thumbnailImage["document_id"]+"&column_id="+JGrid.thumbnailImage["column_id"]+"&row_id="+JGrid.thumbnailImage["row_id"]+"",	     
			            waitMsg: "'.JText::_("UPLOADING_YOUR_IMAGE").'",
			            failure: function (response, o) {  
		                	Ext.MessageBox.alert("'. JText::_("IMAGE_SAVE_FAILED").'",Ext.decode(o.response.responseText).data);        
		       			},';
		?>
			            success: function(jgrid_thumbnail_loader, o){
			            	var revisedData = Ext.decode(o.response.responseText).data;
			            	JGrid.cacheState[JGrid.thumbnailImage["grid_index"]][JGrid.thumbnailImage["column_index"]]++;
			            	JGrid.thumbnailImage["record"].set(JGrid.thumbnailImage["fieldName"],revisedData);
			            	// Ext.ComponentMgr.get("photo").setValue("");
		                	JGrid.thumbnail_win.hide(); 
			  			}
					});
				  }
				}                        
			},
		    {
		<?php     
				echo 'text: "'. JText::_("DELETE").'",
				handler: function(){
		      		Ext.Ajax.request({
		        		waitMsg: "'.JText::_("DELETING_IMAGE").'",            
		            	url: "'.JURI::base().'index.php?option=com_jgrid&task=delete_images&controller=jgrid_images&format=ajax&delete_image=1&grid_id="+JGrid.thumbnailImage["grid_id"]+"&document_id="+JGrid.thumbnailImage["document_id"]+"&column_id="+JGrid.thumbnailImage["column_id"]+"&row_id="+JGrid.thumbnailImage["row_id"]+"&format=ajax",';
		?>                
		            	params: {
		            		rows: '{"'+JGrid.thumbnailImage["fieldName"]+'":"","id":'+JGrid.thumbnailImage["record"].id+'}'               
		            	},
		            	method: "POST",
		            	failure: function (response, options) {  
		<?php  
		            		echo 'Ext.MessageBox.alert("'. JText::_("IMAGE_DELETE_FAILED").'", "");';
		?>            	                                 
		         		},
		           		success: function (response, options) {
		            		var server_response = Ext.decode(response.responseText);
		            		if (!server_response.success) {
		<?php            	
		                		echo 'Ext.MessageBox.alert("'. JText::_("IMAGE_DELETE_FAILED").'", "");';
		?>                                         
		                	} else {
		                    	// delete from screen
		                        Ext.getCmp("JGridOptThumbFm").getForm().reset();
		                        JGrid.thumbnail_win.hide();
		                	}
		          		},
		            	scope: this
		     		});               
				}
			},
		    {
		<?php    	
				echo 'text: "'. JText::_("RESET").'",';
		?>            
				handler: function(){
		       		Ext.getCmp("JGridOptThumbFm").getForm().reset();
				}
			}]
			}]
	}]
});
     

     
