<?php
/*
 *  JGridStores.php in joomla/Components/com_jgrid/views/jgrid/js/app/store
 *
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );


for($j=0;$j<$gridCount;$j++) {
	// set value of primary_key_column when no value
	if($griditems[$j]->primary_key_column==0 || $griditems[$j]->primary_key_column == '..');
		$griditems[$j]->primary_key_column = false;
	
	//check for paging and add default paging limits
    $read_url = '"'.JURI::base().'index.php?option=com_jgrid&task=read&format=ajax&grid_id=' . $griditems[$j]->id;
    if($griditems[$j]->enable_paging==true)
	{
	$read_url .= '&start=0&limit=' . $griditems[$j]->paging_records;
	}
    $read_url .= '"';
    
    //Create Proxys		
	echo 'JGrid.proxy['.$j.'] = Ext.create("Ext.data.HttpProxy", {
		type: "ajax",
		id: "proxy'.$j.'",
	    api: {
	           read : '.$read_url.',
	           create : "'.JURI::base().'index.php?option=com_jgrid&task=create&format=ajax&grid_id=' . $griditems[$j]->id .'",         
	           update: "'.JURI::base().'index.php?option=com_jgrid&task=update&format=ajax&grid_id=' . $griditems[$j]->id .'",
	           destroy: "'.JURI::base().'index.php?option=com_jgrid&task=destroy&format=ajax&grid_id=' . $griditems[$j]->id .'"
	     	},
	     	actionMethods: {
			    create : "POST",
			    read   : "GET",
			    update : "POST",
			    destroy: "POST"
			},
			reader: new Ext.data.JsonReader({
					root:"rows",
					totalProperty: "total",
					successProperty: "success",
					id:"id" 
			},JGrid.dsModel['.$j.']),
			writer: {
	            type: "json",
	            encode: true,
	            root:"rows",
	            writeAllFields : false,  //just send changed fields
	            allowSingle :false      //always wrap in an array
	       }	    
     });';

		 
	// Define Grid Store
	echo 'Ext.define("JGrid.store.JGridStore'.$j.'", {
	    extend: "Ext.data.Store",
	    requires: "JGrid.model.JGridModel'.$j.'",    
	    model: "JGrid.model.JGridModel'.$j.'",
	    alias : "widget.JGridStore' . $j . '",
	    storeId:"JGridStore'.$j.'",
	    id:"JGridStore'.$j.'",
	    autoSync: true,';
if($griditems[$j]->enable_paging==true) { 	    
	    echo 'pageSize: ' . $griditems[$j]->paging_records . ','; // items per page
}
	    echo 'autoLoad: false,';
			
		if($griditems[$j]->enableGroupBy  == 1)
		{
		//	echo 'JGrid.store['.$j.'] = new Ext.data.GroupingStore({';
			echo 'groupField: "' . $griditems[$j]->groupByField . '",';
			echo 'remoteGroup: false,';		
		}
		else if($griditems[$j]->enableGroupBy  == 2)
		{
		//	echo 'JGrid.store['.$j.'] = new Ext.data.GroupingStore({';
			echo 'groupField: "' . $griditems[$j]->groupByField . '",';
			echo 'remoteGroup: true,';				
		}
	//	else 
	//	{
	//	  echo 'JGrid.store['.$j.'] = new Ext.data.Store({';
	//	}
		
		if($griditems[$j]->enableSortBy  == 1)
		{
			  echo ' sorters: [{';
			  echo	' property: "' . $griditems[$j]->sortByField . '",';
			  echo    'direction: "'. $griditems[$j]->sortByDirection . '"';
			  echo  '}],';
			  echo ' remoteSort: false,';	
		}
		else if($griditems[$j]->enableSortBy  == 2)
		{  
			  echo ' sorters: [{';
			  echo	' property: "' . $griditems[$j]->sortByField . '",';
			  echo    'direction: "'. $griditems[$j]->sortByDirection . '"';
			  echo  '}],';
			  echo ' remoteSort: true,';	
		}       
		echo 'autoSave: true,
		proxy: JGrid.proxy['.$j.'],
		listeners: {
	       //RMS  not sure what it is for
	         beforeload: function(store, operation, opts) {
//	             JGrid.store['.$j.'].suspendEvents(); 
//	             JGrid.store['.$j.'].removeAll();
//	             JGrid.store['.$j.'].resumeEvents();
//	             Ext.ComponentMgr.get("'. $griditems[$j]->grid_reference_id  .'").getView().refresh();
	        },
	        beforesync: function(store, opts) {';
	            if($griditems[$j]->primary_key_column)
		          	{
		          		echo 'primary_key_value = store.update[0].data.'.$griditems[$j]->primary_key_column.';
		          		JGrid.store['.$j.'].proxy.api.update = "'.JURI::base().'index.php?option=com_jgrid&task=update&format=ajax&primary_key_value="+primary_key_value+"&grid_id=' . $griditems[$j]->id .'";';
						//store.update[0].getProxy().setExtraParam("primary_key_value", primary_key_value);';
	        		}
	        echo'},
	    	write: function (store, action, eOpts )
	      	{
	       		if(action.records[0].data.row_color)
	           	{
	        //RMS ?    	eOpts.rs.data.row_color=action.records[0].data.row_color;                         
	          //     	Ext.ComponentMgr.get("' . $griditems[$j]->grid_reference_id  . '").getView().refresh(); 
	          	}
	          	if(action.action=="create")
	          	{
	            	for(var i=1;i<=JGrid.columnCount['.$j.'];i++)
	              	{
	               		column_key = action.records[0].fields.keys[i];
	                	if(action.resultSet.records[0].fields.keys[i].substr(0,1)=="R")
	                   	{
	                 		action.records[0].set(column_key, action.resultSet.records[0].data.id);
	                   	} 
	          		}                         
	      		}
	      		if(action.action=="update"&&JGrid.selectType>"1")
	          	{';	
	          	if($griditems[$j]->primary_key_column)
	          	{
	          		echo '{
	          		  primary_key_value = store.data.items[0].data.'.$griditems[$j]->primary_key_column.';
	          		}
	          		store.proxy.api.update =  "'.JURI::base().'index.php?option=com_jgrid&task=update&format=ajax&primary_key_value="+primary_key_value+"&grid_id=' . $griditems[$j]->id .'";';
	          	}
	          	echo '}              
	    	}
	    	,
	    	load: function (store,records, result, eOpts ) {
	    		if(store.getCount() < 1) 
	    		{
	    		  Ext.Msg.alert("'.JText::_("NO_MATCH_FOUND").'");
	    		  return; 
	    		}
	    		JGrid.dslvl['.$j.']=store.getProxy().getReader().rawData.dslvl;
	    		JGrid.selectType['.$j.']=store.getProxy().getReader().rawData.select_type;
//	    		if(!Ext.isEmpty(store.getProxy().getReader().rawData))
//				{
//	    			JGrid.dslvl['.$j.']=store.getProxy().getReader().rawData.dslvl;
//	    		}
//	    		else 
//	    		{
//	    			JGrid.dslvl['.$j.'] = "D"; //RMS??
//	    		}
	     		access_level_array'.$j.' = set_access_levels('.$j.',
	          		"' . $griditems[$j]->grid_reference_id  . '",
	          		"Manage_Sheet_Access'.$j.'",
	         		"Manage_Sheets'.$j.'",
	           		"Add_Row_Above'.$j.'",
	          		"Edit_Row'.$j.'",
	          		JGrid.editMode['.$j.'] );                        
	      		if(records[0].data.id=="0")
	         	{
			    	if(JGrid.dslvl['.$j.'][0]>1) 
			      	{   
			      		if(JGrid.editMode['.$j.']==false)
			         	{
			          		Ext.ComponentMgr.get("Edit_Mode'.$j.'").show();
			           	}
			     	}
			    	else 
			  		{
			    		Ext.ComponentMgr.get("Edit_Mode'.$j.'").hide();
			     		Ext.ComponentMgr.get("View_Mode'.$j.'").hide();
			     	} 
	         	}
	    		access_level_array'.$j.' = set_access_levels('.$j.',
	                          "' . $griditems[$j]->grid_reference_id  . '",
	                          "Manage_Sheet_Access'.$j.'",
	                          "Manage_Sheets'.$j.'",
	                          "Add_Row_Above'.$j.'",
	                          "Edit_Row'.$j.'",
	                          JGrid.editMode['.$j.'] );
		   		if(access_level_array'.$j.'[0] >="2")
		   		{ 
		     		if(JGrid.editMode['.$j.']==false)
		     		{                      
		       			Ext.ComponentMgr.get("Edit_Mode'.$j.'").show();
		     		}   
		   		}
		  		else
		   		{
		     		Ext.ComponentMgr.get("Edit_Mode'.$j.'").hide();
		     		Ext.ComponentMgr.get("View_Mode'.$j.'").hide();
		   		}';
		    	for ($i=0,$m=$columnCount; $i < $m; $i++)
		    	{
		      		if($columnitems[$i]->grid_id == $griditems[$j]->id)
		      		{
		        		if($columnitems[$i]->data_type=='L')
		        		{       
		            		echo 'if(access_level_array'.$j.'[0]>"1") 
		            		{
		               			jgrid_list_box_combo_store_'.$j.'_'.$i.'.load();
		            		}';
		       			 }
			  		}
		    	} 
				echo 'Ext.ComponentMgr.get("' . $griditems[$j]->grid_reference_id  . '").on("validateedit", function(e){
		       		 e.value = Ext.util.Format.stripTags(e.value);
		      	});
	  		}
	  	}		
	 });';
	echo 'JGrid.store[' . $j . '] = Ext.create("JGrid.store.JGridStore'.$j.'");';			
}

?>

// manage grid user access jgrid_security administrator screen xtype: "editorgrid"
JGrid.proxy_access = Ext.create("Ext.data.HttpProxy", {
	type: "ajax",
	id: "proxy_access",
	api: {
<?php
       echo ' read: "'.JURI::base().'index.php?option=com_jgrid&task=read&controller=jgrid_security&grid_application_name='.$griditems[0]->grid_application_name.'&format=ajax",
        create: "'.JURI::base().'index.php?option=com_jgrid&task=create&controller=jgrid_security&grid_application_name='.$griditems[0]->grid_application_name.'&format=ajax",
        update: "'.JURI::base().'index.php?option=com_jgrid&task=update&controller=jgrid_security&grid_application_name='.$griditems[0]->grid_application_name.'&format=ajax",
        destroy: "'.JURI::base().'index.php?option=com_jgrid&task=destroy&controller=jgrid_security&grid_application_name='.$griditems[0]->grid_application_name.'&format=ajax"'
?>	
	},
	actionMethods: {
			create : "POST",
			read   : "GET",
			update : "POST",
			destroy: "POST"
	},
	reader: new Ext.data.JsonReader({
		root:"rows",
		totalProperty: "total",
		successProperty: "success",
		id:"id" 
	},JGrid.dsModel[4]),
	writer: {
		type: "json",
		encode: true,
	  	root:"rows",
	 	writeAllFields : false,  //just send changed fields
	  	allowSingle :false,      //always wrap in an array
    	returnJson: true //RMS check this if needed
	}    
});

// manage grid user access jgrid_security administrator screen xtype: "editorgrid"
Ext.define("JGrid.store.JGridStoreAccess", {
	    extend: "Ext.data.Store",
	    requires: "JGrid.model.JGridModelAccess",    
	    model: "JGrid.model.JGridModelAccess",
	    alias : "widget.JGridStoreAccess",
	    storeId:"JGridStoreAccess",
	    id:"JGridStoreAccess",
	    autoSync: true,
	    autoLoad: false,      
		autoSave: true,
		proxy: JGrid.proxy_access,
		sortInfo: {
        	field: 'access_for_id',
        	direction: 'ASC'
    	},
    	groupField: 'access_for_id'	
	 });	 
JGrid.store_access = Ext.create("JGrid.store.JGridStoreAccess");
JGrid.store_access.on('write', function () {
      JGrid.JGridAccessRules.hide();
      JGrid.JGridSecurity.getView().refresh();   
});
JGrid.store_access.on('beforeload', function () {
   JGrid.combo_store[41].load({
        params: {
            access_for: "0"
        }
    });
   JGrid.combo_store[43].load({
        params: {
            access_type: "0"
        }
    });
       JGrid.combo_store[411].load({
        params: {
            access_for: "0"
        }
    });
   JGrid.combo_store[431].load({
        params: {
            access_type: "0"
        }
    });
});



