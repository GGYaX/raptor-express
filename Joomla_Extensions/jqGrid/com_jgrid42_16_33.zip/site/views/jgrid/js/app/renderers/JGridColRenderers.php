<?php
/*
 *  JGridColRenderers.php in joomla/Components/com_jgrid/r/jgrid/js/app/renderers
 *
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );


// Initialize list box arrays and image renderers 
    $current_grid = $columnitems[0]->grid_id;
    echo 'JGrid.cacheState[0]=new Array();';
    for ($i=0, $j=0, $n=$columnCount; $i < $n; $i++)	{
    	echo 'demodata'.$j.'=false;';
    	
	    if($columnitems[$i]->grid_id != $current_grid) {
	    	$j++;
	    	$current_grid = $columnitems[$i]->grid_id;
	    	echo 'JGrid.cacheState['.$j.']=new Array();';
	    }
	    
	    //define formula calculator object instances
	   	if($columnitems[$i]->formula != '')
		{
	    	echo 'JGrid.formulaCalculator['.$i.'] = new formulaCalculator("");';
		}
   
        if($columnitems[$i]->data_type=='L')
        {       	
            echo 'var jgrid_list_box_combo_proxy_'.$j.'_'.$i.' = Ext.create("Ext.data.HttpProxy", {
                api: {
                    read: "'.JURI::base().'index.php?option=com_jgrid&task=read_listboxvalues&format=ajax&column_id='.$columnitems[$i]->column_id.'"
                }
            });
	  
            var jgrid_list_box_combo_store_'.$j.'_'.$i.' = Ext.create("Ext.data.Store", {
                proxy: jgrid_list_box_combo_proxy_'.$j.'_'.$i.',
              //  autoLoad: {
        		//	callback: function() {
            	//		//Ext.ComponentMgr.get("' . $griditems[$j]->grid_reference_id  . '").getView().getHeaderCt().child("#'.$columnitems[$i]->dataindex . '").initialConfig.filter.options = levelStore.collect("id", "listboxvalues");
            	//		Ext.ComponentMgr.get("'.$columnitems[$i]->dataindex . '").filter.options = levelStore.collect("id", "listboxvalues");
        		//		//test = Ext.ComponentMgr.get("'.$columnitems[$i]->dataindex . '");
        			
        		//	}
    			//},
                reader: Ext.create("Ext.data.JsonReader", {
                    fields: [{name: "id", type: "string"}, 
                             {name: "listboxvalues", type: "string"},
                             {name: "listboxvaluerowcolor", type: "string"}],
                    root: "rows",
                    totalProperty: "results",
                    id: "id"
                })
            });
            
			// combo boxs userdefined column listbox
				Ext.define("JGrid.store.JGridCStore_'.$j.'_'.$i.'", {
				extend: "Ext.data.Store",
				requires: "JGrid.model.JGridCModel60",   
				model: "JGrid.model.JGridCModel60",
				alias : "widget.JGridCStore_'.$j.'_'.$i.'",
				storeId:"JGridCStore_'.$j.'_'.$i.'",
				id:"JGridCStore_'.$j.'_'.$i.'",
				autoLoad: true,
				proxy: {
			   		type: "ajax",
				
			    url: "'.JURI::base().'index.php?option=com_jgrid&task=read_listboxvalues&format=ajax&column_id='.$columnitems[$i]->column_id.'",
			 
					reader: new Ext.data.JsonReader({
				        root: "rows",
				        totalProperty: "results",
				        id: "id"
			    	},JGrid.dsCModel[60]),
			   		 writer: {
						type: "json",
						writeAllFields : false,  //just send changed fields
						allowSingle :false      //always wrap in an array
					}
			    }
			});
			var jgrid_list_box_combo_store_'.$j.'_'.$i.' = Ext.create("JGrid.store.JGridCStore_'.$j.'_'.$i.'");
			            
			var jgrid_list_box_combo_'.$j.'_'.$i.' = {
				id: "jgrid_list_box_combo_'.$j.'_'.$i.'",
				xtype: "combobox",
			    typeAhead: true,          
			    emptyText: "'. JText::_("SELECT_A_TYPE").'",  
			    triggerAction: "query",
			    lazyRender: true,
			    forceSelection: true,
			    valueNotFoundText: "'. JText::_("SELECT_A_VALUE_FROM_THE_LIST").'",                             
			    mode: "remote",
			    store: jgrid_list_box_combo_store_'.$j.'_'.$i.',
			    valueField: "listboxvalues",
			    displayField: "listboxvalues",
			    selectOnFocus: true,
			    typeAhead: true,
			    editable: true,
			    triggerAction: "all"
			};';
       }
       if($columnitems[$i]->data_type=='P')
       {
         if($griditems[0]->enable_row_numbers  == true)
         {
            $column_index=$i+1;
         }
         else
         {
         	// to cover dummy row ?? RMS
            $column_index=$i+1;
         }
         	 echo ' JGrid.cacheState['.$j.']['.$column_index.']=1;';
         	 echo 'function renderThumbnail_'.$j.'_'.$i.'(val) { 
               if (val=="" || val==null)
               {
                // var image_link = "<img src= + Ext.BLANK_IMAGE_URL + >";
                return "";             
               }
               else
               {
                 var picture_end=val.indexOf("~");
                 if(picture_end==-1)
                 {
                   var picture = val;
                 }
                 else
                 {
                   var picture = val.substr(0,picture_end);
                 }
                 var image_link = "<img src='.JURI::base().'media/com_jgrid"+picture+"?state="+JGrid.cacheState['.$j.']['.$column_index.']+" width='.($columnitems[$i]->width-12).'>"                
               }
               return image_link; 
             };';      	 
       }
    }
?>    
    