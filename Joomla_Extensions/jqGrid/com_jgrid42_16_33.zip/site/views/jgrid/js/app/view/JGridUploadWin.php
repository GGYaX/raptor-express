<?php
 /*
 *  JGridUploadWin.php  in joomla/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>

Ext.define("JGrid.view.JGridUploadWin", {
	extend : "Ext.window.Window",
	alias : "widget.JGridUploadWin",
	id: "JGridUploadWin",
    title: "",
    border: false,
    closeAction: "hide",
    layout: 'fit',
    autoHeight: true,
<?php    
	if($params->get ('jgrid_renderTo'))
	{
		echo 'renderTo: "'.$params->get ('jgrid_renderTo').'", ';
	} 
	else echo 'renderTo: "jgrid_component",';
    if($params->get ('jgrid_data_loader_win_width') > 0)
    {
    	echo 'width: '.$params->get ('jgrid_data_loader_win_width').',';
    } 
    else echo 'width: 500,';
    if($params->get ('jgrid_data_loader_win_height') > 0)
    {
    	echo 'height: '.$params->get ('jgrid_data_loader_win_height').',';
    } 
    else echo 'height: 200,';         
    if($params->get ('jgrid_data_loader_win_x') > 0)
    {
    	echo 'x: '.$params->get ('jgrid_data_loader_win_x').',';
    }
    if($params->get ('jgrid_data_loader_win_y') > 0)
    {
    	echo 'y: '.$params->get ('jgrid_data_loader_win_y').',';
    }
?>    
   	items:  
   	[{
		xtype: 'form',
		id: "JGridUploadFm",
		fileUpload: true,
	 	buttonAlign: "center",
	  	width: 450,
	 	frame: true,
	 	style: "margin: 0 auto;",
	<?php 	
	 	echo 'title: "'.JText::_("FILE_UPLOAD_FORM").'",';
	?>
		autoHeight: true,
	 	bodyStyle: "padding: 10px 10px 0 10px;",
		labelWidth: 60,
		    defaults: {
		    	autoEl: {},
		        anchor: '100%',
		        allowBlank: true,
		        msgTarget: "side",
		        layout: 'form'
		    },
          	items: [{
          		xtype: 'fieldset',
              	autoHeight: true,
              	labelAlign: 'right',
               	waitMsgTarget: true,
              	defaultType: "container",
		items: 
		[
			{ 
				xtype: "fileuploadfield",
				id: "data_up_load",
		<?php		                   
		     	echo 'emptyText: "'.JText::_("SELECT_A_FILE_TO_UPLOAD").'",
		   		fieldLabel: "'.JText::_("PHOTO").'",
		      	plugins: [ new Ext.ux.FieldHelp("'. JText::_("SELECT_A_FILE_TO_UPLOAD").'") ],';
		?>                  
		   		name: "data"
			}, 
			combo2
			]
			}],	
			buttons: [{
		<?php               
		      		echo 'text: "'. JText::_("SAVE").'",';
		?>
		     		handler: function(){  
		            	if(JGrid.data_loader.getForm().isValid()){
			            	JGrid.data_loader.getForm().submit({
		<?php	            	
		                 		echo 'url: "'.JURI::base().'index.php?option=com_jgrid&controller=jgrid_csv&task=save_csv&format=ajax&filename="+JGrid.data_loader.form._fields.items[0].getValue()+"&delimiter="+JGrid.data_loader.form._fields.items[1].getValue()+"&grid_id="+JGrid.csvUpload["grid_id"]+"&sel_row_id="+JGrid.csvUpload["sel_row_id"]+"&row_insert_position="+JGrid.csvUpload["row_insert_position"]+"",	     
			                    waitMsg: "'.JText::_("UPLOADING_YOUR_DATA").'",	                    
			                    failure: function (response, o) {  
		                        	Ext.MessageBox.alert("'. JText::_("DATA_UPLOAD_FAILED").'",Ext.decode(o.response.responseText).data);';                              
		?>
		                        },
			                    success: function(jgrid_thumbnail_loader, o){
			                    	var revisedData = Ext.decode(o.response.responseText).data;
			                  		JGrid.store[JGrid.csvUpload["index"]].load();
			                 		//grid refresh
		                      		JGrid.upload_win.hide(); 
			                    }
			                });
		                }
		            }                        
		        },
		        {
		<?php        
		       		echo 'text: "'. JText::_("UNDO_LAST_UPLOAD").'",';
		?>       		
		            handler: function(){
		          		Ext.Ajax.request({
		<?php           
			                echo 'waitMsg: "'.JText::_("DELETING_IMAGE").'",          
			                url: "'.JURI::base().'index.php?option=com_jgrid&controller=jgrid_csv&task=undo_last_csv_upload&grid_id="+JGrid.csvUpload["grid_id"]+"&format=ajax",                                
			                method: "POST",
			                failure: function (response, options) {  
			                    Ext.MessageBox.alert("'. JText::_("UPLOAD_DATA_DELETE_FAILED").'", "");';
			?>                                 
			                },
			                success: function (response, options) {
			                    var server_response = Ext.decode(response.responseText);
			                    if (!server_response.success) {
			<?php
			                        echo 'Ext.MessageBox.alert("'. JText::_("IMAGE_DELETE_FAILED").'", "");';
			?>                                         
			                    } 
			                    else 
			                    {
			                        // delete from screen
			                        JGrid.store[JGrid.csvUpload["index"]].load();
			                        JGrid.upload_win.hide();
			                    }
			                },
							scope: this
					
						});
					}                  
			},
		  	{
		<?php  	
		     	echo 'text: "'. JText::_("RESET").'",';
		?>
		      	handler: function(){
		        	JGrid.data_loader.getForm().reset();
		    	}
			}]
	}]  
});


     
