<?php
/*
 *  JGridColumns.php in joomla/Components/com_jgrid/r/jgrid/js/app/renderers
 *
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
?>

// combo for upload or download deliminator selection
var combo2 = Ext.create('Ext.form.ComboBox', {
    typeAhead: true,
    width: 150,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
	echo 'emptyText: "'. JText::_("SELECT_A_DELIMITER").'",
	fieldLabel: "'.JText::_("DELIMITER").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("SELECT_A_DELIMITER_FOR_CSV_FILE").'") ],                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[2],
	valueField: "delimiter",
	displayField: "delimiter_description",
    selectOnFocus: true,
    typeAhead: true,
    editable: true
}); 

var combo3 = new Ext.form.ComboBox({
    typeAhead: true,
    id:'grid_sheet_title',
    height: 32, 
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_SHEET").'",';
?>  
    triggerAction: 'query',
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("SELECT_A_FIELD").'",
    fieldLabel: "'.JText::_("SHEET_REF").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("SELECT_A_SHEET_TO_ASSOCIATE_WITH_IMAGE_POPUP_BUTTON").'") ],
    ';
?>    
    queryMode: 'remote',
    store: JGrid.combo_store[3],
    valueField: 'grid_sheet_id',
    displayField: 'grid_sheet_title',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all'
});
    
// combo boxs for security access for type role or user	
var combo40 = Ext.create('Ext.form.ComboBox', {
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",
    fieldLabel: "'.JText::_("ACCESS_FOR").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("ACCESS_FOR_TOOLTIP").'") ],                           
   ';
?>    
    queryMode: 'local',
    store: JGrid.combo_store[40],
    valueField: 'access_for',
    displayField: 'Type',
    selectOnFocus: true,
    typeAhead: true,
    editable: true
});

 // hide selections when creator type
combo40.on('select', function () {
  if(combo40.getValue() == "4")
  {
    combo44.setValue("4");
    combo44.hide();
  }
  else
  {
    combo44.show();
  }
  combo411.clearValue();
});     
    
var combo41 = Ext.create('Ext.form.ComboBox', {
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",
    fieldLabel: "'.JText::_("USER_ROLE_NAME").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("USER_NAME_TOOLTIP").'") ],                           
   ';
?>    
    mode: 'local',
    store: JGrid.combo_store[41],
    valueField: 'rslvl_id',
    displayField: 'role_or_user',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all'
});

combo41.on('expand', function () {
    var access_for = combo40.getValue();
    if (access_for=="") 
    {
      combo41.collapse();
<?php 
             echo 'window.alert("'. JText::_("ACCESS_FOR_NOT_SELECTED").'", "'. JText::_("PLEASE_SELECT_ACCESS_FOR").'");';
?> 
      return false;
    } 
    JGrid.combo_store[41].load({
        params: {
            access_for: access_for
        }
    })
});

var combo411 = Ext.create('Ext.form.ComboBox', {
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    triggerAction: 'query',
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",
    fieldLabel: "'.JText::_("USER_ROLE_NAME").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("USER_NAME_TOOLTIP").'") ],                           
   ';
?>    
    mode: 'local',
    store: JGrid.combo_store[411],
    valueField: 'access_for_id',
    displayField: 'access_for_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all'
});

combo411.on('expand', function () {
    var access_for = combo40.getValue();
    if (access_for=="") 
    {
      combo411.collapse();
<?php 
             echo 'window.alert("'. JText::_("ACCESS_FOR_NOT_SELECTED").'", "'. JText::_("PLEASE_SELECT_ACCESS_FOR").'");';
?> 
      return false;
    }
    JGrid.combo_store[411].proxy.url =  "index.php?option=com_jgrid&task=access_for_name_id&controller=jgrid_security&format=ajax&access_for="+access_for;  	      
    JGrid.combo_store[411].load({
        params: {
            access_for: access_for
        }
    })
});

<?php 
echo 'var combo42 = new Ext.form.ComboBox({
    typeAhead: true,
    emptyText: "'. JText::_("SELECT_A_TYPE").'",
    triggerAction: "all",
    lazyRender: true,
    forceSelection: true,
    valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",
    fieldLabel: "'.JText::_("ACCESS_TYPE").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("ACCESS_TYPE_TOOLTIPP").'") ],                            
    mode: "local",
    store: new Ext.data.SimpleStore({
        id: 0,
        fields: [	{name: "access_type", type: "string"}, 
             		{name: "Type", type: "string"}
        ],
        data: [["3", "'. JText::_("SHEET").'"], 
               ["4", "'. JText::_("SHEET_COLUMN").'"]]//comboData              
    }),
    listeners: {
        select: {
            fn: function (combo, value) {
                JGrid.newcolumnrecord = value;
                combo431.clearValue();         
            }
        }
    },
    valueField: "access_type",
    displayField: "Type"});';
?> 

// hide selections when creator type
combo42.on('select', function () {
  combo431.clearValue();
}); 

var combo43 = new Ext.form.ComboBox({
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",
    fieldLabel: "'.JText::_("OBJECT_NAME").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("OBJECT_NAME_TOOLTIPP").'") ],';
?>  
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",';
?>         
    mode: 'local',
    store: JGrid.combo_store[43],
    valueField: 'access_type_id',
    displayField: 'access_type_name',
    selectOnFocus: true,
    typeAhead: true,
    editable: false,
    triggerAction: 'all'
});

combo43.on('focus', function () {
    var access_type = combo42.getValue();  
    if (access_type=="") 
    {
       combo43.collapse();
<?php 
             echo 'window.alert("'. JText::_("ACCESS_TYPE_NOT_SELECTED").'", "'. JText::_("PLEASE_SELECT_ACCESS_TYPE").'");';
?> 
      return false;
    }    
    JGrid.combo_store[43].load({
          params: {
             access_type: access_type,
             grid_application_name: JGrid.grid_application_name,
             grid_id: JGrid.gCurrentGridId
             
          }
    });
});


var combo431 = new Ext.form.ComboBox({
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",
    fieldLabel: "'.JText::_("OBJECT_NAME").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("OBJECT_NAME_TOOLTIPP").'") ],';
?>  
    triggerAction: 'query',
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",';
?>         
    mode: 'local',
    store: JGrid.combo_store[431],
    valueField: 'access_type_id',
    displayField: 'access_type_name',
    selectOnFocus: true,
    width: 250,
    typeAhead: true,
    editable: false,
    triggerAction: 'all'
});

combo431.on('focus', function () {
    var access_type = combo42.getValue();
    if (access_type=="") 
    {
       combo431.collapse();
<?php 
             echo 'window.alert("'. JText::_("ACCESS_TYPE_NOT_SELECTED").'", "'. JText::_("PLEASE_SELECT_ACCESS_TYPE").'");';
?> 
      return false;
    }
	JGrid.combo_store[431].proxy.url =  "index.php?option=com_jgrid&task=access_type_name_id&controller=jgrid_security&format=ajax&access_type="+access_type;  	 	   
    
    JGrid.combo_store[431].load({
		params: {
			access_type: access_type,
	   		grid_application_name: JGrid.grid_application_name,
            grid_id: JGrid.gCurrentGridId
	 	}
	});
});

<?php	
  
                                            
    echo'var combo44 = Ext.create("Ext.form.ComboBox", {
    typeAhead: true,
    emptyText: "'. JText::_("SELECT_A_TYPE").'",
    fieldLabel: "'.JText::_("ACCESS_LEVEL").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("ACCESS_LEVEL_TOOLTIPP").'") ],                           
    triggerAction: "all",
    lazyRender: true,
    forceSelection: true,
    lastQuery: "",    
    valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",
    mode: "local",
    store: new Ext.data.SimpleStore({
        id: 0,
      	fields: [	{name: "access_level", type: "string"}, 
             		{name: "Type", type: "string"}
        ],
                  data: [["0", "'. JText::_("JNO_ACCESS").'"],
                         ["1", "'. JText::_("VIEWER").'"],
                         ["-1", "'. JText::_("VIEW_DOWNLOAD").'"],
                         ["2", "'. JText::_("CELL_EDIT").'"], 
                         ["3", "'. JText::_("ROW_EDITOR").'"], 
                         ["4", "'. JText::_("ADD_DELETE_ROWS").'"],
                         ["-2", "'. JText::_("CREATOR_RULE").'"], 
                         ["5", "'. JText::_("SHEET_MANAGER").'"], 
                         ["6", "'. JText::_("ACCESS_MANAGER").'"]] //comboData
    }),
    valueField: "access_level",
    displayField: "Type"}
);';
 ?>  
 
var combo50 = new Ext.form.ComboBox({
    typeAhead: true,
<?php           
    echo 'emptyText: "'. JText::_("SELECT_A_TYPE").'",';
?>  
    triggerAction: 'query',
    lazyRender: true,
    forceSelection: true,
<?php    
    echo 'valueNotFoundText: "'. JText::_("VALUE_NOT_FOUND").'",
    fieldLabel: "'.JText::_("USER_ROLE_NAME").'",
    plugins: [ new Ext.ux.FieldHelp("'. JText::_("USER_NAME_TOOLTIP").'") ],                           
   ';
?>    
    mode: 'local',
    store: JGrid.combo_store[50],
    valueField: 'rslvl_id',
    displayField: 'role_or_user',
    selectOnFocus: true,
    typeAhead: true,
    editable: true,
    triggerAction: 'all'
}); 
 
 
     
    