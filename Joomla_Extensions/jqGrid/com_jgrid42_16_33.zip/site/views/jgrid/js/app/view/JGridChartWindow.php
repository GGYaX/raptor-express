<?php
 /*
 *  JGridHelp.php  in joomla/Components/com_jgrid/views/jgrid/js/app/view
 * 
 * @version $id$ V4.0
 * @package Jgrid Data Grid Component
 * @subpackage com_jgrid
 * @author Rick MacIntosh
 * @copyright Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license GNU/GPL, see LICENSE.php * com_jgrid! is free software. This version
 *          may have been modified pursuant to the GNU General Public License,
 *          and as distributed it includes or is derivative of works licensed
 *          under the GNU General Public License or other free or open source
 *          software licenses.
 */
 
// no direct access
defined('_JEXEC') or die('Restricted access');
?>

Ext.define("JGrid.view.JGridChartWindow", {
	extend : "Ext.window.Window",
	alias :"widget.JGridChartWindow",
	layout:"fit",
	closeAction: "hide", 
    minimizable: true,
    <?php    
    if($params->get ('jgrid_renderTo'))
	{
		echo 'renderTo: "'.$params->get ('jgrid_renderTo').'", ';
	} 
	else echo 'renderTo: "jgrid_component",';
   	if($params->get ('jgrid_create_chart_win_width') > 0)
    {
    	echo 'width: '.$params->get ('jgrid_create_chart_win_width').',';
    } 
    else echo 'width: 700,';
    if($params->get ('jgrid_create_chart_win_height') > 0)
    {
    	echo 'height: '.$params->get ('jgrid_create_chart_win_height').',';
    } 
    else echo 'height: 700,';         
    if($params->get ('jgrid_create_chart_win_x') > 0)
    {
   	 	echo 'x: '.$params->get ('jgrid_create_chart_win_x').',';
    }
    if($params->get ('jgrid_create_chart_win_y') > 0)
    {
    	echo 'y: '.$params->get ('jgrid_create_chart_win_y').',';
    }
    else echo 'y: 10,';
?> 
    maximizable: true,
    tbar: [
  			{ 	xtype: 'button',
<?php  			 
  				echo 'text: "'. JText::_("CHART_DATA").'",
  				icon: "'.JURI::base().'administrator/components/com_jgrid/os/jgrid/icons/lightbulb.png"
               // tooltip: "'. JText::_("FULL_INDEXED_HELP_TOPICS_ON_USING_JGRID").'"';
?>                
  			}
	],
	listeners: {
			show:function(thisObj,eOption){
						//alert(thisObj.currentIndex)
						createDataChart(thisObj.gridIdVal,thisObj.current_document_id,thisObj.current_document_id,thisObj,thisObj.currentIndex);
			},
			close:function(objectWin,opt){					
					objectWin.removeAll();
			} 
	}	     
});



