<?php
/**
 * Jgrid_images Model in Joomla/Components/models
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
require_once(JPATH_BASE . '/administrator/components/com_jgrid/os/jgrid/functions.php' );
jimport( 'joomla.application.component.model' );
jimport('joomla.application.component.helper');


// define the width and height for the thumbnail and popuP_image
// note that theese dimmensions are considered the maximum dimmension and are not fixed,
// because we have to keep the image ratio intact or it will be deformed
define ("THUMB_WIDTH",151);
define ("THUMB_HEIGHT",150);
//define a maxim size for the uploaded images
define ("MAX_IMAGE_SIZE",3000000);
define ("MAX_IMAGE_STORAGE_SIZE",100000);


/**
 * Jgrid_images model
 *
 * upload and read images
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */


if(!class_exists('RMWorksAroundJoomlaToGetAModel')) {
	if(interface_exists('JModel')) {
		abstract class RMWorksAroundJoomlaToGetAModel extends JModelLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAModel extends JModel {}
	}
}

class JgridModelJgrid_images extends RMWorksAroundJoomlaToGetAModel
{
	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The string containing the SQL call (query) that will retrieve the desired results
	 * @var string
	 */
	var $_query=null;

	/**
	 * create thumbnail from png
	 * @param directory $directory
	 * @return integer
	 */


	// this is the function that will create the thumbnail image from the uploaded image
	// the resize will be done considering the width and height defined, but without deforming the image
	static function make_thumb( $src_img,$filename,$fileID,$new_w,$new_h)
	{

		//gets the dimmensions of the image
		$old_x=imageSX($src_img);
		$old_y=imageSY($src_img);

		// next we will calculate the new dimmensions for the thumbnail image
		// the next steps will be taken:
		// 1. calculate the ratio by dividing the old dimmensions with the new ones
		// 2. if the ratio for the width is higher, the width will remain the one define in WIDTH variable
		// and the height will be calculated so the image ratio will not change
		// 3. otherwise we will use the height ratio for the image
		// as a result, only one of the dimmensions will be from the fixed ones
		$ratio1=$old_x/$new_w;
		$ratio2=$old_y/$new_h;
		if($ratio1>$ratio2) {
			$thumb_w=$new_w;
			$thumb_h=$old_y/$ratio1;
		}
		else {
			$thumb_h=$new_h;
			$thumb_w=$old_x/$ratio2;
		}

		//$image_resized = imagecreatetruecolor( $final_width, $final_height );
		// we create a new image with the new dimmensions
		$dst_img=ImageCreateTrueColor($thumb_w,$thumb_h);

		if ( ($_FILES[$fileID]['type']=='image/gif') || ($_FILES[$fileID]['type']=='image/x-png'||$_FILES[$fileID]['type']=='image/png') ) 
		{
			$trnprt_indx = imagecolortransparent($src_img);
			// If we have a specific transparent color
			if ($trnprt_indx >= 0) {
				// Get the original image's transparent color's RGB values
				$trnprt_color    = imagecolorsforindex($src_img, $trnprt_indx);
				// Allocate the same color in the new image resource
				$trnprt_indx    = imagecolorallocate($dst_img, $trnprt_color['red'], $trnprt_color['green'], $trnprt_color['blue']);
				// Completely fill the background of the new image with allocated color.
				imagefill($dst_img, 0, 0, $trnprt_indx);
				// Set the background color for new image to transparent
				imagecolortransparent($dst_img, $trnprt_indx);
			}
			// Always make a transparent background color for PNGs that don't have one allocated already
			elseif ($_FILES[$fileID]['type']=='image/x-png'||$_FILES[$fileID]['type']=='image/png') {
				// Turn off transparency blending (temporarily)
				imagealphablending($dst_img, false);
				// Create a new transparent color for image
				$color = imagecolorallocatealpha($dst_img, 0, 0, 0, 127);

				// Completely fill the background of the new image with allocated color.
				imagefill($dst_img, 0, 0, $color);

				// Restore transparency blending
				imagesavealpha($dst_img, true);
			}
		}


		// resize the big image to the new created one
		imagecopyresampled($dst_img,$src_img,0,0,0,0,$thumb_w,$thumb_h,$old_x,$old_y);

		// output the created image to the file. Now we will have the thumbnail into the file named by $filename
		header('Content-Type: image/png');
		imagepng($dst_img,$filename);

		//destroys destination image.
		imagedestroy($dst_img);
		return true;
	}

	// this is the function that will create the thumbnail image from the uploaded image
	// the resize will be done considering the width and height defined, but without deforming the image
	function save_images()
	{
		$db = JFactory::getDBO();
		$user =JFactory::getUser();
		$session =  JFactory::getSession();
		$session_id = $session->getId();
	if((JRequest::getVar('application_type','','','STRING')=='MODULE'))
{
	jimport( 'joomla.application.module.helper' );
	$app = JFactory::getApplication();
	$module = JModuleHelper::getModule(JRequest::getVar('jgrid_application_name'));
	$params = new JRegistry();
	$params->loadString($module->params);
}
else 
{
	$params = JComponentHelper::getParams('com_jgrid');
}
		$grid_id=JRequest::getVar('grid_id','','','INTEGER');
		$columngrid_id = JRequest::getVar('column_id','','','INTEGER');
		$row_id = JRequest::getVar('row_id','','','INTEGER');
		$primary_key_value = JRequest::getVar('primary_key_value','','','STRING');
		

		if($params->get ('thumbnail_image_file_width'))
		{
			$thumbnail_width = $params->get ('thumbnail_image_file_width');
		}
		else $thumbnail_width =  THUMB_WIDTH;
		if($params->get ('thumbnail_image_file_height'))
		{
			$thumbnail_height = $params->get ('thumbnail_image_file_height');
		}
		else $thumbnail_height =  THUMB_HEIGHT;

		// get current document ID
		$this->_query = 'SELECT g.current_document_id
	   		             FROM #__jgrid_current_user_grid_document g
	   		             WHERE g.userid = ' . $user->id .'
	                       AND g.grid_id = '.$grid_id.'
	                       AND g.session_id = "'.$session_id.'"';
		$db->setQuery($this->_query);
		$current_document_id=$db->loadResult();
		
		// Find applicatin id for this grid_id
    	$query = 'SELECT b.id, a.select_type
		      	  FROM #__jgrid_grids a,
		      	       #__jgrid_applications b		                        
		          WHERE a.id = '.$grid_id.'
		            AND a.grid_application_name = b.grid_application_name';
		$db->setQuery($query);
		$grids_data = $db->loadObjectList();
		
		$access_rule_application_id = $grids_data[0]->id;
		$select_type = $grids_data[0]->select_type;
		
		

		// check user access rights to be edit
		list($admin_user,$access_control,$remove_access_control,$document_security_level) = check_access_control($grid_id,$current_document_id,2);
		if($access_control==0 || $remove_access_control > 0)
		{
			return array(false,JText::_("USER_DOES_NOT_HAVE_ACCESS_RIGHTS_TO_UPLOAD_DATA_TO_GRID"));
		}
	    
		$loadtype = JRequest::getVar('loadtype','','','STRING');
		if($loadtype =='image') $fileID = 'photo';
		else $fileID = 'thumbnail_image';
		
		// find column ID associated with columngrid_id
        $query = '	SELECT 	column_id
                        FROM #__jgrid_columngrid
                       	WHERE id = '.$columngrid_id;
		$db->setQuery($query);
		$column_id = $db->loadResult();
		
		// setup the inserts if values exist
		$imagetooltip = JRequest::getVar('imagetooltip','','','STRING');
		$tooltip_request = JText::_("ENTER_A_TOOLTIP");
				
		if(imagetooltip==null||$tooltip==$tooltip_request) $updateImagetooltip = false;
		else $updateImagetooltip = true;
				
		$image_url = JRequest::getVar('image_url','','','STRING');
		$image_url_request = JText::_("ENTER_A_URL");
		if($image_url==null||$image_url==$image_url_request) $updateImage_url = false;
		else $updateImage_url = true;
				
		$image_email = JRequest::getVar('image_email','','','STRING');
		$image_email_request = JText::_("ENTER_AN_EMAIL");
		if($image_email==null||$image_email==$image_email_request) $updateImage_email = false;
		else $updateImage_email = true;
		
		$image_email_subject = JRequest::getVar('image_email_subject','','','STRING');
		$image_email_subject_request = JText::_("ENTER_EMAIL_SUBJECT");
		if($image_email_subject==null||$image_email_subject==$image_email_subject_request) $updateImage_subject_email = false;
		else $updateImage_subject_email = true;		
		
		
				
		$grid_sheet = JRequest::getVar('grid_sheet','','','STRING');
		
		
        
		//$image_data = JRequest::getVar($fileID,'','','STRING');
		
		if(isset($_FILES)&&($_FILES[$fileID]['type'] == "image/gif" || $_FILES[$fileID]['type'] == "image/jpeg" || $_FILES[$fileID]['type'] == "image/x-png"  || $_FILES[$fileID]['type'] == 'application/x-shockwave-flash'))
		{
			$db = JFactory::getDBO();
			$user =JFactory::getUser();


			// Check user security
			//   list($admin_user,$access_control,$remove_access_control,$default_security_level) = $this->check_access_control(2);

			//		   if(!($admin_user == 1 ||( $access_control==1 && $remove_access_control!=0 )))
			//		   {
			//		   	  // RMS send error message
			//		   	  return false;
			//		   }

			// if image size is too big then reduce to max size
			if($params->get ('max_image_size'))
			{
				$max_image_size = $params->get ('max_image_size');
			}
			else $max_image_size =  MAX_IMAGE_SIZE;
			if($_FILES[$fileID]['size']>$max_image_size)
			{
				return array(false,JText::_("MAX_IMAGE_SIZE_OF").'" "'.$max_image_size.'" "'.JText::_("EXCEEDED_YOUR_IMAGE_SIZE_IS").'" "'.$_FILES[$fileID]['size']);
			}
			// check the max size of file to store and set to resize if too large
			if($params->get ('max_image_storage_size'))
			{
				$max_image_storage_size = $params->get ('max_image_storage_size');
			}
			else $max_image_storage_size =  MAX_IMAGE_STORAGE_SIZE;

			if($_FILES[$fileID]['size']>$max_image_storage_size)
			{
				$image_size=$max_image_storage_size;
				$scale=$max_image_storage_size/$_FILES[$fileID]['size'];
				$resize_image=true;
			}
			else
			{
				$image_size=$_FILES[$fileID]['size'];
				$scale=1;
				$resize_image=false;
			}

            list($grid_doc_dir,$imgpath,$imgname, $dir) = check_image_path($grid_id,
                                                                     $current_document_id,
                                                                     $columngrid_id,
                                                                     $row_id,
                                                                     $_FILES[$fileID]['size'],
                                                                     getExtension($_FILES[$fileID]['name']));
                                                                     			
			$photo_name = $_FILES[$fileID]['name'];
			$photo_type = $_FILES[$fileID]['type']; 
			$extension = getExtension($_FILES[$fileID]['name']);		
 	
			if($loadtype=='image') // if image and thumbnail load or data update
            {	  
            	     	
				// save file data
				$query = 'INSERT INTO #__jgrid_images (   grid_id,
			                                              document_id,
			                                              columngrid_id,
	                                                      column_id,
	                                                      row_id,';  
	            if($photo_name!=null)  				$query .= 'filename,';
	            if($photo_type!=null)  				$query .= 'file_type,';
	            if($_FILES[$fileID]['size']!=null)  $query .= 'file_size,';
	            if($photo_name!=null)  				$query .= 'image_thumb_path,';
	            if($updateTooltip)  				$query .= 'tooltip,';
	            if($updateImage_url)  				$query .= 'hyper_url,';
	            if($updateImage_email)  			$query .= 'image_email,';
	            if($updateImage_email_subject)  	$query .= 'image_email_subject,';
	            if($grid_sheet!=null)  				$query .= 'hyper_grid_sheet,';
	            if($extension!=null)  				$query .= 'extension,';
	                                                $query .= 'userid) 
	                           VALUES ('. $grid_id.',
			                           '. $current_document_id.',
	                                   '. $columngrid_id.',
	                                   '.$column_id.',
	                                   '. $row_id.',';  
	            if($photo_name!=null)  				$query .= '"'.$photo_name.'",';
	            if($photo_type!=null)  				$query .= '"'.$photo_type.'",';
	            if($_FILES[$fileID]['size']!=null) 	$query .= $image_size.',';
	            if($photo_name!=null)   			$query .='"'.$grid_doc_dir . '/'. $imgpath .'_thumb.png",';
	     		if($updateTooltip)  				$query .= '"'. $imagetooltip.'",';
	            if($updateImage_url)    			$query .= '"'. $image_url.'",';
	            if($updateImage_email)  			$query .= '"'. image_email.'",';
	            if($updateImage_email_subject)  	$query .= '"'. image_email_subject.'",';
	            if($grid_sheet!=null)   			$query .= '"'. $grid_sheet.'",';
	            if($extension!=null)    			$query .= '"'.$extension.'",';
	                                   				$query .= $user->id.') ON DUPLICATE KEY UPDATE '; 
	            if($photo_name!=null)  				$query .= 'filename = "'.$photo_name.'",';
	            if($photo_type!=null)  				$query .= 'file_type = "'.$photo_type.'",';
	            if($_FILES[$fileID]['size']!=null) 	$query .= 'file_size = '.$image_size.',';
	            if($photo_name!=null)   			$query .=' image_thumb_path = "'.$grid_doc_dir . '/'. $imgpath .'_thumb.png",';
	         	if($updateTooltip) 					$query .= 'tooltip = "'. $imagetooltip.'",';
	            if($updateImage_url)    			$query .= 'hyper_url = "'. $image_url.'",';
	            if($updateImage_email)				$query .= 'image_email = "'. $image_email.'",';
	            if($updateImage_email_subject)		$query .= 'image_email_subject = "'. $image_email_subject.'",';
	            if($grid_sheet!=null)   			$query .= 'hyper_grid_sheet="'. $grid_sheet.'",';
	            if($extension!=null)    			$query .= 'extension="'.$extension.'",';                                                                                 
				                        			$query .= 'userid = '.$user->id;																								
				$db->setQuery($query);
				
				
				if(!$db->query())
				{
					return array(false,"Database error1, file not saved");
				}

            }
            else // thumbnail update
		    {
            	$imgname = substr($imgname,0,strrpos($imgname,'_orig')).'_temp_thumb.'.$extension;
            	
            	// get stored info on original
                $data_array = select_image_cell($grid_id,$current_document_id, $columngrid_id, $row_id, $select_type, $primary_key_value);

				if($data_array)
				{
					$img_cell_value = $grid_doc_dir . '/'. $thumb_filename. '~'.$data_array[1].'~'.$data_array[2].'~'.$data_array[3].'~'.$data_array[4].'~'.$data_array[5].'~'.$data_array[6];
            	}
				else
				{
					return array(false,JText::_("FILETYPE").'" "'.$_FILES[$fileID]['type'].'" "'.JText::_("MUST_STORE_ORIGINAL_BEFORE_OPTIONAL_THUMBNAIL"));
				}
		    }
			// save original file
			move_uploaded_file ($_FILES[$fileID]['tmp_name'],$imgname);
			
			$thumb_filename = $imgpath .'_thumb.png';
			$thumbname = $dir. '/'. $thumb_filename;
			//make thumbnail
			if($_FILES[$fileID]['type'] == "image/gif" || $_FILES[$fileID]['type'] == "image/jpeg" || $_FILES[$fileID]['type'] == "image/x-png")
			{			
				//Imagick is installed
				if( class_exists("Imagick") )
				//if( false )
				{
					//try
					//{
					/*** the image file ***/
					//$image = 'images/spork.jpg';
	
					/*** a new imagick object ***/
					//$im = new Imagick();
	
					/*** ping the image ***/
					//$im->pingImage($image);
	
					/*** read the image into the object ***/
					//$im->readImage( $image );
						
					$image = new Imagick();
					$image->readImage($imgname);
					// if image too large to store reduce to smaller size
					if($scale!=1)
					{
						$width=$image->getImageWidth();
						$image->thumbnailImage(($width*$scale), 0, false);
						$image->writeImage($imgname);
					}
					//resize to thumbnail
					if($params->get ('thumb_width'))
					{
						$thumbnail_width = $params->get ('thumb_width');
					}
					else $thumbnail_width =  THUMB_WIDTH;
					$image->thumbnailImage($thumbnail_width, 0);
					/**** convert to png ***/
					$image->setImageFormat("png");
					//$thumbname = $dir. '/'. $imgpath. '_thumb.png';
					/*** write thumbnail image to disk ***/
					$image->writeImage( $thumbname );
					$image->clear();
					$image->destroy();
	
						
	
						
					//}
					//catch(Exception $e)
					//{
					//	echo $e->getMessage();
					//}
				}
				else // use GD libaray
				{
						
					if($_FILES[$fileID]['type']=='image/gif')
					{
						$img = imagecreatefrompgif($imgname);
					}else if($_FILES[$fileID]['type']=='image/jpeg')
					{
						$img = imagecreatefromjpeg($imgname);
					}else if($_FILES[$fileID]['type']=='image/x-png'||$_FILES[$fileID]['type']=='image/png')
					{
						$img = imagecreatefrompng($imgname);
					}else if($_FILES[$fileID]['type']=='image/bmp')
					{
						$img = imagecreatefrombmp($imgname);
					}else
					{
						return array(false,JText::_("FILETYPE").'" "'.$_FILES[$fileID]['type'].'" "'.JText::_("IS_NOT_SUPPORTED_MUST_BE_GIF_JPEG_BMP_OR_PNG_TYPES"));
					}
	
					// resize and save thumbnail
					//$thumbname = $dir. '/'. $imgpath. '_thumb.png';			
					$new_w=$thumbnail_width;
					$new_h=$thumbnail_height;
					if(!JgridModelJgrid_images::make_thumb($img,$thumbname,$fileID,$new_w,$new_h))
					{
						return array(false,JText::_("UNABLE_TO_CREATE_THUMBNAIL_IMAGE_FILE").'" "'.$imgname);
					}
					// resize original if too big to store
					if($scale!=1)
					{
						$new_w = imagesx($img) * $scale;
						$new_h = imagesy($img) * $scale;
						if(!JgridModelJgrid_images::make_thumb($img,$imgname,$fileID,$new_w,$new_h))
						{
							return array(false,JText::_("UNABLE_TO_CREATE_POPUP_IMAGE_FILE").'" "'.$imgname);
						}
					}
	
					imagedestroy($img);
					
				}
				if($loadtype=='thumb') // if thumbnail update thumbnail only
            	{
            		// remove temp image of thumbnail original
            		 unlink($imgname);
            	}
			}
			else // non image type
			{
				// check to see if thumbnail exists separate from stored file if not assign to default image				
				if(!file_exists($thumbname))
				{
					$grid_doc_dir = '';
					// if swf
					if($_FILES[$fileID]['type'] == 'application/x-shockwave-flash')
					{						
						$thumb_filename = 'adobe_swf_thumb.jpg';
					}
//					else // if other text file default
//					{ 
//						$thumb_filename = 'text_dropcaps.png';
//					}
					
				}
			} // end non swf if
			
			if($loadtype=='image') // if image and thumbnail load or data update
            {
				// update cell to store thumbnail record
				$img_cell_value = $grid_doc_dir . '/'. $thumb_filename. '~'.JRequest::getVar('imagetooltip','','','STRING').'~'.JRequest::getVar('image_url','','','STRING').'~'.JRequest::getVar('grid_sheet','','','STRING').'~'.getExtension($_FILES[$fileID]['name']).'~'.JRequest::getVar('image_email','','','STRING').'~'.JRequest::getVar('image_email_subject','','','STRING');
            }
            else 
            {
            	$data_array = select_image_cell($grid_id,$current_document_id, $columngrid_id, $row_id, $select_type, $primary_key_value);

				if($data_array)
				{
					$img_cell_value = $grid_doc_dir . '/'. $thumb_filename. '~'.$data_array[1].'~'.$data_array[2].'~'.$data_array[3].'~'.$data_array[4].'~'.$data_array[5].'~'.$data_array[6];
            	}
				else
				{
					return array(false,JText::_("THUMBNAIL").'" "'.$_FILES[$fileID]['type'].'" "'.JText::_("MUST_LOAD_ORIGINAL_IMAGE_BEFORE_CUSTOM_THUMBNAIL"));
				}
            	
            }
				update_image_cell($grid_id,$current_document_id, $columngrid_id, $row_id, $select_type, $img_cell_value, $primary_key_value);	
				
				return array(true,$img_cell_value);

		}
		else
		{				
			if($loadtype=='image') // if image and thumbnail load or data update
            {
				// update cell to store thumbnail record
				// select current value and if image exists just append the rest of the file data to it.
                $data_array = select_image_cell($grid_id,$current_document_id, $columngrid_id, $row_id, $select_type, $primary_key_value);

				if($data_array)
				{
					$img_cell_value = $grid_doc_dir . '/'. $thumb_filename. '~'.$data_array[1].'~'.$data_array[2].'~'.$data_array[3].'~'.$data_array[4].'~'.$data_array[5].'~'.$data_array[6];
        		}
				else
				{
					return array(false,JText::_("FILETYPE").'" "'.$_FILES[$fileID]['type'].'" "'.JText::_("IS_NOT_SUPPORTED_MUSTBE_GIF_JPRG_PNG_SWF_TYPE"));
				}
				
				if($data_array[0]==""||$data_array[0]==false)
				{
					return array(false,JText::_("FILETYPE").'" "'.$_FILES[$fileID]['type'].'" "'.JText::_("NON_IMAGE_FILE_SPECIFIED_FOR_THIS_CELL"));
				}
				else
				{
					
				// save non file data
				$query = 'INSERT INTO #__jgrid_images (   grid_id,
			                                              document_id,
			                                              columngrid_id,
	                                                      column_id,
	                                                      row_id,';  
	            if($updateTooltip)  				$query .= 'tooltip,';
	            if($updateImage_url)  				$query .= 'hyper_url,';
	            if($updateImage_email)  			$query .= 'image_email,';
	            if($updateImage_email_subject)  	$query .= 'image_email_subject,';
	            if($grid_sheet!=null)  				$query .= 'hyper_grid_sheet,';
	                                                $query .= 'userid) 
	                           VALUES ('. $grid_id.',
			                           '. $current_document_id.',
	                                   '. $columngrid_id.',
	                                   '.$column_id.',
	                                   '. $row_id.',';	                                                  
	            if($updateTooltip)  				$query .= '"'. $imagetooltip.'",';
	            if($updateImage_url)    			$query .= '"'. $image_url.'",';
	            if($updateImage_email)  			$query .= '"'. image_email.'",';
	            if($updateImage_email_subject)  	$query .= '"'. image_email_subject.'",';
	            if($grid_sheet!=null)   			$query .= '"'. $grid_sheet.'",';
	            if($extension!=null)    			$query .= '"'.$extension.'",';
	            									$query .= $user->id.') ON DUPLICATE KEY UPDATE ';	            
				if($updateTooltip) 					$query .= 'tooltip = "'. $imagetooltip.'",';
	            if($updateImage_url)    			$query .= 'hyper_url = "'. $image_url.'",';
	            if($updateImage_email)				$query .= 'image_email = "'. $image_email.'",';
	            if($updateImage_email_subject)		$query .= 'image_email_subject = "'. $image_email_subject.'",';
	            if($grid_sheet!=null)   			$query .= 'hyper_grid_sheet="'. $grid_sheet.'",';                                                                                
				                        			$query .= 'userid = '.$user->id;				                        																											
				$db->setQuery($query);
				if(!$db->query())
				{
					return array(false,"7004 Database error2, file not saved");
				}				
					$img_cell_value = $data_array[0].'~'.JRequest::getVar('imagetooltip','','','STRING').'~'.JRequest::getVar('image_url','','','STRING').'~'.JRequest::getVar('grid_sheet','','','STRING').'~'.$data_array[4].'~'.JRequest::getVar('image_email','','','STRING').'~'.JRequest::getVar('image_email_subject','','','STRING');
			
					update_image_cell($grid_id,$current_document_id, $columngrid_id, $row_id, $select_type, $img_cell_value, $primary_key_value);

					return array(true,$img_cell_value);
	
				}
            }
			return array(true,JText::_("THUMBNAIL_UPDATED"));
		}
	}

	// this is the function that will create the thumbnail image from the uploaded image
	// the resize will be done considering the width and height defined, but without deforming the image
	static function download_images()
	{
		$db =JFactory::getDBO();
		$user =JFactory::getUser();
	if((JRequest::getVar('application_type','','','STRING')=='MODULE'))
{
	jimport( 'joomla.application.module.helper' );
	$app = JFactory::getApplication();
	$module = JModuleHelper::getModule(JRequest::getVar('jgrid_application_name'));
	$params = new JRegistry();
	$params->loadString($module->params);
}
else 
{
	$params = JComponentHelper::getParams('com_jgrid');
}
		$session = JFactory::getSession();
		$session_id = $session->getId();
		$error=0;

		$grid_id=JRequest::getVar('grid_id','','','INTEGER');
		$columngrid_id = JRequest::getVar('column_id','','','INTEGER');
		$row_id = JRequest::getVar('row_id','','','INTEGER');
		
		// get current document ID
		$query = 'SELECT g.current_document_id
	   		             FROM #__jgrid_current_user_grid_document g
	   		             WHERE g.userid = ' . $user->id .'
	                       AND g.grid_id = '.$grid_id.'
	                       AND g.session_id = "'.$session_id.'"';
		$db->setQuery($query);
		$current_document_id=$db->loadResult();

		// check to make sure download enabled
				
		if($params->get('allow_image_download',1)!=1)
		{			
		   return array(false,JText::_("IMAGE_DOWNLOAD_NOT_ENABLED"));
		}
		// this is a relative path from this file to the
		// directory where the download files are stored.
		$grid_doc_dir= '/grid_'. $grid_id.'/document_'. $current_document_id;
		$dir = JPATH_BASE.'/media/com_jgrid';
		$imgpath =  $grid_id. '_'. $current_document_id. '_'. $columngrid_id. '_'. $row_id;

		// first, we'll build an array of files that are legal to download
		//chdir($dir);
		//$files=glob($imgname.'*');

		// next we'll build an array of commonly used content types
		//$mime_types=array();
		//	$mime_types['ai']    ='application/postscript';
		//	$mime_types['asx']   ='video/x-ms-asf';
		//	$mime_types['au']    ='audio/basic';
		//	$mime_types['avi']   ='video/x-msvideo';
		//	$mime_types['bmp']   ='image/bmp';
		//	$mime_types['css']   ='text/css';
		//	$mime_types['doc']   ='application/msword';
		//	$mime_types['eps']   ='application/postscript';
		//	$mime_types['exe']   ='application/octet-stream';
		//	$mime_types['gif']   ='image/gif';
		//	$mime_types['htm']   ='text/html';
		//	$mime_types['html']  ='text/html';
		//	$mime_types['ico']   ='image/x-icon';
		//	$mime_types['jpe']   ='image/jpeg';
		//	$mime_types['jpeg']  ='image/jpeg';
		//	$mime_types['jpg']   ='image/jpeg';
		//	$mime_types['js']    ='application/x-javascript';
		//	$mime_types['mid']   ='audio/mid';
		//	$mime_types['mov']   ='video/quicktime';
		//	$mime_types['mp3']   ='audio/mpeg';
		//	$mime_types['mpeg']  ='video/mpeg';
		//	$mime_types['mpg']   ='video/mpeg';
		//	$mime_types['pdf']   ='application/pdf';
		//	$mime_types['pps']   ='application/vnd.ms-powerpoint';
		//	$mime_types['ppt']   ='application/vnd.ms-powerpoint';
		//	$mime_types['ps']    ='application/postscript';
		//	$mime_types['pub']   ='application/x-mspublisher';
		//	$mime_types['qt']    ='video/quicktime';
		//	$mime_types['rtf']   ='application/rtf';
		//	$mime_types['svg']   ='image/svg+xml';
		//	$mime_types['swf']   ='application/x-shockwave-flash';
		//	$mime_types['tif']   ='image/tiff';
		//	$mime_types['tiff']  ='image/tiff';
		//	$mime_types['txt']   ='text/plain';
		//	$mime_types['wav']   ='audio/x-wav';
		//	$mime_types['wmf']   ='application/x-msmetafile';
		//	$mime_types['xls']   ='application/vnd.ms-excel';
		//
		//	$mime_types['zip']   ='application/zip';
			


		// did we get a parameter telling us what file to download?
		//if(!$_GET['file']){
		// if not, create an error message
		//   $error='No file specified to download';
		///}elseif(!in_array($_GET['file'],$files)){
		// if the file requested is not in our array of legal
		// downloads, create an error for that
		//  $error='Requested file is not available';
		//}else{
		// otherwise, get the file name and its extension
		// $file=$_GET['file'];
		//	$file="images/com_jgrid/images/grid_1/document_1/1_1_31_1_orig.jpg";
		//	http://localhost/joomla/images/com_jgrid/images/grid_1/document_1/1_1_31_1_popup.png
		

		//$ext=strtolower(substr(strrchr($file,'.'),1));
		//}
		// did we get the extension and is it in our array of content types?
		//if($ext && array_key_exists($ext,$mime_types)){
		// if so, grab the content type
		//	$mime=$mime_types[$ext];
		//}else{
		// otherwise, create an error for that
		//	$error=$error?$error:"Invalid MIME type";
		//}

		// if we didn't get any errors above

		// Get tooltip and add as filename of if none user imagename
		$db->setQuery('SELECT filename
	                         FROM  #__jgrid_images
		                       WHERE document_id = '. $current_document_id. '
		                       	AND columngrid_id= '. JRequest::getVar('column_id','','','INTEGER'). '
		                       	AND row_id = '. $row_id); 

		$cell_value = $db->loadResult();
		$data_array=explode("~",$cell_value);
		//if tooltip is not defined then user jgrid location as filename
		if($data_array[0]=="")
		{
			$img_filename = $imgpath =  $grid_id . '_'. $current_document_id. '_'. $row_id;
			$imgname = $dir.$grid_doc_dir.'/'. $imgpath  . '_orig';
		}
		else
		{
			$img_filename = $imgpath =  $grid_id . '_'. $current_document_id. '_'. JRequest::getVar('column_id','','','INTEGER'). '_'. $row_id;			
			//$imgname = $dir.stristr($data_array[0],'thumb.png',true).'orig';
			$imgname = $dir.$grid_doc_dir.'/'. $img_filename  . '_orig';
		}
		

        $ext = '.png';
		if(file_exists($imgname.'.jpg'))
		{
			$ext='.jpg';
			$mime = 'image/jpeg';
		}else if(file_exists($imgname.'.png'))
		{
			$ext='.png';
			$mime = 'image/png';

		}else if(file_exists($imgname.'.x-png'))
		{
			$ext='.x-png';
			$mime = 'image/png';

		}else if(file_exists($imgname.'.gif'))
		{
			$ext='.gif';

		}else if(file_exists($imgname.'.bmp'))
		{
			$ext='.bmp';
			$mime = 'image/bmp';
		}else if(file_exists($imgname.'.swf'))
		{
			$ext='.swf';
			$mime = 'application/x-shockwave-flash';
		}
		else
		{
			// otherwise, create an error for that
			$error=$error?$error:"Original ".$imgname."not stored";
		}
		$file=$imgname.$ext;
		$expose_filename = $cell_value.'_';
//echo 'file ='.$file;
//return;
 //echo 'img_filename ='.$img_filename;
 //echo 'ext ='.$ext;
		if(!$error){
			// and the file is readable
			if(is_readable("$file")){
				// get the file size
				$size=filesize("$file");
				// open the file for reading
				if($fp=@fopen("$file",'r')){
					// send the headers
					header("Content-type: $mime");
					header("Content-Length: $size");
					header("Content-Transfer-Encoding: binary");
					//header("Content-Disposition: attachment; filename=\"$expose_filename$img_filename$ext\"");
					header("Content-Disposition: attachment; filename=\"$expose_filename$ext\"");
					// send the file content
					fpassthru($fp);
					// close the file
					fclose($fp);
					// and quit
					exit;
				}
			}else{ // file is not readable
				$error='Cannot read file';
			}
		}
		// if all went well, the exit above will prevent anything below from showing
		// otherwise, we'll display an error message we created above

		if($error) return array(false,$error);
		else return array(true,'');

	}

}