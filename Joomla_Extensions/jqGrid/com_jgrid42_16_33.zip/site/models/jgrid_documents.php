<?php
/**
 * Jgrid_documents Model in Joomla/Components/models
 *
 * @version		$id$ V4.0
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 * @author      Rick MacIntosh
 * @copyright	Copyright (C) 2009 - 2013 Sealogix Corp. All rights reserved.
 * @link http://DataGrids.ClubsAreUs.org
 * @license		GNU/GPL, see LICENSE.php
 * * com_jgrid! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 */

// No direct access
defined( '_JEXEC' ) or die( 'Restricted access' );

require_once(JPATH_BASE . '/administrator/components/com_jgrid/os/jgrid/functions.php' );
jimport( 'joomla.application.component.model' );
jimport('joomla.application.component.helper');

/**
 * Jgrid_documents model
 *
 * read,update,create,delete,combo box drop downs data in com_jgrid "sheets" screens
 *
 * @package     Jgrid Data Grid Component
 * @subpackage	com_jgrid
 */

if(!class_exists('RMWorksAroundJoomlaToGetAModel')) {
	if(interface_exists('JModel')) {
		abstract class RMWorksAroundJoomlaToGetAModel extends JModelLegacy {}
	} else {
		class RMWorksAroundJoomlaToGetAModel extends JModel {}
	}
}

class JgridModelJgrid_documents extends RMWorksAroundJoomlaToGetAModel
{
	/**
	 * The count (number) of rows returned from the database query
	 * @var integer
	 */
	var $_result_count=null;

	/**
	 * The array of values returned from the database query
	 * @var array
	 */
	var $_result=null;

	/**
	 * The string containing the SQL call (query) that will retrieve the desired results
	 * @var string
	 */
	var $_query=null;



	/**
	 * Retrieves the "Sheets" data
	 * @return array containing the sheets  or false if no rows returned
	 *
	 */
	function getSheets()
	{
		$this->_query = 'SELECT id,
                                document_title,
                                parent_document,
                                creator_userid,
                                grid_id,
                                grid_default_document_flag,
                                last_updated,
                                document_type
				         FROM #__jgrid_document
				         ORDER BY grid_id;';			
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;
	}

	/**
	 * Retrieves the access_for_name and ID  to add in combo box
	 * @return array Array of objects containing the data from the database
	 */
	function get_read_combo()
	{
		$db =JFactory::getDBO();
		$user=JFactory::getUser();
		// check for joomla version
		$version = new JVersion;
		$joomla = $version->getShortVersion();
		$no_access_override_list='0';

		    // Find applicatin id for this grid_id
    $query = 'SELECT b.id
		      FROM #__jgrid_grids a,
		      	   #__jgrid_applications b		                        
		      WHERE a.id = '.JRequest::getVar("grid_id","","","INTEGER").'
		        AND a.grid_application_name = b.grid_application_name';
	$db->setQuery($query);
	$access_rule_application_id = $db->loadResult();
		
		// check for administrative type users
		$admin_user = check_for_backend_admin_access_rights();
		if(!$admin_user)
		{
		  $admin_user = 0;
			// check for overrides for no access commands for specific roles or users
			$this->_query='SELECT DISTINCT a.id
		                                FROM #__jgrid_document a,
		                                     #__jgrid_security e, 
		                                     #__jgrid_role_userlist f
		                                WHERE ((e.access_for = 1 
		                                         AND e.access_for_id = '.$user->id.')
		                                       OR
		                                       (e.access_for=2 
		                                          AND e.access_for_id = f.role_id
		                                          AND f.userid ='.$user->id.')  
		                                        OR (e.access_for=4))
		                                 AND (a.id = e.access_type_id)
		                                 AND e.access_type = 3  
		                                 AND (e.access_level > 0
		                                       OR e.access_for=4);';

			$this->_result_count = $this->_getListCount( $this->_query );
			$this->_result = $this->_getList( $this->_query );
			$no_access_override_list = '0';
			for($i=0;$i<$this->_result_count;$i++)
			{
				$no_access_override_list.=',';
				$no_access_override_list.=$this->_result[$i]->id;

			}

		}
		if(substr($joomla,0,3) == '1.6' || substr($joomla,0,3) == '1.7' || substr($joomla,0,1) > '1')
		{
			$this->_query = 'SELECT a.id,
		                        a.document_title,
		                        a.document_type
			           	             FROM #__jgrid_document a
			           	             WHERE a.grid_id ='.JRequest::getVar("grid_id","","","INTEGER").'
			           	              AND (0 = (SELECT count(1) AS w
		                           FROM #__jgrid_security g, 
		                                #__jgrid_role_userlist h,
		                                #__jgrid_user_type_defaults i,
		                                #__usergroups j,
		                                #__user_usergroup_map k
		                               WHERE ((g.access_for = 1 
		                                       AND 
		                                       g.access_for_id = '.$user->id.')
		                                    OR
		                                     (g.access_for=2
		                                        AND g.access_for_id = h.role_id
		                                        AND h.userid ='.$user->id.')
		                                     OR
		                                       (g.access_for=3
		                                          AND g.access_for_id = i.id
		                                          AND i.usertype_name = j.title
		                                          AND k.user_id = '.$user->id.'
		                                          AND (j.id=k.group_id
		                                            OR ('.$user->id.' = 0))))
		                             AND g.access_level = 0
		                             AND g.access_rule_application_id = '. $access_rule_application_id. '
		                             AND a.id NOT IN ('.$no_access_override_list.') 
		                             AND '.$admin_user.' = 0 
		                             AND ((a.id = g.access_type_id 
		                                             AND g.access_type=3)
		                                   OR (g.access_type=1 
				                                       AND (g.access_type_id=a.grid_id
				                                       		OR g.access_type_id = -1)) 
				                          )	           
                                                                           ));';
		}
		else
		{

			$this->_query = 'SELECT a.id,
		                        a.document_title,
		                         a.document_type
			           	             FROM #__jgrid_document a
			           	             WHERE a.grid_id ='.JRequest::getVar("grid_id","","","INTEGER").'
			           	              AND  (
			           	              0 = (SELECT count(1) AS w
		                               FROM #__jgrid_security g, 
		                                    #__jgrid_role_userlist h,
		                                    #__jgrid_user_type_defaults i
		                               WHERE ((g.access_for = 1 
		                                       AND 
		                                       g.access_for_id = '.$user->id.')
		                                    OR
		                                     (g.access_for=2
		                                        AND g.access_for_id = h.role_id
		                                        AND h.userid ='.$user->id.')
		                                     OR
		                                         (g.access_for=3
		                                            AND g.access_for_id = i.id
		                                            AND (i.usertype_name ="'.$user->usertype.'"
		                                              OR ('.$user->id.' = 0))))
		                             AND g.access_level = 0
		                             AND g.access_rule_application_id = '. $access_rule_application_id. '
		                             AND a.id NOT IN ('.$no_access_override_list.') 
		                             AND '.$admin_user.' = 0 
		                             AND ((a.id = g.access_type_id 
		                                             AND g.access_type=3)
		                                   OR (g.access_type=1 
				                                       AND (g.access_type_id=a.grid_id
				                                       		OR e.access_type_id = -1)
				                              ) 
				                         )
		                             AND ((g.access_type_id NOT IN ('.$no_access_override_list.'))
		                                   OR (g.access_type != 3))));'; 
		}
		//echo 'sql '.$this->_query;
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;
	}

	/**
	 * Retrieves the access_type_name and ID  to add in combo box
	 * @return array Array of objects containing the data from the database
	 */
	function get_access_type_name_id()
	{
		switch (JRequest::getVar("access_type","","","INTEGER")){

			case '1':  //grid
				$this->_query = 'SELECT title AS access_type_name,
				                        id AS access_type_id
			           	         FROM #__jgrid_grids;';
				break;
					
			case '2':  //document
				$this->_query = 'SELECT document_title AS access_type_name,
				                        id AS access_type_id
			           	         FROM #__jgrid_document;';
				break;

			case '3':  //column
				$this->_query = 'SELECT header AS access_type_name,
				                        id AS access_type_id
			           	         FROM #__jgrid_columns;';
				break;
		}
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result) return array($this->_result_count,$this->_result);
		else return false;

	}

	/**
	 * Updates the   "sheets" data being edited
	 * @return integer return true if row updated or false if update failed.
	 */
	function updateSheet()
	{
		$db =JFactory::getDBO();
		$user=JFactory::getUser();
		$row_data=json_decode(JRequest::getVar('rows','','','STRING'),TRUE);
		$current_document_id=JRequest::getVar('last_document_id','','','INTEGER');

		$grid_id=$row_data[0]['grid_id'];
		//check user rights to manage grid documents
		list($admin_user,$access_control,$remove_access_control) = check_grid_sheet_access_control($grid_id,$current_document_id,4);

		if($access_control==0 || $remove_access_control > 0)	 return false;


		$this->_db->setQuery('UPDATE  #__jgrid_document
			                  SET  document_title = "'.$row_data[0]['document_title'].'",
			                       parent_document = "'.$row_data[0]['parent_document'].'", 
			                       creator_userid = "'.$row_data[0]['creator_userid'].'",
			                       grid_id = "'.$row_data[0]['grid_id'].'", 
			                       grid_default_document_flag = "'.$row_data[0]['grid_default_document_flag'].'", 
			                       last_updated = "'.$row_data[0]['last_updated'].'"
			                  WHERE id = '.$row_data[0]['id']);  
		if($this->_db->query()) return true;
		else return false;

	}

	/**
	 * Creates the   "sheets" / Documents data
	 * @return return new sheet number if row created or false if update failed.
	 */
	function createSheet()
	{
		//create sheet
		$db =JFactory::getDBO();
		$user =JFactory::getUser();
		//check to see if current document exists, if not update to the default document, always reset guest to default
		$session =JFactory::getSession();
		$session_id = $session->getId();
		$grid_id=JRequest::getVar('grid_id','','','INTEGER');
		$current_document_id=JRequest::getVar('last_document_id','','','INTEGER');

		//check user rights to manage grid documents
		list($admin_user,$access_control,$remove_access_control) = check_grid_sheet_access_control($grid_id,$current_document_id,4);
		if($access_control==0 || $remove_access_control > 0)	 return false;



		$this->_query='INSERT  INTO #__jgrid_document (document_title,
                                                              parent_document,
                                                              creator_userid,
                                                              grid_id)
		                      VALUES ("'.JRequest::getvar( 'new_document_name' ).'",
		                              '.(JRequest::getvar( 'parent_document_id' )? JRequest::getvar( 'parent_document_id' ) : -1).',
		                              '.$user->id.',
		                              '. JRequest::getvar( 'grid_id' ).')';	
		$this->_db->setQuery($this->_query);
		$this->_result = $this->_db->query();

		$this->_db->setQuery('SELECT last_insert_id()
		                      FROM #__jgrid_document');
		$new_document_id = $this->_db->loadResult();
		$row_data[0]["new_document_id"]=$new_document_id;

		// Change documents to new_document_id
		$this->_query = 'UPDATE #__jgrid_current_user_grid_document
	    	      SET current_document_id ='.$new_document_id.', 
	    	          previous_document_id1='.JRequest::getvar( 'last_document_id' ).' 
	    	      WHERE userid = '. $user->id .'
	    	      AND grid_id = '.JRequest::getvar( 'grid_id' ).'
	    	      AND session_id = "'.$session_id.'"';
		$this->_db->setQuery($this->_query);
		$this->_result = $this->_db->query();

		if($new_document_id) return $row_data[0];
		else return false;
	}

	/**
	* Creates the   "sheets" / Documents data Chart 
	* @return return new sheet number if row created or false if update failed.
	*/
	function create_chart_document()
	{
		//create sheet
		$db =JFactory::getDBO();
		$user =JFactory::getUser();
		//check to see if current document exists, if not update to the default document, always reset guest to default
		$session 			=JFactory::getSession();
		$session_id 		= $session->getId();
		$grid_id            =JRequest::getVar('grid_id','','','INTEGER');
		$current_document_id=JRequest::getVar('last_document_id','','','INTEGER');
		$sub_task  			=JRequest::getVar('sub_task');		
		$selected_sheetId   =JRequest::getVar('selected_sheetId');
		//$label_dgree_rotate = JRequest::getVar('label_dgree_rotate');
		//$cat_ldgree
		
		$numeric_axes_config  = JRequest::getVar('numeric_axes_config');
		$category_axes_config = JRequest::getVar('category_axes_config');
		$series_data_config   = JRequest::getVar('series_data_config');
		//Adding Legend config
		$legendJsonStr        = JRequest::getVar('legendJsonStr');	
		
		
		$numeric_axes_config_object=json_decode($numeric_axes_config);
		$category_axes_config_object=json_decode($category_axes_config);
		$series_data_config_object=json_decode($series_data_config);
		//Legend Config
		$legendJsonStr_object     = json_decode($legendJsonStr);
		
		//check user rights to manage grid documents
		list($admin_user,$access_control,$remove_access_control) = check_grid_sheet_access_control($grid_id,$current_document_id,4);
		if($access_control==0 || $remove_access_control > 0) return false;
		//Putting Condition for edit/new option
		if($sub_task=="New" || $sub_task==""){		
			
			$this->_query='INSERT  INTO #__jgrid_document(document_title,
															parent_document,
															creator_userid,
															grid_id,document_type)
														VALUES ("'.JRequest::getvar( 'new_document_name' ).'",
														'.(JRequest::getvar( 'parent_document_id' )? JRequest::getvar( 'parent_document_id' ) : -1).',
														'.$user->id.',
														'.JRequest::getvar( 'grid_id' ).',1)';	
			$this->_db->setQuery($this->_query);
			$this->_result = $this->_db->query();
			$this->_db->setQuery('SELECT last_insert_id() FROM #__jgrid_document');
			$new_document_id = $this->_db->loadResult();
			$row_data[0]["new_document_id"]=$new_document_id;
		}
		else if($sub_task=="Edit"){
			$this->_query = 'UPDATE #__jgrid_document
			    	      SET document_title ="'.JRequest::getvar( 'new_document_name' ).'",
							  document_type =1 	
			    	      WHERE grid_id = '.JRequest::getvar( 'grid_id' ).'
			    	      AND 	id = "'.$selected_sheetId.'"';
			$this->_db->setQuery($this->_query);
			$this->_result = $this->_db->query();
			$new_document_id=$selected_sheetId;
			$row_data[0]["new_document_id"]=$selected_sheetId;			
	   }		
		//Saving Graph Data 
	if($sub_task=="New" || $sub_task==""){	
		// Inserting New Records For Create new sheet 
		$this->_query='INSERT  INTO #__jgrid_document_graph(document_id,
				                                            grid_id,
				                                            num_axis_title,
				                                            num_axes_position,
				                                            num_field_val,
				                                            chart_grid_option,
				                                            cat_axes_position,
				                                            cat_title,
				                                            cat_field_val,
				                                            chat_type,
				                                            serise_axis_id,
				                                            stacked_chart_opt,
				                                            chart_highlight_opt,
				                                            chart_category
				                                            )				                                            
						                      VALUES ("'.$new_document_id.'",
						                              "'. JRequest::getvar( 'grid_id' ).'",
						                              "'.JRequest::getvar( 'num_axis_title' ).'",
						                              "'.JRequest::getvar( 'num_axes_position' ).'",
						                              "'.JRequest::getvar( 'num_field_val' ).'",
						                              "'.JRequest::getvar( 'chart_grid_option' ).'",
						                              "'.JRequest::getvar( 'cat_axes_position').'",
						                              "'.JRequest::getvar( 'cat_title' ).'",
						                              "'.JRequest::getvar( 'cat_field_val' ).'",
						                              "'.JRequest::getvar( 'chat_type').'",
						                              "'.JRequest::getvar( 'serise_axis_id' ).'",
						                              "'.JRequest::getvar( 'stacked_chart_opt' ).'",
						                              "'.JRequest::getvar( 'chart_highlight_opt' ).'",
													  "'.JRequest::getvar( 'chart_category' ).'")';	
		$this->_db->setQuery($this->_query);
		$this->_result = $this->_db->query();		
		$this->_db->setQuery('SELECT last_insert_id() FROM #__jgrid_document_graph');
		$new_document_graph_id = $this->_db->loadResult();
		$row_data[0]["new_document_graph_id"]=$new_document_graph_id;
	}
	else if($sub_task=="Edit"){
			
			
			
			//First Check if recods exist in document_graph table if exist then update else insert new row
		$this->_db->setQuery('SELECT id FROM #__jgrid_document_graph WHERE grid_id = "'.JRequest::getvar( 'grid_id' ).'"
						   AND 	document_id = "'.$selected_sheetId.'"');
		$new_document_graph_id = $this->_db->loadResult();
		if($new_document_graph_id!=""){
			$row_data[0]["new_document_graph_id"]=$new_document_graph_id;
			$this->_query ='UPDATE #__jgrid_document_graph
			    	           SET chart_category ="'.JRequest::getvar( 'chart_category' ).'"
			    	        WHERE grid_id = '.JRequest::getvar( 'grid_id' ).'
			    	           AND 	document_id = "'.$selected_sheetId.'"';
			$this->_db->setQuery($this->_query);
			$this->_result = $this->_db->query();						
		}else{
			$this->_query='INSERT  INTO #__jgrid_document_graph(document_id,
				                                            grid_id,
				                                            num_axis_title,
				                                            num_axes_position,
				                                            num_field_val,
				                                            chart_grid_option,
				                                            cat_axes_position,
				                                            cat_title,
				                                            cat_field_val,
				                                            chat_type,
				                                            serise_axis_id,
				                                            stacked_chart_opt,
				                                            chart_highlight_opt,
				                                            chart_category
				                                            )				                                            
						                      VALUES ("'.$new_document_id.'",
						                              "'. JRequest::getvar( 'grid_id' ).'",
						                              "'.JRequest::getvar( 'num_axis_title' ).'",
						                              "'.JRequest::getvar( 'num_axes_position' ).'",
						                              "'.JRequest::getvar( 'num_field_val' ).'",
						                              "'.JRequest::getvar( 'chart_grid_option' ).'",
						                              "'.JRequest::getvar( 'cat_axes_position').'",
						                              "'.JRequest::getvar( 'cat_title' ).'",
						                              "'.JRequest::getvar( 'cat_field_val' ).'",
						                              "'.JRequest::getvar( 'chat_type').'",
						                              "'.JRequest::getvar( 'serise_axis_id' ).'",
						                              "'.JRequest::getvar( 'stacked_chart_opt' ).'",
						                              "'.JRequest::getvar( 'chart_highlight_opt' ).'",
													  "'.JRequest::getvar( 'chart_category' ).'")';	
		$this->_db->setQuery($this->_query);
		$this->_result = $this->_db->query();		
		$this->_db->setQuery('SELECT last_insert_id() FROM #__jgrid_document_graph');
		$new_document_graph_id = $this->_db->loadResult();
		$row_data[0]["new_document_graph_id"]=$new_document_graph_id;
			
		}			
			//Delete existing numeric axes config
		$this->_query ='DELETE From #__jgrid_chart_numeric_axes
			    	          WHERE chart_id = "'.$new_document_graph_id.'"';
			$this->_db->setQuery($this->_query);
			$this->_result = $this->_db->query();
			
			//Delete existing numeric axes config
			$this->_query ='DELETE From #__jgrid_chart_category_axes
			    	          WHERE chart_id = "'.$new_document_graph_id.'"';
			$this->_db->setQuery($this->_query);
			$this->_result = $this->_db->query();
			
			//Delete existing numeric axes config
			$this->_query ='DELETE From #__jgrid_chart_series
			    	          WHERE chart_id = "'.$new_document_graph_id.'"';
			$this->_db->setQuery($this->_query);
			$this->_result = $this->_db->query();
			
			
			//Delete existing Legend config option
			$this->_query ='DELETE From #__jgrid_chart_legend
			    	          WHERE chart_id = "'.$new_document_graph_id.'"';
			$this->_db->setQuery($this->_query);
			$this->_result = $this->_db->query();
			
	}
				
	if(JRequest::getvar('chart_category')=="cartesian")	{
		//Insert Query for inserting Numeric Access
		$gridbackgroundId=JRequest::getvar('gridbackgroundId');
		$this->_query='INSERT  INTO #__jgrid_chart_numeric_axes(chart_id,
																title,
																grid,
																position,
																fields,
																minimum	,
																minorTickSteps,
																majorTickSteps,
																width)
		 												VALUES ("'.$new_document_graph_id.'",
																"'.$numeric_axes_config_object->naxes_title.'",
																"'.$gridbackgroundId.'",
																"'.$numeric_axes_config_object->naxes_position.'",
																"'.$numeric_axes_config_object->nFieldId.'",																
																0,
																0,
																20,
																0)';
																
		
		//echo "sql1".$this->_query;
		$this->_db->setQuery($this->_query);
		$this->_result = $this->_db->query();
		//Insert Query for inserting Category Access
		$label_dgree_rotate=JRequest::getvar('cat_ldgree');
		$this->_query='INSERT  INTO #__jgrid_chart_category_axes(chart_id,
																title,
																position,
																cfields,
																minorTickSteps,
																majorTickSteps,
																length,
																label_dgree_rotate)
				 											VALUES ("'.$new_document_graph_id.'",
																	"'.$category_axes_config_object->ctitle.'",
																	"'.$category_axes_config_object->caxes_position.'",
																	"'.$category_axes_config_object->catField.'",																
																	0,
																	10,
																	0,
																	"'.$category_axes_config_object->cat_ldgree.'")';
		
		$this->_db->setQuery($this->_query);
		$this->_result = $this->_db->query();
	}	
	//Inserting Legend Data
	$this->_query='INSERT  INTO #__jgrid_chart_legend(chart_id,
														position,
														x,
														y,
														padding,
														itemSpacing,
														boxFill,
														labelFont)
													VALUES ("'.$new_document_graph_id.'",
															"'.$legendJsonStr_object->position.'",
															"'.$legendJsonStr_object->x.'",
															"'.$legendJsonStr_object->y.'",
															"'.$legendJsonStr_object->padding.'",
															10,																
															"'.$legendJsonStr_object->boxFill.'",	
															"'.$legendJsonStr_object->labelFont.'")';
			$this->_db->setQuery($this->_query);
			$this->_result = $this->_db->query();	
	
	//End of Legend Data
	//Insert Query for the Series configuration  
	for($i=0;$i<count($series_data_config_object);$i++){
			
			$this->_query='INSERT  INTO #__jgrid_chart_series(chart_id,
																	series_type,
																	highlight,
																	showInLegend,
																	xField,
																	yField,
																	axis,
																	showMarkers,
																	stacked
																	)
							 									VALUES ("'.$new_document_graph_id.'",
																		"'.$series_data_config_object[$i]->series_type.'",
																		"'.$series_data_config_object[$i]->highlight.'",
																		true,
																		"'.$series_data_config_object[$i]->series_xaxis.'",
																		"'.$series_data_config_object[$i]->series_yaxis.'",																
																		"'.$series_data_config_object[$i]->series_axis.'",	
																		true,"'.$series_data_config_object[$i]->stacked_opt.'")';
			$this->_db->setQuery($this->_query);
			$this->_result = $this->_db->query();
			
		}
		
		// Change documents to new_document_id
		$last_document_id=JRequest::getvar( 'last_document_id' );
		if($last_document_id==""){
			$this->_query = 'UPDATE #__jgrid_current_user_grid_document
				  SET current_document_id ="'.$new_document_id.'"					   
				  WHERE userid = '. $user->id .'
				  AND grid_id = '.JRequest::getvar( 'grid_id' ).'
				  AND session_id = "'.$session_id.'"';
		$this->_db->setQuery($this->_query);
		$this->_result = $this->_db->query();
		
		}
		else if($last_document_id!=""){
				$this->_query = 'UPDATE #__jgrid_current_user_grid_document
			    	      SET current_document_id ='.$new_document_id.', 
			    	          previous_document_id1='.JRequest::getvar( 'last_document_id' ).' 
			    	      WHERE userid = '. $user->id .'
			    	      AND grid_id = '.JRequest::getvar( 'grid_id' ).'
			    	      AND session_id = "'.$session_id.'"';
		
		}
		
		//$row_data[0]["new_document_graph_id"]
		if($new_document_id) 
			return $row_data[0];
		else
		 return false;
		
	}
	
	/*
	 * Read chart Setting
	 * CHART Config changes
	 */
	function read_chart_setting()
	{
		
		//Fetching Document detail
		$this->_query = 'SELECT	id,document_type,document_title FROM #__jgrid_document  
		                          WHERE grid_id = "'.JRequest::getvar( 'grid_id' ).'" AND id="'.JRequest::getvar( 'new_document_id' ).'"';
		$this->_result_count = $this->_getListCount( $this->_query );
		// rms return no data found
		if(!$this->_result_count)
		{
			return false;
		}
		$this->_result = $this->_getList( $this->_query );	
	   if($this->_result[0]->document_type=="" || $this->_result[0]->document_type==null){
			$this->_result[0]->chart_category="non_chart_sheet";
			$resultArr[]=$this->_result;		
			return $resultArr;
	    
	    }	    		
		$this->_query = 'SELECT c.chart_category, c.id,d.document_title FROM #__jgrid_document_graph as c, #__jgrid_document as d 
		                          WHERE c.grid_id = "'.JRequest::getvar( 'grid_id' ).'" AND c.document_id="'.JRequest::getvar( 'new_document_id' ).'"   AND c.document_id=d.id';
		//echo "sql".$this->_query;
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		$resultArr[]=$this->_result;		
		$document_count=$this->_result_count;
		if($document_count>0){
			$chart_category = $this->_result[0]->chart_category;
			$chart_id	    = $this->_result[0]->id;
			//Reading Chart Legend setting
			$this->_query = 'SELECT *
										FROM #__jgrid_chart_legend
		                         		WHERE chart_id = "'.$chart_id.'"';
			$this->_result_count = $this->_getListCount( $this->_query );
			$this->_result = $this->_getList( $this->_query );
			$chart_legend;
			if($this->_result){
				$chart_legend['position']=$this->_result[0]->position;
				$chart_legend['x']=$this->_result[0]->x;
				$chart_legend['y']=$this->_result[0]->y;
				$chart_legend['padding']=$this->_result[0]->padding;
				$chart_legend['itemSpacing']=$this->_result[0]->itemSpacing;
				$chart_legend['boxFill']=$this->_result[0]->boxFill;
				$chart_legend['labelFont']=$this->_result[0]->labelFont;
				
			}			
			//End of Legend setting
			switch($chart_category)
			{
				                                                                                                                                                                       
				case "cartesian":
					//Reading Numeric axes data
					$this->_query = 'SELECT *
										FROM #__jgrid_chart_numeric_axes
		                         		WHERE chart_id = "'.$chart_id.'"';
					$this->_result_count = $this->_getListCount( $this->_query );
					$this->_result = $this->_getList( $this->_query );
					if($this->_result){
						//for($i=0;$i<$this->_result_count;)
						$arrFields=$this->json_yFields($this->_result[0]->fields);
						
						/*if($this->_result[0]->fields!=""){
							$arrYaxisFields=explode(",",$this->_result[0]->fields);
							for($k=0;$k<count($arrYaxisFields);$k++){
								$arrFields[$k]['field_value']=$arrYaxisFields[$k];$gridbackgroundId
							}
						}*/
						
						$numeric_axesConfig['position']=$this->_result[0]->position;
						$numeric_axesConfig['title']=$this->_result[0]->title;
						$numeric_axesConftitleig['title']=$this->_result[0]->title;
						$numeric_axesConfig['fields']=$arrFields;
						$numeric_axesConfig['minorTickSteps']=5;
						$numeric_axesConfig['gridbackgroundId']=$this->_result[0]->grid;
						$numeric_axesConfig['majorTickSteps']=5;
						$numeric_axesConfig['minimum']=0;						
						//$numeric_axesConfig='[{"position":"'.$this->_result[0]->position.'","title":"'.$this->_result[0]->title.'","fields":"'.json_encode($arrFields).'","minimum":0,"minorTickSteps":0,"majorTickSteps":20}]';
						$array1[]=$numeric_axesConfig;
						$resultArr[]=$array1;
						//Reading Category Axes
						unset($this->_result);
				 		$this->_query1 = 'SELECT *
													FROM #__jgrid_chart_category_axes
								                    WHERE chart_id = "'.$chart_id.'"';
						$this->_result = $this->_getList( $this->_query1 );
						
						if($this->_result){
							//$category_axes='[{"position":"'.$this->_result[0]->position.'","title":"'.$this->_result[0]->title.'","cfields":"'.$this->_result[0]->cfields.'","minorTickSteps":0,"majorTickSteps":20}]';
							$category_axes['position']=$this->_result[0]->position;
							$category_axes['title']=$this->_result[0]->title;
							$category_axes['cfields']=$this->_result[0]->cfields;
							$category_axes['minorTickSteps']=0;
							$category_axes['majorTickSteps']=10;
							$category_axes['label_dgree_rotate']=$this->_result[0]->label_dgree_rotate;
							$array2[]=$category_axes;							
							$resultArr[]=$array2;
						}
						// Fetching Chart Series
						//jos_jgrid_chart_series
						$this->_query = 'SELECT *
										   FROM #__jgrid_chart_series
										   WHERE chart_id = "'.$chart_id.'"';
						$this->_result_count = $this->_getListCount( $this->_query );
						$this->_result = $this->_getList( $this->_query);
						for($i=0;$i<$this->_result_count;$i++){							
							$chart_series['series_id']=$this->_result[$i]->series_id;
							$chart_series['type']=$this->_result[$i]->series_type;
							$chart_series['axis']=$this->_result[$i]->axis;
							$chart_series['highlight']=$this->_result[$i]->highlight;
							$chart_series['xField']=$this->_result[$i]->xField;
							//Managing Y axis fields
							$arrFields1=$this->json_yFields($this->_result[$i]->yField);
							$chart_series['yField']=$arrFields1;
							$chart_series['stacked']=$this->_result[$i]->stacked;
							$array3[]=$chart_series;
						}
						$resultArr[]=$array3;
						$array4[]=$chart_legend;
						$resultArr[]=$array4;
						return $resultArr;
						
					}
					
					
					break;
				case "pie":
					//jos_jgrid_chart_series
					$this->_query = 'SELECT *
											FROM #__jgrid_chart_series
											WHERE chart_id = "'.$chart_id.'"';
					$this->_result_count = $this->_getListCount( $this->_query );
					$this->_result = $this->_getList( $this->_query);
					for($i=0;$i<$this->_result_count;$i++){
						$chart_series['series_id']=$this->_result[$i]->series_id;	
						$chart_series['type']=$this->_result[$i]->series_type;
						$chart_series['axis']=$this->_result[$i]->axis;
						$chart_series['highlight']=$this->_result[$i]->highlight;
						$chart_series['xField']=$this->_result[$i]->xField;
						//Managing Y axis fields
						$arrFields1=$this->json_yFields($this->_result[$i]->yField);
						$chart_series['yField']=$arrFields1;
						$chart_series['stacked']=$this->_result[$i]->stacked;
						$array3[]=$chart_series;
					}
					$resultArr[]=$array3;
					$array4[]=$chart_legend;
					$resultArr[]=$array4;
					return $resultArr;					
					break;
				case "radar":
						//jos_jgrid_chart_series
						$this->_query = 'SELECT *
										FROM #__jgrid_chart_series WHERE chart_id = "'.$chart_id.'"';
						$this->_result_count = $this->_getListCount( $this->_query );
						$this->_result = $this->_getList( $this->_query);
						for($i=0;$i<$this->_result_count;$i++){
							$chart_series['series_id']=$this->_result[$i]->series_id;	
							$chart_series['type']=$this->_result[$i]->series_type;
							$chart_series['axis']=$this->_result[$i]->axis;
							$chart_series['highlight']=$this->_result[$i]->highlight;
							$chart_series['xField']=$this->_result[$i]->xField;
							//Managing Y axis fields
							$arrFields1=$this->json_yFields($this->_result[$i]->yField);
							$chart_series['yField']=$arrFields1;
							$chart_series['stacked']=$this->_result[$i]->stacked;
							$array3[]=$chart_series;
						}
						$resultArr[]=$array3;
						$array4[]=$chart_legend;
						$resultArr[]=$array4;
						return $resultArr;
						break;
			}
			return $this->_result;	
		}
		else return false;
		
	}


	/*Converts commoma saprated yAxisFields into JSON required for settings
	 * 
	 */
	function json_yFields($str_yFields)
	{
		if($str_yFields!=""){
			$arrYaxisFields=explode(",",$str_yFields);
			for($k=0;$k<count($arrYaxisFields);$k++){
				$arrFields[$k]['field_value']=$arrYaxisFields[$k];
			}
		}
		return $arrFields;
	}

	/**
	 * Copies the "sheets" / Documents data
	 * @return return new sheet number if sheet created and data copied or false if update failed.
	 */
	function copySheet()
	{
		//copy sheet
		$db =JFactory::getDBO();
		$user =JFactory::getUser();
		//check to see if current document exists, if not update to the default document, always reset guest to default
		$session =JFactory::getSession();
		$session_id = $session->getId();

		$grid_id=JRequest::getVar('grid_id','','','INTEGER');
		$current_document_id=JRequest::getVar('last_document_id','','','INTEGER');

		//check user rights to manage grid documents
		list($admin_user,$access_control,$remove_access_control) = check_grid_sheet_access_control($grid_id,$current_document_id,4);
		if($access_control==0 || $remove_access_control > 0)	 return false;



		$this->_db->setQuery('INSERT  INTO #__jgrid_document (document_title,
                                                          creator_userid,
                                                          grid_id)
		                      VALUES ("'.JRequest::getvar( 'new_document_name' ).'",
		                              '.$user->id.',
		                              '. JRequest::getvar( 'grid_id' ).')');		              
		$this->_result = $this->_db->query();
		//find new row id and return
		$this->_db->setQuery('SELECT last_insert_id()
		                      FROM #__jgrid_document');
		$new_document_id = $this->_db->loadResult();
		$row_data[0]["new_document_id"]=$new_document_id;

		//copy rows
		//select list of ordering from old document
		$this->_query='SELECT id, ordering
                       FROM #__jgrid_rows a 
                       WHERE a.document_id = '.JRequest::getvar( 'last_document_id' ).'
                       ORDER BY ordering'; 
		$result_count = $this->_getListCount( $this->_query );
		// if no rows insert one
		$temp_id=0;
		if($result_count!=0)
		{
			$ids_to_copy = $this->_getList( $this->_query );		
			for($i=0;$i<$result_count;$i++)
			{
				$this->_query = 'INSERT INTO #__jgrid_rows (document_id,
	                                                    ordering,
	                                                    parent_id,
                                                        grid_id)
		              SELECT  "'.$new_document_id.'",
	                           ordering,
	                           "'.$temp_id.'",
                               grid_id
		              FROM #__jgrid_rows		                   
	    	          WHERE id  = '.$ids_to_copy[$i]->id;
				$this->_db->setQuery($this->_query);					
				$this->_result = $this->_db->query();
				//find new rowid
				$this->_db->setQuery('SELECT last_insert_id()
		                         FROM #__jgrid_rows');
				$temp_id = $this->_db->loadResult();
				// copy cells to from old row to new row
				$this->_query =   'INSERT INTO #__jgrid_columndata (document_id,
		                                                    column_id,
		                                                    columngrid_id,
		                                                    column_header,
		                                                    userid,
		                                                    row_number,
		                                                    string_data,
		                                                    int_data,
		                                                    float_data,
		                                                    boolean_data,
		                                                    date_data)	
		                   SELECT "'.$new_document_id.'",
		                          a.column_id,
		                          a.columngrid_id,
		                          a.column_header,
		                          "'.$user->id.'",
		                          "'.$temp_id.'",
		                          a.string_data,
		                          a.int_data,
		                          a.float_data,
		                          a.boolean_data,
		                          a.date_data
		                  FROM #__jgrid_columndata a		                   
	    	              WHERE a.row_number = '.$ids_to_copy[$i]->id;
//echo 'sql'.$this->_query;
//return;									
				$this->_db->setQuery($this->_query);
				$this->_result = $this->_db->query();
				// copy and rename images
				$this->_query = 'SELECT column_id
                          FROM #__jgrid_images
                          WHERE grid_id = '.$grid_id.'
                            AND document_id = '.$current_document_id.'
                            AND row_id = '.$ids_to_copy[$i]->id;

				$result_count2 = $this->_getListCount( $this->_query );
				if($result_count2!=0)
				{
					$image_ids_to_copy = $this->_getList( $this->_query );
					for($j=0;$j<$result_count2;$j++)
					{
						copy_images('S',$grid_id, $current_document_id, $new_document_id, $image_ids_to_copy[$j]->column_id, $ids_to_copy[$i]->id, $temp_id);
					}

				}
			}
		}
		// Change documents to new_document_id
		$this->_query = 'UPDATE #__jgrid_current_user_grid_document
	    	      SET current_document_id ='.$new_document_id.', 
	    	          previous_document_id1='.JRequest::getvar( 'last_document_id' ).' 
	    	      WHERE userid = '. $user->id .'
	    	      AND grid_id = '.JRequest::getvar( 'grid_id' ).'
	    	      AND session_id = "'.$session_id.'"';
		$this->_db->setQuery($this->_query);
		$this->_result = $this->_db->query();
		if($new_document_id) return $row_data[0];
		else return false;
	}

	/**
	 * Renames the current  "sheet" / Documents data
	 * @return  renamed sheet number if row created or false if update failed.
	 */
	function renameSheet()
	{
		//create sheet
		$db =JFactory::getDBO();
		$user =JFactory::getUser();

		$grid_id=JRequest::getVar('grid_id','','','INTEGER');
		$current_document_id=JRequest::getVar('last_document_id','','','INTEGER');

		//check user rights to manage grid documents
		list($admin_user,$access_control,$remove_access_control) = check_grid_sheet_access_control($grid_id,$current_document_id,4);

		if($access_control==0 || $remove_access_control > 0)	 return false;


		$this->_db->setQuery('UPDATE  #__jgrid_document
			                  SET  document_title = "'.JRequest::getvar( 'new_document_name' ).'"
			                  WHERE id = '.JRequest::getvar( 'last_document_id' ));  
		if($this->_db->query()) return true;
		else return false;
	}

	/**
	 * Removes Current Sheet from the grid
	 * @var integer $row_id the database row id of the row to be deleted.
	 * @return integer result true if sheet deleted or false if delete failed
	 */
	function remove_document()
	{
		$db =JFactory::getDBO();
		$user=JFactory::getUser();
		//check to see if current document exists, if not update to the default document, always reset guest to default
		$session =JFactory::getSession();
		$session_id = $session->getId();
		$grid_id=JRequest::getVar('grid_id','','','INTEGER');
		$current_document_id=JRequest::getVar('last_document_id','','','INTEGER');

		// find document id to delete
		$this->_query = 'SELECT current_document_id
			                      FROM #__jgrid_current_user_grid_document 
			                      WHERE userid = ' . $user->id .'
	                              AND grid_id = '.$grid_id.'
	                              AND session_id = "'.$session_id.'"';
		$db->setQuery($this->_query);
		$document_delete_id = $db->loadResult();

		//check user rights to manage grid documents
		list($admin_user,$access_control,$remove_access_control) = check_grid_sheet_access_control($grid_id,$current_document_id,4);

		if($access_control==0 || $remove_access_control > 0)	 return false;




		$new_document_id=JRequest::getVar('new_document_id');
		// If new document does exists on current edit-grid stack check to see if new documents exists in document database
		if($new_document_id == 0)
		{
			// get count
			$this->_query = 'SELECT id
			          FROM #__jgrid_document
			          WHERE grid_id ='. $grid_id.';';
			// If only one document then return without deleting last document
			$this->_count = $this->_getListCount( $this->_query );
			if($this->_count <= 1) return(false);


			// if count > 1 then get the document id then delete the current document and set the new_document to the newest document id
		}



		// delete sheet images
		delete_images('S',
		$grid_id,
		$document_delete_id,
                      '',
                      '');

		// delete references in jgrid_images
		$this->_db->setQuery('DELETE FROM  #__jgrid_images
			                  WHERE document_id = '.$document_delete_id);
		$this->_db->query();

		// check to see if it is default document and if it is assign default to another sheet.





		// delete the current document values
		$this->_query =   'delete from #__jgrid_columndata
	    	         where document_id = '. $document_delete_id;					
		$this->_db->setQuery($this->_query);
		$this->_result = $this->_db->query();

		//delete rows
		$db->setQuery('DELETE FROM  #__jgrid_rows
			                  WHERE document_id = '.$document_delete_id);
		$db->query();

		// delete current document header
		$this->_query = 'DELETE FROM  #__jgrid_document
			    	    WHERE id = '. $document_delete_id ;
		$this->_db->setQuery($this->_query);
		$this->_result = $this->_db->query();
		if(!$this->_result) return false;
		
		//CHART Config Changes
		//Get The document graph Id first
		// find document id to delete
		$this->_query = 'SELECT id
			                    FROM #__jgrid_document_graph 
			                      WHERE document_id = "'.$document_delete_id.'"';
		
		$db->setQuery($this->_query);
		$chart_delete_id = $db->loadResult();
		//If $chart_delete_id>0 then we need to delete chart config data
		if($chart_delete_id!=""){
			// delete Chart category axes config option
			$this->_query = 'DELETE FROM  #__jgrid_chart_category_axes
			    	    WHERE 	chart_id = '. $chart_delete_id;
			$this->_db->setQuery($this->_query);	
			
			// delete Chart Numeric axes config option
			$this->_query = 'DELETE FROM  #__jgrid_chart_numeric_axes
			    	    WHERE 	chart_id = '. $chart_delete_id;
			$this->_db->setQuery($this->_query);	
		
			// delete Chart Numeric axes config option
			$this->_query = 'DELETE FROM  #__jgrid_chart_numeric_axes_fields
			    	    WHERE 	chart_id = '. $chart_delete_id;
			$this->_db->setQuery($this->_query);			
			
			// delete Chart series config opton
			$this->_query = 'DELETE FROM  #__jgrid_chart_series
			    	    WHERE 	chart_id = '. $chart_delete_id;
			$this->_db->setQuery($this->_query);
			
			// delete Chart Legend  config opton
			$this->_query = 'DELETE FROM  #__jgrid_chart_legend
			    	    WHERE 	chart_id = '. $chart_delete_id;
			$this->_db->setQuery($this->_query);
			
			// delete Chart Legend  config opton
			$this->_query = 'DELETE FROM  #__jgrid_chart_legend
			    	    WHERE 	chart_id = '. $chart_delete_id;
			$this->_db->setQuery($this->_query);
						
			// Finally deleting from docuyment graph
			$this->_query = 'DELETE FROM  #__jgrid_document_graph   
			    	    WHERE 	document_id  = '.$document_delete_id;
			$this->_db->setQuery($this->_query);
			
			//END of Deleting CHART setting
		
		}		
		
		//END CHART Config Changes
		// find the newest document id to display if not set from last viewed on current session edit-grid stack
		if($new_document_id == 0)
		{
			$this->_query = 'SELECT id
			          FROM #__jgrid_document
			          WHERE grid_id ='. $grid_id.'
			          ORDER BY last_updated DESC;';
			$this->_data = $this->_getList( $this->_query);
			$new_document_id=$this->_data[0]->id;
		}

		// Change documents to new_document_id
		$this->_query = 'UPDATE #__jgrid_current_user_grid_document
	    	      SET current_document_id ='.$new_document_id.', 
	    	          previous_document_id1='.JRequest::getVar('previous_document_id').' 
	    	      WHERE userid = '. $user->id .'
	    	      AND grid_id = '.$grid_id.'
	    	      AND session_id = "'.$session_id.'"';
		$this->_db->setQuery($this->_query);
		$this->_result = $this->_db->query();
		$row_data[0]["new_document_id"]=$new_document_id;

		// delete any references to document
		$query = 'SELECT a.id,
		                 CONCAT_WS("~",b.image_thumb_path,b.tooltip,b.hyper_url,"") AS string_data
		          FROM #__jgrid_columndata a,
		               #__jgrid_images b
		          WHERE b.hyper_grid_sheet = CONCAT_WS("-",'.$grid_id.','.$document_delete_id.')
		            AND a.document_id = b.document_id
		            AND a.column_id = b.column_id
		            AND a.row_number = b.row_id';		

		$this->_count = $this->_getListCount( $query );
		if($this->_count)
		{
			$this->_result = $this->_getList( $query );
		}
		for($i=0;$i<$this->_count;$i++)
		{
			$query='UPDATE #__jgrid_columndata
		                        SET string_data = "'.$this->_result[$i]->string_data.'"
		                        WHERE id = '.$this->_result[$i]->id;
			$this->_db->setQuery($query);
			$this->_db->query();
		}

		// check to see if the default document is deleted, if it is then set another document to the default document
		$this->_query = 'SELECT id
			          FROM #__jgrid_document
			          WHERE grid_default_document_flag = true
			            AND grid_id ='. $grid_id;
		$this->_count = $this->_getListCount( $this->_query );
		if($this->_count == 0) // set the next document as default
		{

			// find document id to make default
			$this->_query = 'SELECT id
			                 FROM #__jgrid_document
			                 WHERE grid_id = '.$grid_id.'
			                 LIMIT 1';
			
			$db->setQuery($this->_query);
			$top_document_id = $db->loadResult();
            // set next document id to default

			$this->_query = 'UPDATE #__jgrid_document
	    	      SET grid_default_document_flag = true 
	    	      WHERE id = '.$top_document_id;
			$this->_db->setQuery($this->_query);
			$this->_result = $this->_db->query();
		}


		if($new_document_id>=0) return $row_data[0];
		else return false;


	}

	/**
	 * Retrieves the "grid-sheet" title to select jump to

	 * @return array Array of grid-sheet title and grid_id-sheet_id containing the object id and name depending on the access type selection or false if no rules were found
	 */
	function get_combo_Grid_Sheet()
	{
		$this->_query = 'SELECT CONCAT(a.title,"-",b.document_title) AS grid_sheet_title,
				                        CONCAT(a.id,"-",b.id) AS grid_sheet_id
			           	 FROM #__jgrid_grids a,
                              #__jgrid_document b
                         WHERE a.id = b.grid_id
                           AND a.grid_application_name = "'.JRequest::getVar('grid_application_name').'"
                         ORDER BY a.title, b.document_title';		
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result)return array($this->_result_count,$this->_result);
		else return false;

	}

	/**
	 * Retrieves the "application-grid-sheet" title to select jump to

	 * @return array Array of grid-sheet title and grid_id-sheet_id containing the object id and name depending on the access type selection or false if no rules were found
	 */
	function get_combo_Application_Grid_Sheet()
	{
		$this->_query = 'SELECT CONCAT(a.title,"-",b.document_title) AS grid_sheet_title,
				                        CONCAT(a.id,"-",b.id) AS grid_sheet_id
			           	 FROM #__jgrid_grids a,
                              #__jgrid_document b
                         WHERE a.id = b.grid_id
                           AND a.grid_application_name = "'. JRequest::getVar('grid_application_name','','','STRING').'"
                         ORDER BY a.title, b.document_title';
//echo "sql".$this->_query;			
		$this->_result_count = $this->_getListCount( $this->_query );
		$this->_result = $this->_getList( $this->_query );
		if($this->_result)return array($this->_result_count,$this->_result);
		else return false;

	}

}
