<?php
/**
 * Module's entry point
 * 
 * @package    com.express
 * @subpackage Modules
 * @license    ???
 */
class modPDFGenHelper
{
    /**
     * Retrieves the message
     *
     * @param array $params An object containing the module parameters
     * @access public
     */    
    public static function getPDF( $params )
    {
        return 'PDF form helper';
    }
}
?>