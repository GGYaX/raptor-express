<?php
  echo "Price Simulator back-end : nothing to do here for instance...";
?>