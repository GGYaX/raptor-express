<?php
/**
* @package Joomla.Administrator
* @subpackage com_pricecalc
*
* @copyright Copyright (C) 2014 
* @license GNU??? BSD???
*/

defined('_JEXEC') or die;
jimport('joomla.application.component.view');
 
/**
* @since 1.0.0
*/
class PriceCalcController extends JControllerLegacy
{
}
