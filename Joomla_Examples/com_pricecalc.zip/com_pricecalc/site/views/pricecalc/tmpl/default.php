<?php
/**
* @package Joomla.Administrator
* @subpackage com_pricecalc
*
* @copyright Copyright (C) 2014 
* @license GNU??? BSD???
*/
defined('_JEXEC') or die;
?>

<h1><?php echo $this->msg; ?></h1> 
